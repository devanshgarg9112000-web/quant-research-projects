from __future__ import annotations

import argparse

from src.main import run_system


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Devansh Trading System.")
    parser.add_argument("--data-feed", choices=["sample", "truedata", "replay"], default="sample")
    parser.add_argument("--symbols", default=None, help="Comma-separated symbols for live data or replay mode.")
    parser.add_argument("--seconds", type=int, default=60, help="TrueData live collection duration.")
    parser.add_argument("--tick-file", default=None, help="Replay CSV path, defaults to data/ticks/latest_truedata_ticks.csv.")
    args = parser.parse_args()
    run_system(data_feed=args.data_feed, symbols=args.symbols, seconds=args.seconds, tick_file=args.tick_file)
