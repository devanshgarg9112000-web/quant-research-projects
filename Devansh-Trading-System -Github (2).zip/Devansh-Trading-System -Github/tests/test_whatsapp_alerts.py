from __future__ import annotations

import csv

from src.alerts.whatsapp_alerts import WhatsAppAlertProvider, format_launch_one_whatsapp_alert


def _accepted_row() -> dict:
    return {
        "symbol": "GOLD-I",
        "status": "ACCEPTED_PAPER_SIGNAL",
        "direction": "SELL",
        "strategy": "MCX Estimated Buyer Trap Short",
        "entry": 150238.0,
        "stop": 150599.83,
        "target": 149514.33,
        "rr": 2.0,
        "qty": 1,
        "score": 8.8,
        "estimated_risk_amount": 361.83,
        "market_mode": "TREND_DOWN",
        "cluster_status": "ESTIMATED_BUYER_TRAP_POSSIBLE",
        "execution_allowed": False,
    }


def test_whatsapp_dry_run_writes_preview_and_csv(tmp_path, capsys):
    provider = WhatsAppAlertProvider(tmp_path)

    count = provider.alert_rows([_accepted_row()], "whatsapp-dry-run")

    assert count == 1
    preview = provider.preview_path.read_text(encoding="utf-8")
    assert "PAPER SIGNAL ALERT - MANUAL EXECUTION ONLY" in preview
    assert "Symbol: GOLD-I" in preview
    assert "execution_allowed=false" in preview
    assert "Algo Trading: DISABLED" in preview
    with provider.log_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["delivery_status"] == "PREVIEW"
    assert rows[0]["execution_allowed"] == "false"
    assert rows[0]["manual_execution_only"] == "true"
    assert "PAPER SIGNAL ALERT" in capsys.readouterr().out


def test_live_whatsapp_refuses_missing_env_and_never_prints_token(tmp_path, capsys):
    called = {"value": False}

    def fail_opener(*args, **kwargs):
        called["value"] = True
        raise AssertionError("Live WhatsApp must not send with missing environment variables.")

    secret = "super-secret-token"
    provider = WhatsAppAlertProvider(
        tmp_path,
        config={"enabled": True},
        environ={
            "ENABLE_WHATSAPP_ALERTS": "true",
            "WHATSAPP_ACCESS_TOKEN": secret,
        },
        opener=fail_opener,
    )

    count = provider.alert_rows([_accepted_row()], "whatsapp-live")

    out = capsys.readouterr().out
    assert count == 0
    assert called["value"] is False
    assert "missing environment variables" in out
    assert secret not in out


def test_live_whatsapp_is_disabled_by_default_config(tmp_path, capsys):
    provider = WhatsAppAlertProvider(
        tmp_path,
        config={"enabled": False},
        environ={
            "ENABLE_WHATSAPP_ALERTS": "true",
            "WHATSAPP_PHONE_NUMBER_ID": "123",
            "WHATSAPP_ACCESS_TOKEN": "secret",
            "WHATSAPP_TO_NUMBER": "919999999999",
        },
        opener=lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("Must not send.")),
    )

    assert provider.alert_rows([_accepted_row()], "whatsapp-live") == 0
    assert "config alerts.whatsapp.enabled is false" in capsys.readouterr().out


def test_risk_rejected_message_recommends_no_manual_execution():
    row = {
        **_accepted_row(),
        "symbol": "SILVER-I",
        "status": "RISK_REJECTED",
        "rejection_reason": "risk amount too small for minimum MCX quantity",
    }

    message = format_launch_one_whatsapp_alert(row)

    assert message.startswith("PAPER SIGNAL REJECTED")
    assert "Manual execution not recommended." in message
    assert "execution_allowed=false" in message
