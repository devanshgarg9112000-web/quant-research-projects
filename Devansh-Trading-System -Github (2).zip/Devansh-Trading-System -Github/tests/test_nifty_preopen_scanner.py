from __future__ import annotations

from datetime import date, timedelta

from src.brokers.kite_broker import KiteBroker
from src.scanners import nifty_preopen_scanner
from src.scanners.nifty_preopen_scanner import (
    KITE_UNAVAILABLE_MESSAGE,
    QUOTE_SOURCE_KITE,
    QUOTE_SOURCE_SAMPLE,
    format_scanner_output,
    kite_quotes_to_option_snapshots,
    list_kite_nifty_options,
    main,
    run_scanner_full,
    run_scanner,
    save_scanner_report,
    select_effective_iv,
)
from src.strategies.opening_option_mispricing import MODEL_WARNING_MESSAGE, detect_model_reference_warning


def _expiry() -> str:
    return (date.today() + timedelta(days=30)).isoformat()


def test_scanner_logic_does_not_call_kite_place_order(monkeypatch):
    def fail_place_order(*args, **kwargs):
        raise AssertionError("Scanner must not call Kite place_order.")

    monkeypatch.setattr(KiteBroker, "place_order", fail_place_order)

    rows = run_scanner("NIFTY", 23500, 23360, _expiry(), 0.18)

    assert rows
    assert all(row["dry_run"] is True for row in rows)


def test_default_scanner_still_uses_sample_quotes():
    rows = run_scanner("NIFTY", 23500, 23360, _expiry(), 0.18)
    text = format_scanner_output(rows, "NIFTY", 23500, 23360, _expiry(), 0.18)

    assert rows
    assert "Quote Source: SAMPLE MOCK" in text
    assert "Default IV Input:" in text
    assert "Effective IV Used:" in text


def test_effective_iv_uses_average_when_ce_and_pe_market_iv_exist():
    result = select_effective_iv(ce_iv=0.10, pe_iv=0.20, default_iv=0.18, prefer_market_iv=True)

    assert result == {"effective_iv": 0.15, "source": "MARKET IMPLIED"}


def test_effective_iv_uses_one_side_when_only_one_market_iv_exists():
    result = select_effective_iv(ce_iv=None, pe_iv=0.22, default_iv=0.18, prefer_market_iv=True)

    assert result == {"effective_iv": 0.22, "source": "MARKET IMPLIED"}


def test_effective_iv_falls_back_to_default_when_market_iv_missing():
    result = select_effective_iv(ce_iv=None, pe_iv=None, default_iv=0.18, prefer_market_iv=True)

    assert result == {"effective_iv": 0.18, "source": "DEFAULT FALLBACK"}


def test_scanner_cli_output_includes_dry_run_text(monkeypatch, capsys):
    monkeypatch.setattr(
        "sys.argv",
        [
            "nifty_preopen_scanner",
            "--underlying",
            "NIFTY",
            "--spot",
            "23500",
            "--previous-close",
            "23360",
            "--expiry",
            _expiry(),
            "--default-iv",
            "0.18",
        ],
    )

    result = main()

    out = capsys.readouterr().out
    assert result == 0
    assert "NIFTY PRE-OPEN OPTION MISPRICING SCANNER" in out
    assert "DRY RUN ONLY. No orders were placed." in out
    assert "Broker Orders: DISABLED" in out
    assert "Quote Source: SAMPLE MOCK" in out
    assert "Model Status:" in out
    assert "SCANNER ONLY - NOT EXECUTION READY" in out


def test_scanner_output_table_contains_required_columns():
    rows = run_scanner("NIFTY", 23500, 23360, _expiry(), 0.18)

    text = format_scanner_output(rows, "NIFTY", 23500, 23360, _expiry(), 0.18)

    assert "OPENING SPIKE LIMIT ORDER PLANNER" in text
    assert "Visible Match Side | Visible Match Price | Suggested Limit Price" in text
    assert "Expected Gross Edge | Expected Gross Edge %" in text
    assert "Execution Allowed | Hedge Required" in text
    assert "SCANNER ONLY - NOT EXECUTION READY" in text
    assert "Active Filters:" in text
    assert "number of opportunities found:" in text


def test_use_kite_quotes_path_uses_mocked_read_only_kite(monkeypatch):
    expiry = _expiry()

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            assert exchange == "NFO"
            return [
                {"exchange": "NFO", "tradingsymbol": "NIFTYFAKE23500CE", "expiry": expiry, "strike": 23500, "instrument_type": "CE"},
                {"exchange": "NFO", "tradingsymbol": "NIFTYFAKE23500PE", "expiry": expiry, "strike": 23500, "instrument_type": "PE"},
                {"exchange": "NFO", "tradingsymbol": "NIFTYFAKE24000CE", "expiry": expiry, "strike": 24000, "instrument_type": "CE"},
            ]

        def get_quote(self, symbols):
            assert "NFO:NIFTYFAKE23500CE" in symbols
            return {
                "NFO:NIFTYFAKE23500CE": {
                    "last_price": 600,
                    "oi": 10000,
                    "depth": {
                        "buy": [{"price": 650, "quantity": 100}],
                        "sell": [{"price": 690, "quantity": 100}],
                    },
                },
                "NFO:NIFTYFAKE23500PE": {
                    "last_price": 300,
                    "oi": 8000,
                    "depth": {
                        "buy": [{"price": 300, "quantity": 100}],
                        "sell": [{"price": 340, "quantity": 100}],
                    },
                },
            }

    def fail_place_order(*args, **kwargs):
        raise AssertionError("Scanner must not call Kite place_order.")

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)
    monkeypatch.setattr(KiteBroker, "place_order", fail_place_order)

    rows = run_scanner("NIFTY", 23500, 23360, expiry, 0.18, use_kite_quotes=True, strikes_around_atm=1, exchange="NFO")

    assert rows
    assert all(row["dry_run"] is True for row in rows)
    assert {row["suggested_action"] for row in rows} <= {"BUY", "SELL"}


def test_use_kite_quotes_passes_effective_iv_to_scan(monkeypatch):
    expiry = _expiry()
    captured = {}

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return [
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500CE", "expiry": expiry, "strike": 23500, "instrument_type": "CE"},
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500PE", "expiry": expiry, "strike": 23500, "instrument_type": "PE"},
            ]

        def get_quote(self, symbols):
            return {
                "NFO:NIFTYFAKE23500CE": {
                    "depth": {
                        "buy": [{"price": 600, "quantity": 100}],
                        "sell": [{"price": 620, "quantity": 100}],
                    }
                },
                "NFO:NIFTYFAKE23500PE": {
                    "depth": {
                        "buy": [{"price": 380, "quantity": 100}],
                        "sell": [{"price": 400, "quantity": 100}],
                    }
                },
            }

    def fake_atm_ivs(*args, **kwargs):
        return {"ce_iv": 0.10, "pe_iv": 0.20, "iv_source": "MARKET IMPLIED"}

    def fake_scan_opening_option_mispricing(*args, **kwargs):
        captured["default_iv"] = kwargs["default_iv"]
        return []

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)
    monkeypatch.setattr(nifty_preopen_scanner, "calculate_atm_implied_ivs", fake_atm_ivs)
    monkeypatch.setattr(nifty_preopen_scanner, "scan_opening_option_mispricing", fake_scan_opening_option_mispricing)

    result = run_scanner_full(
        "NIFTY",
        23500,
        23360,
        expiry,
        0.18,
        use_kite_quotes=True,
        strikes_around_atm=0,
        suppress_signals_on_model_warning=False,
    )

    assert captured["default_iv"] == 0.15
    assert result["effective_iv_used"] == 0.15
    assert result["default_iv_input"] == 0.18
    assert result["iv_source"] == "MARKET IMPLIED"


def test_quote_conversion_extracts_best_bid_ask_and_quantities():
    snapshots = kite_quotes_to_option_snapshots(
        {
            "NFO:NIFTYFAKE23500CE": {
                "last_price": 500,
                "oi": 12345,
                "depth": {
                    "buy": [{"price": 510.5, "quantity": 75}],
                    "sell": [{"price": 515.5, "quantity": 80}],
                },
            }
        },
        {"NFO:NIFTYFAKE23500CE": {"strike": 23500, "instrument_type": "CE"}},
    )

    assert snapshots == [{
        "symbol": "NFO:NIFTYFAKE23500CE",
        "strike": 23500.0,
        "option_type": "CE",
        "best_bid": 510.5,
        "best_ask": 515.5,
        "bid_qty": 75,
        "ask_qty": 80,
        "depth": {
            "buy": [{"price": 510.5, "quantity": 75}],
            "sell": [{"price": 515.5, "quantity": 80}],
        },
        "last_price": 500,
        "oi": 12345,
    }]


def test_missing_kite_session_is_handled_safely(monkeypatch, capsys):
    class MissingSessionKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return {"status": "credentials_missing", "missing": ["KITE_ACCESS_TOKEN"]}

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", MissingSessionKiteBroker)
    monkeypatch.setattr(
        "sys.argv",
        [
            "nifty_preopen_scanner",
            "--underlying",
            "NIFTY",
            "--spot",
            "23500",
            "--previous-close",
            "23360",
            "--expiry",
            _expiry(),
            "--default-iv",
            "0.18",
            "--use-kite-quotes",
            "--strikes-around-atm",
            "5",
        ],
    )

    result = main()

    out = capsys.readouterr().out
    assert result == 1
    assert KITE_UNAVAILABLE_MESSAGE in out
    assert "DRY RUN ONLY. No orders were placed." in out


def test_kite_quote_source_is_printed_in_output():
    text = format_scanner_output([], "NIFTY", 23500, 23360, _expiry(), 0.18, quote_source=QUOTE_SOURCE_KITE)

    assert "Quote Source: KITE READ-ONLY" in text
    assert "Quote Source: SAMPLE MOCK" not in text


def test_list_mode_output_includes_available_expiries(monkeypatch):
    expiry = _expiry()

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return [
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500CE", "expiry": date.fromisoformat(expiry), "strike": 23500, "instrument_type": "CE", "instrument_token": 111},
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500PE", "expiry": date.fromisoformat(expiry), "strike": 23500, "instrument_type": "PE", "instrument_token": 112},
                {"exchange": "NFO", "name": "BANKNIFTY", "tradingsymbol": "BANKNIFTYFAKE50000CE", "expiry": date.fromisoformat(expiry), "strike": 50000, "instrument_type": "CE", "instrument_token": 113},
            ]

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)

    text = list_kite_nifty_options(spot=23500, exchange="NFO")

    assert "Available Expiries:" in text
    assert f"- {expiry}: 2 instruments" in text
    assert "NIFTYFAKE23500CE" in text
    assert "BANKNIFTY" not in text


def test_cli_list_mode_output_includes_available_expiries(monkeypatch, capsys):
    expiry = _expiry()

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return [
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500CE", "expiry": expiry, "strike": 23500, "instrument_type": "CE", "instrument_token": 111},
            ]

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)
    monkeypatch.setattr("sys.argv", ["nifty_preopen_scanner", "--list-kite-nifty-options", "--spot", "23500"])

    result = main()

    out = capsys.readouterr().out
    assert result == 0
    assert "KITE NIFTY OPTION INSTRUMENTS" in out
    assert "Available Expiries:" in out
    assert expiry in out


def test_use_kite_quotes_handles_expiry_mismatch_safely(monkeypatch, capsys):
    expiry = _expiry()

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return [
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500CE", "expiry": expiry, "strike": 23500, "instrument_type": "CE", "instrument_token": 111},
            ]

        def get_quote(self, symbols):
            raise AssertionError("Quote should not be called when expiry does not match.")

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)
    monkeypatch.setattr(
        "sys.argv",
        [
            "nifty_preopen_scanner",
            "--underlying",
            "NIFTY",
            "--spot",
            "23500",
            "--previous-close",
            "23360",
            "--expiry",
            "2099-01-01",
            "--default-iv",
            "0.18",
            "--use-kite-quotes",
        ],
    )

    result = main()

    out = capsys.readouterr().out
    assert result == 1
    assert "Requested expiry 2099-01-01 was not found" in out
    assert "Available expiries:" in out
    assert "DRY RUN ONLY. No orders were placed." in out


def test_use_kite_quotes_auto_expiry_uses_nearest_available(monkeypatch):
    expiry = _expiry()

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return [
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500CE", "expiry": expiry, "strike": 23500, "instrument_type": "CE", "instrument_token": 111},
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23500PE", "expiry": expiry, "strike": 23500, "instrument_type": "PE", "instrument_token": 112},
            ]

        def get_quote(self, symbols):
            return {
                "NFO:NIFTYFAKE23500CE": {"depth": {"buy": [{"price": 650, "quantity": 100}], "sell": [{"price": 690, "quantity": 100}]}},
                "NFO:NIFTYFAKE23500PE": {"depth": {"buy": [{"price": 300, "quantity": 100}], "sell": [{"price": 340, "quantity": 100}]}},
            }

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)

    rows, resolved_expiry = nifty_preopen_scanner.run_scanner_with_metadata("NIFTY", 23500, 23360, "auto", 0.18, use_kite_quotes=True, strikes_around_atm=0)

    assert resolved_expiry == expiry
    assert rows


def test_auto_spot_mode_uses_mocked_kite_quote(monkeypatch):
    expiry = _expiry()

    class FakeKiteBroker:
        def __init__(self, base_dir="."):
            pass

        def get_instruments(self, exchange=None):
            return [
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23600CE", "expiry": expiry, "strike": 23600, "instrument_type": "CE"},
                {"exchange": "NFO", "name": "NIFTY", "tradingsymbol": "NIFTYFAKE23600PE", "expiry": expiry, "strike": 23600, "instrument_type": "PE"},
            ]

        def get_quote(self, symbols):
            if symbols == ["NSE:NIFTY 50"]:
                return {"NSE:NIFTY 50": {"last_price": 23600}}
            return {
                "NFO:NIFTYFAKE23600CE": {"depth": {"buy": [{"price": 650, "quantity": 100}], "sell": [{"price": 655, "quantity": 100}]}},
                "NFO:NIFTYFAKE23600PE": {"depth": {"buy": [{"price": 500, "quantity": 100}], "sell": [{"price": 505, "quantity": 100}]}},
            }

    monkeypatch.setattr(nifty_preopen_scanner, "KiteBroker", FakeKiteBroker)

    result = run_scanner_full("NIFTY", 23500, 23360, "auto", 0.18, use_kite_quotes=True, auto_spot=True, strikes_around_atm=0)

    assert result["spot_source"] == "KITE READ-ONLY"
    assert result["spot_symbol"] == "NSE:NIFTY 50"
    assert result["spot_used"] == 23600


def test_model_warning_triggers_when_most_calls_are_massively_overpriced():
    rows = [
        {"option_type": "CALL", "strike": 23400, "fair_price": 100, "mid_price": 250, "best_bid": 245, "bid_mispricing_pct": 145, "ask_mispricing_pct": 155, "abs_extreme_mispricing_pct": 155},
        {"option_type": "CALL", "strike": 23500, "fair_price": 100, "mid_price": 260, "best_bid": 255, "bid_mispricing_pct": 155, "ask_mispricing_pct": 165, "abs_extreme_mispricing_pct": 165},
        {"option_type": "CALL", "strike": 23600, "fair_price": 100, "mid_price": 270, "best_bid": 265, "bid_mispricing_pct": 165, "ask_mispricing_pct": 175, "abs_extreme_mispricing_pct": 175},
    ]

    assert detect_model_reference_warning(rows) == MODEL_WARNING_MESSAGE


def test_signals_are_suppressed_when_model_warning_is_active():
    text = format_scanner_output(
        [],
        "NIFTY",
        23500,
        23360,
        _expiry(),
        0.18,
        model_status="WARNING",
        model_warning=MODEL_WARNING_MESSAGE,
        warning_reason="straddle premium mismatch",
        suppressed_count=4,
    )

    assert "Model Status: WARNING" in text
    assert "Warning Reason: straddle premium mismatch" in text
    assert "opportunities suppressed due to model warning: 4" in text
    assert "Symbol | Type | Strike" not in text


def test_no_suppression_when_model_status_ok():
    row = {
        "symbol": "NIFTYFAKE23500CE",
        "option_type": "CALL",
        "strike": 23500.0,
        "fair_price": 100.0,
        "best_bid": 120.0,
        "best_ask": 122.0,
        "spread_pct": 2.0,
        "mispricing_pct": 20.0,
        "suggested_action": "SELL",
        "confidence": 7.0,
        "reason": "visible bid is above model fair value",
    }

    text = format_scanner_output([row], "NIFTY", 23500, 23360, _expiry(), 0.18, model_status="OK")

    assert "Model Status: OK" in text
    assert "NIFTYFAKE23500CE" in text


def test_scanner_report_files_are_created(tmp_path):
    rows = run_scanner("NIFTY", 23500, 23360, _expiry(), 0.18)
    text = format_scanner_output(rows, "NIFTY", 23500, 23360, _expiry(), 0.18)

    paths = save_scanner_report(text, rows, base_dir=tmp_path)

    assert paths["text"].exists()
    assert paths["csv"].exists()
    assert "SCANNER ONLY - NOT EXECUTION READY" in paths["text"].read_text(encoding="utf-8")
    csv_text = paths["csv"].read_text(encoding="utf-8")
    assert "suggested_limit_price" in csv_text
    assert "expected_gross_edge_points" in csv_text
    assert "execution_allowed,hedge_required,risk_note" in csv_text
    assert "Option selling is blocked in scanner mode. Hedge required. Dry-run only." in csv_text
