from __future__ import annotations

import csv
from datetime import date, datetime, timedelta

from src.data_collection.market_data_schema import (
    KITE_TICK_COLUMNS,
    kite_feature_path,
    kite_tick_path,
)
from src.research.forward_validation import load_ledger
from src.research.kite_vwap_forward_bridge import (
    build_closed_one_minute_candles,
    run_kite_vwap_forward_bridge,
)


DAY = date(2026, 6, 23)


def _configs() -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "forward_validation": {
            "enabled": True,
            "symbols": ["GOLD-I"],
            "record_watchlist_signals": True,
            "production_alerts_allowed": False,
            "active_lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
            "active_lock_timestamp": "2026-06-23T00:00:00+05:30",
            "recognized_real_providers": ["KITE", "TRUEDATA"],
        },
    }


def _tick(timestamp: datetime, price: float, *, ltq: float = 1) -> dict:
    return {
        "timestamp": timestamp,
        "symbol": "GOLD-I",
        "internal_symbol": "GOLD-I",
        "kite_exchange": "MCX",
        "kite_tradingsymbol": "GOLD26AUGFUT",
        "instrument_token": "119445255",
        "expiry": "2026-08-05",
        "data_mode": "REAL_READ_ONLY",
        "is_synthetic": "false",
        "ltp": price,
        "ltq": ltq,
        "volume": "",
        "source": "KITE",
    }


def _write_ticks(base, rows: list[dict]) -> None:
    path = kite_tick_path(base, DAY, "GOLD-I")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=KITE_TICK_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in KITE_TICK_COLUMNS})


def _rejection_ticks() -> list[dict]:
    start = datetime(2026, 6, 23, 9, 15)
    return [
        _tick(start, 100),
        _tick(start + timedelta(seconds=40), 101),
        _tick(start + timedelta(minutes=1), 101),
        _tick(start + timedelta(minutes=1, seconds=40), 102),
        _tick(start + timedelta(minutes=2), 102),
        _tick(start + timedelta(minutes=2, seconds=40), 103),
        _tick(start + timedelta(minutes=3), 104),
        _tick(start + timedelta(minutes=3, seconds=30), 105),
        _tick(start + timedelta(minutes=3, seconds=50), 100),
        _tick(start + timedelta(minutes=4), 99),
        _tick(start + timedelta(minutes=4, seconds=1), 99),
    ]


def test_builds_closed_minute_candles_and_excludes_incomplete_minute():
    ticks = _rejection_ticks()
    candles = build_closed_one_minute_candles(ticks)

    assert len(candles) == 4
    assert candles[-1]["timestamp"] == datetime(2026, 6, 23, 9, 18)
    assert candles[-1]["open"] == 104
    assert candles[-1]["high"] == 105
    assert candles[-1]["close"] == 100
    assert all(candle["timestamp"] < datetime(2026, 6, 23, 9, 19) for candle in candles)


def test_locked_rejection_records_one_pending_post_lock_next_tick_entry(tmp_path):
    _write_ticks(tmp_path, _rejection_ticks())

    result = run_kite_vwap_forward_bridge(
        tmp_path,
        symbol="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.candles_built == 4
    assert result.rejection_candidates_found == 1
    assert result.ledger_rows_added == 1
    rows = load_ledger(tmp_path)
    assert len(rows) == 1
    row = rows[0]
    assert row["status"] == "PENDING"
    assert row["result"] == "PENDING"
    assert row["provider"] == "KITE"
    assert row["lock_version"] == "GOLD_VWAP_RESEARCH_LOCK_V1"
    assert row["post_lock"] == "true"
    assert row["canonical_family"] == "gold_vwap_rejection_reclaim_family"
    assert row["canonical_setup"] == "gold_vwap_rejection_short"
    assert row["session_id"] == "GOLD-I_2026-06-23_KITE"
    assert row["signal_time"] == "2026-06-23T09:19:00"
    assert row["entry_time"] == "2026-06-23T09:19:01"
    assert datetime.fromisoformat(row["entry_time"]) > datetime.fromisoformat(row["signal_time"])
    assert row["entry"] == "99.0"
    assert row["approval_status_at_signal"] == "RESEARCH_ONLY"
    assert row["execution_allowed"] == "false"
    assert row["alert_mode"] == "blocked"


def test_duplicate_signal_is_not_appended_twice(tmp_path):
    _write_ticks(tmp_path, _rejection_ticks())
    first = run_kite_vwap_forward_bridge(tmp_path, symbol="GOLD-I", day=DAY, configs=_configs())
    second = run_kite_vwap_forward_bridge(tmp_path, symbol="GOLD-I", day=DAY, configs=_configs())

    assert first.ledger_rows_added == 1
    assert second.ledger_rows_added == 0
    assert second.duplicate_signals_skipped == 1
    assert len(load_ledger(tmp_path)) == 1


def test_feature_rows_are_never_treated_as_candles(tmp_path):
    path = kite_feature_path(tmp_path, DAY, "GOLD-I")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "timestamp,symbol,last_price,price_vs_vwap,feature_mode\n"
        "2026-06-23T09:15:00,GOLD-I,100,-1,DEPTH_ORDERFLOW_LITE\n",
        encoding="utf-8",
    )

    result = run_kite_vwap_forward_bridge(
        tmp_path,
        symbol="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.status == "NO_INPUT"
    assert result.candles_built == 0
    assert result.ledger_rows_added == 0
    assert load_ledger(tmp_path) == []


def test_no_setup_creates_no_ledger_row(tmp_path):
    start = datetime(2026, 6, 23, 9, 15)
    rows = []
    for minute, price in enumerate((100, 101, 102, 103, 104)):
        rows.extend(
            [
                _tick(start + timedelta(minutes=minute), price),
                _tick(start + timedelta(minutes=minute, seconds=30), price + 1),
            ]
        )
    _write_ticks(tmp_path, rows)

    result = run_kite_vwap_forward_bridge(
        tmp_path,
        symbol="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.status == "NO_SETUP"
    assert result.candidates_found == 0
    assert result.ledger_rows_added == 0
    assert load_ledger(tmp_path) == []


def test_bridge_has_no_executable_order_path_text():
    from pathlib import Path

    module = Path(__file__).resolve().parents[2] / "src" / "research" / "kite_vwap_forward_bridge.py"
    text = module.read_text(encoding="utf-8")
    forbidden = "place" + "_order"

    assert forbidden not in text
    assert '"execution_allowed": False' in text
