﻿from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

from src.data_collection.kite_daily_pipeline import run_kite_daily_pipeline
from src.data_collection.kite_instrument_resolver import KiteInstrumentMapping
from src.data_collection.kite_live_recorder import KiteRecordingResult
from src.data_collection.kite_orderflow_features import KiteOrderFlowFeatureResult


def _configs() -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "risk": {},
        "strategies": {"vwap_rejection": True, "vwap_reclaim": True},
        "approved_strategies": {},
        "instruments": {"GOLD-I": {"exchange": "MCX"}},
        "alerts": {"enable_whatsapp_alerts": False},
        "forward_validation": {
            "enabled": True,
            "symbols": ["GOLD-I"],
            "record_watchlist_signals": True,
            "production_alerts_allowed": False,
            "active_lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
            "active_lock_timestamp": "2026-06-23T00:00:00+05:30",
        },
    }


def _resolver(*_args, **_kwargs):
    return SimpleNamespace(
        mappings=[
            KiteInstrumentMapping(
                internal_symbol="GOLD-I",
                exchange="MCX",
                tradingsymbol="GOLD26AUGFUT",
                instrument_token=119445255,
                expiry="2026-08-05",
                status="RESOLVED",
            )
        ],
        source="TEST",
        errors=[],
    )


def _readonly(*_args, **_kwargs):
    return SimpleNamespace(quote_status="OK", depth_status="PRESENT", errors=[], report_path=None)


def _features(*_args, **_kwargs):
    return KiteOrderFlowFeatureResult(
        rows_generated=1,
        output_csv_data_rows=1,
        feature_mode="DEPTH_ORDERFLOW_LITE",
        market_data_status="FULL_DEPTH",
        contract_consistency_status="CONSISTENT",
        report_csv_contract_match=True,
    )


def _bridge(*_args, **_kwargs):
    return SimpleNamespace(
        status="NO_SETUP",
        reason="No setup on closed candles.",
        candles_built=4,
        candidates_found=0,
        ledger_rows_added=0,
        duplicate_signals_skipped=0,
        warnings=[],
    )


def _forward(*_args, **_kwargs):
    return SimpleNamespace(
        decision=SimpleNamespace(status="RESEARCH_ONLY", reason="Independent sample is incomplete."),
        ledger_path=None,
        summary_path=None,
    )


def test_recoverable_recorder_warning_keeps_completed_usable_chunk(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    def recorder(*_args, **_kwargs):
        return KiteRecordingResult(
            operation_type="recorder",
            market_data_status="RECORDED",
            tick_rows_recorded=3,
            depth_rows_recorded=15,
            recorder_completed_normally=True,
            recorder_failed_safely=False,
            errors=["Kite quote read failed safely: ConnectTimeout."],
        )

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=5,
        record_depth=True,
        dry_run=True,
        now_fn=lambda: datetime(2026, 6, 23, 9, 15),
        configs=_configs(),
        resolver_func=_resolver,
        readonly_check_func=_readonly,
        recorder_func=recorder,
        feature_builder_func=_features,
        vwap_bridge_func=_bridge,
        pending_outcome_updater_func=_forward,
        forward_summary_func=_forward,
    )

    assert result.chunks_attempted == 1
    assert result.chunks_completed == 1
    assert result.recorder_completed_normally is True
    assert result.recorder_failed_safely is False
    assert result.partial_data_usable is True
    assert result.step_status["recorder"] == "SUCCESS"
    assert any("ConnectTimeout" in warning for warning in result.warnings)


def test_pipeline_report_exposes_vwap_bridge_diagnostics(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=lambda: datetime(2026, 6, 23, 9, 15),
        configs=_configs(),
        resolver_func=_resolver,
        readonly_check_func=_readonly,
        recorder_func=lambda *_args, **_kwargs: KiteRecordingResult(
            operation_type="recorder",
            recorder_completed_normally=True,
        ),
        feature_builder_func=_features,
        vwap_bridge_func=_bridge,
        pending_outcome_updater_func=_forward,
        forward_summary_func=_forward,
    )

    report = result.report_path.read_text(encoding="utf-8")
    assert "GOLD-I VWAP FORWARD BRIDGE" in report
    assert "VWAP bridge status: NO_SETUP" in report
    assert "candles_built: 4" in report
    assert "candidates_found: 0" in report
    assert "pending_post_lock_rows_added: 0" in report
    assert "duplicate_signals_skipped: 0" in report
    assert "execution_allowed=false" in report
    assert "Production WhatsApp alerts: BLOCKED" in report

def test_pipeline_calls_pending_outcome_updater_after_bridge(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)
    calls = []

    def bridge(*_args, **_kwargs):
        calls.append("bridge")
        return _bridge()

    def updater(*_args, **_kwargs):
        calls.append("updater")
        return SimpleNamespace(
            pending_update=SimpleNamespace(
                checked=1,
                resolved=1,
                still_pending=0,
                no_tick_data=0,
                no_later_tick=0,
            ),
            decision=SimpleNamespace(status="RESEARCH_ONLY", reason="Independent sample is incomplete."),
            ledger_path=None,
            summary_path=None,
        )

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=lambda: datetime(2026, 6, 23, 9, 15),
        configs=_configs(),
        resolver_func=_resolver,
        readonly_check_func=_readonly,
        recorder_func=lambda *_args, **_kwargs: KiteRecordingResult(
            operation_type="recorder",
            recorder_completed_normally=True,
        ),
        feature_builder_func=_features,
        vwap_bridge_func=bridge,
        pending_outcome_updater_func=updater,
        forward_summary_func=_forward,
    )

    assert calls == ["bridge", "updater"]
    assert result.pending_outcomes_checked == 1
    assert result.pending_outcomes_resolved == 1
    assert result.pending_outcomes_still_pending == 0
    report = result.report_path.read_text(encoding="utf-8")
    assert "pending_outcomes_checked: 1" in report
    assert "pending_outcomes_resolved: 1" in report


