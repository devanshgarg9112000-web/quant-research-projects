from __future__ import annotations

import csv
import zipfile
from datetime import datetime
from pathlib import Path

from scripts.create_safe_weekend_backup import (
    HISTORY_PATH,
    REPORT_PATH,
    create_safe_weekend_backup,
)


def _write_file(base: Path, relative: str, text: str = "x\n") -> Path:
    path = base / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _seed_project(base: Path) -> None:
    _write_file(base, "src/main.py", "print('paper only')\n")
    _write_file(base, "scripts/tool.py", "print('safe')\n")
    _write_file(base, "tests/test_example.py", "def test_ok(): assert True\n")
    _write_file(base, "docs/MONDAY_KITE_RECORDING_RUNBOOK.md", "# runbook\n")
    _write_file(base, "config/settings.yaml", "mode: PAPER\nenable_live_trading: false\n")
    _write_file(base, "reports/final_safety/latest_final_safety_audit_report.txt", "FINAL VERDICT\nFINAL_SAFETY_PASS_WITH_WARNINGS\n")
    _write_file(base, "reports/launch1/latest_launch1_readiness_report.txt", "decision: LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA\n")
    _write_file(base, "data/kite_recorded/ticks/2026-06-20/GOLD-I_ticks.csv", "timestamp,symbol\nx,GOLD-I\n")
    _write_file(base, "data/kite_instruments/instruments_mcx.csv", "tradingsymbol\nGOLD26AUGFUT\n")
    _write_file(base, "requirements.txt", "pytest\n")
    _write_file(base, "pytest.ini", "[pytest]\n")
    _write_file(base, "README.md", "# README\n")


def _zip_names(path: Path) -> set[str]:
    with zipfile.ZipFile(path) as zf:
        return set(zf.namelist())


def test_backup_script_creates_zip(tmp_path):
    _seed_project(tmp_path)

    result = create_safe_weekend_backup(
        tmp_path,
        label="weekend_pre_monday_launch1",
        now_fn=lambda: datetime(2026, 6, 21, 12, 0),
    )

    assert result.backup_zip_path.exists()
    assert result.backup_zip_path.suffix == ".zip"
    assert result.sha256
    assert len(result.sha256) == 64


def test_env_venv_pycache_are_excluded(tmp_path):
    _seed_project(tmp_path)
    _write_file(tmp_path, ".env", "KITE_ACCESS_TOKEN=realToken1234567890\n")
    _write_file(tmp_path, ".venv/Lib/site.py", "x\n")
    _write_file(tmp_path, "src/__pycache__/main.cpython-311.pyc", "x\n")

    result = create_safe_weekend_backup(tmp_path, label="safe", now_fn=lambda: datetime(2026, 6, 21, 12, 0))

    names = _zip_names(result.backup_zip_path)
    assert ".env" not in names
    assert ".venv/Lib/site.py" not in names
    assert "src/__pycache__/main.cpython-311.pyc" not in names
    assert result.env_excluded is True


def test_secret_like_file_is_excluded_and_not_printed(tmp_path):
    _seed_project(tmp_path)
    secret = "secretValue1234567890"
    _write_file(tmp_path, "reports/leaky_report.txt", f"KITE_ACCESS_TOKEN={secret}\n")

    result = create_safe_weekend_backup(tmp_path, label="safe", now_fn=lambda: datetime(2026, 6, 21, 12, 0))

    names = _zip_names(result.backup_zip_path)
    assert "reports/leaky_report.txt" not in names
    assert result.secret_scan_passed is True
    report = (tmp_path / REPORT_PATH).read_text(encoding="utf-8")
    assert secret not in report
    assert "KITE_ACCESS_TOKEN=****" in report


def test_manifest_report_and_history_are_created(tmp_path):
    _seed_project(tmp_path)

    result = create_safe_weekend_backup(tmp_path, label="safe", now_fn=lambda: datetime(2026, 6, 21, 12, 0))

    assert (tmp_path / REPORT_PATH).exists()
    assert (tmp_path / HISTORY_PATH).exists()
    with (tmp_path / HISTORY_PATH).open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[-1]["execution_allowed"] == "false"
    assert rows[-1]["production_whatsapp_status"] == "BLOCKED"
    assert rows[-1]["sha256"] == result.sha256
    names = _zip_names(result.backup_zip_path)
    assert "reports/backups/latest_safe_backup_report.txt" in names


def test_backup_includes_important_source_report_and_data_files(tmp_path):
    _seed_project(tmp_path)

    result = create_safe_weekend_backup(tmp_path, label="safe", now_fn=lambda: datetime(2026, 6, 21, 12, 0))

    names = _zip_names(result.backup_zip_path)
    assert "src/main.py" in names
    assert "scripts/tool.py" in names
    assert "tests/test_example.py" in names
    assert "docs/MONDAY_KITE_RECORDING_RUNBOOK.md" in names
    assert "config/settings.yaml" in names
    assert "reports/final_safety/latest_final_safety_audit_report.txt" in names
    assert "data/kite_recorded/ticks/2026-06-20/GOLD-I_ticks.csv" in names
    assert "data/kite_instruments/instruments_mcx.csv" in names
    assert "requirements.txt" in names
    assert "pytest.ini" in names
    assert "README.md" in names


def test_backup_report_preserves_safety_flags(tmp_path):
    _seed_project(tmp_path)

    result = create_safe_weekend_backup(tmp_path, label="safe", now_fn=lambda: datetime(2026, 6, 21, 12, 0))

    report = (tmp_path / REPORT_PATH).read_text(encoding="utf-8")
    assert "execution_allowed=false" in report
    assert "Production WhatsApp: BLOCKED" in report
    assert "Mode: PAPER / RESEARCH / MANUAL ONLY" in report
    assert "No broker orders were placed." in report
    assert result.production_whatsapp_status == "BLOCKED"


def test_backup_script_does_not_add_executable_order_path_text():
    script = Path(__file__).resolve().parents[1] / "scripts" / "create_safe_weekend_backup.py"
    text = script.read_text(encoding="utf-8")

    assert "place_order" not in text


def test_backup_supports_explicit_output_directory_and_stage_note(tmp_path):
    _seed_project(tmp_path)
    output_dir = tmp_path / "external_backups"

    result = create_safe_weekend_backup(
        tmp_path,
        label="stage0_data_ready_310tests",
        output_dir=output_dir,
        latest_test_status="310 passed",
        now_fn=lambda: datetime(2026, 6, 22, 15, 0),
    )

    assert result.backup_zip_path.parent == output_dir
    assert result.backup_zip_path.exists()
    assert result.latest_test_status == "310 passed"
    assert result.stage_note == "Stage 0 infrastructure/data readiness; not tradeable Launch 1"
    report = (tmp_path / REPORT_PATH).read_text(encoding="utf-8")
    assert f"Backup output directory: {output_dir}" in report
    assert "Latest test status: 310 passed" in report
    assert "Stage 0 infrastructure/data readiness; not tradeable Launch 1" in report
    with (tmp_path / HISTORY_PATH).open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[-1]["backup_output_directory"] == str(output_dir)
    assert rows[-1]["stage_note"] == "Stage 0 infrastructure/data readiness; not tradeable Launch 1"
