from __future__ import annotations

import ast
import csv
from datetime import datetime
from pathlib import Path

from src.reports.tradeable_launch1_readiness_report import (
    HISTORY_PATH,
    TRADEABLE_LAUNCH1_NOT_READY,
    generate_tradeable_launch1_readiness_report,
)


def _write(base: Path, relative: str, text: str) -> None:
    path = base / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _write_current_checkpoint(base: Path) -> None:
    _write(
        base,
        "reports/launch1/latest_launch1_readiness_report.txt",
        "\n".join(
            [
                "STAGE 0 / LEGACY LAUNCH 1 READINESS REPORT",
                "Stage 0 Infrastructure/Data Readiness: READY",
                "Tradeable Launch 1: NOT_READY",
                "target_validation_passed: true",
                "strategy_approval_status: RESEARCH_ONLY",
                "decision: LAUNCH1_READY_FOR_PAPER_RESEARCH",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write(
        base,
        "reports/final_safety/latest_final_safety_audit_report.txt",
        "\n".join(
            [
                "FINAL SAFETY AUDIT",
                "execution_allowed=false",
                "production_whatsapp_status: BLOCKED",
                "FINAL VERDICT",
                "FINAL_SAFETY_PASS_WITH_WARNINGS",
            ]
        )
        + "\n",
    )
    _write(
        base,
        "reports/forward_validation/latest_forward_validation_summary.txt",
        "\n".join(
            [
                "Forward/replay-recorded trades: trades=5 wins=3 losses=2 net_pnl=1508.15 PF=2.81",
                "Approval Decision: RESEARCH_ONLY",
                "Decision Reason: Forward trades are 5; at least 10 are required before WATCHLIST review.",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write(
        base,
        "reports/strategy_research/latest_gold_vwap_rejection_deep_dive.txt",
        "\n".join(
            [
                "Robustness: ROBUST;LOW_SAMPLE",
                "Current approval status: WATCHLIST",
                "Validation: trades=4 net_pnl=709.86 PF=1.85",
                "Warnings: LOW_SAMPLE;LOW_VALIDATION_SAMPLE;OVERFIT_RISK",
                "Evidence is not approval-grade.",
            ]
        )
        + "\n",
    )
    _write(
        base,
        "reports/strategy_research/latest_gold_vwap_rejection_deep_dive.csv",
        "adjusted_entry,adjusted_exit,gross_pnl,trade_net_pnl,execution_allowed\n1,1,0,0,false\n",
    )
    _write(
        base,
        "reports/strategy_research/latest_strategy_research_report.txt",
        "Strategy Research Lab tested 72 variants. LOW_TRADE_COUNT.\n",
    )
    _write(
        base,
        "config/approved_strategies.yaml",
        "enabled: true\nallow_approved: true\nallow_watchlist: false\n",
    )
    _write(
        base,
        "src/data_collection/kite_live_recorder.py",
        "class _StreamingCsvAppender:\n    pass\nmemory_safe_streaming = True\n",
    )
    _write(
        base,
        "src/data_collection/kite_daily_pipeline.py",
        "chunk_seconds = 1800\n",
    )


def test_tradeable_launch1_report_is_not_ready_and_contains_all_gates(tmp_path):
    _write_current_checkpoint(tmp_path)

    result = generate_tradeable_launch1_readiness_report(
        tmp_path,
        now_fn=lambda: datetime(2026, 6, 22, 18, 0),
    )

    assert result.decision == TRADEABLE_LAUNCH1_NOT_READY
    assert result.stage0_status == "READY"
    assert result.real_money_approval is False
    assert len(result.gates) == 14
    assert result.strategy_approval_status == "RESEARCH_ONLY"
    assert result.production_whatsapp_status == "BLOCKED"
    assert result.execution_allowed == "false"
    assert result.report_path.exists()
    assert result.history_path.exists()


def test_tradeable_report_marks_expected_ready_and_not_ready_gates(tmp_path):
    _write_current_checkpoint(tmp_path)

    result = generate_tradeable_launch1_readiness_report(tmp_path)
    gates = {gate.key: gate.status for gate in result.gates}

    assert gates["stage0_infrastructure_data"] == "READY"
    assert gates["recorder_stability"] == "CODE_READY / NEEDS_NEXT_LIVE_CHUNK_VALIDATION"
    assert gates["strategy_inventory"] == "NOT_CONFIRMED"
    assert gates["professional_backtesting"] == "NOT_READY"
    assert gates["out_of_sample_walk_forward"] == "NOT_READY"
    assert gates["robustness_sensitivity"] == "NOT_READY"
    assert gates["forward_validation_sample"] == "RESEARCH_ONLY / INSUFFICIENT_FOR_APPROVAL"
    assert gates["strategy_approval"] == "RESEARCH_ONLY"
    assert gates["signal_generation_engine"] == "NOT_READY"
    assert gates["alert_delivery"] == "BLOCKED"
    assert gates["manual_risk_plan"] == "NOT_READY"
    assert gates["final_safety_audit"] == "PASS_WITH_WARNINGS_ACCEPTED"
    assert gates["real_money_small_size_approval"] == "false"


def test_tradeable_report_contains_roadmap_and_unambiguous_safety_language(tmp_path):
    _write_current_checkpoint(tmp_path)

    result = generate_tradeable_launch1_readiness_report(tmp_path)
    text = result.report_path.read_text(encoding="utf-8")

    assert "TRADEABLE_LAUNCH1_NOT_READY" in text
    assert "Stage 0: Data + infrastructure readiness - READY" in text
    assert "Stage 7: Scaling only after stable live results - LOCKED" in text
    assert "No auto trading" in text
    assert "No broker orders" in text
    assert "No Kite place_order" in text
    assert "execution_allowed=false" in text
    assert "Production WhatsApp alerts: BLOCKED" in text
    assert "Strategy remains: RESEARCH_ONLY" in text
    assert "Real-money trading: 0% approved" in text


def test_tradeable_history_csv_records_research_only_and_false_approval(tmp_path):
    _write_current_checkpoint(tmp_path)

    generate_tradeable_launch1_readiness_report(tmp_path)
    generate_tradeable_launch1_readiness_report(tmp_path)

    with (tmp_path / HISTORY_PATH).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 2
    assert rows[-1]["decision"] == TRADEABLE_LAUNCH1_NOT_READY
    assert rows[-1]["strategy_approval_status"] == "RESEARCH_ONLY"
    assert rows[-1]["real_money_approval"] == "false"
    assert rows[-1]["execution_allowed"] == "false"
    assert rows[-1]["production_whatsapp_status"] == "BLOCKED"


def test_tradeable_report_module_has_no_executable_order_call():
    module_path = Path(__file__).resolve().parents[1] / "src" / "reports" / "tradeable_launch1_readiness_report.py"
    tree = ast.parse(module_path.read_text(encoding="utf-8"))
    executable_order_calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "place_order"
    ]
    assert executable_order_calls == []
