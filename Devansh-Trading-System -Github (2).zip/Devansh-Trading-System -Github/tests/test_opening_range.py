from src.data.sample_data import generate_sample_candles
from src.indicators.opening_range import calculate_opening_range


def test_opening_range_high_low():
    opening = calculate_opening_range(generate_sample_candles())
    assert opening["opening_range_high"] == opening["first_15_high"]
    assert opening["opening_range_high"] > opening["opening_range_low"]
