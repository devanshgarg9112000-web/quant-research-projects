from __future__ import annotations

import csv
from datetime import datetime, timedelta

from src.alerts.whatsapp_alerts import WhatsAppAlertProvider
from src.config_loader import load_configs
from src.research.vwap_rejection_deep_dive import (
    ApprovalDecision,
    DeepDiveMetrics,
    VariationResult,
    assess_deep_dive_approval,
    classify_robustness,
    run_deep_dive,
)
from src.scoring.strategy_verification import StrategyApprovalGate


def _variation(
    variation_id="baseline",
    changed_dimension="baseline",
    train=None,
    validation=None,
    combined=None,
    warnings=(),
):
    return VariationResult(
        variation_id=variation_id,
        changed_dimension=changed_dimension,
        params={},
        trades=(),
        train=train or DeepDiveMetrics(trades=12, net_pnl=1000, profit_factor=1.5),
        validation=validation or DeepDiveMetrics(trades=8, net_pnl=500, profit_factor=1.4),
        combined=combined or DeepDiveMetrics(trades=20, net_pnl=1500, profit_factor=1.45),
        warnings=warnings,
    )


def test_deep_dive_report_generation(tmp_path):
    source = tmp_path / "data" / "historical" / "truedata" / "bars"
    for day in (4, 5):
        day_dir = source / f"2026-06-{day:02d}"
        day_dir.mkdir(parents=True)
        path = day_dir / "GOLD-I_1minute_bars.csv"
        start = datetime(2026, 6, day, 9, 0)
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "timestamp", "symbol", "open", "high", "low", "close",
                    "volume", "oi", "source", "interval",
                ],
            )
            writer.writeheader()
            for index in range(40):
                close = 100 - index * 0.05
                writer.writerow({
                    "timestamp": (start + timedelta(minutes=index)).isoformat(),
                    "symbol": "GOLD-I",
                    "open": close + 0.05,
                    "high": close + 0.20,
                    "low": close - 0.20,
                    "close": close,
                    "volume": 100,
                    "oi": "",
                    "source": "TRUEDATA",
                    "interval": "1minute",
                })
    project_result = run_deep_dive(
        base_dir=tmp_path,
        symbol="GOLD-I",
        bar_dir="data/historical/truedata/bars",
        from_date="2026-06-04",
        to_date="2026-06-05",
        configs={
            "risk": {"capital": 100000, "risk_per_trade_percent": 0.5},
            "instruments": {"GOLD-I": {"lot_size": 1, "min_qty": 1, "point_value": 1}},
        },
    )

    assert project_result.report_path.exists()
    assert project_result.csv_path.exists()
    assert project_result.playbook_path.exists()
    assert "execution_allowed=false" in project_result.report_path.read_text(encoding="utf-8")


def test_robustness_requires_multiple_profitable_dimensions():
    baseline = _variation()
    fragile = [
        baseline,
        _variation("atr=1.5", "atr_stop_multiplier", combined=DeepDiveMetrics(trades=20, net_pnl=-1, profit_factor=0.9)),
    ]
    robust = [
        baseline,
        *[
            _variation(f"v{index}", dimension)
            for index, dimension in enumerate(
                ["atr_stop_multiplier", "reward_risk", "volume_multiplier", "cooldown_seconds"],
                start=1,
            )
        ],
    ]

    assert classify_robustness(fragile) == "FRAGILE"
    assert classify_robustness(robust) == "ROBUST"


def test_low_sample_remains_watchlist():
    baseline = _variation(
        train=DeepDiveMetrics(trades=4, net_pnl=500, profit_factor=2),
        validation=DeepDiveMetrics(trades=3, net_pnl=300, profit_factor=2),
        combined=DeepDiveMetrics(trades=7, net_pnl=800, profit_factor=2),
    )

    decision = assess_deep_dive_approval(baseline, "LOW_SAMPLE")

    assert decision == ApprovalDecision("WATCHLIST", "Sample size is too small for approval.")


def test_fragile_parameter_result_not_approved():
    decision = assess_deep_dive_approval(_variation(), "FRAGILE")

    assert decision.status == "WATCHLIST"
    assert "FRAGILE" in decision.reason


def test_research_watchlist_preview_has_do_not_trade_label(tmp_path):
    provider = WhatsAppAlertProvider(
        tmp_path,
        config={"research_watchlist_enabled": True},
    )
    row = {
        "symbol": "GOLD-I",
        "strategy": "VWAP Rejection Short",
        "status": "NO_SIGNAL",
        "strategy_verification_status": "WATCHLIST",
        "strategy_verification_reason": "Low sample",
        "execution_allowed": False,
    }

    assert provider.preview_research_watchlist(row) is True
    text = provider.research_watchlist_preview_path.read_text(encoding="utf-8")
    assert text.startswith("RESEARCH ONLY - DO NOT TRADE")
    assert "execution_allowed=false" in text


def test_research_watchlist_preview_disabled_by_default_and_rejected_rows_blocked(tmp_path):
    assert load_configs(".")["alerts"]["whatsapp"]["research_watchlist_enabled"] is False
    provider = WhatsAppAlertProvider(tmp_path, config={"research_watchlist_enabled": True})

    assert provider.preview_research_watchlist({
        "symbol": "GOLD-I",
        "strategy": "VWAP Rejection Short",
        "status": "REJECTED",
        "strategy_verification_status": "WATCHLIST",
        "execution_allowed": False,
    }) is False


def test_production_alert_gate_remains_blocked_for_watchlist(tmp_path):
    report = tmp_path / "reports" / "strategy_verification"
    report.mkdir(parents=True)
    (report / "latest_strategy_approval_report.csv").write_text(
        "strategy,symbol,status\nvwap_rejection,GOLD-I,WATCHLIST\n",
        encoding="utf-8",
    )
    gate = StrategyApprovalGate(
        tmp_path,
        {
            "enabled": True,
            "allow_approved": True,
            "allow_watchlist": False,
            "approval_report_path": "reports/strategy_verification/latest_strategy_approval_report.csv",
        },
    )

    decision = gate.evaluate({"symbol": "GOLD-I", "strategy": "VWAP Rejection Short"})

    assert decision.allowed is False
    assert decision.status == "WATCHLIST"
