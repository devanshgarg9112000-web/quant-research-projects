from src.config_loader import load_configs
from src.data.sample_data import generate_sample_candles, generate_sample_ticks
from src.strategies.strategy_engine import StrategyEngine
from src.strategies.cluster_imbalance_trap import generate_signal as generate_cluster_signal


def test_strategy_signals_detected_over_sample():
    configs = load_configs(".")
    candles = generate_sample_candles()
    ticks = generate_sample_ticks()
    names = set()
    for i in range(4, len(candles)):
        result = StrategyEngine(configs["settings"], configs["strategies"]).run(candles[:i + 1], ticks)
        names.update(signal.strategy_name for signal in result.candidates)
    assert "Failed Breakout Short" in names
    assert "Failed Breakdown Long" in names
    assert "Breakout Acceptance Long" in names
    assert "Trend Day VWAP Pullback Long" in names or "VWAP Pullback Long" in names
    assert "Cluster Imbalance Trap Short" in names


def test_mcx_cluster_strategy_uses_data_sufficient_buyer_trap():
    candles = generate_sample_candles()[:4]
    candles = [{**candle, "symbol": "GOLD-I"} for candle in candles]
    context = {
        "market_mode": "TRAP_REVERSAL",
        "cluster_diagnostics": {
            "data_sufficient": True,
            "cluster_imbalance_trap_status": "ESTIMATED_BUYER_TRAP_POSSIBLE",
            "buy_imbalance_levels": [candles[-1]["high"] + 10],
        },
        "clusters": [],
    }

    signal = generate_cluster_signal(candles, context)

    assert signal is not None
    assert signal.side == "SELL"
    assert signal.strategy_name == "MCX Estimated Buyer Trap Short"
    assert signal.stop_loss > signal.entry_price
    assert signal.reward_risk == 2.0


def test_candle_only_backtest_does_not_require_cluster_ticks_for_candle_strategy():
    candles = [
        {
            "timestamp": generate_sample_candles()[0]["timestamp"],
            "symbol": "GOLD-I",
            "open": 100,
            "high": 102,
            "low": 99,
            "close": 100,
            "volume": 100,
        },
        {
            "timestamp": generate_sample_candles()[1]["timestamp"],
            "symbol": "GOLD-I",
            "open": 100,
            "high": 103,
            "low": 99,
            "close": 101,
            "volume": 100,
        },
        {
            "timestamp": generate_sample_candles()[2]["timestamp"],
            "symbol": "GOLD-I",
            "open": 101,
            "high": 104,
            "low": 100,
            "close": 102,
            "volume": 100,
        },
        {
            "timestamp": generate_sample_candles()[3]["timestamp"],
            "symbol": "GOLD-I",
            "open": 101,
            "high": 104,
            "low": 99,
            "close": 100,
            "volume": 100,
        },
        {
            "timestamp": generate_sample_candles()[4]["timestamp"],
            "symbol": "GOLD-I",
            "open": 101,
            "high": 110,
            "low": 101,
            "close": 109,
            "volume": 200,
        },
    ]
    engine = StrategyEngine(
        {"min_signal_score": 7, "candle_only_backtest": True},
        {"breakout_acceptance": True},
    )

    result = engine.run(candles, [])

    assert any(signal.setup_type == "breakout_acceptance" for signal in result.candidates)
    assert result.candidates[0].metadata["cluster_gate_result"] == "NOT_APPLICABLE_CANDLE_ONLY"
