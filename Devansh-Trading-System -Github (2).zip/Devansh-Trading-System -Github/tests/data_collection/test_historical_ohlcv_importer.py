from __future__ import annotations

from pathlib import Path

from src.data_collection.historical_ohlcv_importer import run_historical_ohlcv_import


def _write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _valid_csv(base: Path) -> Path:
    return _write(
        base / "input" / "gold.csv",
        "timestamp,open,high,low,close,volume\n"
        "2024-01-01T09:00:00,100,101,99,100.5,10\n"
        "2024-01-01T09:01:00,100.5,102,100,101,12\n",
    )


def _run(base: Path, input_file: Path, *, dry_run: bool = True):
    return run_historical_ohlcv_import(
        base,
        input_file=input_file,
        provider="manual",
        symbol="GOLD-I",
        timeframe="1minute",
        contract="GOLD-I-CONT",
        expiry="",
        is_continuous=True,
        dry_run=dry_run,
    )


def test_valid_small_csv_dry_run_creates_manifest_but_no_output(tmp_path: Path) -> None:
    source = _valid_csv(tmp_path)

    result = _run(tmp_path, source, dry_run=True)

    assert result.success is True
    assert result.manifest_txt_path.exists()
    assert result.manifest_csv_path.exists()
    assert result.file_results[0].rows_valid == 2
    assert result.file_results[0].source_file_hash
    assert result.file_results[0].output_file is None
    output = tmp_path / "data" / "historical" / "ohlcv" / "manual" / "GOLD-I" / "1minute" / "2024.csv"
    assert not output.exists()
    manifest = result.manifest_txt_path.read_text(encoding="utf-8")
    assert "dry_run: true" in manifest
    assert "source_file_hash:" in manifest
    assert "execution_allowed=false" in manifest


def test_valid_small_csv_write_mode_creates_output_file_and_manifest(tmp_path: Path) -> None:
    source = _valid_csv(tmp_path)

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is True
    output = tmp_path / "data" / "historical" / "ohlcv" / "manual" / "GOLD-I" / "1minute" / "2024.csv"
    assert output.exists()
    text = output.read_text(encoding="utf-8")
    assert "timestamp,open,high,low,close,volume,symbol,provider,timeframe,contract,expiry,is_continuous,source_file" in text
    assert "GOLD-I-CONT" in text
    assert result.file_results[0].output_file == output
    assert result.file_results[0].output_file_hash
    manifest = result.manifest_txt_path.read_text(encoding="utf-8")
    assert "output_file_hash:" in manifest


def test_missing_required_ohlc_columns_fails_safely(tmp_path: Path) -> None:
    source = _write(tmp_path / "bad.csv", "timestamp,open,close,volume\n2024-01-01T09:00:00,100,101,10\n")

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is False
    assert "missing required OHLC" in ";".join(result.file_results[0].errors)
    assert result.manifest_txt_path.exists()
    assert not (tmp_path / "data" / "historical" / "ohlcv").exists()


def test_high_less_than_low_fails_safely(tmp_path: Path) -> None:
    source = _write(
        tmp_path / "bad.csv",
        "timestamp,open,high,low,close,volume\n2024-01-01T09:00:00,100,99,101,100,10\n",
    )

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is False
    assert "high < low" in ";".join(result.file_results[0].errors)


def test_zero_or_negative_prices_fail_safely(tmp_path: Path) -> None:
    source = _write(
        tmp_path / "bad.csv",
        "timestamp,open,high,low,close,volume\n2024-01-01T09:00:00,0,101,99,100,10\n",
    )

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is False
    assert "open must be positive" in ";".join(result.file_results[0].errors)


def test_negative_volume_fails_safely(tmp_path: Path) -> None:
    source = _write(
        tmp_path / "bad.csv",
        "timestamp,open,high,low,close,volume\n2024-01-01T09:00:00,100,101,99,100,-1\n",
    )

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is False
    assert "volume must not be negative" in ";".join(result.file_results[0].errors)


def test_duplicate_timestamps_are_reported_and_fail(tmp_path: Path) -> None:
    source = _write(
        tmp_path / "dup.csv",
        "timestamp,open,high,low,close,volume\n"
        "2024-01-01T09:00:00,100,101,99,100,10\n"
        "2024-01-01T09:00:00,100,101,99,100,10\n",
    )

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is False
    assert result.file_results[0].duplicate_timestamps == 1
    assert "duplicate timestamp" in ";".join(result.file_results[0].errors)
    assert "duplicate_timestamps: 1" in result.manifest_txt_path.read_text(encoding="utf-8")


def test_missing_volume_is_filled_with_warning(tmp_path: Path) -> None:
    source = _write(
        tmp_path / "novol.csv",
        "timestamp,open,high,low,close\n2024-01-01T09:00:00,100,101,99,100\n",
    )

    result = _run(tmp_path, source, dry_run=False)

    assert result.success is True
    assert any("volume missing" in warning for warning in result.file_results[0].warnings)
    output = result.file_results[0].output_file
    assert output is not None
    assert ",0,GOLD-I," in output.read_text(encoding="utf-8")


def test_no_place_order_path_added() -> None:
    module = Path(__file__).resolve().parents[2] / "src" / "data_collection" / "historical_ohlcv_importer.py"
    text = module.read_text(encoding="utf-8")
    forbidden = "place" + "_order"
    assert forbidden not in text
    assert "execution_allowed=false" in text
