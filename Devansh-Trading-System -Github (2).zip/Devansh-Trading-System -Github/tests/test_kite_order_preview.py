from __future__ import annotations

from argparse import Namespace

import pytest

from src.brokers.kite_broker import KiteBroker
from src.execution.kite_order_preview import (
    KiteOrderPreviewError,
    build_kite_order_payload,
    evaluate_kite_live_order_safety,
    format_order_preview,
    run_preview_cli,
)


def test_dry_run_creates_correct_kite_order_payload():
    payload = build_kite_order_payload(
        symbol="NSE:RELIANCE",
        side="BUY",
        quantity=1,
        order_type="MARKET",
    )

    assert payload == {
        "symbol": "NSE:RELIANCE",
        "exchange": "NSE",
        "tradingsymbol": "RELIANCE",
        "transaction_type": "BUY",
        "quantity": 1,
        "order_type": "MARKET",
        "product": "MIS",
        "variety": "regular",
        "validity": "DAY",
    }


def test_buy_sell_mapping_works():
    buy = build_kite_order_payload("NSE:RELIANCE", "buy", 1, "MARKET")
    sell = build_kite_order_payload("NSE:RELIANCE", "sell", 1, "MARKET")

    assert buy["transaction_type"] == "BUY"
    assert sell["transaction_type"] == "SELL"


def test_invalid_quantity_is_rejected():
    with pytest.raises(KiteOrderPreviewError, match="quantity must be positive"):
        build_kite_order_payload("NSE:RELIANCE", "BUY", 0, "MARKET")


def test_invalid_side_is_rejected():
    with pytest.raises(KiteOrderPreviewError, match="side must be BUY or SELL"):
        build_kite_order_payload("NSE:RELIANCE", "HOLD", 1, "MARKET")


def test_limit_order_requires_positive_price():
    with pytest.raises(KiteOrderPreviewError, match="LIMIT order requires a positive price"):
        build_kite_order_payload("NSE:RELIANCE", "BUY", 1, "LIMIT")

    payload = build_kite_order_payload("NSE:RELIANCE", "BUY", 1, "LIMIT", price=2500)
    assert payload["price"] == 2500.0


def test_dry_run_does_not_call_kite_place_order(monkeypatch, capsys):
    def fail_place_order(*args, **kwargs):
        raise AssertionError("Dry-run preview must not call Kite place_order.")

    monkeypatch.setattr(KiteBroker, "place_order", fail_place_order)
    args = Namespace(
        symbol="NSE:RELIANCE",
        side="BUY",
        quantity=1,
        order_type="MARKET",
        price=None,
        product="MIS",
        variety="regular",
        validity="DAY",
    )

    result = run_preview_cli(args)

    out = capsys.readouterr().out
    assert result == 0
    assert "KITE ORDER PREVIEW" in out
    assert "DRY RUN ONLY. No Kite order was placed." in out


def test_live_order_is_blocked_by_default():
    payload = build_kite_order_payload("NSE:RELIANCE", "BUY", 1, "MARKET")

    result = evaluate_kite_live_order_safety(
        payload=payload,
        settings={"enable_live_trading": False},
        risk_config={"allow_live_trading": False},
        confirm_live_order=False,
        risk_approved=False,
        allowed_symbols=[],
        env={},
    )

    assert not result.approved
    assert "environment ENABLE_LIVE_TRADING is not true" in result.reasons
    assert "environment I_UNDERSTAND_LIVE_TRADING_RISK is not true" in result.reasons
    assert "explicit command flag --confirm-live-order was not passed" in result.reasons
    assert "risk engine did not approve the order" in result.reasons
    assert "symbol is not in allowed list" in result.reasons


def test_missing_confirmation_blocks_live_order():
    payload = build_kite_order_payload("NSE:RELIANCE", "BUY", 1, "MARKET")

    result = evaluate_kite_live_order_safety(
        payload=payload,
        settings={"enable_live_trading": True},
        risk_config={"allow_live_trading": True},
        confirm_live_order=False,
        risk_approved=True,
        allowed_symbols={"NSE:RELIANCE"},
        env={"ENABLE_LIVE_TRADING": "true", "I_UNDERSTAND_LIVE_TRADING_RISK": "true"},
    )

    assert not result.approved
    assert result.reasons == ["explicit command flag --confirm-live-order was not passed"]


def test_preview_format_matches_required_safety_text():
    payload = build_kite_order_payload("NSE:RELIANCE", "BUY", 1, "MARKET")

    text = format_order_preview(payload, live_trading=False)

    assert "KITE ORDER PREVIEW" in text
    assert "Symbol: NSE:RELIANCE" in text
    assert "Transaction Type: BUY" in text
    assert "Live Trading: false" in text
    assert "DRY RUN ONLY. No Kite order was placed." in text
