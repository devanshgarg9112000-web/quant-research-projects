from __future__ import annotations

import csv

from src.config_loader import load_configs
from src.scoring.strategy_verification import (
    StrategyApprovalGate,
    canonical_strategy_name,
    evaluate_strategy_result,
    generate_strategy_approval_report,
)


def _summary(**overrides):
    row = {
        "strategy": "cluster_imbalance_trap",
        "symbol": "GOLD-I",
        "accepted": 30,
        "wins": 18,
        "losses": 12,
        "win_rate": 60,
        "gross_pnl": 4000,
        "net_pnl": 2500,
        "profit_factor": 1.6,
        "expectancy": 83.33,
        "max_drawdown": -800,
        "raw_signals": 80,
        "quality_accepted_signals": 35,
        "risk_rejected": 5,
        "sample_status": "OK",
    }
    row.update(overrides)
    return row


def test_approved_classification():
    result = evaluate_strategy_result(_summary())

    assert result.status == "APPROVED"
    assert result.confidence == "MEDIUM"


def test_watchlist_classification_and_low_trade_warning():
    result = evaluate_strategy_result(_summary(accepted=8, wins=5, losses=3, profit_factor=1.25, raw_signals=20))

    assert result.status == "WATCHLIST"
    assert result.confidence == "LOW"
    assert "LOW_TRADE_COUNT" in result.warnings


def test_rejected_classification():
    result = evaluate_strategy_result(_summary(net_pnl=-100, profit_factor=0.8))

    assert result.status == "REJECTED"


def test_high_frequency_warning_blocks_apparent_high_profit_result():
    result = evaluate_strategy_result(
        _summary(
            accepted=240,
            net_pnl=500000,
            profit_factor=2.6,
            raw_signals=3800,
            sample_status="HIGH_SIGNAL_FREQUENCY_WARNING",
        )
    )

    assert result.status == "REJECTED"
    assert "HIGH_SIGNAL_FREQUENCY" in result.warnings


def test_zero_signal_is_rejected_needs_diagnosis():
    result = evaluate_strategy_result(_summary(accepted=0, wins=0, losses=0, net_pnl=0, profit_factor=0, raw_signals=0))

    assert result.status == "REJECTED"
    assert "NEEDS_DIAGNOSIS" in result.final_recommendation


def test_strategy_approval_report_and_gate(tmp_path):
    source = tmp_path / "summary.csv"
    with source.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(_summary()))
        writer.writeheader()
        writer.writerow(_summary())
        writer.writerow(_summary(symbol="SILVER-I", net_pnl=-10, profit_factor=0.9))

    results = generate_strategy_approval_report([source], base_dir=tmp_path)
    gate = StrategyApprovalGate(
        tmp_path,
        {
            "enabled": True,
            "allow_approved": True,
            "allow_watchlist": False,
            "approval_report_path": "reports/strategy_verification/latest_strategy_approval_report.csv",
        },
    )

    assert len(results) == 2
    allowed = gate.evaluate({"symbol": "GOLD-I", "strategy": "MCX Estimated Buyer Trap Short"})
    blocked = gate.evaluate({"symbol": "SILVER-I", "strategy": "MCX Estimated Buyer Trap Short"})
    assert allowed.allowed is True
    assert blocked.allowed is False
    assert "blocked_by_strategy_verification" in blocked.reason


def test_approved_strategy_config_loading():
    configs = load_configs(".")

    assert configs["approved_strategies"]["allow_approved"] is True
    assert configs["approved_strategies"]["allow_watchlist"] is False


def test_strategy_name_canonicalization_keeps_trend_pullback_distinct():
    assert canonical_strategy_name("trend_day_vwap_pullback") == "trend_day_vwap_pullback"
    assert canonical_strategy_name("Trend Day VWAP Pullback Long") == "trend_day_vwap_pullback"
    assert canonical_strategy_name("VWAP Pullback Long") == "vwap_rejection"
