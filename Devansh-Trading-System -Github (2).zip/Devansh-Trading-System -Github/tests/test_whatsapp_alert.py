from datetime import datetime

from src.alerts.whatsapp import MISSING_MESSAGE, send_whatsapp_trade_alert
from src.models.signal import Signal


def _signal() -> Signal:
    return Signal(
        symbol="BANKNIFTY",
        timestamp=datetime(2026, 1, 1, 9, 45),
        strategy_name="Failed Breakout Short",
        side="SELL",
        entry_price=48320,
        stop_loss=48420,
        target_price=48120,
        reward_risk=2,
        score=8.5,
        reason="Buy imbalance failed above ORH, price closed back below level",
        market_mode="RANGE / TRAP_REVERSAL",
    )


def test_whatsapp_skipped_safely_when_credentials_missing(monkeypatch, capsys):
    monkeypatch.setenv("WHATSAPP_ALERTS_ENABLED", "true")
    for key in ["WHATSAPP_PROVIDER", "WHATSAPP_TO_NUMBER", "WHATSAPP_FROM_NUMBER", "TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"]:
        monkeypatch.delenv(key, raising=False)

    sent = send_whatsapp_trade_alert(_signal(), mode="PAPER", live_trading=False, config_enabled=True)

    assert sent is False
    assert MISSING_MESSAGE in capsys.readouterr().out
