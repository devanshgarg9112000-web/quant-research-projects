from __future__ import annotations

import csv
from datetime import datetime

import pytest

from src.backtesting.strategy_backtest_runner import run_strategy_backtest
from src.data_collection.historical_data_downloader import (
    BAR_COLUMNS,
    HistoricalDownloadError,
    build_historical_data_path,
    download_historical_data,
    normalize_kite_candle_response,
    normalize_truedata_tick_response,
    save_rows_dedup,
)


def test_downloader_builds_expected_file_paths(tmp_path):
    day = datetime(2026, 6, 10).date()

    tick_path = build_historical_data_path(tmp_path, "truedata", "ticks", day, "GOLD-I")
    bar_path = build_historical_data_path(tmp_path, "truedata", "bars", day, "GOLD-I", "1minute")
    kite_path = build_historical_data_path(tmp_path, "kite", "candles", day, "NSE:NIFTY 50", "minute")

    assert tick_path == tmp_path / "data" / "historical" / "truedata" / "ticks" / "2026-06-10" / "GOLD-I_ticks.csv"
    assert bar_path == tmp_path / "data" / "historical" / "truedata" / "bars" / "2026-06-10" / "GOLD-I_1minute_bars.csv"
    assert kite_path == tmp_path / "data" / "historical" / "kite" / "candles" / "2026-06-10" / "NSE_NIFTY_50_minute_candles.csv"


def test_normalizes_sample_truedata_tick_response():
    csv_text = "\n".join([
        "timestamp,ltp,volume,oi,bid,bidqty,ask,askqty",
        "2026-06-10T09:15:00,150000,2,9000,149999,1,150001,3",
    ])

    rows = normalize_truedata_tick_response(csv_text, "GOLD-I", received_at=datetime(2026, 6, 10, 9, 16))

    assert rows[0]["timestamp"] == "2026-06-10 09:15:00"
    assert rows[0]["symbol"] == "GOLD-I"
    assert rows[0]["ltp"] == 150000.0
    assert rows[0]["ltq"] == 2
    assert rows[0]["bid_qty"] == 1
    assert rows[0]["source"] == "TRUEDATA"


def test_normalizes_sample_kite_candle_response():
    rows = normalize_kite_candle_response(
        [{
            "date": datetime(2026, 6, 10, 9, 15),
            "open": 100,
            "high": 110,
            "low": 95,
            "close": 105,
            "volume": 1000,
            "oi": 10,
        }],
        "NSE:NIFTY 50",
        "minute",
    )

    assert rows[0]["timestamp"] == "2026-06-10 09:15:00"
    assert rows[0]["symbol"] == "NSE:NIFTY 50"
    assert rows[0]["close"] == 105
    assert rows[0]["source"] == "KITE"
    assert rows[0]["interval"] == "minute"


def test_missing_truedata_credentials_are_handled_safely(tmp_path):
    class Credentials:
        missing = ["TRUEDATA_USERNAME", "TRUEDATA_PASSWORD"]

    class FakeTrueData:
        credentials = Credentials()

    with pytest.raises(HistoricalDownloadError, match="missing TRUEDATA_USERNAME"):
        download_historical_data(
            base_dir=tmp_path,
            source="truedata",
            data_type="ticks",
            symbols_text="GOLD-I",
            from_date_text="2026-06-10",
            to_date_text="2026-06-10",
            truedata_client=FakeTrueData(),
            rate_limit_seconds=0,
            configs={"settings": {}, "risk": {}},
        )


def test_missing_kite_credentials_are_handled_safely(tmp_path):
    class FakeKiteBroker:
        def _missing_read_credentials(self):
            return ["KITE_API_KEY", "KITE_ACCESS_TOKEN or today's saved token from --login"]

    with pytest.raises(HistoricalDownloadError, match="missing KITE_API_KEY"):
        download_historical_data(
            base_dir=tmp_path,
            source="kite",
            data_type="candles",
            symbols_text="NSE:NIFTY 50",
            from_date_text="2026-06-10",
            to_date_text="2026-06-10",
            interval="minute",
            kite_broker=FakeKiteBroker(),
            rate_limit_seconds=0,
            configs={"settings": {}, "risk": {}},
        )


def test_duplicate_rows_are_skipped(tmp_path):
    path = tmp_path / "rows.csv"
    rows = [
        {
            "timestamp": "2026-06-10 09:15:00",
            "symbol": "GOLD-I",
            "open": 1,
            "high": 2,
            "low": 1,
            "close": 2,
            "volume": 10,
            "oi": "",
            "source": "TEST",
            "interval": "minute",
        }
    ]

    first = save_rows_dedup(path, BAR_COLUMNS, rows, ["timestamp", "symbol", "interval"])
    second = save_rows_dedup(path, BAR_COLUMNS, rows, ["timestamp", "symbol", "interval"])

    with path.open(newline="", encoding="utf-8") as f:
        saved = list(csv.DictReader(f))
    assert first.rows_written == 1
    assert second.rows_written == 0
    assert len(saved) == 1


def test_downloader_kite_uses_read_only_historical_and_never_orders(tmp_path):
    class FakeKiteBroker:
        def _missing_read_credentials(self):
            return []

        def get_instruments(self, exchange=None):
            assert exchange == "NSE"
            return [{"exchange": "NSE", "tradingsymbol": "NIFTY 50", "instrument_token": 256265}]

        def get_historical_data(self, instrument_token, from_date, to_date, interval, oi=True):
            assert instrument_token == 256265
            return [{
                "date": datetime(2026, 6, 10, 9, 15),
                "open": 100,
                "high": 110,
                "low": 95,
                "close": 105,
                "volume": 1000,
                "oi": 10,
            }]

        def place_order(self, *args, **kwargs):
            raise AssertionError("Historical downloader must not place broker orders.")

    result = download_historical_data(
        base_dir=tmp_path,
        source="kite",
        data_type="candles",
        symbols_text="NSE:NIFTY 50",
        from_date_text="2026-06-10",
        to_date_text="2026-06-10",
        interval="minute",
        kite_broker=FakeKiteBroker(),
        rate_limit_seconds=0,
        configs={"settings": {}, "risk": {}},
    )

    assert result.rows_written == 1
    assert result.files[0].path.exists()
    assert "kite" in str(result.files[0].path)


def test_backtest_runner_loads_historical_tick_dir(tmp_path):
    day = datetime(2026, 6, 10).date()
    path = build_historical_data_path(tmp_path, "truedata", "ticks", day, "GOLD-I")
    tick_rows = normalize_truedata_tick_response(
        "\n".join([
            "timestamp,ltp,volume,oi,bid,bidqty,ask,askqty",
            "2026-06-10T09:15:00,100,1,0,99,1,101,1",
            "2026-06-10T09:15:15,101,1,0,100,1,102,1",
            "2026-06-10T09:15:30,102,1,0,101,1,103,1",
            "2026-06-10T09:15:45,103,1,0,102,1,104,1",
        ]),
        "GOLD-I",
    )
    save_rows_dedup(path, list(tick_rows[0]), tick_rows, ["timestamp", "symbol", "ltp", "ltq"])

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_dir="data/historical/truedata/ticks",
        symbols_text="GOLD-I",
        strategies_text="abnormal_flow",
        configs={"settings": {}, "risk": {}, "instruments": {}},
    )

    assert result.source_kind == "TICKS"
    assert result.total_source_ticks == 4
    assert result.total_filtered_ticks == 4


def test_backtest_runner_loads_historical_bar_dir(tmp_path):
    day = datetime(2026, 6, 10).date()
    path = build_historical_data_path(tmp_path, "kite", "candles", day, "NSE:NIFTY 50", "minute")
    rows = normalize_kite_candle_response(
        [
            {"date": datetime(2026, 6, 10, 9, 15), "open": 100, "high": 101, "low": 99, "close": 100, "volume": 100},
            {"date": datetime(2026, 6, 10, 9, 16), "open": 100, "high": 102, "low": 99, "close": 101, "volume": 100},
            {"date": datetime(2026, 6, 10, 9, 17), "open": 101, "high": 103, "low": 100, "close": 102, "volume": 100},
            {"date": datetime(2026, 6, 10, 9, 18), "open": 102, "high": 104, "low": 101, "close": 103, "volume": 100},
        ],
        "NSE:NIFTY 50",
        "minute",
    )
    save_rows_dedup(path, BAR_COLUMNS, rows, ["timestamp", "symbol", "interval"])

    result = run_strategy_backtest(
        base_dir=tmp_path,
        bar_dir="data/historical/kite/candles",
        symbols_text="NSE:NIFTY 50",
        strategies_text="abnormal_flow",
        configs={"settings": {}, "risk": {}, "instruments": {}},
    )

    assert result.source_kind == "BARS"
    assert result.total_source_bars == 4
    assert result.total_filtered_bars == 4


def test_bar_dir_runs_candle_strategy_and_simulates_future_bars(tmp_path, monkeypatch):
    from types import SimpleNamespace

    import src.backtesting.strategy_backtest_runner as runner
    from src.models.signal import Signal

    day = datetime(2026, 6, 10).date()
    path = build_historical_data_path(tmp_path, "truedata", "bars", day, "GOLD-I", "1minute")
    rows = [
        {
            "timestamp": f"2026-06-10 09:{15 + index:02d}:00",
            "symbol": "GOLD-I",
            "open": 100 + index,
            "high": 102 + index,
            "low": 99 + index,
            "close": 101 + index,
            "volume": 100,
            "oi": "",
            "source": "TRUEDATA",
            "interval": "1minute",
        }
        for index in range(8)
    ]
    save_rows_dedup(path, BAR_COLUMNS, rows, ["timestamp", "symbol", "interval"])

    class FakeStrategyEngine:
        def __init__(self, *_args, **_kwargs):
            pass

        def run(self, candles, ticks):
            assert ticks == []
            last = candles[-1]
            signal = Signal(
                symbol="GOLD-I",
                timestamp=last["timestamp"],
                strategy_name="Bar Test",
                side="BUY",
                entry_price=last["close"],
                stop_loss=last["close"] - 10,
                target_price=last["close"] + 20,
                reward_risk=2,
                score=8,
                reason="bar strategy test",
                market_mode="TREND_UP",
                setup_type="abnormal_flow",
            )
            return SimpleNamespace(candidates=[signal], context={"cluster_gate": {}})

    class FakeRiskEngine:
        def __init__(self, *_args, **_kwargs):
            pass

        def validate_signal(self, *_args, **_kwargs):
            return SimpleNamespace(
                approved=True,
                quantity=1,
                sizing={"allowed_risk_amount": 500, "estimated_risk_amount": 10},
                reasons=[],
                risk_amount=10,
            )

    monkeypatch.setattr(runner, "StrategyEngine", FakeStrategyEngine)
    monkeypatch.setattr(runner, "RiskEngine", FakeRiskEngine)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        bar_dir="data/historical/truedata/bars",
        symbols_text="GOLD-I",
        strategies_text="abnormal_flow",
        exit_at_end=True,
        configs={"settings": {}, "risk": {}, "instruments": {}, "strategy_quality": {"enabled": False}},
    )

    assert result.source_kind == "BARS"
    assert result.trade_rows
    assert result.trade_rows[0]["entry_time"] > result.trade_rows[0]["signal_time"]
    assert result.trade_rows[0]["execution_allowed"] is False
