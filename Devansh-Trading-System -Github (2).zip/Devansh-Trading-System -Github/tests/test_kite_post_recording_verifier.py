from __future__ import annotations

import csv
from datetime import date, datetime
from pathlib import Path

from src.data_collection.kite_post_recording_verifier import (
    DAY_ACCEPTED_FOR_RESEARCH,
    DAY_MARKET_CLOSED_OR_NO_DATA,
    DAY_PARTIAL_BUT_KEEP,
    DAY_REQUIRES_INVESTIGATION,
    DATA_COLLECTION_REPORT_PATH,
    RUN_LOG_PATH,
    verify_kite_post_recording,
)
from src.data_collection.market_data_schema import (
    KITE_DEPTH_COLUMNS,
    KITE_TICK_COLUMNS,
    ORDERFLOW_LITE_COLUMNS,
    kite_depth_path,
    kite_feature_path,
    kite_tick_path,
)


DAY = date(2026, 6, 20)


def _configs() -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "forward_validation": {"production_alerts_allowed": False},
    }


def _tick_row(timestamp: str = "2026-06-20 09:15:00") -> dict[str, str]:
    return {
        "timestamp": timestamp,
        "symbol": "GOLD-I",
        "internal_symbol": "GOLD-I",
        "kite_exchange": "MCX",
        "kite_tradingsymbol": "GOLD26AUGFUT",
        "instrument_token": "119445255",
        "expiry": "2026-08-05",
        "data_mode": "REAL_READ_ONLY",
        "is_synthetic": "false",
        "ltp": "150000",
        "source": "KITE",
        "received_at": timestamp,
    }


def _depth_row(timestamp: str = "2026-06-20 09:15:00") -> dict[str, str]:
    return {
        "timestamp": timestamp,
        "symbol": "GOLD-I",
        "internal_symbol": "GOLD-I",
        "kite_exchange": "MCX",
        "kite_tradingsymbol": "GOLD26AUGFUT",
        "instrument_token": "119445255",
        "expiry": "2026-08-05",
        "data_mode": "REAL_READ_ONLY",
        "is_synthetic": "false",
        "level": "1",
        "bid_price": "149999",
        "ask_price": "150001",
        "source": "KITE",
        "received_at": timestamp,
    }


def _feature_row(
    timestamp: str = "2026-06-20 09:15:00",
    *,
    tradingsymbol: str = "GOLD26AUGFUT",
    token: str = "119445255",
    expiry: str = "2026-08-05",
    synthetic: str = "false",
) -> dict[str, str]:
    return {
        "timestamp": timestamp,
        "symbol": "GOLD-I",
        "internal_symbol": "GOLD-I",
        "kite_exchange": "MCX",
        "kite_tradingsymbol": tradingsymbol,
        "instrument_token": token,
        "expiry": expiry,
        "data_mode": "DRY_RUN" if synthetic == "true" else "REAL_READ_ONLY",
        "is_synthetic": synthetic,
        "last_price": "150000",
        "has_depth": "true",
        "data_quality": "DEPTH_AVAILABLE",
        "feature_mode": "DEPTH_ORDERFLOW_LITE",
        "source": "KITE_ORDERFLOW_LITE",
    }


def _write_csv(path: Path, columns: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows({column: row.get(column, "") for column in columns} for row in rows)


def _write_reports(
    base: Path,
    *,
    feature_rows: int,
    quality_status: str = "READY_FOR_FORWARD_VALIDATION",
    contract_status: str = "REAL_CONTRACT_SELECTED",
    safe: bool = True,
) -> None:
    pipeline = base / "reports" / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"
    pipeline.parent.mkdir(parents=True, exist_ok=True)
    pipeline.write_text(
        "\n".join(
            [
                "KITE DAILY PIPELINE REPORT",
                "Mode: PAPER",
                f"Live Trading: {'DISABLED' if safe else 'ENABLED'}",
                f"Broker Orders: {'DISABLED' if safe else 'ENABLED'}",
                f"execution_allowed={'false' if safe else 'true'}",
                f"Feature output CSV data rows: {feature_rows}",
                "",
                "CONTRACT CONSISTENCY",
                f"status: {contract_status}",
                "",
                "DATA QUALITY GATE",
                f"status: {quality_status}",
                "",
                f"Production WhatsApp Alerts: {'BLOCKED' if safe else 'ALLOWED'}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    forward = base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"
    forward.parent.mkdir(parents=True, exist_ok=True)
    forward.write_text(
        "\n".join(
            [
                "GOLD-I VWAP REJECTION SHORT FORWARD VALIDATION SUMMARY",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
                "Approval Decision: RESEARCH_ONLY",
            ]
        )
        + "\n",
        encoding="utf-8",
    )




def _write_feature_builder_report(
    base: Path,
    *,
    feature_rows: int,
    tick_rows: int = 2,
    depth_rows: int = 2,
    clean: bool = True,
    contract_status: str = "CONSISTENT",
    market_status: str = "FULL_DEPTH",
    csv_match: bool = True,
    metadata_complete: bool = True,
) -> None:
    report = base / "reports" / "kite_data_collection" / "latest_kite_data_collection_report.txt"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(
        "\n".join(
            [
                "KITE DATA COLLECTION REPORT",
                "Mode: PAPER",
                "Kite Mode: READ_ONLY",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "",
                "LAST OPERATION",
                "Last operation type: feature_builder",
                f"Features generated in last operation: {feature_rows}",
                f"Tick rows loaded: {tick_rows}",
                f"Depth rows loaded: {depth_rows}",
                f"Output CSV data row count: {feature_rows}",
                "Feature mode: DEPTH_ORDERFLOW_LITE",
                f"Market data status: {market_status}",
                f"Contract consistency status: {contract_status}",
                "Selected contract: GOLD-I:MCX:GOLD26AUGFUT instrument_token=119445255 expiry=2026-08-05 data_mode=REAL_READ_ONLY synthetic=false",
                f"Report/CSV contract match: {str(csv_match).lower()}",
                f"Contract metadata complete: {str(metadata_complete).lower()}",
                "Errors: NONE" if clean else "Errors: Feature builder failed",
                "",
                "PAPER MODE ONLY. Kite read-only data calls only. No broker orders were placed.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def _write_stale_failed_pipeline_report(base: Path) -> None:
    _write_reports(
        base,
        feature_rows=0,
        quality_status="MARKET_CLOSED_OR_NO_LIVE_DATA",
        contract_status="NOT_CHECKED",
    )
    pipeline = base / "reports" / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"
    text = pipeline.read_text(encoding="utf-8")
    text = text.replace("Feature output CSV data rows: 0", "Feature output CSV data rows: 0")
    text += "\nSTEP STATUS\n- recorder: FAIL\n\nERRORS\n- Kite live recorder failed safely: MemoryError.\n"
    pipeline.write_text(text, encoding="utf-8")

def _write_clean_day(base: Path, feature_rows: list[dict[str, str]] | None = None) -> None:
    features = feature_rows if feature_rows is not None else [_feature_row()]
    _write_csv(kite_tick_path(base, DAY, "GOLD-I"), KITE_TICK_COLUMNS, [_tick_row()])
    _write_csv(kite_depth_path(base, DAY, "GOLD-I"), KITE_DEPTH_COLUMNS, [_depth_row()])
    _write_csv(kite_feature_path(base, DAY, "GOLD-I"), ORDERFLOW_LITE_COLUMNS, features)
    _write_reports(base, feature_rows=len(features))


def test_accepted_day_with_clean_tick_depth_features(tmp_path):
    _write_clean_day(tmp_path)

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 20, 23, 0),
    )

    assert result.verdict == DAY_ACCEPTED_FOR_RESEARCH
    assert result.tick_rows == 1
    assert result.depth_rows == 1
    assert result.feature_rows == 1
    assert result.synthetic_rows_found == 0
    assert result.mixed_contracts_found is False
    assert "GOLD26AUGFUT" in result.symbol_results[0].selected_contract
    assert "expiry=2026-08-05" in result.symbol_results[0].selected_contract
    assert result.forward_validation_decision == "RESEARCH_ONLY"
    assert result.report_path.exists()
    assert result.run_log_path.exists()


def test_no_tick_file_is_market_closed_or_no_data(tmp_path):
    _write_csv(kite_feature_path(tmp_path, DAY, "GOLD-I"), ORDERFLOW_LITE_COLUMNS, [])
    _write_reports(tmp_path, feature_rows=0, quality_status="MARKET_CLOSED_OR_NO_LIVE_DATA")

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.verdict == DAY_MARKET_CLOSED_OR_NO_DATA
    assert result.tick_rows == 0


def test_tick_exists_but_features_zero_is_partial_when_report_is_not_failure(tmp_path):
    _write_csv(kite_tick_path(tmp_path, DAY, "GOLD-I"), KITE_TICK_COLUMNS, [_tick_row()])
    _write_csv(kite_depth_path(tmp_path, DAY, "GOLD-I"), KITE_DEPTH_COLUMNS, [_depth_row()])
    _write_csv(kite_feature_path(tmp_path, DAY, "GOLD-I"), ORDERFLOW_LITE_COLUMNS, [])
    _write_reports(tmp_path, feature_rows=0, quality_status="PARTIAL_DATA_KEEP_RECORDING")

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.verdict == DAY_PARTIAL_BUT_KEEP
    assert result.feature_rows == 0


def test_mixed_real_contracts_require_investigation(tmp_path):
    _write_clean_day(
        tmp_path,
        [
            _feature_row(timestamp="2026-06-20 09:15:00"),
            _feature_row(
                timestamp="2026-06-20 09:16:00",
                tradingsymbol="GOLD26JULFUT",
                token="111",
                expiry="2026-07-20",
            ),
        ],
    )

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.verdict == DAY_REQUIRES_INVESTIGATION
    assert result.mixed_contracts_found is True


def test_synthetic_feature_row_requires_investigation(tmp_path):
    _write_clean_day(
        tmp_path,
        [
            _feature_row(),
            _feature_row(
                timestamp="2026-06-20 09:16:00",
                tradingsymbol="GOLD26JULFUT",
                token="900001",
                expiry="2026-07-20",
                synthetic="true",
            ),
        ],
    )

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.verdict == DAY_REQUIRES_INVESTIGATION
    assert result.synthetic_rows_found == 1


def test_verifier_report_created_and_run_log_appends(tmp_path):
    _write_clean_day(tmp_path)

    first = verify_kite_post_recording(tmp_path, symbols_text="GOLD-I", day=DAY, configs=_configs())
    second = verify_kite_post_recording(tmp_path, symbols_text="GOLD-I", day=DAY, configs=_configs())

    report = first.report_path.read_text(encoding="utf-8")
    assert "VERDICT: DAY_ACCEPTED_FOR_RESEARCH" in report
    assert "Production WhatsApp Alerts: BLOCKED" in report
    assert "execution_allowed=false" in report
    with (tmp_path / RUN_LOG_PATH).open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 2
    assert rows[-1]["execution_allowed"] == "false"
    assert second.run_log_path == tmp_path / RUN_LOG_PATH


def test_verifier_module_has_no_order_execution_path_text():
    module_path = Path(__file__).resolve().parents[1] / "src" / "data_collection" / "kite_post_recording_verifier.py"
    text = module_path.read_text(encoding="utf-8")

    assert "place_order" not in text
    assert "execution_allowed=false" in text


def test_stale_failed_pipeline_clean_feature_builder_report_accepts_day(tmp_path):
    _write_clean_day(tmp_path)
    _write_stale_failed_pipeline_report(tmp_path)
    _write_feature_builder_report(tmp_path, feature_rows=1, tick_rows=1, depth_rows=1)

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.verdict == DAY_ACCEPTED_FOR_RESEARCH
    assert result.authoritative_feature_source == "DATA_COLLECTION_FEATURE_BUILDER_REPORT"
    assert result.feature_rebuild_reconciliation_status == "RECONCILED"
    assert result.pipeline_report_stale_or_failed is True
    assert result.manual_feature_rebuild_reconciled is True
    report = result.report_path.read_text(encoding="utf-8")
    assert "Authoritative feature source used: DATA_COLLECTION_FEATURE_BUILDER_REPORT" in report
    assert "Daily pipeline report was stale/failed" in report
    assert "Long continuous recorder failed with MemoryError" in report


def test_stale_failed_pipeline_without_clean_feature_builder_requires_investigation(tmp_path):
    _write_clean_day(tmp_path)
    _write_stale_failed_pipeline_report(tmp_path)
    _write_feature_builder_report(tmp_path, feature_rows=1, tick_rows=1, depth_rows=1, clean=False)

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.verdict == DAY_REQUIRES_INVESTIGATION
    assert result.authoritative_feature_source == "ACTUAL_CSV_ONLY"
    assert result.feature_rebuild_reconciliation_status == "NOT_RECONCILED"


def test_pipeline_feature_count_mismatch_reconciled_by_data_collection_report(tmp_path):
    features = [_feature_row(), _feature_row(timestamp="2026-06-20 09:16:00")]
    _write_clean_day(tmp_path, features)
    _write_stale_failed_pipeline_report(tmp_path)
    _write_feature_builder_report(tmp_path, feature_rows=2, tick_rows=2, depth_rows=2)

    result = verify_kite_post_recording(
        tmp_path,
        symbols_text="GOLD-I",
        day=DAY,
        configs=_configs(),
    )

    assert result.feature_rows == 2
    assert result.report_feature_count_match is False
    assert result.data_collection_feature_count_match is True
    assert result.verdict == DAY_ACCEPTED_FOR_RESEARCH
    assert result.authoritative_feature_source == "DATA_COLLECTION_FEATURE_BUILDER_REPORT"


def test_clean_feature_builder_does_not_override_synthetic_rows(tmp_path):
    _write_clean_day(
        tmp_path,
        [
            _feature_row(),
            _feature_row(
                timestamp="2026-06-20 09:16:00",
                tradingsymbol="GOLD26JULFUT",
                token="900001",
                expiry="2026-07-20",
                synthetic="true",
            ),
        ],
    )
    _write_stale_failed_pipeline_report(tmp_path)
    _write_feature_builder_report(tmp_path, feature_rows=2, tick_rows=2, depth_rows=2)

    result = verify_kite_post_recording(tmp_path, symbols_text="GOLD-I", day=DAY, configs=_configs())

    assert result.verdict == DAY_REQUIRES_INVESTIGATION
    assert result.synthetic_rows_found == 1


def test_clean_feature_builder_does_not_override_expected_contract_mismatch(tmp_path):
    _write_clean_day(
        tmp_path,
        [
            _feature_row(
                tradingsymbol="SILVER26JULFUT",
                token="111",
                expiry="2026-07-20",
            )
        ],
    )
    _write_stale_failed_pipeline_report(tmp_path)
    _write_feature_builder_report(tmp_path, feature_rows=1, tick_rows=1, depth_rows=1)

    result = verify_kite_post_recording(tmp_path, symbols_text="GOLD-I", day=DAY, configs=_configs())

    assert result.verdict == DAY_REQUIRES_INVESTIGATION
    assert result.symbol_results[0].expected_contract_match is False


def test_execution_allowed_true_still_rejects_even_with_clean_feature_builder(tmp_path):
    _write_clean_day(tmp_path)
    _write_reports(tmp_path, feature_rows=0, safe=False)
    _write_feature_builder_report(tmp_path, feature_rows=1, tick_rows=1, depth_rows=1)

    result = verify_kite_post_recording(tmp_path, symbols_text="GOLD-I", day=DAY, configs=_configs())

    assert result.verdict == "DAY_REJECTED_BAD_DATA"
    assert result.safety_ok is False
