from src.backtesting.engine import BacktestEngine
from src.backtesting.reports import save_backtest_report
from src.config_loader import load_configs
from src.data.sample_data import generate_sample_candles, generate_sample_ticks


def test_strategy_wise_backtest_report_file_is_generated(tmp_path):
    configs = load_configs(".")
    result = BacktestEngine(configs["settings"], configs["risk"], configs["strategies"]).run(
        generate_sample_candles(),
        generate_sample_ticks(),
    )

    report_path = save_backtest_report(result.combined_trades, result.strategy_trades, configs["strategies"], tmp_path)
    text = report_path.read_text(encoding="utf-8")

    assert report_path.exists()
    assert "FULL COMBINED SYSTEM PERFORMANCE" in text
    assert "INDIVIDUAL STRATEGY-WISE PERFORMANCE" in text
    assert "Review:" in text
