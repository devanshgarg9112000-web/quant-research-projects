from __future__ import annotations

import csv
from pathlib import Path

from src.reports.strategy_identity_report import generate_strategy_identity_report, main


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _strategy_identity_yaml() -> str:
    return """families:
  gold_vwap_rejection_reclaim_family:
    status: RESEARCH_ONLY
    real_money_approved: false
    production_alerts_allowed: false
    approval_review_requirements:
      minimum_backtest_trades: 100
      minimum_backtest_days: 20
      minimum_forward_trades: 30
      minimum_forward_days: 5
      minimum_distinct_sessions: 5
      minimum_profit_factor: 1.30
      maximum_drawdown_allowed_points: null
      requires_cost_slippage_spread: true
      requires_oos_or_walk_forward: true
      requires_forward_independence: true
      requires_manual_risk_plan: true
    canonical_setups:
      gold_vwap_rejection_short:
        aliases:
          - vwap_rejection
          - vwap_rejection_short
          - gold_vwap_rejection_short
        direction: short
        module: vwap_rejection
        forward_validation_id: gold_vwap_rejection_short
        approval_id: gold_vwap_rejection_short
        status: RESEARCH_ONLY
      gold_vwap_reclaim_long:
        aliases:
          - vwap_reclaim
          - vwap_reclaim_long
        direction: long
        module: vwap_reclaim
        status: RESEARCH_ONLY
      trend_day_vwap_pullback:
        aliases:
          - trend_day_vwap_pullback
        direction: long_or_short
        module: trend_day_vwap_pullback
        status: RESEARCH_ONLY
"""


def _seed_identity_project(base: Path) -> None:
    _write(base / "config" / "strategy_identity.yaml", _strategy_identity_yaml())
    _write(
        base / "config" / "strategies.yaml",
        "\n".join(
            [
                "strategies:",
                "  trend_following: true",
                "  breakout_acceptance: true",
                "  breakdown_acceptance: true",
                "  failed_breakout: true",
                "  failed_breakdown: true",
                "  vwap_reclaim: true",
                "  vwap_rejection: true",
                "  value_area_rejection: true",
                "  poc_magnet: true",
                "  trend_day_vwap_pullback: true",
                "  cluster_imbalance_trap: true",
                "  abnormal_flow: true",
                "  opening_option_mispricing: false",
                "  mcx_metals: false",
            ]
        )
        + "\n",
    )
    _write(
        base / "config" / "forward_validation.yaml",
        "\n".join(
            [
                "enabled: true",
                "strategy: gold_vwap_rejection_short",
                "symbols: [\"GOLD-I\"]",
                "production_alerts_allowed: false",
            ]
        )
        + "\n",
    )
    strategy_names = [
        "abnormal_flow",
        "base_strategy",
        "breakdown_acceptance",
        "breakout_acceptance",
        "cluster_imbalance_trap",
        "cluster_signal_quality",
        "failed_breakdown",
        "failed_breakout",
        "mcx_metals",
        "opening_option_mispricing",
        "poc_magnet",
        "strategy_engine",
        "trend_day_vwap_pullback",
        "value_area_rejection",
        "vwap_reclaim",
        "vwap_rejection",
    ]
    for name in strategy_names:
        _write(base / "src" / "strategies" / f"{name}.py", "# fixture\n")
    _write(
        base / "src" / "strategies" / "strategy_engine.py",
        "STRATEGY_MODULES = {\n"
        "    'breakout_acceptance': object(),\n"
        "    'breakdown_acceptance': object(),\n"
        "    'failed_breakout': object(),\n"
        "    'failed_breakdown': object(),\n"
        "    'vwap_reclaim': object(),\n"
        "    'vwap_rejection': object(),\n"
        "    'value_area_rejection': object(),\n"
        "    'poc_magnet': object(),\n"
        "    'trend_day_vwap_pullback': object(),\n"
        "    'cluster_imbalance_trap': object(),\n"
        "    'abnormal_flow': object(),\n"
        "    'opening_option_mispricing': object(),\n"
        "    'mcx_metals': object(),\n"
        "}\n",
    )
    _write(
        base / "src" / "backtesting" / "strategy_backtest_runner.py",
        "BACKTEST_STRATEGIES = [\n"
        "    'trend_following', 'breakout_acceptance', 'breakdown_acceptance',\n"
        "    'failed_breakout', 'failed_breakdown', 'vwap_reclaim', 'vwap_rejection',\n"
        "    'value_area_rejection', 'poc_magnet', 'trend_day_vwap_pullback',\n"
        "    'cluster_imbalance_trap', 'abnormal_flow',\n"
        "]\n",
    )
    _write(
        base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv",
        "\n".join(
            [
                "strategy,symbol,status,confidence,trades,win_rate,net_pnl,profit_factor,expectancy,warnings,final_recommendation",
                "trend_following,GOLD-I,REJECTED,LOW,0,0,0,0,0,NO_USABLE_SIGNALS,NEEDS_DIAGNOSIS",
                "vwap_rejection,GOLD-I,REJECTED,MEDIUM,67,43.94,-761,0.96,-11.36,HIGH_DRAWDOWN,REJECTED",
                "abnormal_flow,GOLD-I,REJECTED,LOW,0,0,0,0,0,NO_USABLE_SIGNALS,NEEDS_DIAGNOSIS",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_research" / "latest_strategy_research_report.csv",
        "\n".join(
            [
                "strategy,symbol,status,confidence,trades,win_rate,net_pnl,profit_factor,expectancy,warnings,final_recommendation",
                "research_lab__gold_i__vrs,GOLD-I,WATCHLIST,LOW,5,60,1508.14,2.81,301.63,LOW_TRADE_COUNT,\"vwap_rejection_short: WATCHLIST; isolated research ID\"",
                "research_lab__gold_i__vrl,GOLD-I,WATCHLIST,LOW,14,50,1851.86,1.51,132.28,LOW_TRADE_COUNT,\"vwap_reclaim_long: WATCHLIST; isolated research ID\"",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt",
        "\n".join(
            [
                "GOLD-I VWAP REJECTION SHORT FORWARD VALIDATION SUMMARY",
                "Approval Decision: RESEARCH_ONLY",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )


def test_strategy_identity_report_outputs_expected_classifications(tmp_path: Path) -> None:
    _seed_identity_project(tmp_path)

    result = generate_strategy_identity_report(tmp_path)
    report = result.report_path.read_text(encoding="utf-8")
    rows = {row["canonical_strategy_id"]: row for row in result.rows}

    assert result.report_path.exists()
    assert result.csv_path.exists()
    assert rows["trend_following"]["role"] == "missing_module"
    assert rows["abnormal_flow_filter"]["role"] == "filter_or_confirmation"
    assert rows["opening_option_mispricing_scanner"]["role"] == "scanner_only"
    assert rows["mcx_metals_placeholder"]["role"] == "placeholder"
    assert rows["gold_vwap_rejection_short"]["current_status"] == "RESEARCH_ONLY"
    assert result.approved_strategy_count == 0
    assert "Approved strategy count: 0" in report
    assert "Real Money Approval: false" in report
    assert "Production WhatsApp Alerts: BLOCKED" in report
    assert "execution_allowed=false" in report
    assert "GOLD-I VWAP rejection/reclaim family" in report
    assert "Canonical strategy identity config: FOUND" in report
    assert "GOLD VWAP identity consistency: CONSISTENT" in report
    assert "GOLD VWAP family status: RESEARCH_ONLY" in report
    assert "GOLD VWAP real-money approved: false" in report
    assert "GOLD VWAP production alerts allowed: false" in report
    assert "GOLD VWAP approval thresholds configured: true" in report
    assert "GOLD VWAP required forward trades: 30" in report
    assert "GOLD VWAP required backtest trades: 100" in report
    config_text = (tmp_path / "config" / "strategy_identity.yaml").read_text(encoding="utf-8")
    assert "gold_vwap_rejection_reclaim_family" in config_text
    assert "vwap_rejection_short" in config_text
    assert "gold_vwap_rejection_short" in config_text
    assert "real_money_approved: false" in config_text
    assert "production_alerts_allowed: false" in config_text
    assert ("place" + "_order") not in report


def test_strategy_identity_csv_has_required_columns(tmp_path: Path) -> None:
    _seed_identity_project(tmp_path)

    result = generate_strategy_identity_report(tmp_path)
    with result.csv_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))

    assert rows
    assert "canonical_strategy_id" in rows[0]
    assert "current_status" in rows[0]
    assert "recommended_action" in rows[0]
    assert any(row["recommended_action"] == "CONSOLIDATE" for row in rows)


def test_strategy_identity_cli_runs_without_credentials(tmp_path: Path, monkeypatch) -> None:
    _seed_identity_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main([]) == 0
    report = tmp_path / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt"
    csv_path = tmp_path / "reports" / "strategy_identity" / "strategy_identity_map.csv"
    assert report.exists()
    assert csv_path.exists()
    assert "No live data was requested by this report." in report.read_text(encoding="utf-8")
