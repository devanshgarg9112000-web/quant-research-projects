from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from src.reports.backtest_data_coverage_report import generate_backtest_data_coverage_report, main


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "config" / "strategies.yaml",
        "strategies:\n"
        "  vwap_rejection: true\n"
        "  vwap_reclaim: true\n"
        "  cluster_imbalance_trap: true\n"
        "  abnormal_flow: true\n"
        "  opening_option_mispricing: false\n",
    )
    _write(
        base / "reports" / "strategy_identity" / "strategy_identity_map.csv",
        "canonical_strategy_id,module_name,config_key,backtest_key,role,current_status,recommended_action,known_gaps\n"
        "gold_vwap_rejection_short,vwap_rejection,vwap_rejection,vwap_rejection,standalone_strategy,RESEARCH_ONLY,KEEP_RESEARCH,low sample\n"
        "vwap_reclaim_family,vwap_reclaim,vwap_reclaim,vwap_reclaim,standalone_strategy,REJECTED,KEEP_RESEARCH,low sample\n"
        "mcx_cluster_orderflow_trap,cluster_imbalance_trap,cluster_imbalance_trap,cluster_imbalance_trap,standalone_strategy,REJECTED,NEEDS_MORE_DATA,tick data\n"
        "abnormal_flow_filter,abnormal_flow,abnormal_flow,abnormal_flow,filter_or_confirmation,REJECTED,CONVERT_TO_FILTER,filter only\n",
    )
    _write(
        base / "src" / "strategies" / "vwap_rejection.py",
        "def generate_signal(*args, **kwargs): return None\n",
    )
    _write(
        base / "src" / "strategies" / "vwap_reclaim.py",
        "def generate_signal(*args, **kwargs): return None\n",
    )
    _write(
        base / "src" / "strategies" / "cluster_imbalance_trap.py",
        "def generate_signal(*args, **kwargs): return None\n",
    )
    _write(
        base / "src" / "strategies" / "abnormal_flow.py",
        "def detect(*args, **kwargs): return None\n",
    )
    _write(
        base / "data" / "historical" / "truedata" / "bars" / "2026-06-19" / "GOLD-I_1minute_bars.csv",
        "timestamp,symbol,open,high,low,close,volume,oi,source,interval\n"
        "2026-06-19T09:00:00,GOLD-I,100,101,99,100,10,,TRUEDATA,1minute\n"
        "2026-06-19T09:01:00,GOLD-I,100,102,98,101,12,,TRUEDATA,1minute\n",
    )
    _write(
        base / "data" / "kite_recorded" / "features" / "2026-06-23" / "GOLD-I_orderflow_lite.csv",
        "timestamp,internal_symbol,last_price,feature_mode\n"
        "2026-06-23T13:26:00,GOLD-I,145950,DEPTH_ORDERFLOW_LITE\n",
    )


def test_backtest_data_coverage_report_created(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_backtest_data_coverage_report(tmp_path, now=datetime(2026, 6, 23, 22, 45))
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.csv_path.exists()
    assert "backtest_data_coverage_status:" in report
    assert "STRATEGY READINESS BUCKETS" in report
    assert "REGIME COVERAGE READINESS" in report
    assert "REGIME_LABELS_MISSING" in report
    assert "all_strategies_reliable: false" in report
    assert "real_money_approval_allowed: false" in report
    assert "execution_allowed=false" in report
    forbidden = "place" + "_order"
    assert forbidden not in report

    with result.csv_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows
    assert any(row["record_type"] == "DATA" for row in rows)
    assert any(row["record_type"] == "STRATEGY" for row in rows)
    assert any(row["readiness_bucket"] == "FILTER_ONLY_NOT_STANDALONE" for row in rows)


def test_backtest_data_coverage_report_runs_with_missing_data_folders(tmp_path: Path) -> None:
    _write(
        tmp_path / "config" / "strategies.yaml",
        "strategies:\n  vwap_rejection: true\n",
    )
    _write(
        tmp_path / "src" / "strategies" / "vwap_rejection.py",
        "def generate_signal(*args, **kwargs): return None\n",
    )

    result = generate_backtest_data_coverage_report(tmp_path, now=datetime(2026, 6, 23, 22, 45))
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.csv_path.exists()
    assert "No local historical/recorded CSV data folders were found." in report
    assert "multi_year_backtest_ready: false" in report
    assert "all_strategies_reliable: false" in report
    assert "real_money_approval_allowed: false" in report


def test_backtest_data_coverage_cli_runs(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main([]) == 0
    assert (tmp_path / "reports" / "strategy_audits" / "latest_backtest_data_coverage_report.txt").exists()
    assert (tmp_path / "reports" / "strategy_audits" / "backtest_data_coverage_matrix.csv").exists()
