from __future__ import annotations

from pathlib import Path

from src.reports.backtest_execution_quality_gate import (
    SUPPORTED_FAMILY,
    generate_backtest_execution_quality_gate,
    main,
)


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _strategy_identity_yaml() -> str:
    return """families:
  gold_vwap_rejection_reclaim_family:
    status: RESEARCH_ONLY
    real_money_approved: false
    production_alerts_allowed: false
    approval_review_requirements:
      minimum_backtest_trades: 100
      minimum_backtest_days: 20
      minimum_forward_trades: 30
      minimum_forward_days: 5
      minimum_distinct_sessions: 5
      minimum_profit_factor: 1.30
      maximum_drawdown_allowed_points: null
      requires_cost_slippage_spread: true
      requires_oos_or_walk_forward: true
      requires_forward_independence: true
      requires_manual_risk_plan: true
    canonical_setups:
      gold_vwap_rejection_short:
        aliases:
          - vwap_rejection
          - vwap_rejection_short
          - gold_vwap_rejection_short
        direction: short
        module: vwap_rejection
        forward_validation_id: gold_vwap_rejection_short
        approval_id: gold_vwap_rejection_short
        status: RESEARCH_ONLY
      gold_vwap_reclaim_long:
        aliases:
          - vwap_reclaim
          - vwap_reclaim_long
        direction: long
        module: vwap_reclaim
        status: RESEARCH_ONLY
      trend_day_vwap_pullback:
        aliases:
          - trend_day_vwap_pullback
        direction: long_or_short
        module: trend_day_vwap_pullback
        status: RESEARCH_ONLY
"""


def _seed_project(base: Path) -> None:
    _write(base / "config" / "strategy_identity.yaml", _strategy_identity_yaml())
    _write(
        base / "reports" / "strategy_audits" / "latest_vwap_family_backtest_bias_audit.txt",
        "\n".join(
            [
                "GOLD-I VWAP FAMILY BACKTEST BIAS AUDIT",
                "VWAP_FAMILY_BACKTEST_APPROVAL_READY: false",
                "Bias risk: MEDIUM",
                "Fill realism risk: HIGH",
                "Cost/slippage completeness: PARTIAL",
                "Evidence trust level: LOW",
                "Required guard: signal candle close must be treated as decision time, with entry at next candle open or next available quote/tick.",
                "RECOMMENDED NEXT 5 FIXES",
                "4. Re-run backtests with conservative fills and same-bar stop-first assumptions.",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt",
        "\n".join(
            [
                "canonical_family_id: gold_vwap_rejection_reclaim_family",
                "Approved strategy count: 0",
                "Current family approval status: RESEARCH_ONLY",
                "Forward trades count: 5",
                "Forward approval decision: RESEARCH_ONLY",
                "canonical identity complete: partial",
                "Stop-loss/invalidation availability: available",
                "Target/risk-reward availability: available",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt",
        "Duplicate/overlapping strategy identities: vwap_rejection/vwap_rejection_short/gold_vwap_rejection_short are fragmented.\n",
    )
    _write(base / "config" / "approved_strategies.yaml", "allow_approved: true\n")
    _write(base / "config" / "strategies.yaml", "strategies:\n  vwap_rejection: true\n")
    _write(
        base / "src" / "backtesting" / "strategy_backtest_runner.py",
        "slippage_points = 0.0\ncost_per_trade = 0.0\nentry_delay_ticks = 1\n",
    )
    _write(base / "src" / "research" / "vwap_rejection_deep_dive.py", "SLIPPAGE_POINTS = 5.0\n")


def test_backtest_execution_quality_gate_report_fails_for_current_vwap_family(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_backtest_execution_quality_gate(tmp_path, family=SUPPORTED_FAMILY)
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.overall_gate == "FAIL"
    assert result.approval_grade_backtest_ready is False
    assert result.real_money_approval_allowed is False
    assert result.failed_gates_count >= 1
    assert "Overall gate: FAIL" in report
    assert "Approval-grade backtest ready: false" in report
    assert "Real-money approval allowed: false" in report
    assert "Same-bar stop-first ambiguity rule defined" in report
    assert "Cost model defined" in report
    assert "Slippage/spread model defined" in report
    assert "Sample-size threshold defined | PASS" in report
    assert "sample_size_threshold_defined: true" in report
    assert "approval_review_requirements_source: config/strategy_identity.yaml" in report
    assert "current_forward_trades: 5" in report
    assert "required_forward_trades: 30" in report
    assert "forward_sample_sufficient: false" in report
    assert "required_backtest_trades: 100" in report
    assert "backtest_sample_sufficient: false" in report
    assert "Approval identity consistency | PASS" in report
    assert "real_money_approved: False" in report
    assert "production_alerts_allowed: False" in report
    assert "Production WhatsApp Alerts: BLOCKED" in report
    assert "execution_allowed=false" in report
    assert ("place" + "_order") not in report


def test_backtest_execution_quality_gate_cli_runs_without_live_credentials(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["--family", SUPPORTED_FAMILY]) == 0
    report = tmp_path / "reports" / "strategy_audits" / "latest_backtest_execution_quality_gate.txt"
    text = report.read_text(encoding="utf-8")
    assert "No live data used." in text
    assert "No broker orders." in text
    assert "Real-money trading remains 0% approved." in text
    assert "Implement conservative execution model for VWAP family backtests" in text
    assert "Approval identity consistency | PASS" in text
    assert "Overall gate: FAIL" in text
