from __future__ import annotations

from pathlib import Path

from src.reports.vwap_family_backtest_bias_audit import generate_vwap_family_backtest_bias_audit, main


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "src" / "strategies" / "vwap_rejection.py",
        "def generate_signal(candles, context):\n"
        "    last = candles[-1]\n"
        "    entry = last['close']\n"
        "    return None\n",
    )
    _write(
        base / "src" / "strategies" / "vwap_reclaim.py",
        "def generate_signal(candles, context):\n"
        "    prev_candle, last = candles[-2], candles[-1]\n"
        "    return None\n",
    )
    _write(
        base / "src" / "strategies" / "trend_day_vwap_pullback.py",
        "def generate_signal(candles, context):\n"
        "    return None\n",
    )
    _write(
        base / "src" / "backtesting" / "strategy_backtest_runner.py",
        "\n".join(
            [
                "slippage_points = 0.0",
                "cost_per_trade = 0.0",
                "entry_delay_ticks = 1",
            ]
        )
        + "\n",
    )
    _write(
        base / "src" / "research" / "vwap_rejection_deep_dive.py",
        "SLIPPAGE_POINTS = 5.0\nCOST_PER_TRADE = 50.0\n",
    )
    _write(base / "src" / "research" / "forward_validation.py", "FORWARD_STRATEGY = 'gold_vwap_rejection_short'\n")
    _write(
        base / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt",
        "current implementation enters at the rejecting candle close; research version uses delayed/future-bar assumptions.\n",
    )
    _write(
        base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt",
        "vwap_rejection/vwap_rejection_short/gold_vwap_rejection_short are fragmented.\n",
    )
    _write(
        base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt",
        "\n".join(
            [
                "Forward/replay-recorded trades: trades=5 wins=3 losses=2 net_pnl=1508.15 PF=2.81",
                "Approval Decision: RESEARCH_ONLY",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv",
        "strategy,symbol,status\nvwap_rejection,GOLD-I,REJECTED\n",
    )
    _write(
        base / "reports" / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.txt",
        "Current approval status: WATCHLIST\nRobustness: ROBUST;LOW_SAMPLE\n",
    )


def test_vwap_family_bias_audit_report_contains_required_sections(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_vwap_family_backtest_bias_audit(tmp_path)
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.approval_ready is False
    assert "VWAP_FAMILY_BACKTEST_APPROVAL_READY: false" in report
    assert "LOOKAHEAD / FUTURE-BAR AUDIT" in report
    assert "COST / SLIPPAGE / SPREAD AUDIT" in report
    assert "FILL REALISM AUDIT" in report
    assert "Real Money Approval: false" in report
    assert "Production WhatsApp Alerts: BLOCKED" in report
    assert "execution_allowed=false" in report
    assert "Forward validation remains RESEARCH_ONLY" in report
    assert ("place" + "_order") not in report


def test_vwap_family_bias_audit_cli_runs_without_credentials(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main([]) == 0
    report = tmp_path / "reports" / "strategy_audits" / "latest_vwap_family_backtest_bias_audit.txt"
    text = report.read_text(encoding="utf-8")
    assert "No live data used." in text
    assert "No broker orders." in text
    assert "Real-money trading remains 0% approved." in text
