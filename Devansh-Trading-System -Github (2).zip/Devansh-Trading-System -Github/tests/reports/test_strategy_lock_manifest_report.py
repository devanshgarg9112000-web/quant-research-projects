﻿from __future__ import annotations

import csv
from datetime import datetime, timedelta
from pathlib import Path

from src.reports.strategy_lock_manifest_report import (
    SUPPORTED_FAMILY,
    generate_strategy_lock_manifest_report,
    main,
)


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "config" / "strategy_identity.yaml",
        """families:
  gold_vwap_rejection_reclaim_family:
    status: RESEARCH_ONLY
    real_money_approved: false
    production_alerts_allowed: false
    approval_review_requirements:
      minimum_forward_trades: 30
      minimum_distinct_sessions: 5
    canonical_setups:
      gold_vwap_rejection_short:
        status: RESEARCH_ONLY

active_research_lock:
  lock_version: GOLD_VWAP_RESEARCH_LOCK_V1
  lock_status: LOCKED_FOR_FORWARD_RESEARCH
  lock_timestamp: 2026-06-23T00:00:00+05:30
  family: gold_vwap_rejection_reclaim_family
  canonical_setup: gold_vwap_rejection_short
  strategy_status: RESEARCH_ONLY
  real_money_approved: false
  production_alerts_allowed: false
  execution_allowed: false
  execution_model: CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK
  approval_grade_backtest_ready: false
  forward_validation_required: true
  required_forward_trades: 30
  required_forward_sessions: 5
  notes: Research lock only.
""",
    )
    _write(
        base / "config" / "forward_validation.yaml",
        """production_alerts_allowed: false
active_lock_version: GOLD_VWAP_RESEARCH_LOCK_V1
active_lock_timestamp: 2026-06-23T00:00:00+05:30
recognized_real_providers: [KITE, TRUEDATA]
""",
    )
    ledger = base / "reports" / "forward_validation" / "gold_vwap_rejection_short_ledger.csv"
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["signal_id", "date", "symbol", "strategy", "signal_time", "side", "entry", "stop", "target", "status", "execution_allowed"],
        )
        writer.writeheader()
        start = datetime(2026, 6, 19, 9, 0)
        for index in range(5):
            signal_time = start + timedelta(minutes=index)
            writer.writerow({
                "signal_id": f"legacy-{index}",
                "date": signal_time.date().isoformat(),
                "symbol": "GOLD-I",
                "strategy": "gold_vwap_rejection_short",
                "signal_time": signal_time.isoformat(),
                "side": "SELL",
                "entry": "1000",
                "stop": "1010",
                "target": "980",
                "status": "WIN",
                "execution_allowed": "false",
            })


def test_strategy_lock_manifest_report_created_and_research_only(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_strategy_lock_manifest_report(tmp_path, family=SUPPORTED_FAMILY)
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.lock_version == "GOLD_VWAP_RESEARCH_LOCK_V1"
    assert result.lock_status == "LOCKED_FOR_FORWARD_RESEARCH"
    assert result.current_independent_forward_trades == 0
    assert result.required_forward_trades == 30
    assert result.real_money_approved is False
    assert result.production_alerts_allowed is False
    assert result.execution_allowed is False
    assert "strategy_status: RESEARCH_ONLY" in report
    assert "real_money_approved: false" in report
    assert "production_alerts_allowed: false" in report
    assert "execution_allowed=false" in report
    assert "approval_grade_backtest_ready: false" in report
    assert "current_independent_forward_trades: 0" in report
    assert "future_rows_can_be_marked_post_lock_true_if_they_match_this_lock: true" in report
    assert "This is NOT strategy approval." in report
    assert ("place" + "_order") not in report


def test_strategy_lock_manifest_cli_runs_without_live_credentials(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["--family", SUPPORTED_FAMILY]) == 0
    report = tmp_path / "reports" / "strategy_locks" / "latest_strategy_lock_manifest_report.txt"
    text = report.read_text(encoding="utf-8")
    assert "No live data used." in text
    assert "No broker orders." in text
    assert "No production WhatsApp." in text
    assert "Real-money trading remains 0% approved." in text
    assert "Strategy approval unchanged: RESEARCH_ONLY." in text
