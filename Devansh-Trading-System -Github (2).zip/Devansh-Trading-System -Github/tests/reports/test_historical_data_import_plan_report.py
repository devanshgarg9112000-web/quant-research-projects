from __future__ import annotations

from datetime import datetime
from pathlib import Path

from src.reports.historical_data_import_plan_report import (
    REQUIRED_COLUMNS,
    VALIDATION_CHECKLIST,
    generate_historical_data_import_plan_report,
    main,
)


def test_historical_data_import_plan_report_created(tmp_path: Path) -> None:
    result = generate_historical_data_import_plan_report(
        tmp_path,
        now=datetime(2026, 6, 23, 22, 50),
    )
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.historical_import_required is True
    assert result.multi_year_backtest_currently_reliable is False
    assert result.regime_labeling_required is True
    assert "historical_import_required: true" in report
    assert "multi_year_backtest_currently_reliable: false" in report
    assert "regime_labeling_required: true" in report
    assert "real_money_approval_allowed: false" in report
    assert "execution_allowed=false" in report
    for column in REQUIRED_COLUMNS:
        assert f"- {column}" in report
    for item in VALIDATION_CHECKLIST:
        assert f"- {item}" in report
    forbidden = "place" + "_order"
    assert forbidden not in report


def test_historical_data_import_plan_cli_runs(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    assert main([]) == 0
    report = tmp_path / "reports" / "strategy_audits" / "latest_historical_data_import_plan_report.txt"
    assert report.exists()
    text = report.read_text(encoding="utf-8")
    assert "minimum_history: at least 2 years OHLCV bars" in text
    assert "preferred_history: 3-5 years if available" in text
    assert "Stage 3: create regime labeling report" in text
    assert "No historical data downloaded automatically." in text
