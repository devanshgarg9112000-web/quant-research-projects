﻿from __future__ import annotations

import csv
from datetime import datetime, timedelta
from pathlib import Path

from src.reports.forward_validation_independence_report import (
    SUPPORTED_FAMILY,
    generate_forward_validation_independence_report,
    main,
)


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "config" / "strategy_identity.yaml",
        """families:
  gold_vwap_rejection_reclaim_family:
    status: RESEARCH_ONLY
    real_money_approved: false
    production_alerts_allowed: false
    approval_review_requirements:
      minimum_backtest_trades: 100
      minimum_backtest_days: 20
      minimum_forward_trades: 30
      minimum_forward_days: 5
      minimum_distinct_sessions: 5
      minimum_profit_factor: 1.30
      maximum_drawdown_allowed_points: null
      requires_cost_slippage_spread: true
      requires_oos_or_walk_forward: true
      requires_forward_independence: true
      requires_manual_risk_plan: true
    canonical_setups:
      gold_vwap_rejection_short:
        aliases:
          - vwap_rejection
          - vwap_rejection_short
          - gold_vwap_rejection_short
        forward_validation_id: gold_vwap_rejection_short
        approval_id: gold_vwap_rejection_short
        status: RESEARCH_ONLY
""",
    )
    _write(
        base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt",
        "\n".join(
            [
                "Canonical strategy identity config: FOUND",
                "GOLD VWAP identity consistency: CONSISTENT",
                "GOLD VWAP family status: RESEARCH_ONLY",
                "GOLD VWAP real-money approved: false",
                "GOLD VWAP production alerts allowed: false",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt",
        "\n".join(
            [
                "canonical_family_id: gold_vwap_rejection_reclaim_family",
                "Current family approval status: RESEARCH_ONLY",
                "Forward trades count: 5",
                "Forward approval decision: RESEARCH_ONLY",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_audits" / "latest_backtest_execution_quality_gate.txt",
        "\n".join(
            [
                "Overall gate: FAIL",
                "Failed gates count: 1",
                "current_forward_trades: 5",
                "required_forward_trades: 30",
                "forward_sample_sufficient: false",
                "Conservative execution model available: true",
                "GATE-03 | Entry fill model defined | PASS | execution_model=CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK",
                "GATE-11 | Forward validation independence | FAIL",
                "CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_audits" / "latest_vwap_family_backtest_bias_audit.txt",
        "\n".join(
            [
                "Bias risk: MEDIUM",
                "Evidence trust level: LOW",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt",
        "\n".join(
            [
                "Ledger Rows: 5",
                "Provider Breakdown: UNKNOWN=5",
                "Approval Decision: RESEARCH_ONLY",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(base / "config" / "forward_validation.yaml", "production_alerts_allowed: false\nactive_lock_version: GOLD_VWAP_RESEARCH_LOCK_V1\nactive_lock_timestamp: 2026-06-23T00:00:00+05:30\n")
    _write(base / "config" / "approved_strategies.yaml", "approved_strategies: []\n")
    ledger = base / "reports" / "forward_validation" / "gold_vwap_rejection_short_ledger.csv"
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["signal_id", "date", "symbol", "strategy", "signal_time", "side", "entry", "stop", "target", "status", "execution_allowed"],
        )
        writer.writeheader()
        start = datetime(2026, 6, 19, 9, 0)
        for index in range(5):
            signal_time = start + timedelta(minutes=index)
            writer.writerow({
                "signal_id": f"legacy-{index}",
                "date": signal_time.date().isoformat(),
                "symbol": "GOLD-I",
                "strategy": "gold_vwap_rejection_short",
                "signal_time": signal_time.isoformat(),
                "side": "SELL",
                "entry": "1000",
                "stop": "1010",
                "target": "980",
                "status": "WIN" if index < 3 else "LOSS",
                "execution_allowed": "false",
            })


def test_forward_validation_independence_report_not_passed(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_forward_validation_independence_report(tmp_path, family=SUPPORTED_FAMILY)
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.forward_validation_independence_status == "NOT_PASSED"
    assert result.current_forward_trades == 0
    assert result.required_forward_trades == 30
    assert result.forward_sample_sufficient is False
    assert result.real_money_approval_allowed is False
    assert result.production_alerts_allowed is False
    assert "forward_validation_independence_status: NOT_PASSED" in report
    assert "current_forward_trades: 0" in report
    assert "total_ledger_rows: 5" in report
    assert "legacy_pre_lock_rows: 5" in report
    assert "legacy_rows_counted_for_approval: 0" in report
    assert "completed_independent_post_lock_trades: 0" in report
    assert "required_forward_sessions: 5" in report
    assert "required_forward_trades: 30" in report
    assert "forward_sample_sufficient: false" in report
    assert "real_money_approval_allowed: false" in report
    assert "production_alerts_allowed: false" in report
    assert "execution_allowed=false" in report
    assert "execution model: CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK" in report
    assert "strategy_lock_status: LOCKED_FOR_FORWARD_RESEARCH" in report
    assert "lock_version: GOLD_VWAP_RESEARCH_LOCK_V1" in report
    assert "PRE_LOCK_RESEARCH_SAMPLE" in report
    assert "Create/extend a forward validation ledger schema" in report
    assert ("place" + "_order") not in report


def test_forward_validation_independence_cli_runs_without_live_credentials(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["--family", SUPPORTED_FAMILY]) == 0
    report = tmp_path / "reports" / "forward_validation" / "latest_forward_validation_independence_report.txt"
    text = report.read_text(encoding="utf-8")
    assert "No live data used." in text
    assert "No broker orders." in text
    assert "No production WhatsApp." in text
    assert "Real-money trading remains 0% approved." in text
    assert "No strategy approval was changed." in text






