from __future__ import annotations

from pathlib import Path

from src.reports.gold_vwap_family_spec_report import (
    CANONICAL_FAMILY_ID,
    generate_gold_vwap_family_spec_report,
    main,
)


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "src" / "strategies" / "vwap_rejection.py",
        "def generate_signal(candles, context):\n"
        "    # high >= vwap and close < vwap, stop high + 5, target 2R\n"
        "    return None\n",
    )
    _write(
        base / "src" / "strategies" / "vwap_reclaim.py",
        "def generate_signal(candles, context):\n"
        "    # prev close below VWAP and latest close above VWAP\n"
        "    return None\n",
    )
    _write(
        base / "src" / "strategies" / "trend_day_vwap_pullback.py",
        "def generate_signal(candles, context):\n"
        "    # trend day VWAP pullback long or short\n"
        "    return None\n",
    )
    _write(base / "config" / "strategies.yaml", "strategies:\n  vwap_rejection: true\n  vwap_reclaim: true\n")
    _write(
        base / "config" / "forward_validation.yaml",
        "strategy: gold_vwap_rejection_short\nproduction_alerts_allowed: false\n",
    )
    _write(
        base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv",
        "\n".join(
            [
                "strategy,symbol,status,confidence,trades,win_rate,net_pnl,profit_factor,expectancy,warnings,final_recommendation",
                "vwap_rejection,GOLD-I,REJECTED,MEDIUM,67,43.94,-761,0.96,-11.36,HIGH_DRAWDOWN,REJECTED",
                "vwap_reclaim,GOLD-I,REJECTED,MEDIUM,80,30.38,-12454,0.55,-155.68,NONE,REJECTED",
                "trend_day_vwap_pullback,GOLD-I,REJECTED,LOW,29,35.71,-1171,0.87,-40.38,HIGH_DRAWDOWN,REJECTED",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_research" / "latest_strategy_research_report.csv",
        "\n".join(
            [
                "strategy,symbol,status,confidence,trades,win_rate,net_pnl,profit_factor,expectancy,warnings,final_recommendation",
                "research_lab__gold_i__vrs,GOLD-I,WATCHLIST,LOW,5,60,1508.14,2.81,301.63,LOW_TRADE_COUNT,\"vwap_rejection_short: WATCHLIST; isolated research ID\"",
                "research_lab__gold_i__vrl,GOLD-I,WATCHLIST,LOW,14,50,1851.86,1.51,132.28,LOW_TRADE_COUNT,\"vwap_reclaim_long: WATCHLIST; isolated research ID\"",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt",
        "\n".join(
            [
                "Forward/replay-recorded trades: trades=5 wins=3 losses=2 net_pnl=1508.15 PF=2.81",
                "Approval Decision: RESEARCH_ONLY",
                "Decision Reason: Forward trades are 5; at least 10 are required before WATCHLIST review.",
                "Production WhatsApp Alerts: BLOCKED",
                "execution_allowed=false",
            ]
        )
        + "\n",
    )
    _write(
        base / "reports" / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.txt",
        "Robustness: ROBUST;LOW_SAMPLE\nCurrent approval status: WATCHLIST\n",
    )
    _write(
        base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt",
        "gold_vwap_rejection_short | vwap_rejection | RESEARCH_ONLY\n",
    )


def test_gold_vwap_family_spec_report_contains_required_conclusions(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_gold_vwap_family_spec_report(tmp_path)
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.csv_path.exists()
    assert result.canonical_family_id == CANONICAL_FAMILY_ID
    assert "gold_vwap_rejection_reclaim_family" in report
    assert "VWAP Rejection Short" in report
    assert "VWAP Reclaim Long" in report
    assert "Approved strategy count: 0" in report
    assert "Real Money Approval: false" in report
    assert "Production WhatsApp Alerts: BLOCKED" in report
    assert "execution_allowed=false" in report
    assert "Evidence sufficient for manual trading approval: false" in report
    assert ("place" + "_order") not in report


def test_gold_vwap_family_spec_report_cli_runs_without_credentials(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main([]) == 0
    report = tmp_path / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt"
    assert report.exists()
    text = report.read_text(encoding="utf-8")
    assert "No live data used." in text
    assert "No broker orders." in text
    assert "Real-money trading remains 0% approved." in text
