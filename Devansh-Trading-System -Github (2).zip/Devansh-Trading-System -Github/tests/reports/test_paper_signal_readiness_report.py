﻿from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from src.reports.paper_signal_readiness_report import (
    PAPER_VERDICT,
    REAL_MONEY_VERDICT,
    SUPPORTED_FAMILY,
    TRADEABLE_LAUNCH_VERDICT,
    generate_paper_signal_readiness_report,
    main,
)


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "config" / "strategy_identity.yaml",
        "minimum_forward_trades: 30\nminimum_distinct_sessions: 5\n",
    )
    _write(
        base / "config" / "forward_validation.yaml",
        "active_lock_version: GOLD_VWAP_RESEARCH_LOCK_V1\n"
        "active_lock_timestamp: 2026-06-23T00:00:00+05:30\n"
        "recognized_real_providers: [KITE, TRUEDATA]\n",
    )
    _write(
        base / "reports" / "final_safety" / "latest_final_safety_audit_report.txt",
        "FINAL SAFETY AUDIT\n"
        "FINAL_SAFETY_PASS_WITH_WARNINGS\n"
        "Blockers: 0\n"
        "Executable order paths: 0\n"
        "Production WhatsApp: BLOCKED\n"
        "execution_allowed=false\n",
    )
    _write(
        base / "reports" / "forward_validation" / "latest_forward_validation_independence_report.txt",
        "forward_validation_independence_status: NOT_PASSED\n"
        "current_forward_trades: 1\n"
        "required_forward_trades: 30\n"
        "real_money_approval_allowed: false\n"
        "production_alerts_allowed: false\n"
        "execution_allowed=false\n",
    )
    _write(
        base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt",
        "Completed Independent Post-lock Trades: 1\n"
        "Approval Decision: RESEARCH_ONLY\n"
        "Production WhatsApp Alerts: BLOCKED\n"
        "execution_allowed=false\n",
    )
    _write(
        base / "reports" / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt",
        "Recorder tick rows: 10\n"
        "Feature rows generated: 10\n"
        "VWAP bridge status: PENDING_POST_LOCK_RECORDED\n"
        "pending_outcomes_resolved: 1\n"
        "Production WhatsApp alerts: BLOCKED\n"
        "execution_allowed=false\n",
    )
    _write(base / "data" / "kite_recorded" / "ticks" / "2026-06-23" / "GOLD-I_ticks.csv", "timestamp,symbol,ltp\n2026-06-23T09:01:01,GOLD-I,1000\n")
    _write(base / "data" / "kite_recorded" / "features" / "2026-06-23" / "GOLD-I_orderflow_lite.csv", "timestamp,symbol,last_price\n2026-06-23T09:01:01,GOLD-I,1000\n")
    ledger = base / "reports" / "forward_validation" / "gold_vwap_rejection_short_ledger.csv"
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "ledger_schema_version",
                "signal_id",
                "lock_version",
                "post_lock",
                "session_id",
                "date",
                "provider",
                "symbol",
                "canonical_family",
                "canonical_setup",
                "strategy",
                "signal_time",
                "entry_time",
                "side",
                "entry",
                "stop",
                "stop_loss",
                "target",
                "data_role",
                "used_for_parameter_tuning",
                "risk_per_unit",
                "reward_per_unit",
                "expected_R",
                "approval_status_at_signal",
                "execution_allowed",
                "alert_mode",
                "status",
                "result",
                "exit_time",
                "exit_price",
                "gross_pnl",
                "net_pnl_after_costs",
                "R_multiple",
                "mfe",
                "mae",
            ],
        )
        writer.writeheader()
        signal_time = datetime(2026, 6, 23, 9, 0)
        writer.writerow(
            {
                "ledger_schema_version": "2_post_lock",
                "signal_id": "fvsig-test",
                "lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
                "post_lock": "true",
                "session_id": "GOLD-I_2026-06-23_KITE",
                "date": "2026-06-23",
                "provider": "KITE",
                "symbol": "GOLD-I",
                "canonical_family": "gold_vwap_rejection_reclaim_family",
                "canonical_setup": "gold_vwap_rejection_short",
                "strategy": "gold_vwap_rejection_short",
                "signal_time": signal_time.isoformat(),
                "entry_time": "2026-06-23T09:01:00",
                "side": "SELL",
                "entry": "1000",
                "stop": "1010",
                "stop_loss": "1010",
                "target": "980",
                "data_role": "FORWARD_VALIDATION",
                "used_for_parameter_tuning": "false",
                "risk_per_unit": "10",
                "reward_per_unit": "20",
                "expected_R": "2",
                "approval_status_at_signal": "RESEARCH_ONLY",
                "execution_allowed": "false",
                "alert_mode": "blocked",
                "status": "WIN",
                "result": "WIN",
                "exit_time": "2026-06-23T09:02:00",
                "exit_price": "980",
                "gross_pnl": "20",
                "net_pnl_after_costs": "14",
                "R_multiple": "1.4",
                "mfe": "21",
                "mae": "1",
            }
        )


def test_paper_signal_readiness_report_created_and_blocks_approval(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_paper_signal_readiness_report(tmp_path, family=SUPPORTED_FAMILY)
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.paper_signal_readiness_verdict == PAPER_VERDICT
    assert result.tradeable_launch_verdict == TRADEABLE_LAUNCH_VERDICT
    assert result.real_money_approval_status == REAL_MONEY_VERDICT
    assert result.current_forward_trades == 1
    assert result.required_forward_trades == 30
    assert "paper_signal_observation: PAPER_SIGNAL_OBSERVATION_READY_WITH_RESTRICTIONS" in report
    assert "tradeable_launch1: TRADEABLE_LAUNCH1_NOT_READY" in report
    assert "real_money: REAL_MONEY_NOT_ALLOWED" in report
    assert "execution_allowed=false" in report
    assert "Production WhatsApp Alerts: BLOCKED" in report
    assert "current_forward_trades: 1" in report
    assert "required_forward_trades: 30" in report
    assert "approval_progress: 1/30 does not pass approval" in report
    assert "- real money" in report
    assert "- broker orders" in report
    assert "- production WhatsApp alerts" in report
    assert "- averaging losers" in report
    assert "place_order" not in report


def test_paper_signal_readiness_cli_runs_without_live_services(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["--family", SUPPORTED_FAMILY]) == 0
    report = tmp_path / "reports" / "paper_signal_readiness" / "latest_paper_signal_readiness_report.txt"
    text = report.read_text(encoding="utf-8")
    assert "No live data used by this report." in text
    assert "No broker orders." in text
    assert "No production WhatsApp." in text
    assert "No strategy approval was changed." in text


def test_report_module_does_not_introduce_order_execution_path() -> None:
    module_text = Path("src/reports/paper_signal_readiness_report.py").read_text(encoding="utf-8")
    assert "place_order" not in module_text
