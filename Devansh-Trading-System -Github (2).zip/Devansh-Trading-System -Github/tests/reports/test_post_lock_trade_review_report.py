from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from src.reports.post_lock_trade_review_report import (
    CSV_COLUMNS,
    SUPPORTED_FAMILY,
    generate_post_lock_trade_review_report,
    main,
)


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _seed_project(base: Path) -> None:
    _write(
        base / "config" / "strategy_identity.yaml",
        "minimum_forward_trades: 30\nminimum_distinct_sessions: 5\n",
    )
    _write(
        base / "config" / "forward_validation.yaml",
        "active_lock_version: GOLD_VWAP_RESEARCH_LOCK_V1\n"
        "active_lock_timestamp: 2026-06-23T00:00:00+05:30\n"
        "recognized_real_providers: [KITE, TRUEDATA]\n",
    )
    ledger = base / "reports" / "forward_validation" / "gold_vwap_rejection_short_ledger.csv"
    ledger.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "ledger_schema_version",
        "signal_id",
        "lock_version",
        "post_lock",
        "session_id",
        "date",
        "provider",
        "symbol",
        "canonical_family",
        "canonical_setup",
        "strategy",
        "signal_time",
        "entry_time",
        "side",
        "entry",
        "stop",
        "stop_loss",
        "target",
        "data_role",
        "used_for_parameter_tuning",
        "risk_per_unit",
        "reward_per_unit",
        "expected_R",
        "market_regime",
        "signal_score",
        "approval_status_at_signal",
        "execution_allowed",
        "alert_mode",
        "status",
        "result",
        "exit_time",
        "exit_price",
        "gross_pnl",
        "net_pnl_after_costs",
        "R_multiple",
        "mfe",
        "mae",
        "notes",
    ]
    with ledger.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(
            {
                "ledger_schema_version": "1_legacy",
                "signal_id": "legacy",
                "lock_version": "PRE_LOCK_LEGACY",
                "post_lock": "false",
                "date": "2026-06-20",
                "provider": "UNKNOWN",
                "symbol": "GOLD-I",
                "canonical_family": SUPPORTED_FAMILY,
                "canonical_setup": "gold_vwap_rejection_short",
                "strategy": "gold_vwap_rejection_short",
                "status": "WIN",
                "result": "WIN",
                "execution_allowed": "false",
            }
        )
        writer.writerow(
            {
                "ledger_schema_version": "2_post_lock",
                "signal_id": "win-row",
                "lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
                "post_lock": "true",
                "session_id": "GOLD-I_2026-06-23_KITE",
                "date": "2026-06-23",
                "provider": "KITE",
                "symbol": "GOLD-I",
                "canonical_family": SUPPORTED_FAMILY,
                "canonical_setup": "gold_vwap_rejection_short",
                "strategy": "gold_vwap_rejection_short",
                "signal_time": "2026-06-23T13:26:00",
                "entry_time": "2026-06-23T13:26:01",
                "side": "SELL",
                "entry": "145950",
                "stop": "145987",
                "stop_loss": "145987",
                "target": "145876",
                "data_role": "FORWARD_VALIDATION",
                "used_for_parameter_tuning": "false",
                "risk_per_unit": "37",
                "reward_per_unit": "74",
                "expected_R": "2.0",
                "market_regime": "TRAP_REVERSAL",
                "signal_score": "7.7",
                "approval_status_at_signal": "RESEARCH_ONLY",
                "execution_allowed": "false",
                "alert_mode": "blocked",
                "status": "WIN",
                "result": "WIN",
                "exit_time": "2026-06-23T13:26:03",
                "exit_price": "145876",
                "gross_pnl": "74",
                "net_pnl_after_costs": "14",
                "R_multiple": "0.378",
                "mfe": "84",
                "mae": "0",
                "notes": "target reached",
            }
        )
        writer.writerow(
            {
                "ledger_schema_version": "2_post_lock",
                "signal_id": "loss-row",
                "lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
                "post_lock": "true",
                "session_id": "GOLD-I_2026-06-23_KITE",
                "date": "2026-06-23",
                "provider": "KITE",
                "symbol": "GOLD-I",
                "canonical_family": SUPPORTED_FAMILY,
                "canonical_setup": "gold_vwap_rejection_short",
                "strategy": "gold_vwap_rejection_short",
                "signal_time": "2026-06-23T13:55:00",
                "entry_time": "2026-06-23T13:55:01",
                "side": "SELL",
                "entry": "145700",
                "stop": "145752",
                "stop_loss": "145752",
                "target": "145596",
                "data_role": "FORWARD_VALIDATION",
                "used_for_parameter_tuning": "false",
                "risk_per_unit": "52",
                "reward_per_unit": "104",
                "expected_R": "2.0",
                "market_regime": "RANGE",
                "signal_score": "7.7",
                "approval_status_at_signal": "RESEARCH_ONLY",
                "execution_allowed": "false",
                "alert_mode": "blocked",
                "status": "LOSS",
                "result": "LOSS",
                "exit_time": "2026-06-23T14:04:12",
                "exit_price": "145752",
                "gross_pnl": "-52",
                "net_pnl_after_costs": "-112",
                "R_multiple": "-2.154",
                "mfe": "94",
                "mae": "1198",
                "notes": "stop reached",
            }
        )


def test_post_lock_trade_review_report_and_csv_created(tmp_path: Path) -> None:
    _seed_project(tmp_path)

    result = generate_post_lock_trade_review_report(
        tmp_path,
        family=SUPPORTED_FAMILY,
        now=datetime(2026, 6, 23, 22, 30),
    )
    report = result.report_path.read_text(encoding="utf-8")

    assert result.report_path.exists()
    assert result.csv_path.exists()
    assert result.completed_post_lock_trades == 2
    assert result.required_post_lock_trades == 30
    assert "approval_progress: 2/30" in report
    assert "overall_decision: RESEARCH_ONLY" in report
    assert "real_money: REAL_MONEY_NOT_ALLOWED" in report
    assert "execution_allowed=false" in report
    assert "Do not optimize yet." in report
    assert "result: WIN" in report
    assert "result: LOSS" in report
    assert "No broker orders." in report
    forbidden = "place" + "_order"
    assert forbidden not in report

    with result.csv_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 2
    assert "MFE_vs_target" in rows[0]
    assert "MAE_vs_stop" in rows[0]
    assert rows[0]["did_price_nearly_hit_target"] == "true"
    assert rows[1]["did_costs_reduce_edge"] == "true"
    assert rows[1]["result"] == "LOSS"
    assert CSV_COLUMNS[-1] == "regime_review_comment"


def test_post_lock_trade_review_cli_runs(tmp_path: Path, monkeypatch) -> None:
    _seed_project(tmp_path)
    monkeypatch.chdir(tmp_path)

    assert main(["--family", SUPPORTED_FAMILY]) == 0
    report = tmp_path / "reports" / "trade_reviews" / "latest_post_lock_trade_review_report.txt"
    assert report.exists()
    text = report.read_text(encoding="utf-8")
    assert "RESEARCH_ONLY" in text
    assert "Formal decision only after 30 independent post-lock trades" in text
