from __future__ import annotations

import csv
import sys
import time
from datetime import datetime, timedelta
from types import SimpleNamespace

import src.backtesting.strategy_backtest_runner as runner
from src.backtesting.strategy_backtest_runner import BACKTEST_STRATEGIES, run_strategy_backtest
from src.config_loader import load_configs
from src.data_feeds.tick_storage import save_normalized_ticks


def _buyer_trap_ticks(symbol: str = "GOLD-I", count: int = 60) -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    rows = []
    for index in range(count):
        rows.append({
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": symbol,
            "ltp": 110.0,
            "ltq": 2,
            "volume": 100 + index,
            "oi": None,
            "bid": 109.0,
            "bid_qty": 10,
            "ask": 110.0,
            "ask_qty": 12,
        })
    rows[-1].update({"ltp": 100.0, "bid": 100.0, "ask": 101.0})
    return rows


def _small_ticks(symbol: str = "GOLD-I", count: int = 4) -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    return [
        {
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": symbol,
            "ltp": 100.0 + index,
            "ltq": 1,
            "volume": 100 + index,
            "oi": None,
            "bid": 99.5 + index,
            "bid_qty": 10,
            "ask": 100.5 + index,
            "ask_qty": 12,
        }
        for index in range(count)
    ]


def _test_candles(symbol: str = "GOLD-I", count: int = 40) -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    return [
        {
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": symbol,
            "open": 100.0,
            "high": 101.0,
            "low": 99.0,
            "close": 100.0,
            "volume": 100 + index,
        }
        for index in range(count)
    ]


def _test_ticks(symbol: str = "GOLD-I", count: int = 50) -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    return [
        {
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": symbol,
            "ltp": 100.0,
            "ltq": 1,
            "volume": 100 + index,
            "oi": None,
            "bid": 99.5,
            "bid_qty": 10,
            "ask": 100.5,
            "ask_qty": 12,
        }
        for index in range(count)
    ]


def _fake_signal(symbol: str = "GOLD-I") -> SimpleNamespace:
    return SimpleNamespace(
        symbol=symbol,
        setup_type="cluster_imbalance_trap",
        strategy_name="Cluster Imbalance Trap",
        side="BUY",
        entry_price=100.0,
        stop_loss=90.0,
        target_price=200.0,
        reward_risk=2.0,
        score=8.0,
        market_mode="RANGE",
        reason="deterministic test signal",
        metadata={},
    )


def _patch_repeating_strategy(monkeypatch, approved: bool = True) -> None:
    class FakeStrategyEngine:
        def __init__(self, *_args, **_kwargs):
            pass

        def run(self, *_args, **_kwargs):
            return SimpleNamespace(
                candidates=[_fake_signal()],
                context={"cluster_gate": {"diagnostic_status": "TEST_CLUSTER", "gate_status": "PASS"}},
            )

    class FakeRiskEngine:
        def __init__(self, *_args, **_kwargs):
            pass

        def validate_signal(self, *_args, **_kwargs):
            return SimpleNamespace(
                approved=approved,
                quantity=1 if approved else 0,
                sizing={"allowed_risk_amount": 500.0, "estimated_risk_amount": 10.0},
                reasons=[] if approved else ["risk amount too small for minimum MCX quantity"],
                risk_amount=10.0,
            )

    monkeypatch.setattr(runner, "StrategyEngine", FakeStrategyEngine)
    monkeypatch.setattr(runner, "RiskEngine", FakeRiskEngine)


def test_strategy_backtest_runner_loads_tick_csv_and_runs_one_strategy(tmp_path, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        configs=load_configs("."),
    )

    out = capsys.readouterr().out
    assert result.total_source_ticks == 60
    assert result.total_filtered_ticks == 60
    assert {row["strategy"] for row in result.summary_rows} == {"cluster_imbalance_trap"}
    assert "STRATEGY BACKTEST SUMMARY" in out
    assert "PAPER MODE ONLY. No broker orders were placed." in out


def test_strategy_backtest_runner_runs_all_strategies(tmp_path):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_small_ticks(), tick_path)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="all",
        configs=load_configs("."),
    )

    assert [row["strategy"] for row in result.summary_rows] == BACKTEST_STRATEGIES


def test_strategy_backtest_runner_loads_tick_dir_and_combines_multiple_files(tmp_path, capsys):
    tick_root = tmp_path / "data" / "ticks" / "daily"
    day_one = tick_root / "2026-06-10" / "GOLD-I_ticks.csv"
    day_two = tick_root / "2026-06-11" / "GOLD-I_ticks.csv"
    save_normalized_ticks(_small_ticks("GOLD-I", 4), day_one)
    later_ticks = [
        {**tick, "timestamp": tick["timestamp"] + timedelta(days=1)}
        for tick in _small_ticks("GOLD-I", 4)
    ]
    save_normalized_ticks(later_ticks, day_two)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_dir="data/ticks/daily",
        symbols_text="GOLD-I",
        strategies_text="abnormal_flow",
        configs=load_configs("."),
    )

    out = capsys.readouterr().out
    assert len(result.tick_files) == 2
    assert result.total_source_ticks == 8
    assert result.total_filtered_ticks == 8
    assert "Files Loaded: 2" in out
    assert "Date Range:" in result.report_path.read_text(encoding="utf-8")


def test_date_filter_loads_only_requested_day(tmp_path, capsys):
    tick_root = tmp_path / "data" / "historical" / "truedata" / "ticks"
    day_one = tick_root / "2026-06-10" / "GOLD-I_ticks.csv"
    day_two = tick_root / "2026-06-11" / "GOLD-I_ticks.csv"
    save_normalized_ticks(_small_ticks("GOLD-I", 4), day_one)
    save_normalized_ticks(
        [{**tick, "timestamp": tick["timestamp"] + timedelta(days=1)} for tick in _small_ticks("GOLD-I", 4)],
        day_two,
    )

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_dir="data/historical/truedata/ticks",
        symbols_text="GOLD-I",
        strategies_text="abnormal_flow",
        from_date="2026-06-11",
        to_date="2026-06-11",
        configs=load_configs("."),
    )

    out = capsys.readouterr().out
    assert len(result.tick_files) == 1
    assert result.tick_files[0] == day_two
    assert result.total_source_ticks == 4
    assert "2026-06-11" in result.date_range
    assert "Files Loaded: 1" in out


def test_progress_output_includes_file_count_and_symbol_strategy_start(tmp_path, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)

    run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        configs=load_configs("."),
    )

    out = capsys.readouterr().out
    assert "[BACKTEST] Files Loaded: 1" in out
    assert "[BACKTEST] Ticks Loaded [GOLD-I]: 60" in out
    assert "[BACKTEST] Starting Symbol/Strategy: GOLD-I / cluster_imbalance_trap" in out
    assert "[BACKTEST] Raw Signals Count Before Simulation [GOLD-I / cluster_imbalance_trap]:" in out


def test_strategy_backtest_summary_and_trades_csv_are_created(tmp_path):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        configs=load_configs("."),
    )

    assert result.summary_csv_path.exists()
    assert result.trades_csv_path.exists()
    assert result.report_path.exists()
    assert "STRATEGY BACKTEST SUMMARY" in result.report_path.read_text(encoding="utf-8")
    with result.summary_csv_path.open(newline="", encoding="utf-8") as f:
        summary_rows = list(csv.DictReader(f))
    assert summary_rows[0]["strategy"] == "cluster_imbalance_trap"
    assert summary_rows[0]["execution_allowed"] == "false"
    with result.trades_csv_path.open(newline="", encoding="utf-8") as f:
        trade_rows = list(csv.DictReader(f))
    assert trade_rows
    assert {row["execution_allowed"] for row in trade_rows} == {"false"}


def test_strategy_backtest_marks_insufficient_sample(tmp_path):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_small_ticks(), tick_path)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="abnormal_flow",
        configs=load_configs("."),
    )

    assert result.summary_rows[0]["sample_status"] == "INSUFFICIENT_SAMPLE"
    assert result.summary_rows[0]["total_signals"] == 0


def test_exit_at_end_closes_open_trades_and_mfe_mae_fields_exist(tmp_path):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")
    configs["strategy_quality"] = {"enabled": False}

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        exit_at_end=True,
        configs=configs,
    )

    assert result.trade_rows
    assert result.exit_at_end is True
    assert {row["status"] for row in result.trade_rows} == {"END_EXIT"}
    assert all("mfe" in row and "mae" in row for row in result.trade_rows)
    with result.trades_csv_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["status"] == "END_EXIT"
    assert "mfe" in rows[0]
    assert "mae" in rows[0]
    assert rows[0]["execution_allowed"] == "false"


def test_one_active_trade_at_a_time_prevents_overlapping_trades(monkeypatch):
    _patch_repeating_strategy(monkeypatch)

    rows = runner._run_symbol_strategy_backtest(
        symbol="GOLD-I",
        strategy="cluster_imbalance_trap",
        candles=_test_candles(count=40),
        ticks=_test_ticks(count=50),
        settings={"mode": "PAPER", "enable_live_trading": False},
        risk_config={},
        instruments={},
        exit_at_end=True,
        controls=runner.BacktestControls(one_trade_at_a_time=True, signal_cooldown_seconds=0, max_trades_per_day=0),
    )
    summary = runner._build_summary_row("cluster_imbalance_trap", "GOLD-I", rows)

    assert summary["accepted"] == 1
    assert summary["overlap_skipped"] > 0
    assert summary["wins"] == 0
    assert summary["losses"] == 0


def test_signal_cooldown_skip_works(monkeypatch):
    _patch_repeating_strategy(monkeypatch)

    rows = runner._run_symbol_strategy_backtest(
        symbol="GOLD-I",
        strategy="cluster_imbalance_trap",
        candles=_test_candles(count=40),
        ticks=_test_ticks(count=50),
        settings={"mode": "PAPER", "enable_live_trading": False},
        risk_config={},
        instruments={},
        exit_at_end=True,
        controls=runner.BacktestControls(one_trade_at_a_time=False, signal_cooldown_seconds=300, max_trades_per_day=0),
    )
    summary = runner._build_summary_row("cluster_imbalance_trap", "GOLD-I", rows)

    assert summary["accepted"] >= 1
    assert summary["cooldown_skipped"] > 0


def test_max_trades_per_day_skip_works(monkeypatch):
    _patch_repeating_strategy(monkeypatch)

    rows = runner._run_symbol_strategy_backtest(
        symbol="GOLD-I",
        strategy="cluster_imbalance_trap",
        candles=_test_candles(count=40),
        ticks=_test_ticks(count=50),
        settings={"mode": "PAPER", "enable_live_trading": False},
        risk_config={},
        instruments={},
        exit_at_end=True,
        controls=runner.BacktestControls(one_trade_at_a_time=False, signal_cooldown_seconds=0, max_trades_per_day=1),
    )
    summary = runner._build_summary_row("cluster_imbalance_trap", "GOLD-I", rows)

    assert summary["accepted"] == 1
    assert summary["daily_limit_skipped"] > 0


def test_entry_delay_uses_future_tick_not_signal_tick():
    signal_time = datetime(2026, 6, 10, 9, 30)
    ticks = [
        {"timestamp": signal_time, "ltp": 100.0},
        {"timestamp": signal_time + timedelta(seconds=1), "ltp": 101.0},
    ]
    future_ticks = runner._ticks_at_or_after(ticks, signal_time)

    simulation = runner._simulate_paper_trade(
        _fake_signal(),
        quantity=1,
        future_ticks=future_ticks,
        signal_complete_at=signal_time,
        exit_at_end=False,
        controls=runner.BacktestControls(entry_delay_ticks=1),
    )

    assert future_ticks[0]["timestamp"] > signal_time
    assert simulation["entry_time"] == signal_time + timedelta(seconds=1)
    assert simulation["entry_price"] == 101.0


def test_slippage_and_cost_reduce_net_pnl():
    signal_time = datetime(2026, 6, 10, 9, 30)
    signal = _fake_signal()
    signal.target_price = 110.0
    future_ticks = [
        {"timestamp": signal_time + timedelta(seconds=1), "ltp": 100.0},
        {"timestamp": signal_time + timedelta(seconds=2), "ltp": 110.0},
    ]

    no_cost = runner._simulate_paper_trade(
        signal,
        quantity=1,
        future_ticks=future_ticks,
        signal_complete_at=signal_time,
        exit_at_end=False,
        controls=runner.BacktestControls(slippage_points=0.0, cost_per_trade=0.0),
    )
    with_cost = runner._simulate_paper_trade(
        signal,
        quantity=1,
        future_ticks=future_ticks,
        signal_complete_at=signal_time,
        exit_at_end=False,
        controls=runner.BacktestControls(slippage_points=1.0, cost_per_trade=2.0),
    )

    assert no_cost["net_pnl"] == 10.0
    assert with_cost["gross_pnl"] == 8.0
    assert with_cost["net_pnl"] == 6.0
    assert with_cost["net_pnl"] < no_cost["net_pnl"]


def test_high_signal_frequency_warning_appears():
    start = datetime(2026, 6, 10, 9, 15)
    rows = [
        {
            "signal_time": start + timedelta(seconds=index),
            "risk_status": "SKIPPED",
            "status": "COOLDOWN_SKIPPED",
            "net_pnl": 0.0,
            "gross_pnl": 0.0,
            "cost": 0.0,
        }
        for index in range(101)
    ]

    summary = runner._build_summary_row("cluster_imbalance_trap", "GOLD-I", rows)

    assert "HIGH_SIGNAL_FREQUENCY_WARNING" in summary["sample_status"]


def test_trade_csv_has_entry_time_and_outcome_populated(tmp_path):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        exit_at_end=True,
        configs=load_configs("."),
    )

    with result.trades_csv_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    assert rows[0]["entry_time"]
    assert rows[0]["outcome"]
    assert "adjusted_entry" in rows[0]
    assert "adjusted_exit" in rows[0]
    assert rows[0]["quality_status"]
    assert "quality_rejection_reason" in rows[0]
    assert rows[0]["signal_score"]
    assert "trap_strength" in rows[0]


def test_quality_counters_appear_in_summary():
    start = datetime(2026, 6, 18, 9, 15)
    rows = [
        {
            "signal_time": start,
            "status": "QUALITY_REJECTED",
            "quality_status": "QUALITY_REJECTED",
            "quality_rejection_codes": ("WEAK_TRAP", "MARKET_MODE"),
            "risk_status": "NOT_EVALUATED",
            "net_pnl": 0.0,
            "gross_pnl": 0.0,
            "cost": 0.0,
        },
        {
            "signal_time": start + timedelta(seconds=15),
            "status": "QUALITY_REJECTED",
            "quality_status": "QUALITY_REJECTED",
            "quality_rejection_codes": ("SAME_ZONE", "BAD_STOP_DISTANCE"),
            "risk_status": "NOT_EVALUATED",
            "net_pnl": 0.0,
            "gross_pnl": 0.0,
            "cost": 0.0,
        },
    ]

    summary = runner._build_summary_row("cluster_imbalance_trap", "GOLD-I", rows)

    assert summary["raw_signals"] == 2
    assert summary["quality_accepted_signals"] == 0
    assert summary["quality_rejected"] == 2
    assert summary["weak_trap_rejected"] == 1
    assert summary["bad_stop_distance_rejected"] == 1
    assert summary["same_zone_rejected"] == 1
    assert summary["market_mode_rejected"] == 1
    assert "SIGNAL_FILTERING_ACTIVE" in summary["sample_status"]


def test_risk_rejected_rows_do_not_count_as_wins_losses_or_accepted(monkeypatch):
    _patch_repeating_strategy(monkeypatch, approved=False)

    rows = runner._run_symbol_strategy_backtest(
        symbol="GOLD-I",
        strategy="cluster_imbalance_trap",
        candles=_test_candles(count=8),
        ticks=_test_ticks(count=10),
        settings={"mode": "PAPER", "enable_live_trading": False},
        risk_config={},
        instruments={},
        exit_at_end=True,
        controls=runner.BacktestControls(),
    )
    summary = runner._build_summary_row("cluster_imbalance_trap", "GOLD-I", rows)

    assert summary["accepted"] == 0
    assert summary["wins"] == 0
    assert summary["losses"] == 0
    assert summary["risk_rejected"] == len(rows)
    assert {row["outcome"] for row in rows} == {"RISK_REJECTED"}
    assert {row["net_pnl"] for row in rows} == {0.0}


def test_risk_rejected_signals_do_not_trigger_future_path_simulation(monkeypatch):
    _patch_repeating_strategy(monkeypatch, approved=False)

    def fail_simulation(*_args, **_kwargs):
        raise AssertionError("Risk-rejected signals must not scan or simulate future ticks.")

    monkeypatch.setattr(runner, "_simulate_paper_trade", fail_simulation)

    rows = runner._run_symbol_strategy_backtest(
        symbol="GOLD-I",
        strategy="cluster_imbalance_trap",
        candles=_test_candles(count=12),
        ticks=_test_ticks(count=20),
        settings={"mode": "PAPER", "enable_live_trading": False},
        risk_config={},
        instruments={},
        exit_at_end=True,
        controls=runner.BacktestControls(),
    )

    assert rows
    assert {row["status"] for row in rows} == {"RISK_REJECTED"}


def test_quality_rejected_signal_does_not_reach_risk_engine(monkeypatch):
    class FakeStrategyEngine:
        def __init__(self, *_args, **_kwargs):
            pass

        def run(self, *_args, **_kwargs):
            signal = _fake_signal()
            signal.metadata.update({"trap_strength": 0.2, "latest_ltq": 2, "cluster_zone": 100.0})
            signal.market_mode = "TREND_UP"
            return SimpleNamespace(candidates=[signal], context={"cluster_gate": {}})

    class FailRiskEngine:
        def __init__(self, *_args, **_kwargs):
            pass

        def validate_signal(self, *_args, **_kwargs):
            raise AssertionError("Quality-rejected signals must not reach the risk engine.")

    monkeypatch.setattr(runner, "StrategyEngine", FakeStrategyEngine)
    monkeypatch.setattr(runner, "RiskEngine", FailRiskEngine)

    rows = runner._run_symbol_strategy_backtest(
        symbol="GOLD-I",
        strategy="cluster_imbalance_trap",
        candles=_test_candles(count=8),
        ticks=_test_ticks(count=10),
        settings={"mode": "PAPER", "enable_live_trading": False},
        risk_config={},
        instruments={},
        quality_config=runner.ClusterSignalQualityConfig(min_trap_strength=0.7),
    )

    assert rows
    assert {row["status"] for row in rows} == {"QUALITY_REJECTED"}


def test_multi_day_sample_backtest_completes_in_reasonable_time(tmp_path):
    tick_root = tmp_path / "ticks"
    for offset in range(3):
        day = datetime(2026, 6, 10) + timedelta(days=offset)
        ticks = [
            {**tick, "timestamp": tick["timestamp"] + timedelta(days=offset)}
            for tick in _buyer_trap_ticks(count=80)
        ]
        save_normalized_ticks(ticks, tick_root / day.date().isoformat() / "GOLD-I_ticks.csv")

    started = time.monotonic()
    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_dir="ticks",
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        exit_at_end=True,
        configs=load_configs("."),
    )
    elapsed = time.monotonic() - started

    assert len(result.tick_files) == 3
    assert result.total_filtered_ticks == 240
    assert elapsed < 5.0


def test_max_backtest_seconds_stops_safely_with_partial_report(tmp_path, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(count=80), tick_path)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        max_backtest_seconds=0.000001,
        configs=load_configs("."),
    )

    out = capsys.readouterr().out
    assert result.timed_out is True
    assert "BACKTEST_TIMEOUT" in out
    assert "BACKTEST_TIMEOUT" in result.report_path.read_text(encoding="utf-8")
    assert result.summary_csv_path.exists()
    assert result.trades_csv_path.exists()


def test_cli_quality_overrides_are_forwarded(monkeypatch):
    captured = {}

    def fake_run_strategy_backtest(**kwargs):
        captured.update(kwargs)

    monkeypatch.setattr(runner, "run_strategy_backtest", fake_run_strategy_backtest)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "strategy_backtest_runner",
            "--tick-file",
            "ticks.csv",
            "--min-score",
            "8.8",
            "--min-trap-strength",
            "0.7",
            "--same-zone-cooldown-seconds",
            "420",
            "--direction-flip-cooldown-seconds",
            "360",
        ],
    )

    assert runner.main() == 0
    assert captured["min_score"] == 8.8
    assert captured["min_trap_strength"] == 0.7
    assert captured["same_zone_cooldown_seconds"] == 420
    assert captured["direction_flip_cooldown_seconds"] == 360


def test_strategy_backtest_runner_never_places_broker_orders(tmp_path, monkeypatch):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)

    def fail_place_order(*args, **kwargs):
        raise AssertionError("Strategy backtest runner must not place broker orders.")

    monkeypatch.setattr("src.brokers.paper_broker.PaperBroker.place_order", fail_place_order)
    monkeypatch.setattr("src.brokers.kite_broker.KiteBroker.place_order", fail_place_order)

    result = run_strategy_backtest(
        base_dir=tmp_path,
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        strategies_text="cluster_imbalance_trap",
        configs=load_configs("."),
    )

    assert result.summary_rows[0]["execution_allowed"] is False
