from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from src.reports.final_safety_audit import (
    FINAL_SAFETY_BLOCKED,
    FINAL_SAFETY_PASS_WITH_WARNINGS,
    HISTORY_PATH,
    run_final_safety_audit,
)


def _configs(*, live: bool = False, production_alerts: bool = False) -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": live},
        "risk": {"allow_live_trading": False},
        "forward_validation": {
            "production_alerts_allowed": production_alerts,
            "send_research_whatsapp_preview": False,
        },
        "alerts": {"whatsapp": {"enabled": False, "dry_run": True}},
        "approved_strategies": {"allow_approved": True, "allow_watchlist": False},
    }


def _write_file(base: Path, relative: str, text: str) -> Path:
    path = base / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def _write_safe_reports(base: Path, *, execution_allowed: str = "false") -> None:
    _write_file(
        base,
        "reports/launch1/latest_launch1_readiness_report.txt",
        "\n".join(
            [
                "LAUNCH 1 READINESS REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                f"execution_allowed={execution_allowed}",
                "Production WhatsApp Alerts: BLOCKED",
                "automatic_strategy_approval: DISABLED",
                "target_validation_date: 2026-06-22",
                "latest_verifier_date: 2026-06-20",
                "data_quality_status: READY_FOR_FORWARD_VALIDATION",
                "strategy_approval_status: RESEARCH_ONLY",
                "decision: LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA",
                "Small sample warning: still too few forward trades.",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_post_recording_verifier_report.txt",
        "\n".join(
            [
                "KITE POST-RECORDING VERIFIER REPORT",
                "Date: 2026-06-20",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                f"execution_allowed={execution_allowed}",
                "Data Quality Gate status: READY_FOR_FORWARD_VALIDATION",
                "VERDICT: DAY_ACCEPTED_FOR_RESEARCH",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/forward_validation/latest_forward_validation_summary.txt",
        "\n".join(
            [
                "GOLD-I VWAP REJECTION SHORT FORWARD VALIDATION SUMMARY",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                f"execution_allowed={execution_allowed}",
                "Production WhatsApp Alerts: BLOCKED",
                "Approval Decision: RESEARCH_ONLY",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_kite_daily_pipeline_report.txt",
        "\n".join(
            [
                "KITE DAILY PIPELINE REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                f"execution_allowed={execution_allowed}",
                "automatic_strategy_approval: DISABLED",
                "",
                "DATA QUALITY GATE",
                "status: READY_FOR_FORWARD_VALIDATION",
                "",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )


def _write_safe_project_files(base: Path) -> None:
    _write_file(base, "src/data_collection/kite_readonly.py", "print('read only data')\n")
    _write_file(base, "src/research/forward_validation.py", "STATUS = 'RESEARCH_ONLY'\n")
    _write_file(base, "docs/safety.md", "Kite place_order is prohibited in Launch 1.\n")



def _write_reconciled_reports_with_stale_pipeline(base: Path) -> None:
    _write_file(
        base,
        "reports/launch1/latest_launch1_readiness_report.txt",
        "\n".join(
            [
                "LAUNCH 1 READINESS REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
                "automatic_strategy_approval: DISABLED",
                "target_validation_date: 2026-06-22",
                "latest_verifier_date: 2026-06-22",
                "target_validation_passed: true",
                "data_quality_status: FULL_DEPTH",
                "feature_mode: DEPTH_ORDERFLOW_LITE",
                "contract_consistency_status: CONSISTENT",
                "feature_rebuild_reconciliation_status: RECONCILED",
                "authoritative_feature_source: DATA_COLLECTION_FEATURE_BUILDER_REPORT",
                "pipeline_report_status: STALE_OR_FAILED",
                "data_collection_report_status: CLEAN_FEATURE_BUILDER_REPORT",
                "pipeline_report_stale_or_failed: true",
                "manual_feature_rebuild_reconciled_day: true",
                "strategy_approval_status: RESEARCH_ONLY",
                "decision: LAUNCH1_READY_FOR_PAPER_RESEARCH",
                "Small sample warning: still too few forward trades.",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_post_recording_verifier_report.txt",
        "\n".join(
            [
                "KITE POST-RECORDING VERIFIER REPORT",
                "Date: 2026-06-22",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Data Quality Gate status: MARKET_CLOSED_OR_NO_LIVE_DATA",
                "Data collection market data status: FULL_DEPTH",
                "Pipeline contract status: NOT_CHECKED",
                "Data collection contract status: CONSISTENT",
                "Pipeline report status: STALE_OR_FAILED",
                "Data collection report status: CLEAN_FEATURE_BUILDER_REPORT",
                "Feature rebuild reconciliation status: RECONCILED",
                "Authoritative feature source used: DATA_COLLECTION_FEATURE_BUILDER_REPORT",
                "Pipeline report stale/failed: true",
                "Manual feature rebuild reconciled day: true",
                "VERDICT: DAY_ACCEPTED_FOR_RESEARCH",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_data_collection/latest_kite_data_collection_report.txt",
        "\n".join(
            [
                "KITE DATA COLLECTION REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Market data status: FULL_DEPTH",
                "Feature mode: DEPTH_ORDERFLOW_LITE",
                "Contract consistency status: CONSISTENT",
                "Errors: NONE",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/forward_validation/latest_forward_validation_summary.txt",
        "\n".join(
            [
                "GOLD-I VWAP REJECTION SHORT FORWARD VALIDATION SUMMARY",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
                "Approval Decision: RESEARCH_ONLY",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_kite_daily_pipeline_report.txt",
        "\n".join(
            [
                "KITE DAILY PIPELINE REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "automatic_strategy_approval: DISABLED",
                "Feature mode: NO_FEATURES",
                "",
                "CONTRACT CONSISTENCY",
                "status: NOT_CHECKED",
                "",
                "DATA QUALITY GATE",
                "status: MARKET_CLOSED_OR_NO_LIVE_DATA",
                "",
                "ERRORS",
                "- Kite live recorder failed safely: MemoryError.",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )

def test_final_safety_audit_report_generated(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(
        tmp_path,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 21, 10, 0),
    )

    assert result.report_path.exists()
    assert result.history_path.exists()
    text = result.report_path.read_text(encoding="utf-8")
    assert "FINAL SAFETY AUDIT" in text
    assert "FINAL VERDICT" in text
    assert "execution_allowed=false" in text


def test_final_safety_pass_with_warnings_for_clean_safety_and_non_executable_refs(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_PASS_WITH_WARNINGS
    assert result.blockers == []
    assert result.executable_order_findings == []
    assert result.non_executable_order_references


def test_execution_allowed_true_blocks_audit(tmp_path):
    _write_safe_reports(tmp_path, execution_allowed="true")
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_BLOCKED
    assert any("execution_allowed" in blocker for blocker in result.blockers)


def test_live_trading_enabled_blocks_audit(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs(live=True))

    assert result.verdict == FINAL_SAFETY_BLOCKED
    assert any("Live trading" in blocker for blocker in result.blockers)


def test_production_whatsapp_enabled_blocks_audit(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs(production_alerts=True))

    assert result.verdict == FINAL_SAFETY_BLOCKED
    assert any("Production WhatsApp" in blocker for blocker in result.blockers)


def test_executable_place_order_path_blocks_audit(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)
    _write_file(tmp_path, "src/data_collection/bad_live_path.py", "kite.place_order(symbol='GOLD')\n")

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_BLOCKED
    assert result.executable_order_findings
    assert any("Executable broker/order-placement path" in blocker for blocker in result.blockers)


def test_non_executable_place_order_in_docs_tests_comments_is_warning_only(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)
    _write_file(tmp_path, "tests/test_guard.py", "assert 'place_order' not in module_text\n")
    _write_file(tmp_path, "src/data_collection/comment_only.py", "# kite.place_order must never run\n")

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_PASS_WITH_WARNINGS
    assert result.executable_order_findings == []
    assert len(result.non_executable_order_references) >= 2


def test_secret_like_token_is_masked_and_blocks(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)
    secret_value = "kiteAccessToken1234567890"
    _write_file(tmp_path, "reports/leak.txt", f"KITE_ACCESS_TOKEN={secret_value}\n")

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_BLOCKED
    assert result.secret_findings
    report = result.report_path.read_text(encoding="utf-8")
    assert secret_value not in report
    assert "value=****" in report


def test_local_env_secret_is_masked_warning_not_leak_blocker(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)
    _write_file(tmp_path, ".env", "KITE_ACCESS_TOKEN=kiteAccessToken1234567890\n")

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_PASS_WITH_WARNINGS
    assert result.secret_findings[0].classification == "LOCAL_ENV_SECRET_PRESENT"
    assert not any("Secret-like token" in blocker for blocker in result.blockers)
    report = result.report_path.read_text(encoding="utf-8")
    assert "kiteAccessToken1234567890" not in report
    assert "LOCAL_ENV_SECRET_PRESENT" in report


def test_launch1_waiting_and_research_only_appear_in_audit(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs())

    report = result.report_path.read_text(encoding="utf-8")
    assert result.launch1_decision == "LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA"
    assert result.strategy_status == "RESEARCH_ONLY"
    assert "launch1_decision: LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA" in report
    assert "strategy_status: RESEARCH_ONLY" in report


def test_csv_history_created(tmp_path):
    _write_safe_reports(tmp_path)
    _write_safe_project_files(tmp_path)

    first = run_final_safety_audit(tmp_path, configs=_configs())
    run_final_safety_audit(tmp_path, configs=_configs())

    with (tmp_path / HISTORY_PATH).open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 2
    assert rows[-1]["execution_allowed"] == "false"
    assert rows[-1]["verdict"] == first.verdict


def test_final_safety_uses_launch1_reconciled_data_quality_over_stale_pipeline(tmp_path):
    _write_reconciled_reports_with_stale_pipeline(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.verdict == FINAL_SAFETY_PASS_WITH_WARNINGS
    assert result.data_quality_status == "FULL_DEPTH"
    assert result.feature_mode == "DEPTH_ORDERFLOW_LITE"
    assert result.contract_consistency_status == "CONSISTENT"
    assert result.reconciliation_status == "RECONCILED"
    assert result.authoritative_feature_source == "DATA_COLLECTION_FEATURE_BUILDER_REPORT"
    assert result.launch1_decision == "LAUNCH1_READY_FOR_PAPER_RESEARCH"
    assert result.post_recording_verdict == "DAY_ACCEPTED_FOR_RESEARCH"
    assert result.forward_validation_decision == "RESEARCH_ONLY"
    report = result.report_path.read_text(encoding="utf-8")
    assert "data_quality_status: FULL_DEPTH" in report
    assert "feature_mode: DEPTH_ORDERFLOW_LITE" in report
    assert "contract_consistency_status: CONSISTENT" in report
    assert "reconciliation_status: RECONCILED" in report
    assert "authoritative_feature_source: DATA_COLLECTION_FEATURE_BUILDER_REPORT" in report
    assert "data_quality_status: MARKET_CLOSED_OR_NO_LIVE_DATA" not in report
    assert "feature_mode: NO_FEATURES" not in report
    assert "contract_consistency_status: NOT_CHECKED" not in report


def test_final_safety_warns_when_pipeline_stale_but_reconciled(tmp_path):
    _write_reconciled_reports_with_stale_pipeline(tmp_path)
    _write_safe_project_files(tmp_path)

    result = run_final_safety_audit(tmp_path, configs=_configs())

    assert result.blockers == []
    assert any("Daily pipeline report was stale/failed" in warning for warning in result.warnings)
    report = result.report_path.read_text(encoding="utf-8")
    assert "Daily pipeline report was stale/failed, but final safety uses reconciled verifier/feature-builder status." in report
    assert "pipeline_report_status: STALE_OR_FAILED" in report
    assert "data_collection_report_status: CLEAN_FEATURE_BUILDER_REPORT" in report
    assert "pipeline_report_stale_or_failed: true" in report
    assert "manual_feature_rebuild_reconciled_day: true" in report
