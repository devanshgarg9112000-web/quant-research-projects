from src.data.sample_data import generate_sample_candles, generate_sample_ticks
from src.indicators.absorption import detect_absorption
from src.indicators.cluster import build_cluster_table
from src.indicators.delta import calculate_delta_ticks
from src.indicators.key_levels import calculate_key_levels
from src.indicators.order_flow import analyze_order_flow


def test_order_flow_delta_and_absorption_possible():
    ticks = generate_sample_ticks()
    deltas = calculate_delta_ticks(ticks)
    assert any(row["delta"] != 0 for row in deltas)
    flow = analyze_order_flow(ticks)
    assert flow["total_delta"] != 0
    absorption = detect_absorption(generate_sample_candles(), build_cluster_table(ticks), calculate_key_levels(generate_sample_candles()))
    assert "bullish_absorption" in absorption
