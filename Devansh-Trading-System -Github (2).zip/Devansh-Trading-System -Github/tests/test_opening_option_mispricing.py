from __future__ import annotations

from datetime import date, timedelta

from src.options.black_scholes import black_scholes_price
from src.strategies import opening_option_mispricing
from src.strategies.opening_option_mispricing import scan_opening_option_mispricing


def _expiry() -> str:
    return (date.today() + timedelta(days=30)).isoformat()


def _fair(option_type: str = "CALL") -> float:
    return black_scholes_price(100, 100, 30 / 365, 0.065, 0.18, option_type)


def test_overpriced_bid_creates_sell_dry_run_row():
    fair = _fair("CALL")
    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100CE", "best_bid": fair * 1.25, "best_ask": fair * 1.33, "bid_qty": 100, "ask_qty": 100}],
        _expiry(),
    )

    assert rows
    assert rows[0]["suggested_action"] == "SELL"
    assert rows[0]["dry_run"] is True
    assert rows[0]["execution_allowed"] is False
    assert rows[0]["hedge_required"] is True
    assert rows[0]["risk_note"] == "Option selling is blocked in scanner mode. Hedge required. Dry-run only."
    assert "visible bid is above model fair value" in rows[0]["reason"]


def test_underpriced_ask_creates_buy_dry_run_row():
    fair = _fair("PUT")
    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100PE", "best_bid": fair * 0.70, "best_ask": fair * 0.80, "bid_qty": 100, "ask_qty": 100}],
        _expiry(),
    )

    assert rows
    assert rows[0]["suggested_action"] == "BUY"
    assert rows[0]["dry_run"] is True
    assert rows[0]["execution_allowed"] is False
    assert rows[0]["hedge_required"] is False
    assert rows[0]["risk_note"] == "Option buying is scanner-only. Manual review required. Dry-run only."
    assert "visible ask is below model fair value" in rows[0]["reason"]


def test_wide_spread_is_ignored():
    fair = _fair("CALL")
    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100CE", "best_bid": fair * 1.25, "best_ask": fair * 1.80, "bid_qty": 100, "ask_qty": 100}],
        _expiry(),
        max_spread_pct=20,
    )

    assert rows == []


def test_low_bid_quantity_ignores_sell():
    fair = _fair("CALL")
    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100CE", "best_bid": fair * 1.25, "best_ask": fair * 1.33, "bid_qty": 10, "ask_qty": 100}],
        _expiry(),
        min_depth_quantity=50,
    )

    assert rows == []


def test_low_ask_quantity_ignores_buy():
    fair = _fair("PUT")
    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100PE", "best_bid": fair * 0.70, "best_ask": fair * 0.80, "bid_qty": 100, "ask_qty": 10}],
        _expiry(),
        min_depth_quantity=50,
    )

    assert rows == []


def test_depth_like_quote_format_is_supported():
    fair = _fair("CALL")
    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{
            "symbol": "NIFTY30JUN100CE",
            "depth": {
                "buy": [{"price": fair * 1.25, "quantity": 100}],
                "sell": [{"price": fair * 1.33, "quantity": 100}],
            },
        }],
        _expiry(),
    )

    assert rows[0]["suggested_action"] == "SELL"
    assert rows[0]["dry_run"] is True


def test_sell_opening_spike_planner_uses_visible_bid_minus_one_tick(monkeypatch):
    monkeypatch.setattr(opening_option_mispricing, "black_scholes_price", lambda *args, **kwargs: 100.0)

    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100CE", "best_bid": 140, "best_ask": 141, "bid_qty": 100, "ask_qty": 100}],
        _expiry(),
        tick_size=0.05,
        suggested_limit_offset_ticks=1,
    )

    assert rows[0]["visible_match_side"] == "BUYER_BID"
    assert rows[0]["visible_match_price"] == 140.0
    assert rows[0]["suggested_limit_price"] == 139.95
    assert rows[0]["expected_gross_edge_points"] == 39.95
    assert rows[0]["execution_allowed"] is False
    assert rows[0]["hedge_required"] is True


def test_buy_opening_spike_planner_uses_visible_ask_plus_one_tick(monkeypatch):
    monkeypatch.setattr(opening_option_mispricing, "black_scholes_price", lambda *args, **kwargs: 100.0)

    rows = scan_opening_option_mispricing(
        "NIFTY",
        100,
        99,
        [{"symbol": "NIFTY30JUN100PE", "best_bid": 69, "best_ask": 70, "bid_qty": 100, "ask_qty": 100}],
        _expiry(),
        tick_size=0.05,
        suggested_limit_offset_ticks=1,
    )

    assert rows[0]["visible_match_side"] == "SELLER_ASK"
    assert rows[0]["visible_match_price"] == 70.0
    assert rows[0]["suggested_limit_price"] == 70.05
    assert rows[0]["expected_gross_edge_points"] == 29.95
    assert rows[0]["execution_allowed"] is False
    assert rows[0]["hedge_required"] is False
