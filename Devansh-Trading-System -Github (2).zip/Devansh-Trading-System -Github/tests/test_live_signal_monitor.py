from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone

from src.config_loader import load_configs
from src.data_feeds.tick_storage import save_normalized_ticks
from src.monitors.live_signal_monitor import LiveSignalMonitor, run_monitor
from src.scoring.strategy_verification import StrategyGateDecision


def _buyer_trap_ticks(symbol: str = "GOLD-I", count: int = 60) -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    ticks = []
    for index in range(count):
        ticks.append({
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": symbol,
            "ltp": 110.0,
            "ltq": 2,
            "volume": 100 + index,
            "oi": None,
            "bid": 109.0,
            "bid_qty": 10,
            "ask": 110.0,
            "ask_qty": 12,
        })
    ticks[-1].update({"ltp": 100.0, "bid": 100.0, "ask": 101.0})
    return ticks


class FakeClock:
    def __init__(self):
        self.value = 0.0

    def monotonic(self) -> float:
        return self.value

    def sleep(self, seconds: float) -> None:
        self.value += max(0.0, seconds)


class AllowStrategyGate:
    def evaluate(self, row):
        return StrategyGateDecision(True, "APPROVED", "strategy verification APPROVED", "cluster_imbalance_trap")


class RejectStrategyGate:
    def evaluate(self, row):
        return StrategyGateDecision(
            False,
            "REJECTED",
            "blocked_by_strategy_verification: status=REJECTED",
            "cluster_imbalance_trap",
        )


def _write_approval_report(base, status="APPROVED"):
    path = base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "strategy,symbol,status,confidence,trades,win_rate,net_pnl,profit_factor,expectancy,warnings,final_recommendation\n"
        f"cluster_imbalance_trap,GOLD-I,{status},LOW,5,40,120,1.3,24,NONE,test\n",
        encoding="utf-8",
    )


def test_monitor_runs_replay_writes_reports_and_never_orders(tmp_path, monkeypatch, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")

    def fail_place_order(*args, **kwargs):
        raise AssertionError("PAPER monitor must not place broker orders.")

    monkeypatch.setattr("src.main.PaperBroker.place_order", fail_place_order)

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="replay",
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        scan_interval=60,
        configs=configs,
    )

    out = capsys.readouterr().out
    assert result == 0
    assert "LAUNCH 1 LIVE PAPER SIGNAL DASHBOARD" in out
    assert "Launch: 1" in out
    assert "Accepted PAPER Signals: GOLD-I" in out
    assert "execution_allowed=false" in out
    assert "broker_orders=disabled" in out
    assert "PAPER MODE ONLY" in out
    assert "Manual Execution Only" in out
    report_dir = tmp_path / "reports" / "signals"
    assert (report_dir / "live_signal_log.csv").exists()
    assert (report_dir / "latest_live_signal_dashboard.txt").exists()
    with (report_dir / "live_signal_log.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["status"] == "ACCEPTED_PAPER_SIGNAL"
    assert rows[0]["execution_allowed"] == "false"


def test_duplicate_signal_is_skipped_within_five_minutes(tmp_path):
    configs = load_configs(".")
    times = iter([
        datetime(2026, 6, 10, 10, 0, tzinfo=timezone.utc),
        datetime(2026, 6, 10, 10, 1, tzinfo=timezone.utc),
    ])
    monitor = LiveSignalMonitor(
        tmp_path,
        configs,
        ["GOLD-I"],
        "replay",
        scan_interval=60,
        window_seconds=300,
        alert_channel="whatsapp-dry-run",
        now_fn=lambda: next(times),
        strategy_gate=AllowStrategyGate(),
    )
    ticks = _buyer_trap_ticks()

    monitor.scan_ticks(ticks)
    monitor.scan_ticks(ticks)

    with monitor.signal_log_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 1
    dashboard = monitor.dashboard_path.read_text(encoding="utf-8")
    assert "Duplicate Signals Skipped: 1" in dashboard
    assert "execution_allowed=false" in dashboard
    assert "Manual Execution Only" in dashboard
    alert_log = tmp_path / "reports" / "alerts" / "whatsapp_alert_log.csv"
    with alert_log.open(newline="", encoding="utf-8") as f:
        alert_rows = list(csv.DictReader(f))
    assert len(alert_rows) == 1


def test_monitor_whatsapp_dry_run_creates_alert_preview(tmp_path, monkeypatch):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")
    _write_approval_report(tmp_path)

    def fail_place_order(*args, **kwargs):
        raise AssertionError("WhatsApp monitor must not place broker orders.")

    monkeypatch.setattr("src.main.PaperBroker.place_order", fail_place_order)

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="replay",
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        scan_interval=60,
        alert_channel="whatsapp-dry-run",
        configs=configs,
    )

    assert result == 0
    preview = tmp_path / "reports" / "alerts" / "latest_whatsapp_alert_preview.txt"
    alert_log = tmp_path / "reports" / "alerts" / "whatsapp_alert_log.csv"
    assert preview.exists()
    assert alert_log.exists()
    assert "execution_allowed=false" in preview.read_text(encoding="utf-8")


def test_rejected_strategy_is_blocked_from_whatsapp_and_logged(tmp_path):
    configs = load_configs(".")
    monitor = LiveSignalMonitor(
        tmp_path,
        configs,
        ["GOLD-I"],
        "replay",
        scan_interval=60,
        window_seconds=300,
        alert_channel="whatsapp-dry-run",
        strategy_gate=RejectStrategyGate(),
    )

    monitor.scan_ticks(_buyer_trap_ticks())

    assert monitor.last_scan_stats["whatsapp_alerts"] == 0
    assert not (tmp_path / "reports" / "alerts" / "latest_whatsapp_alert_preview.txt").exists()
    with monitor.signal_log_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["strategy_verification_status"] == "REJECTED"
    assert "blocked_by_strategy_verification" in rows[0]["strategy_verification_reason"]
    assert rows[0]["alert_allowed"] == "False"


def test_approved_strategy_is_allowed_for_paper_whatsapp_alert(tmp_path):
    configs = load_configs(".")
    monitor = LiveSignalMonitor(
        tmp_path,
        configs,
        ["GOLD-I"],
        "replay",
        scan_interval=60,
        window_seconds=300,
        alert_channel="whatsapp-dry-run",
        strategy_gate=AllowStrategyGate(),
    )

    monitor.scan_ticks(_buyer_trap_ticks())

    assert monitor.last_scan_stats["whatsapp_alerts"] == 1
    preview = tmp_path / "reports" / "alerts" / "latest_whatsapp_alert_preview.txt"
    assert preview.exists()
    assert "execution_allowed=false" in preview.read_text(encoding="utf-8")


def test_max_runtime_stops_monitor_and_writes_heartbeat(tmp_path, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")
    clock = FakeClock()

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="replay",
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        scan_interval=60,
        max_runtime_seconds=180,
        heartbeat_interval_seconds=60,
        configs=configs,
        monotonic_fn=clock.monotonic,
        sleep_fn=clock.sleep,
    )

    out = capsys.readouterr().out
    assert result == 0
    assert "Shutdown Reason: MAX_RUNTIME_REACHED" in out
    assert "Total Scans: 3" in out
    heartbeat = tmp_path / "reports" / "signals" / "latest_monitor_heartbeat.txt"
    assert heartbeat.exists()
    text = heartbeat.read_text(encoding="utf-8")
    assert "Total Scans: 3" in text
    assert "Live Trading: DISABLED" in text
    assert "Broker Orders: DISABLED" in text
    assert "PAPER MODE ONLY" in text
    assert "Manual Execution Only" in text
    assert "execution_allowed=false" in text


def test_scan_error_is_logged_and_next_scan_continues(tmp_path, monkeypatch, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")
    clock = FakeClock()
    original_scan = LiveSignalMonitor.scan_ticks
    calls = {"count": 0}
    secret = "hidden-monitor-token"
    monkeypatch.setenv("WHATSAPP_ACCESS_TOKEN", secret)

    def fail_once(self, ticks):
        calls["count"] += 1
        if calls["count"] == 1:
            raise RuntimeError(f"temporary provider failure {secret}")
        return original_scan(self, ticks)

    monkeypatch.setattr(LiveSignalMonitor, "scan_ticks", fail_once)

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="replay",
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        scan_interval=1,
        max_runtime_seconds=2,
        heartbeat_interval_seconds=1,
        alert_channel="whatsapp-dry-run",
        configs=configs,
        monotonic_fn=clock.monotonic,
        sleep_fn=clock.sleep,
    )

    out = capsys.readouterr().out
    assert result == 0
    assert calls["count"] == 2
    assert "Scan 1 failed safely: RuntimeError. Continuing." in out
    assert secret not in out
    error_log = tmp_path / "reports" / "signals" / "monitor_error_log.csv"
    assert error_log.exists()
    with error_log.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["error_type"] == "RuntimeError"
    assert rows[0]["scan_number"] == "1"
    assert secret not in rows[0]["error_message"]
    assert "[REDACTED]" in rows[0]["error_message"]
    error_preview = tmp_path / "reports" / "alerts" / "latest_whatsapp_error_preview.txt"
    assert error_preview.exists()
    assert secret not in error_preview.read_text(encoding="utf-8")


def test_ctrl_c_shutdown_is_graceful(tmp_path, monkeypatch, capsys):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")

    def interrupt_scan(self, ticks):
        raise KeyboardInterrupt

    monkeypatch.setattr(LiveSignalMonitor, "scan_ticks", interrupt_scan)

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="replay",
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        scan_interval=1,
        max_runtime_seconds=10,
        configs=configs,
    )

    out = capsys.readouterr().out
    assert result == 0
    assert "Shutdown Reason: CTRL_C" in out
    assert "Broker Orders: DISABLED" in out
    assert "execution_allowed=false" in out


def test_log_file_captures_monitor_output(tmp_path):
    tick_path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), tick_path)
    configs = load_configs(".")

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="replay",
        tick_file=str(tick_path),
        symbols_text="GOLD-I",
        scan_interval=60,
        heartbeat_interval_seconds=0,
        log_file="reports/signals/monitor_console.log",
        configs=configs,
    )

    assert result == 0
    log_path = tmp_path / "reports" / "signals" / "monitor_console.log"
    assert log_path.exists()
    text = log_path.read_text(encoding="utf-8")
    assert "LAUNCH 1 ALL-DAY PAPER SIGNAL MONITOR" in text
    assert "FINAL MONITOR SUMMARY" in text


def test_truedata_monitor_record_ticks_writes_latest_and_daily_files(tmp_path, monkeypatch):
    configs = load_configs(".")
    ticks = _buyer_trap_ticks("GOLD-I", 12)

    class FakeTrueDataFeed:
        def __init__(self, settings, base, allow_network=True):
            self.settings = settings
            self.base = base
            self.allow_network = allow_network

        def collect_live_ticks(self, symbols, seconds, echo=False):
            return ticks

    monkeypatch.setattr("src.monitors.live_signal_monitor.TrueDataFeed", FakeTrueDataFeed)

    result = run_monitor(
        base_dir=tmp_path,
        data_feed="truedata",
        symbols_text="GOLD-I",
        scan_interval=1,
        window_seconds=300,
        max_scans=1,
        heartbeat_interval_seconds=0,
        record_ticks=True,
        configs=configs,
    )

    latest = tmp_path / "data" / "ticks" / "latest_truedata_ticks.csv"
    daily = tmp_path / "data" / "ticks" / "daily" / "2026-06-10" / "GOLD-I_ticks.csv"
    assert result == 0
    assert latest.exists()
    assert daily.exists()
    with daily.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 12
    assert rows[0]["source"] == "TRUEDATA_MONITOR"
