from pathlib import Path

import pytest

from src.brokers import kite_broker
from src.brokers.kite_broker import KiteBroker, evaluate_live_order_guard, extract_request_token, mask_login_url


def test_kite_request_token_extraction_from_redirect_url():
    redirect_url = "https://127.0.0.1/?status=success&request_token=abc123xyz&action=login"
    assert extract_request_token(redirect_url) == "abc123xyz"


def test_live_trading_guard_blocks_orders_by_default(monkeypatch):
    monkeypatch.delenv("ENABLE_LIVE_TRADING", raising=False)
    monkeypatch.delenv("I_UNDERSTAND_LIVE_TRADING_RISK", raising=False)
    result = evaluate_live_order_guard(
        mode="PAPER",
        settings={"enable_live_trading": False},
        risk_config={"allow_live_trading": False},
        broker_name="paper",
        env={},
    )
    assert not result.approved
    assert "mode is not LIVE" in result.reasons
    assert "broker is not explicitly selected as kite" in result.reasons

    broker = KiteBroker(settings={"mode": "PAPER", "enable_live_trading": False}, risk_config={"allow_live_trading": False}, broker_name="paper")
    with pytest.raises(RuntimeError, match="refused live order"):
        broker.place_order(risk_approved=True)


def test_kite_login_saves_token_without_printing_secrets(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("KITE_API_KEY", "api_key_secret_123")
    monkeypatch.setenv("KITE_API_SECRET", "api_secret_456")
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    class FakeKiteConnect:
        def __init__(self, api_key):
            self.api_key = api_key

        def login_url(self):
            return f"https://kite.example/connect/login?api_key={self.api_key}&v=3"

        def generate_session(self, request_token, api_secret):
            assert request_token == "request_token_secret_789"
            assert api_secret == "api_secret_456"
            return {"access_token": "access_token_secret_abc"}

    monkeypatch.setattr(kite_broker, "_kite_connect_class", lambda: FakeKiteConnect)
    monkeypatch.setattr("builtins.input", lambda prompt: "https://localhost/callback?request_token=request_token_secret_789&status=success")

    result = kite_broker._login_cli(tmp_path)

    out = capsys.readouterr().out
    assert result == 0
    assert "access_token_secret_abc" not in out
    assert "request_token_secret_789" not in out
    assert "api_key_secret_123" not in out
    assert "Masked URL preview" not in out
    assert (tmp_path / ".tokens").exists()
    assert kite_broker.load_saved_access_token(tmp_path) == "access_token_secret_abc"

    fresh_client = KiteBroker(base_dir=tmp_path, broker_name="kite")
    assert fresh_client.access_token == "access_token_secret_abc"
    assert fresh_client.credential_state.access_token_source == "DAILY_TOKEN_FILE"


def test_today_token_file_overrides_stale_environment_token(monkeypatch, tmp_path):
    monkeypatch.setenv("KITE_API_KEY", "api_key_secret_123")
    monkeypatch.setenv("KITE_API_SECRET", "api_secret_456")
    monkeypatch.setenv("KITE_ACCESS_TOKEN", "stale_environment_token")
    token_path = kite_broker._today_token_path(tmp_path)
    token_path.parent.mkdir(parents=True)
    token_path.write_text("  fresh_daily_token\n", encoding="utf-8")

    broker = KiteBroker(base_dir=tmp_path, broker_name="kite")

    assert broker.access_token == "fresh_daily_token"
    assert broker.credential_state.access_token_source == "DAILY_TOKEN_FILE"
    assert kite_broker.load_saved_access_token(tmp_path) == "fresh_daily_token"


def test_missing_daily_token_fails_read_credentials_even_with_stale_env(monkeypatch, tmp_path):
    monkeypatch.setenv("KITE_API_KEY", "api_key_secret_123")
    monkeypatch.setenv("KITE_ACCESS_TOKEN", "stale_environment_token")

    broker = KiteBroker(base_dir=tmp_path, broker_name="kite")

    assert broker.access_token is None
    assert broker.credential_state.access_token_source == "MISSING"
    assert "KITE_ACCESS_TOKEN or today's saved token from --login" in broker._missing_read_credentials()


def test_auth_diagnose_reports_sources_without_secret_values(monkeypatch, tmp_path, capsys):
    secrets = {
        "KITE_API_KEY": "api_key_secret_123",
        "KITE_API_SECRET": "api_secret_456",
        "KITE_ACCESS_TOKEN": "stale_environment_token",
    }
    for key, value in secrets.items():
        monkeypatch.setenv(key, value)
    kite_broker.save_access_token("fresh_daily_token", tmp_path)

    assert kite_broker._auth_diagnose_cli(tmp_path) == 0
    output = capsys.readouterr().out
    assert "source=DAILY_TOKEN_FILE" in output
    assert "Daily token file: PRESENT" in output
    assert "No network call was made" in output
    for secret in [*secrets.values(), "fresh_daily_token"]:
        assert secret not in output


def test_authenticated_client_uses_canonical_daily_session(monkeypatch, tmp_path):
    monkeypatch.setenv("KITE_API_KEY", "api_key_secret_123")
    monkeypatch.setenv("KITE_ACCESS_TOKEN", "stale_environment_token")
    kite_broker.save_access_token("fresh_daily_token", tmp_path)

    class FakeKiteConnect:
        def __init__(self, api_key):
            assert api_key == "api_key_secret_123"
            self.access_token = None

        def set_access_token(self, access_token):
            self.access_token = access_token

    monkeypatch.setattr(kite_broker, "_kite_connect_class", lambda: FakeKiteConnect)
    broker = KiteBroker(base_dir=tmp_path, broker_name="kite")
    client, error = broker._authenticated_client()

    assert error is None
    assert client.access_token == "fresh_daily_token"


def test_option_signal_live_consumers_do_not_load_credentials_independently():
    root = Path(__file__).resolve().parents[1]
    for relative in ["src/option_signals/cli.py", "src/option_signals/runtime.py", "src/option_signals/market_data.py"]:
        text = (root / relative).read_text(encoding="utf-8")
        assert "KITE_ACCESS_TOKEN" not in text
        assert "KiteBroker" in text


def test_kite_profile_test_uses_mock_client(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("KITE_API_KEY", "api_key_secret_123")
    monkeypatch.setenv("KITE_ACCESS_TOKEN", "access_token_secret_abc")
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    kite_broker.save_access_token("access_token_secret_abc", tmp_path)

    class FakeKiteConnect:
        def __init__(self, api_key):
            self.api_key = api_key
            self.access_token = None

        def set_access_token(self, access_token):
            self.access_token = access_token

        def profile(self):
            return {"user_id": "DU1234", "user_name": "Devansh", "email": "devansh@example.com", "broker": "ZERODHA"}

        def margins(self):
            return {"equity": {"available": {"cash": 1000}}}

        def positions(self):
            return {"day": [], "net": [{"tradingsymbol": "RELIANCE"}]}

        def instruments(self):
            return [{"exchange": "NSE", "tradingsymbol": "RELIANCE", "instrument_type": "EQ"}]

    monkeypatch.setattr(kite_broker, "_kite_connect_class", lambda: FakeKiteConnect)

    result = kite_broker._profile_test_cli(tmp_path)

    out = capsys.readouterr().out
    assert result == 0
    assert "Kite profile test succeeded" in out
    assert "access_token_secret_abc" not in out
    assert "api_key_secret_123" not in out
    assert "net_count" in out


def test_kite_quote_test_uses_mock_client(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("KITE_API_KEY", "api_key_secret_123")
    monkeypatch.setenv("KITE_ACCESS_TOKEN", "access_token_secret_abc")
    kite_broker.save_access_token("access_token_secret_abc", tmp_path)

    class FakeKiteConnect:
        def __init__(self, api_key):
            self.api_key = api_key

        def set_access_token(self, access_token):
            self.access_token = access_token

        def quote(self, symbols):
            assert symbols == ["NSE:RELIANCE", "NSE:INFY"]
            return {"NSE:RELIANCE": {"last_price": 2500}, "NSE:INFY": {"last_price": 1500}}

        def instruments(self):
            return [{"exchange": "NSE", "tradingsymbol": "INFY", "instrument_type": "EQ"}]

    monkeypatch.setattr(kite_broker, "_kite_connect_class", lambda: FakeKiteConnect)

    result = kite_broker._quote_test_cli("NSE:RELIANCE,NSE:INFY", tmp_path)

    out = capsys.readouterr().out
    assert result == 0
    assert "Kite quote test succeeded" in out
    assert "NSE:RELIANCE" in out
    assert "access_token_secret_abc" not in out


def test_kite_mask_login_url_hides_api_key():
    masked = mask_login_url("https://kite.example/connect/login?api_key=api_key_secret_123&v=3")

    assert "api_key_secret_123" not in masked
    assert "api_key=api_" in masked
