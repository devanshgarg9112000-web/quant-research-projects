from src.data.sample_data import generate_sample_candles
from src.indicators.key_levels import calculate_key_levels


def test_key_levels_calculated():
    levels = calculate_key_levels(generate_sample_candles())
    assert levels["day_high_so_far"] >= levels["day_low_so_far"]
    assert levels["previous_day_high"] is not None
