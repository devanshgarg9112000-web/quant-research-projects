from datetime import datetime, timedelta

from src.indicators.cluster_diagnostics import (
    assess_data_sufficiency,
    build_symbol_diagnostics,
    build_mcx_cluster_gate,
    build_volume_at_price,
    calculate_delta_cvd_by_candle,
    classify_tick_aggression,
    find_stacked_imbalance_zones,
    format_diagnostics_report,
    evaluate_mcx_cluster_gate_for_side,
)


def _tick(symbol, seconds, ltp, ltq, bid=None, ask=None):
    return {
        "symbol": symbol,
        "timestamp": datetime(2026, 1, 1, 9, 15) + timedelta(seconds=seconds),
        "ltp": ltp,
        "ltq": ltq,
        "volume": ltq,
        "oi": None,
        "bid": bid,
        "ask": ask,
        "bid_qty": 1 if bid is not None else None,
        "ask_qty": 1 if ask is not None else None,
        "raw": {},
    }


def test_classify_tick_aggression_handles_buy_sell_unknown():
    assert classify_tick_aggression(_tick("X", 0, 100, 10, bid=99, ask=100)) == "BUY"
    assert classify_tick_aggression(_tick("X", 1, 99, 10, bid=99, ask=100)) == "SELL"
    assert classify_tick_aggression(_tick("X", 2, 99.5, 10, bid=99, ask=100)) == "UNKNOWN"


def test_delta_and_cvd_by_candle_are_calculated():
    ticks = [
        _tick("X", 0, 100, 10, bid=99, ask=100),
        _tick("X", 1, 99, 4, bid=99, ask=100),
        _tick("X", 20, 101, 3, bid=100, ask=101),
    ]

    rows = calculate_delta_cvd_by_candle(ticks, bucket_seconds=15)

    assert rows[0]["delta"] == 6
    assert rows[0]["cvd"] == 6
    assert rows[1]["delta"] == 3
    assert rows[1]["cvd"] == 9


def test_volume_at_price_marks_estimated_imbalances():
    ticks = [
        _tick("X", 0, 100, 10, bid=99, ask=100),
        _tick("X", 1, 100, 5, bid=99, ask=100),
        _tick("X", 2, 99, 3, bid=99, ask=100),
    ]

    rows = build_volume_at_price(ticks, imbalance_ratio=3)
    price_100 = [row for row in rows if row["price"] == 100][0]

    assert price_100["ask_volume_at_price"] == 15
    assert price_100["buy_imbalance"] is True
    assert price_100["classification"] == "ESTIMATED_FROM_LTP_VS_BID_ASK"


def test_stacked_imbalance_zones_require_three_levels():
    rows = [
        {"price": 100, "buy_imbalance": True, "sell_imbalance": False},
        {"price": 101, "buy_imbalance": True, "sell_imbalance": False},
        {"price": 102, "buy_imbalance": True, "sell_imbalance": False},
    ]

    zones = find_stacked_imbalance_zones(rows, "BUY")

    assert zones == [{"side": "BUY", "from_price": 100, "to_price": 102, "levels": [100, 101, 102]}]


def test_symbol_diagnostics_and_report_note_weak_data():
    ticks = [_tick("X", 0, 100, 10, bid=99, ask=100)]

    diagnostics = build_symbol_diagnostics("X", ticks, bucket_seconds=15)
    report = format_diagnostics_report([diagnostics])

    assert diagnostics["data_sufficient"] is False
    assert "Only 1 ticks" in diagnostics["data_quality_notes"][0]
    assert "ESTIMATED" in report
    assert "PAPER MODE ONLY" in report


def test_data_sufficiency_reports_missing_bid_ask_context():
    ticks = [_tick("X", i, 100 + i, 1) for i in range(60)]

    reliable, notes = assess_data_sufficiency(ticks)

    assert reliable is False
    assert any("Bid/ask coverage" in note for note in notes)


def test_mcx_buyer_trap_gate_only_passes_sell_candidates():
    gate = build_mcx_cluster_gate({
        "symbol": "GOLD-I",
        "data_sufficient": True,
        "cluster_imbalance_trap_status": "ESTIMATED_BUYER_TRAP_POSSIBLE",
    })

    sell_allowed, sell_reason, sell_status = evaluate_mcx_cluster_gate_for_side(gate, "SELL")
    buy_allowed, buy_reason, buy_status = evaluate_mcx_cluster_gate_for_side(gate, "BUY")

    assert gate["preferred_side"] == "SELL"
    assert sell_allowed is True
    assert sell_status == "PASS"
    assert "confirms SELL" in sell_reason
    assert buy_allowed is False
    assert buy_status == "REJECT_SIDE_CONFLICT"
    assert "prefers SELL" in buy_reason


def test_mcx_cluster_gate_blocks_insufficient_data():
    gate = build_mcx_cluster_gate({
        "symbol": "SILVER-I",
        "data_sufficient": False,
        "cluster_imbalance_trap_status": "ESTIMATED_BUYER_TRAP_POSSIBLE",
    })

    allowed, reason, status = evaluate_mcx_cluster_gate_for_side(gate, "SELL")

    assert allowed is False
    assert status == "BLOCKED_DATA_INSUFFICIENT"
    assert "insufficient" in reason.lower()
