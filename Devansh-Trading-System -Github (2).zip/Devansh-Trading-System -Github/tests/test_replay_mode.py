from __future__ import annotations

import csv
from datetime import datetime, timedelta

import pytest

from src.data_feeds.tick_storage import TickCsvError, load_normalized_ticks, save_normalized_ticks
from src.main import run_replay_paper_mode
from src.models.signal import Signal
from src.replay.replay_engine import filter_replay_ticks, group_replay_ticks, parse_replay_symbols


def _ticks(count: int = 6) -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    rows = []
    for index in range(count):
        rows.append({
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": "GOLD-I",
            "ltp": 100.0 + index,
            "ltq": 1,
            "volume": 100 + index,
            "oi": None,
            "bid": 99.5 + index,
            "bid_qty": 10,
            "ask": 100.0 + index,
            "ask_qty": 12,
        })
    return rows


def _buyer_trap_ticks(count: int = 60) -> list[dict]:
    ticks = _ticks(count)
    for index, tick in enumerate(ticks):
        tick["ltp"] = 110.0
        tick["bid"] = 109.0
        tick["ask"] = 110.0
        tick["ltq"] = 2
    ticks[-1].update({"ltp": 100.0, "bid": 100.0, "ask": 101.0})
    return ticks


def test_replay_csv_parsing_round_trip(tmp_path):
    path = tmp_path / "ticks.csv"
    save_normalized_ticks(_ticks(2), path)

    loaded = load_normalized_ticks(path)

    assert loaded[0]["timestamp"] == datetime(2026, 6, 10, 9, 15)
    assert loaded[0]["symbol"] == "GOLD-I"
    assert loaded[0]["ltp"] == 100.0
    assert loaded[0]["oi"] is None


def test_replay_symbol_filter_and_grouping():
    ticks = _ticks(2) + [{**tick, "symbol": "SILVER-I"} for tick in _ticks(3)]

    symbols = parse_replay_symbols("SILVER-I, SILVER-I")
    filtered = filter_replay_ticks(ticks, symbols)
    grouped = group_replay_ticks(filtered)

    assert symbols == ["SILVER-I"]
    assert len(filtered) == 3
    assert list(grouped) == ["SILVER-I"]
    assert all(tick["symbol"] == "SILVER-I" for tick in grouped["SILVER-I"])


def test_replay_csv_missing_columns_are_clear(tmp_path):
    path = tmp_path / "bad_ticks.csv"
    path.write_text("timestamp,symbol,ltp\n2026-06-10 09:15:00,GOLD-I,100\n", encoding="utf-8")

    with pytest.raises(TickCsvError, match="missing columns"):
        load_normalized_ticks(path)


def test_replay_missing_file_handling(tmp_path, capsys):
    run_replay_paper_mode(tmp_path, {}, {}, {}, symbols_text=None, tick_file="missing.csv")

    out = capsys.readouterr().out
    assert "Replay tick file missing" in out
    assert "PAPER MODE ONLY. No broker orders were placed." in out
    assert "Tick File:" in out


def test_replay_mode_does_not_enable_live_trading(tmp_path, capsys):
    path = tmp_path / "ticks.csv"
    save_normalized_ticks(_ticks(2), path)
    settings = {"mode": "LIVE", "enable_live_trading": True}

    run_replay_paper_mode(tmp_path, settings, {}, {}, symbols_text=None, tick_file=str(path))

    out = capsys.readouterr().out
    assert "Live Trading: DISABLED" in out
    assert "Data Feed: REPLAY" in out
    assert "Broker Orders: DISABLED" in out
    assert "PAPER MODE ONLY. No broker orders were placed." in out
    assert settings["enable_live_trading"] is True


def test_replay_empty_tick_file_is_clear(tmp_path, capsys):
    path = tmp_path / "empty.csv"
    save_normalized_ticks([], path)

    run_replay_paper_mode(tmp_path, {}, {}, {}, symbols_text=None, tick_file=str(path))

    out = capsys.readouterr().out
    assert "Replay tick file is empty. No signal evaluation performed." in out
    assert "PAPER MODE ONLY. No broker orders were placed." in out


def test_replay_filters_before_strategy_evaluation(tmp_path, monkeypatch):
    path = tmp_path / "ticks.csv"
    mixed = _ticks(6) + [{**tick, "symbol": "SILVER-I"} for tick in _ticks(6)]
    save_normalized_ticks(mixed, path)
    seen = {}

    class FakeEngine:
        def __init__(self, settings, strategies):
            pass

        def run(self, candles, ticks):
            seen["symbols"] = {tick["symbol"] for tick in ticks}
            seen["tick_count"] = len(ticks)
            return type("Result", (), {
                "market_mode": "RANGE",
                "candidates": [],
                "best_signal": None,
                "rejected_reasons": [],
                "context": {},
            })()

    monkeypatch.setattr("src.main.StrategyEngine", FakeEngine)

    run_replay_paper_mode(tmp_path, {}, {}, {}, symbols_text="SILVER-I", tick_file=str(path))

    assert seen == {"symbols": {"SILVER-I"}, "tick_count": 6}


def test_replay_passes_saved_ticks_through_cluster_trap_strategy(tmp_path, capsys):
    path = tmp_path / "ticks.csv"
    save_normalized_ticks(_buyer_trap_ticks(), path)
    strategies = {"cluster_imbalance_trap": True}
    risk = {
        "capital": 100000,
        "risk_per_trade_percent": 0.5,
        "min_reward_risk": 2.0,
        "allow_long_trades": True,
        "allow_short_trades": True,
        "max_trades_per_day": 3,
        "max_daily_loss_percent": 1.5,
        "max_consecutive_losses": 2,
        "max_spread_percent": 0.25,
        "allow_live_trading": False,
    }

    run_replay_paper_mode(tmp_path, {}, risk, strategies, symbols_text="GOLD-I", tick_file=str(path))

    out = capsys.readouterr().out
    assert "MCX Cluster Diagnostic: ESTIMATED_BUYER_TRAP_POSSIBLE" in out
    assert "MCX Estimated Buyer Trap Short SELL" in out
    assert "Accepted PAPER signal:" in out
    assert "Risk Per Unit:" in out
    assert "Estimated Risk Amount:" in out
    assert "PAPER MODE ONLY" in out
    assert "Execution Allowed: false" in out


def test_replay_mode_does_not_place_broker_orders(tmp_path, monkeypatch):
    path = tmp_path / "ticks.csv"
    save_normalized_ticks(_ticks(6), path)
    signal = Signal(
        symbol="GOLD-I",
        timestamp=datetime(2026, 6, 10, 9, 16),
        strategy_name="Replay Forced Signal",
        side="BUY",
        entry_price=105,
        stop_loss=100,
        target_price=115,
        reward_risk=2,
        score=9,
        reason="forced test signal",
        market_mode="RANGE",
    )

    class FakeEngine:
        def __init__(self, settings, strategies):
            pass

        def run(self, candles, ticks):
            return type("Result", (), {
                "market_mode": "RANGE",
                "candidates": [signal],
                "best_signal": signal,
                "rejected_reasons": [],
            })()

    class FakeRiskEngine:
        def __init__(self, risk_config, settings, instruments=None):
            pass

        def validate_signal(self, signal, mode=None, data_quality_ok=True):
            return type("Decision", (), {"approved": True, "quantity": 1, "risk_amount": 5.0, "reasons": []})()

    def fail_place_order(*args, **kwargs):
        raise AssertionError("Replay mode must not place broker orders.")

    monkeypatch.setattr("src.main.StrategyEngine", FakeEngine)
    monkeypatch.setattr("src.main.RiskEngine", FakeRiskEngine)
    monkeypatch.setattr("src.main.PaperBroker.place_order", fail_place_order)

    run_replay_paper_mode(tmp_path, {}, {}, {"forced": True}, symbols_text=None, tick_file=str(path))

    signals_csv = tmp_path / "reports" / "daily_trade_reports" / "latest_paper_signals.csv"
    assert signals_csv.exists()
    csv_text = signals_csv.read_text(encoding="utf-8")
    assert "execution_allowed" in csv_text
    assert "false" in csv_text


def test_final_dashboard_contains_accepted_gold_and_rejected_silver(tmp_path, monkeypatch, capsys):
    path = tmp_path / "ticks.csv"
    mixed_ticks = _ticks(6) + [{**tick, "symbol": "SILVER-I"} for tick in _ticks(6)]
    save_normalized_ticks(mixed_ticks, path)
    signals = {
        "GOLD-I": Signal(
            symbol="GOLD-I",
            timestamp=datetime(2026, 6, 10, 9, 16),
            strategy_name="MCX Estimated Buyer Trap Short",
            side="SELL",
            entry_price=105,
            stop_loss=110,
            target_price=95,
            reward_risk=2,
            score=8.8,
            reason="buyer trap confirmed",
            market_mode="TREND_DOWN",
        ),
        "SILVER-I": Signal(
            symbol="SILVER-I",
            timestamp=datetime(2026, 6, 10, 9, 16),
            strategy_name="MCX Estimated Buyer Trap Short",
            side="SELL",
            entry_price=205,
            stop_loss=220,
            target_price=175,
            reward_risk=2,
            score=8.8,
            reason="buyer trap confirmed",
            market_mode="RANGE",
        ),
    }

    class FakeEngine:
        def __init__(self, settings, strategies):
            pass

        def run(self, candles, ticks):
            symbol = ticks[0]["symbol"]
            signal = signals[symbol]
            return type("Result", (), {
                "market_mode": signal.market_mode,
                "candidates": [signal],
                "best_signal": signal,
                "rejected_reasons": [],
                "context": {
                    "cluster_diagnostics": {},
                    "cluster_gate": {
                        "applicable": True,
                        "diagnostic_status": "ESTIMATED_BUYER_TRAP_POSSIBLE",
                        "data_sufficient": True,
                        "preferred_side": "SELL",
                        "gate_status": "READY_SELL_CONFIRMATION",
                        "reason": "buyer trap permits SELL",
                    },
                },
            })()

    class FakeRiskEngine:
        def __init__(self, risk_config, settings, instruments=None):
            pass

        def validate_signal(self, signal, mode=None, data_quality_ok=True):
            approved = signal.symbol == "GOLD-I"
            reason = "risk amount too small for minimum MCX quantity"
            return type("Decision", (), {
                "approved": approved,
                "quantity": 1 if approved else 0,
                "risk_amount": 5.0 if approved else 0.0,
                "reasons": [] if approved else [reason],
                "sizing": {
                    "calculated_qty": 1 if approved else 0,
                    "allowed_risk_amount": 500.0,
                    "estimated_risk_amount": 5.0 if approved else 0.0,
                    "risk_per_unit": 5.0 if approved else 15.0,
                    "rejection_reason": None if approved else reason,
                },
            })()

    def fail_place_order(*args, **kwargs):
        raise AssertionError("Dashboard generation must not place broker orders.")

    monkeypatch.setattr("src.main.StrategyEngine", FakeEngine)
    monkeypatch.setattr("src.main.RiskEngine", FakeRiskEngine)
    monkeypatch.setattr("src.main.PaperBroker.place_order", fail_place_order)

    run_replay_paper_mode(
        tmp_path,
        {},
        {},
        {"cluster_imbalance_trap": True},
        symbols_text="GOLD-I,SILVER-I",
        tick_file=str(path),
    )

    out = capsys.readouterr().out
    assert "FINAL PAPER SIGNAL DASHBOARD" in out
    assert "Symbol: GOLD-I" in out
    assert "Status: ACCEPTED_PAPER_SIGNAL" in out
    assert "Symbol: SILVER-I" in out
    assert "Status: RISK_REJECTED" in out
    assert "Execution Allowed: false" in out

    report_dir = tmp_path / "reports" / "daily_trade_reports"
    dashboard_txt = report_dir / "latest_paper_signal_dashboard.txt"
    dashboard_csv = report_dir / "latest_paper_signal_dashboard.csv"
    combined_report = report_dir / "latest_live_paper_report.txt"
    assert dashboard_txt.exists()
    assert dashboard_csv.exists()
    assert "FINAL PAPER SIGNAL DASHBOARD" in combined_report.read_text(encoding="utf-8")
    dashboard_text = dashboard_txt.read_text(encoding="utf-8")
    assert "ACCEPTED_PAPER_SIGNAL" in dashboard_text
    assert "RISK_REJECTED" in dashboard_text
    with dashboard_csv.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["symbol"] == "GOLD-I"
    assert rows[0]["status"] == "ACCEPTED_PAPER_SIGNAL"
    assert rows[0]["execution_allowed"] == "false"
    assert rows[1]["symbol"] == "SILVER-I"
    assert rows[1]["status"] == "RISK_REJECTED"
