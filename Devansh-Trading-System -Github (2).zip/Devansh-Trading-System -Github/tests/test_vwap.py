from src.data.sample_data import generate_sample_candles
from src.indicators.vwap import calculate_vwap


def test_vwap_created_and_cumulative_volume():
    rows = calculate_vwap(generate_sample_candles())
    assert "vwap" in rows[0]
    assert all(row["vwap"] for row in rows)
    assert rows[-1]["cumulative_volume"] > rows[0]["cumulative_volume"]
