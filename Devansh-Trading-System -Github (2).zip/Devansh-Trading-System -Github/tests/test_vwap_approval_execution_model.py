from __future__ import annotations

from datetime import datetime, timedelta

from src.backtesting import strategy_backtest_runner as runner
from src.models.signal import Signal


def _signal(side: str = "BUY") -> Signal:
    if side == "BUY":
        entry, stop, target = 100.0, 95.0, 110.0
    else:
        entry, stop, target = 100.0, 105.0, 90.0
    return Signal(
        symbol="GOLD-I",
        strategy_name="VWAP Rejection Short" if side == "SELL" else "VWAP Reclaim Long",
        setup_type="vwap_rejection" if side == "SELL" else "vwap_reclaim",
        side=side,
        entry_price=entry,
        stop_loss=stop,
        target_price=target,
        reward_risk=2.0,
        score=8.0,
        reason="test",
        market_mode="TREND_DOWN" if side == "SELL" else "TREND_UP",
        timestamp=datetime(2026, 6, 22, 9, 30),
    )


def _approval_controls(**overrides):
    values = {
        "execution_model": runner.CONSERVATIVE_VWAP_EXECUTION_MODEL,
        "entry_delay_ticks": 1,
        "cost_per_trade": 2.0,
        "slippage_points": 1.0,
        "spread_points": 0.5,
        "tick_size": 0.05,
        "same_bar_rule": "STOP_FIRST",
    }
    values.update(overrides)
    return runner.BacktestControls(**values)


def test_vwap_approval_grade_requires_cost_slippage_spread_and_tick_size():
    assert _approval_controls().approval_grade_execution_ready is True
    assert _approval_controls(entry_delay_ticks=0).approval_grade_execution_ready is False
    assert _approval_controls(cost_per_trade=0).approval_grade_execution_ready is False
    assert _approval_controls(slippage_points=0).approval_grade_execution_ready is False
    assert _approval_controls(spread_points=0).approval_grade_execution_ready is False
    assert _approval_controls(tick_size=0).approval_grade_execution_ready is False


def test_spread_points_reduce_net_pnl_compared_with_no_spread():
    signal_time = datetime(2026, 6, 22, 9, 30)
    future_ticks = [
        {"timestamp": signal_time + timedelta(seconds=1), "ltp": 100.0},
        {"timestamp": signal_time + timedelta(seconds=2), "ltp": 110.0},
    ]
    no_spread = runner._simulate_paper_trade(
        _signal("BUY"),
        quantity=1,
        future_ticks=future_ticks,
        signal_complete_at=signal_time,
        controls=_approval_controls(spread_points=0.0),
    )
    with_spread = runner._simulate_paper_trade(
        _signal("BUY"),
        quantity=1,
        future_ticks=future_ticks,
        signal_complete_at=signal_time,
        controls=_approval_controls(spread_points=0.5),
    )

    assert with_spread["net_pnl"] < no_spread["net_pnl"]
    assert with_spread["spread_points"] == 0.5
    assert with_spread["execution_model"] == runner.CONSERVATIVE_VWAP_EXECUTION_MODEL
    assert with_spread["approval_grade_execution_ready"] is True


def test_tick_size_rounding_is_conservative_by_side_and_purpose():
    controls = _approval_controls(tick_size=0.25)

    assert runner._round_conservative_price(100.01, "BUY", "entry", controls) == 100.25
    assert runner._round_conservative_price(94.99, "BUY", "stop", controls) == 94.75
    assert runner._round_conservative_price(109.99, "BUY", "target", controls) == 110.0
    assert runner._round_conservative_price(100.24, "SELL", "entry", controls) == 100.0
    assert runner._round_conservative_price(105.01, "SELL", "stop", controls) == 105.25
    assert runner._round_conservative_price(90.01, "SELL", "target", controls) == 90.0


def test_approval_grade_mode_does_not_fill_at_signal_candle_close():
    signal_time = datetime(2026, 6, 22, 9, 30)
    ticks = [
        {"timestamp": signal_time, "ltp": 100.0},
        {"timestamp": signal_time + timedelta(seconds=1), "ltp": 101.0},
        {"timestamp": signal_time + timedelta(seconds=2), "ltp": 110.0},
    ]
    future_ticks = runner._ticks_at_or_after(ticks, signal_time)
    result = runner._simulate_paper_trade(
        _signal("BUY"),
        quantity=1,
        future_ticks=future_ticks,
        signal_complete_at=signal_time,
        controls=_approval_controls(entry_delay_ticks=1),
    )

    assert result["entry_time"] > signal_time
    assert result["entry_price"] == 101.0
    assert result["entry_timing"] == "NEXT_FUTURE_TICK_OR_NEXT_BAR"
    assert result["execution_allowed"] if "execution_allowed" in result else True


def test_same_bar_ohlc_ambiguity_uses_stop_first():
    assert runner._approval_grade_same_bar_exit("BUY", high=111, low=94, stop=95, target=110) == ("LOSS", 95.0)
    assert runner._approval_grade_same_bar_exit("SELL", high=106, low=89, stop=105, target=90) == ("LOSS", 105.0)
