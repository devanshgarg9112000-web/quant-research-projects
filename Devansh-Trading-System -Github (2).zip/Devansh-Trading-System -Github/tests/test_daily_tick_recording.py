from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone

from src.data_feeds.tick_storage import append_daily_ticks, load_tick_csv


def _ticks() -> list[dict]:
    start = datetime(2026, 6, 10, 9, 15)
    return [
        {
            "timestamp": start + timedelta(seconds=15 * index),
            "symbol": "GOLD-I",
            "ltp": 100.0 + index,
            "ltq": 1,
            "volume": 100 + index,
            "oi": None,
            "bid": 99.5 + index,
            "bid_qty": 10,
            "ask": 100.5 + index,
            "ask_qty": 12,
        }
        for index in range(2)
    ]


def test_daily_tick_recorder_writes_symbol_files(tmp_path):
    received_at = datetime(2026, 6, 10, 9, 16, tzinfo=timezone.utc)

    result = append_daily_ticks(_ticks(), tmp_path, source="TEST", received_at=received_at)

    path = tmp_path / "data" / "ticks" / "daily" / "2026-06-10" / "GOLD-I_ticks.csv"
    assert result["rows_written"] == 2
    assert path.exists()
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["timestamp"] == "2026-06-10 09:15:00"
    assert rows[0]["symbol"] == "GOLD-I"
    assert rows[0]["source"] == "TEST"
    assert rows[0]["received_at"] == "2026-06-10 09:16:00+00:00"
    assert list(rows[0]) == [
        "timestamp",
        "symbol",
        "ltp",
        "ltq",
        "bid",
        "ask",
        "bid_qty",
        "ask_qty",
        "source",
        "received_at",
    ]


def test_daily_tick_recorder_does_not_duplicate_same_tick(tmp_path):
    ticks = _ticks()

    first = append_daily_ticks(ticks, tmp_path, source="TEST")
    second = append_daily_ticks(ticks, tmp_path, source="TEST")

    path = tmp_path / "data" / "ticks" / "daily" / "2026-06-10" / "GOLD-I_ticks.csv"
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert first["rows_written"] == 2
    assert second["rows_written"] == 0
    assert len(rows) == 2


def test_daily_tick_file_loads_for_backtest_shape(tmp_path):
    append_daily_ticks(_ticks(), tmp_path, source="TEST")
    path = tmp_path / "data" / "ticks" / "daily" / "2026-06-10" / "GOLD-I_ticks.csv"

    loaded = load_tick_csv(path)

    assert loaded[0]["symbol"] == "GOLD-I"
    assert loaded[0]["ltp"] == 100.0
    assert loaded[0]["volume"] == 0.0
    assert loaded[0]["oi"] is None
