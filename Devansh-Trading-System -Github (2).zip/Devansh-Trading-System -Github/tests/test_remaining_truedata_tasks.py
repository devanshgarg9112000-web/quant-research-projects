from __future__ import annotations

from datetime import datetime
from pathlib import Path

import scripts.run_remaining_truedata_tasks as master


def _touch_symbol_file(root: Path, day: str, symbol: str, suffix: str) -> Path:
    path = root / day / f"{symbol}_{suffix}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("header\n", encoding="utf-8")
    return path


def test_scan_symbol_files_counts_gold_and_silver(tmp_path):
    root = tmp_path / "ticks"
    _touch_symbol_file(root, "2026-06-18", "GOLD-I", "ticks")
    _touch_symbol_file(root, "2026-06-18", "SILVER-I", "ticks")
    _touch_symbol_file(root, "2026-06-19", "GOLD-I", "ticks")

    files = master.scan_symbol_files(root, "ticks")

    assert len(files["GOLD-I"]) == 2
    assert len(files["SILVER-I"]) == 1


def test_safe_environment_forces_live_flags_false(monkeypatch):
    monkeypatch.setenv("ENABLE_LIVE_TRADING", "true")
    monkeypatch.setenv("I_UNDERSTAND_LIVE_TRADING_RISK", "true")

    env = master.safe_environment()

    assert env["ENABLE_LIVE_TRADING"] == "false"
    assert env["I_UNDERSTAND_LIVE_TRADING_RISK"] == "false"


def test_master_runner_runs_steps_sequentially_and_writes_summary(tmp_path, monkeypatch):
    report_root = tmp_path / "reports" / "today_truedata_tasks"
    tick_root = tmp_path / "ticks"
    bar_root = tmp_path / "bars"
    _touch_symbol_file(tick_root, "2026-06-18", "GOLD-I", "ticks")
    _touch_symbol_file(tick_root, "2026-06-18", "SILVER-I", "ticks")

    monkeypatch.setattr(master, "REPORT_ROOT", report_root)
    monkeypatch.setattr(master, "TICK_ROOT", tick_root)
    monkeypatch.setattr(master, "BAR_ROOT", bar_root)
    calls: list[str] = []

    def fake_run(name, command, log_path):
        calls.append(name)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text("success\n", encoding="utf-8")
        if "DOWNLOAD TRUEDATA 1-MINUTE BARS" in name:
            _touch_symbol_file(bar_root, "2026-06-18", "GOLD-I", "1minute_bars")
            _touch_symbol_file(bar_root, "2026-06-18", "SILVER-I", "1minute_bars")
        now = datetime.now().astimezone()
        return master.StepResult(name, "SUCCESS", now, now, log_path)

    def fake_preserve(run_dir, prefix):
        path = run_dir / f"{prefix}_report.txt"
        path.write_text("report\n", encoding="utf-8")
        return [path]

    monkeypatch.setattr(master, "run_logged_command", fake_run)
    monkeypatch.setattr(master, "preserve_backtest_reports", fake_preserve)

    result = master.main()

    assert result == 0
    assert calls == [
        "STEP 2 - DOWNLOAD TRUEDATA 1-MINUTE BARS",
        "STEP 3 - RUN PYTEST",
        "STEP 4 - RUN TICK CLUSTER BACKTEST",
        "STEP 5 - RUN BAR/CANDLE STRATEGY BACKTEST",
    ]
    summary = (report_root / "latest_summary.txt").read_text(encoding="utf-8")
    assert "Overall Status: SUCCESS" in summary
    assert "GOLD-I: 1" in summary
    assert "SILVER-I: 1" in summary
    assert "execution_allowed=false" in summary


def test_master_runner_stops_after_failed_step(tmp_path, monkeypatch):
    report_root = tmp_path / "reports" / "today_truedata_tasks"
    tick_root = tmp_path / "ticks"
    bar_root = tmp_path / "bars"
    _touch_symbol_file(tick_root, "2026-06-18", "GOLD-I", "ticks")
    _touch_symbol_file(tick_root, "2026-06-18", "SILVER-I", "ticks")

    monkeypatch.setattr(master, "REPORT_ROOT", report_root)
    monkeypatch.setattr(master, "TICK_ROOT", tick_root)
    monkeypatch.setattr(master, "BAR_ROOT", bar_root)
    calls: list[str] = []

    def fail_first(name, command, log_path):
        calls.append(name)
        raise master.TaskStepError("simulated download failure")

    monkeypatch.setattr(master, "run_logged_command", fail_first)

    result = master.main()

    assert result == 1
    assert calls == ["STEP 2 - DOWNLOAD TRUEDATA 1-MINUTE BARS"]
    summary = (report_root / "latest_summary.txt").read_text(encoding="utf-8")
    assert "Overall Status: FAILED" in summary
    assert "simulated download failure" in summary
