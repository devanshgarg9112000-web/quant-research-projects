from __future__ import annotations

from datetime import datetime
from pathlib import Path

from src.data_collection.kite_credentials import load_kite_credentials
from src.data_collection.kite_monday_checklist import run_kite_monday_checklist


def _configs() -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "forward_validation": {"production_alerts_allowed": False},
    }


def test_monday_runbook_exists_and_contains_required_commands():
    root = Path(__file__).resolve().parents[1]
    runbook = root / "docs" / "MONDAY_KITE_RECORDING_RUNBOOK.md"

    assert runbook.exists()
    text = runbook.read_text(encoding="utf-8")
    assert "kite_monday_preflight" in text
    assert "--duration-seconds 60" in text
    assert "--duration-seconds 25200" in text
    assert "MCX:GOLD26AUGFUT" in text
    assert "2026-08-05" in text
    assert "No real trading is enabled." in text
    assert "RESEARCH_ONLY" in text


def test_checklist_runs_without_real_credentials(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_monday_checklist(
        tmp_path,
        symbols_text="GOLD-I",
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 22, 8, 30),
    )

    output = capsys.readouterr().out
    assert result.safety_ok is True
    assert result.credential_status == "MISSING"
    assert result.report_path.exists()
    assert "KITE_API_KEY: MISSING" in output
    assert "execution_allowed=false" in output
    assert "READ ONLY. NO BROKER ORDERS. NO LIVE TRADING." in output


def test_checklist_masks_credentials_and_never_prints_values(tmp_path, capsys):
    secrets = {
        "KITE_API_KEY": "secret_key_should_never_print",
        "KITE_API_SECRET": "secret_api_should_never_print",
        "KITE_ACCESS_TOKEN": "secret_access_should_never_print",
    }
    state = load_kite_credentials(env=secrets)

    result = run_kite_monday_checklist(
        tmp_path,
        symbols_text="GOLD-I",
        configs=_configs(),
        credential_state=state,
    )

    output = capsys.readouterr().out
    report = result.report_path.read_text(encoding="utf-8")
    for secret in secrets.values():
        assert secret not in output
        assert secret not in report
    assert "KITE_API_KEY: PRESENT" in output
    assert "KITE_ACCESS_TOKEN: PRESENT" in report


def test_checklist_includes_safety_flags_no_orders_and_expected_reports(tmp_path):
    result = run_kite_monday_checklist(
        tmp_path,
        symbols_text="GOLD-I",
        configs=_configs(),
    )

    report = result.report_path.read_text(encoding="utf-8")
    assert "mode=PAPER: OK" in report
    assert "enable_live_trading=false: OK" in report
    assert "production_alerts_allowed=false: OK" in report
    assert "execution_allowed=false" in report
    assert "Broker Orders: DISABLED" in report
    assert "latest_monday_preflight_report.txt" in report
    assert "latest_kite_daily_pipeline_report.txt" in report
    assert "latest_forward_validation_summary.txt" in report
    assert "kite_daily_pipeline_runs.csv" in report


def test_checklist_module_has_no_order_execution_path_text():
    module_path = Path(__file__).resolve().parents[1] / "src" / "data_collection" / "kite_monday_checklist.py"
    text = module_path.read_text(encoding="utf-8")

    assert "place_order" not in text
    assert "execution_allowed=false" in text
