from __future__ import annotations

from datetime import datetime, timedelta

from src.backtesting.bar_strategy_diagnostics import diagnose_bar_strategies
from src.data_collection.historical_data_downloader import BAR_COLUMNS, save_rows_dedup


def test_zero_signal_diagnosis_writes_reports(tmp_path):
    path = tmp_path / "data" / "historical" / "truedata" / "bars" / "2026-06-18" / "GOLD-I_1minute_bars.csv"
    start = datetime(2026, 6, 18, 9, 15)
    rows = [
        {
            "timestamp": start + timedelta(minutes=index),
            "symbol": "GOLD-I",
            "open": 100,
            "high": 101,
            "low": 99,
            "close": 100,
            "volume": 100,
            "oi": "",
            "source": "TRUEDATA",
            "interval": "1minute",
        }
        for index in range(12)
    ]
    save_rows_dedup(path, BAR_COLUMNS, rows, ["timestamp", "symbol", "interval"])

    results = diagnose_bar_strategies(
        base_dir=tmp_path,
        bar_dir="data/historical/truedata/bars",
        symbols_text="GOLD-I",
        from_date="2026-06-18",
        to_date="2026-06-18",
        configs={
            "settings": {"min_signal_score": 7, "mode": "PAPER"},
            "risk": {},
            "instruments": {},
        },
    )

    output_dir = tmp_path / "reports" / "strategy_diagnostics"
    assert results
    assert (output_dir / "latest_bar_strategy_zero_signal_diagnosis.txt").exists()
    assert (output_dir / "latest_bar_strategy_zero_signal_diagnosis.csv").exists()
    breakout = next(row for row in results if row["strategy"] == "breakout_acceptance")
    assert breakout["required_columns_ok"] is True
    assert breakout["datetime_parsing_ok"] is True
    assert breakout["ohlcv_valid"] is True
    assert breakout["vwap_calculated"] is True
    assert breakout["zero_signal_reason"]
