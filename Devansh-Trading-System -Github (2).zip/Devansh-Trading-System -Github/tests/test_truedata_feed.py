from datetime import datetime

from src.data_feeds.truedata_feed import (
    TrueDataFeed,
    normalize_historical_bar_response,
    normalize_historical_tick_response,
    normalize_live_tick,
)


def test_truedata_disabled_mode_does_not_connect(capsys):
    feed = TrueDataFeed(settings={"enable_true_data": False})

    assert feed.connect() is False
    assert "enable_true_data is false" in capsys.readouterr().out


def test_truedata_missing_credentials_do_not_crash(monkeypatch, capsys):
    for key in ["TRUEDATA_USERNAME", "TRUEDATA_PASSWORD", "TRUEDATA_REALTIME_PORT"]:
        monkeypatch.setenv(key, "")

    feed = TrueDataFeed(settings={"enable_true_data": True})

    assert feed.connect() is False
    assert "credentials missing" in capsys.readouterr().out


def test_truedata_unit_tests_do_not_open_real_websocket(monkeypatch, capsys):
    monkeypatch.setenv("TRUEDATA_USERNAME", "unit_user")
    monkeypatch.setenv("TRUEDATA_PASSWORD", "unit_password")
    monkeypatch.setenv("TRUEDATA_REALTIME_PORT", "9999")

    feed = TrueDataFeed(settings={"enable_true_data": True})

    assert feed.connect() is False
    assert "real network access is disabled" in capsys.readouterr().out


def test_truedata_trade_tick_normalization_from_docs_sample():
    raw = {
        "trade": [
            "100000995",
            "2020-12-16T14:02:32",
            "1472.8",
            "635",
            "1475.83",
            "680949",
            "1475.05",
            "1484",
            "1463",
            "1468.35",
            "0",
            "0",
            "1004964962.67",
            "",
            "4775",
            "1472.8",
            "429",
            "1473.3",
            "34",
        ]
    }

    tick = normalize_live_tick(raw, {"100000995": "RELIANCE"})

    assert tick["symbol"] == "RELIANCE"
    assert tick["timestamp"] == datetime(2020, 12, 16, 14, 2, 32)
    assert tick["ltp"] == 1472.8
    assert tick["ltq"] == 635
    assert tick["volume"] == 680949
    assert tick["bid"] == 1472.8
    assert tick["ask_qty"] == 34
    assert tick["raw"] == raw


def test_truedata_historical_tick_response_normalization_from_docs_sample():
    csv_text = "\n".join([
        "timestamp,ltp,volume,oi,bid,bidqty,ask,askqty",
        "2021-02-24T09:15:00,14755.15,1,7390425,14730,225,14745.45,375",
    ])

    rows = normalize_historical_tick_response(csv_text, "NIFTY-I")

    assert rows[0]["symbol"] == "NIFTY-I"
    assert rows[0]["ltp"] == 14755.15
    assert rows[0]["ltq"] == 1
    assert rows[0]["oi"] == 7390425
    assert rows[0]["bid_qty"] == 225


def test_truedata_historical_bar_response_normalization_from_docs_sample():
    csv_text = "\n".join([
        "timestamp,open,high,low,close,volume,oi",
        "2021-02-01T09:15,1859.4,1862.3,1853.05,1856.95,578586,0",
    ])

    rows = normalize_historical_bar_response(csv_text, "RELIANCE")

    assert rows[0]["symbol"] == "RELIANCE"
    assert rows[0]["timestamp"] == datetime(2021, 2, 1, 9, 15)
    assert rows[0]["open"] == 1859.4
    assert rows[0]["volume"] == 578586


def test_truedata_historical_bar_interval_alias_uses_documented_1min(monkeypatch):
    from src.data_feeds.truedata_feed import TrueDataFeed

    feed = TrueDataFeed({"enable_true_data": True})
    captured = {}

    def fake_rest_get(path, params):
        captured["path"] = path
        captured["params"] = params
        return "timestamp,open,high,low,close,volume,oi\n2026-06-18T09:15,1,2,1,2,10,0\n"

    monkeypatch.setattr(feed, "_rest_get", fake_rest_get)

    rows = feed.get_historical(
        "GOLD-I",
        datetime(2026, 6, 18),
        datetime(2026, 6, 18, 23, 59),
        "1minute",
    )

    assert rows
    assert captured["path"] == "getbars"
    assert captured["params"]["interval"] == "1min"
