from src.data.sample_data import generate_sample_ticks
from src.indicators.cluster import build_cluster_table


def test_cluster_imbalances_detected():
    rows = build_cluster_table(generate_sample_ticks())
    assert any(row["buy_imbalance"] for row in rows)
    assert any(row["sell_imbalance"] for row in rows)
    assert any(row["stacked_buy_imbalance"] for row in rows)
    assert any(row["stacked_sell_imbalance"] for row in rows)
