from __future__ import annotations

from datetime import date

from src.research.strategy_research_lab import (
    ResearchMetrics,
    assess_research_result,
    split_train_validation_dates,
)


def _metrics(**overrides):
    values = {
        "trades": 30,
        "wins": 18,
        "losses": 12,
        "win_rate": 60.0,
        "net_pnl": 2000.0,
        "profit_factor": 1.6,
        "expectancy": 66.67,
        "max_drawdown": -500.0,
        "max_consecutive_losses": 2,
        "raw_signals": 60,
        "max_raw_signals_per_day": 10,
    }
    values.update(overrides)
    return ResearchMetrics(**values)


def test_train_validation_split_is_chronological_70_30():
    dates = [date(2026, 6, day) for day in range(1, 11)]

    train, validation = split_train_validation_dates(reversed(dates))

    assert train == dates[:7]
    assert validation == dates[7:]
    assert max(train) < min(validation)


def test_low_trade_count_remains_watchlist():
    train = _metrics(trades=8)
    validation = _metrics(trades=4)
    combined = _metrics(trades=12)

    result = assess_research_result(train, validation, combined)

    assert result.approval_candidate is False
    assert result.recommendation == "WATCHLIST"
    assert "LOW_TRADE_COUNT" in result.warnings


def test_validation_failure_rejects_strategy():
    validation = _metrics(net_pnl=-100.0, profit_factor=0.8)

    result = assess_research_result(_metrics(), validation, _metrics())

    assert result.recommendation == "REJECTED"
    assert result.approval_candidate is False


def test_high_frequency_strategy_is_rejected():
    combined = _metrics(raw_signals=1000, max_raw_signals_per_day=150)

    result = assess_research_result(_metrics(), _metrics(), combined)

    assert result.recommendation == "REJECTED"
    assert "HIGH_SIGNAL_FREQUENCY_WARNING" in result.warnings


def test_profitable_but_overfit_strategy_is_not_approved():
    train = _metrics(profit_factor=4.0, net_pnl=5000.0)
    validation = _metrics(trades=10, profit_factor=1.4, net_pnl=200.0)
    combined = _metrics(trades=40, profit_factor=2.0, net_pnl=5200.0)

    result = assess_research_result(train, validation, combined)

    assert result.recommendation == "REJECTED"
    assert "OVERFITTING_WARNING" in result.warnings


def test_approved_candidate_requires_train_and_validation_to_pass():
    result = assess_research_result(
        _metrics(trades=25, profit_factor=1.5, net_pnl=1200.0),
        _metrics(trades=10, profit_factor=1.4, net_pnl=400.0),
        _metrics(trades=35, profit_factor=1.45, net_pnl=1600.0),
    )

    assert result.approval_candidate is True
    assert result.recommendation == "APPROVED_CANDIDATE"


def test_execution_is_never_part_of_research_metrics():
    assert not hasattr(ResearchMetrics(), "execution_allowed")
