from __future__ import annotations

import csv

import src.data_collection.kite_live_recorder as recorder_module
from datetime import date, datetime
from pathlib import Path

from src.config_loader import load_configs
from src.data_collection.kite_credentials import format_kite_credential_status, load_kite_credentials
from src.data_collection.kite_historical_downloader import download_kite_historical_bars
from src.data_collection.kite_instrument_resolver import main as resolver_main, resolve_kite_instruments
from src.data_collection.kite_readonly_check import run_kite_readonly_check
from src.data_collection.kite_live_recorder import _StreamingCsvAppender, record_kite_live_data
from src.data_collection.kite_orderflow_features import (
    build_kite_orderflow_lite_features,
    calculate_orderflow_lite_features,
)
from src.data_collection.market_data_schema import (
    KITE_DEPTH_COLUMNS,
    KITE_TICK_COLUMNS,
    ORDERFLOW_LITE_COLUMNS,
    kite_depth_path,
    kite_feature_path,
    kite_tick_path,
    normalize_kite_depth_rows,
    normalize_kite_tick_row,
    save_rows_dedup,
)
from src.research.forward_validation import load_ledger, record_watchlist_signal_from_row


def _quote(timestamp: datetime | None = None):
    timestamp = timestamp or datetime(2026, 6, 19, 9, 15)
    return {
        "instrument_token": 12345,
        "timestamp": timestamp,
        "last_price": 150000.0,
        "last_quantity": 2,
        "volume_traded": 1000,
        "oi": 5000,
        "depth": {
            "buy": [
                {"price": 149999 - index, "quantity": 10 + index, "orders": index + 1}
                for index in range(5)
            ],
            "sell": [
                {"price": 150001 + index, "quantity": 20 + index, "orders": index + 2}
                for index in range(5)
            ],
        },
    }


def _real_quote(timestamp: datetime | None = None):
    quote = _quote(timestamp)
    quote["instrument_token"] = 119445255
    return quote


def _real_tick_row(symbol: str, quote: dict):
    return normalize_kite_tick_row(
        symbol,
        quote,
        internal_symbol=symbol,
        kite_exchange="MCX",
        kite_tradingsymbol="GOLD26AUGFUT",
    )


def _real_depth_rows(symbol: str, quote: dict):
    return normalize_kite_depth_rows(
        symbol,
        quote,
        internal_symbol=symbol,
        kite_exchange="MCX",
        kite_tradingsymbol="GOLD26AUGFUT",
    )


def test_normalized_kite_tick_row():
    row = normalize_kite_tick_row("GOLD-I", _quote(), received_at=datetime(2026, 6, 19, 9, 16))

    assert row["symbol"] == "GOLD-I"
    assert row["instrument_token"] == 12345
    assert row["ltp"] == 150000.0
    assert row["ltq"] == 2
    assert row["volume"] == 1000
    assert row["oi"] == 5000
    assert row["bid"] == 149999
    assert row["ask"] == 150001
    assert row["source"] == "KITE"


def test_normalized_kite_depth_row():
    rows = normalize_kite_depth_rows("GOLD-I", _quote(), received_at=datetime(2026, 6, 19, 9, 16))

    assert len(rows) == 5
    assert rows[0]["level"] == 1
    assert rows[0]["bid_price"] == 149999
    assert rows[0]["ask_price"] == 150001
    assert rows[4]["bid_qty"] == 14
    assert rows[4]["ask_qty"] == 24


def test_depth_imbalance_calculation():
    rows = normalize_kite_depth_rows("GOLD-I", _quote())

    features = calculate_orderflow_lite_features("GOLD-I", rows, [normalize_kite_tick_row("GOLD-I", _quote())])

    bid_total = sum(range(10, 15))
    ask_total = sum(range(20, 25))
    expected = (bid_total - ask_total) / (bid_total + ask_total)
    assert features[0]["bid_qty_total_top5"] == bid_total
    assert features[0]["ask_qty_total_top5"] == ask_total
    assert features[0]["depth_imbalance"] == round(expected, 6)
    assert features[0]["spread"] == 2


def test_feature_file_generation(tmp_path):
    day = datetime(2026, 6, 19).date()
    quote1 = _real_quote(datetime(2026, 6, 19, 9, 15))
    quote2 = _real_quote(datetime(2026, 6, 19, 9, 16))
    quote2["volume_traded"] = 1020
    save_rows_dedup(
        kite_depth_path(tmp_path, day, "GOLD-I"),
        KITE_DEPTH_COLUMNS,
        _real_depth_rows("GOLD-I", quote1) + _real_depth_rows("GOLD-I", quote2),
        ["timestamp", "symbol", "level", "bid_price", "ask_price"],
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", quote1), _real_tick_row("GOLD-I", quote2)],
        ["timestamp", "symbol", "ltp", "volume"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    path = kite_feature_path(tmp_path, day, "GOLD-I")
    assert result.rows_generated == 2
    assert path.exists()
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["source"] == "KITE_ORDERFLOW_LITE"
    assert "depth_imbalance" in rows[0]


def test_kite_recorder_dry_run_without_credentials_does_not_print_token(tmp_path, monkeypatch, capsys):
    secret = "access_token_secret_should_not_print"
    monkeypatch.setenv("KITE_ACCESS_TOKEN", secret)
    monkeypatch.delenv("KITE_API_KEY", raising=False)

    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
    )

    out = capsys.readouterr().out
    assert result.tick_rows_recorded == 1
    assert result.depth_rows_recorded == 5
    assert secret not in out
    assert "execution_allowed=false" in out


def test_kite_recorder_uses_resolved_read_only_quote_and_never_orders(tmp_path):
    class FakeBroker:
        def _missing_read_credentials(self):
            return []

        def get_instruments(self, exchange=None):
            assert exchange == "MCX"
            return [{
                "instrument_token": 777,
                "exchange": "MCX",
                "tradingsymbol": "GOLD26JULFUT",
                "name": "GOLD",
                "expiry": "2026-07-20",
                "lot_size": 1,
                "tick_size": 1,
                "instrument_type": "FUT",
                "segment": "MCX-FUT",
            }]

        def get_quote(self, symbols):
            assert symbols == ["MCX:GOLD26JULFUT"]
            return {"MCX:GOLD26JULFUT": _quote()}

        def place_order(self, *_args, **_kwargs):
            raise AssertionError("Kite recorder must never place broker orders.")

    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=False,
        broker=FakeBroker(),
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
        now_fn=lambda: datetime(2026, 6, 20, 9, 15),
    )

    assert result.tick_rows_recorded == 1
    assert result.depth_rows_recorded == 5
    assert result.symbol_resolutions[0].tradingsymbol == "GOLD26JULFUT"


def test_kite_historical_downloader_saves_bars_and_never_orders(tmp_path):
    class FakeBroker:
        def _missing_read_credentials(self):
            return []

        def get_instruments(self, exchange=None):
            assert exchange == "MCX"
            return [{"exchange": "MCX", "tradingsymbol": "GOLD-I", "instrument_token": 12345}]

        def get_historical_data(self, instrument_token, from_date, to_date, interval, oi=True):
            assert instrument_token == 12345
            assert interval == "minute"
            return [{
                "date": datetime(2026, 6, 19, 9, 15),
                "open": 1,
                "high": 2,
                "low": 1,
                "close": 2,
                "volume": 100,
                "oi": 10,
            }]

        def place_order(self, *_args, **_kwargs):
            raise AssertionError("Kite historical downloader must never place broker orders.")

    result = download_kite_historical_bars(
        tmp_path,
        symbols_text="GOLD-I",
        from_date="2026-06-19",
        to_date="2026-06-19",
        interval="minute",
        broker=FakeBroker(),
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
        rate_limit_seconds=0,
    )

    assert result.rows_downloaded == 1
    assert result.files[0].name == "GOLD-I_bars.csv"


def test_forward_validation_ledger_accepts_provider_kite(tmp_path):
    scan_time = datetime(2026, 6, 19, 9, 30)
    row = {
        "symbol": "GOLD-I",
        "provider": "KITE",
        "status": "ACCEPTED_PAPER_SIGNAL",
        "direction": "SELL",
        "strategy": "VWAP Rejection Short",
        "entry": 150000,
        "stop": 150200,
        "target": 149600,
        "market_mode": "TREND_DOWN",
        "score": 7.7,
        "approval_status_at_signal": "RESEARCH_ONLY",
        "execution_allowed": False,
    }

    recorded = record_watchlist_signal_from_row(
        tmp_path,
        row,
        scan_time=scan_time,
        alert_mode="none",
        config={"enabled": True, "symbols": ["GOLD-I"], "record_watchlist_signals": True},
    )

    rows = load_ledger(tmp_path)
    assert recorded is True
    assert rows[0]["provider"] == "KITE"
    assert rows[0]["approval_status_at_signal"] == "RESEARCH_ONLY"
    assert rows[0]["execution_allowed"] == "false"


def test_live_trading_flags_remain_false():
    configs = load_configs(".")

    assert configs["settings"]["mode"] == "PAPER"
    assert configs["settings"]["enable_live_trading"] is False
    assert configs["forward_validation"]["production_alerts_allowed"] is False



def test_kite_collection_report_has_last_operation_and_append_log(tmp_path):
    configs = {"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}}

    first = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        configs=configs,
        now_fn=lambda: datetime(2026, 6, 19, 9, 15),
    )
    second = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        configs=configs,
        now_fn=lambda: datetime(2026, 6, 19, 9, 16),
    )

    report_path = tmp_path / "reports" / "kite_data_collection" / "latest_kite_data_collection_report.txt"
    operation_log = tmp_path / "reports" / "kite_data_collection" / "kite_data_collection_operations.csv"
    assert first.report_path == report_path
    assert second.report_path == report_path
    text = report_path.read_text(encoding="utf-8")
    assert "LAST OPERATION" in text
    assert "Last operation type: recorder" in text
    assert "Tick rows recorded in last operation: 1" in text
    assert "Depth rows recorded in last operation: 5" in text
    assert "CUMULATIVE OPERATION LOG" in text
    assert "Operations logged: 2" in text
    assert "PAPER MODE ONLY" in text
    assert operation_log.exists()
    with operation_log.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert [row["operation_type"] for row in rows] == ["recorder", "recorder"]
    assert all(row["execution_allowed"] == "false" for row in rows)


def test_feature_builder_updates_kite_report_last_operation(tmp_path):
    day = datetime(2026, 6, 19).date()
    quote = _real_quote(datetime(2026, 6, 19, 9, 15))
    save_rows_dedup(
        kite_depth_path(tmp_path, day, "GOLD-I"),
        KITE_DEPTH_COLUMNS,
        _real_depth_rows("GOLD-I", quote),
        ["timestamp", "symbol", "level", "bid_price", "ask_price"],
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", quote)],
        ["timestamp", "symbol", "ltp", "volume"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    report_path = tmp_path / "reports" / "kite_data_collection" / "latest_kite_data_collection_report.txt"
    operation_log = tmp_path / "reports" / "kite_data_collection" / "kite_data_collection_operations.csv"
    assert result.rows_generated == 1
    text = report_path.read_text(encoding="utf-8")
    assert "Last operation type: feature_builder" in text
    assert "Features generated in last operation: 1" in text
    with operation_log.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[-1]["operation_type"] == "feature_builder"
    assert rows[-1]["features_generated"] == "1"


def test_kite_data_collection_reuses_schema_helpers_and_has_no_order_calls():
    root = Path(__file__).resolve().parents[1]
    module_paths = [
        root / "src" / "data_collection" / "kite_live_recorder.py",
        root / "src" / "data_collection" / "kite_historical_downloader.py",
        root / "src" / "data_collection" / "kite_orderflow_features.py",
        root / "src" / "data_collection" / "kite_instrument_resolver.py",
        root / "src" / "data_collection" / "kite_readonly_check.py",
        root / "src" / "data_collection" / "kite_credentials.py",
    ]

    for module_path in module_paths:
        module_text = module_path.read_text(encoding="utf-8")
        if module_path.name in {"kite_live_recorder.py", "kite_historical_downloader.py", "kite_orderflow_features.py"}:
            assert "market_data_schema" in module_text
        assert "def normalize_kite" not in module_text
        assert "place_order" not in module_text



def test_kite_credential_status_masks_values(capsys):
    secret_key = "kite_api_key_should_not_print"
    secret_api = "kite_api_secret_should_not_print"
    secret_token = "kite_access_token_should_not_print"
    state = load_kite_credentials(
        env={
            "KITE_API_KEY": secret_key,
            "KITE_API_SECRET": secret_api,
            "KITE_ACCESS_TOKEN": secret_token,
        }
    )

    lines = format_kite_credential_status(state)
    print("\n".join(lines))
    output = capsys.readouterr().out

    assert state.credential_status == "PRESENT"
    assert lines == [
        "KITE_API_KEY: PRESENT",
        "KITE_API_SECRET: PRESENT",
        "KITE_ACCESS_TOKEN: PRESENT",
    ]
    assert secret_key not in output
    assert secret_api not in output
    assert secret_token not in output
    assert secret_key not in repr(state)
    assert secret_api not in repr(state)
    assert secret_token not in repr(state)


def test_kite_readonly_check_dry_run_works_without_credentials(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_readonly_check(
        tmp_path,
        symbols_text="GOLD-I",
        dry_run="auto",
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
    )

    out = capsys.readouterr().out
    assert result.dry_run is True
    assert result.credential_status == "MISSING"
    assert result.profile_status == "DRY_RUN"
    assert result.quote_status == "DRY_RUN_OK"
    assert result.depth_status == "PRESENT"
    assert "KITE_API_KEY: MISSING" in out
    assert "READ ONLY CHECK ONLY. NO ORDERS." in out
    assert "execution_allowed=false" in out
    assert result.report_path.exists()
    report = result.report_path.read_text(encoding="utf-8")
    assert "credential_status: MISSING" in report
    assert "Last operation type: readonly_check" in report


def test_kite_readonly_check_does_not_print_token_values(tmp_path, monkeypatch, capsys):
    secret_key = "kite_api_key_secret_value"
    secret_api = "kite_api_secret_value"
    secret_token = "kite_access_token_secret_value"
    monkeypatch.setenv("KITE_API_KEY", secret_key)
    monkeypatch.setenv("KITE_API_SECRET", secret_api)
    monkeypatch.setenv("KITE_ACCESS_TOKEN", secret_token)

    result = run_kite_readonly_check(
        tmp_path,
        symbols_text="GOLD-I",
        dry_run="true",
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
    )

    out = capsys.readouterr().out
    assert result.dry_run is True
    assert result.credential_status == "PRESENT"
    assert "KITE_API_KEY: PRESENT" in out
    assert "KITE_API_SECRET: PRESENT" in out
    assert "KITE_ACCESS_TOKEN: PRESENT" in out
    assert secret_key not in out
    assert secret_api not in out
    assert secret_token not in out


def test_kite_recorder_fails_safely_without_credentials_when_dry_run_false(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=False,
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
    )

    out = capsys.readouterr().out
    assert result.tick_rows_recorded == 0
    assert result.depth_rows_recorded == 0
    assert result.credential_status == "MISSING"
    assert result.errors
    assert "skipped safely" in result.errors[0]
    assert "KITE_API_KEY" in result.errors[0]
    assert "READ ONLY CHECK ONLY. NO ORDERS." in out
    assert "execution_allowed=false" in out
    assert result.report_path.exists()
    report = result.report_path.read_text(encoding="utf-8")
    assert "credential_status: MISSING" in report


def test_kite_recorder_defaults_to_dry_run_without_credentials(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
    )

    assert result.tick_rows_recorded == 1
    assert result.depth_rows_recorded == 5
    assert result.credential_status == "MISSING"
    assert not result.errors



def test_kite_operation_log_old_header_is_upgraded_safely(tmp_path):
    log_path = tmp_path / "reports" / "kite_data_collection" / "kite_data_collection_operations.csv"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(
        "timestamp,operation_type,tick_rows_recorded,depth_rows_recorded,candle_rows_downloaded,features_generated,files_touched,missing_fields,errors,execution_allowed\n"
        "2026-06-19T09:15:00+05:30,recorder,1,5,0,0,2,NONE,NONE,false\n",
        encoding="utf-8",
    )

    record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
        now_fn=lambda: datetime(2026, 6, 19, 9, 16),
    )

    with log_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert "credential_status" in rows[0]
    assert rows[0]["credential_status"] == "NOT_CHECKED"
    assert rows[-1]["operation_type"] == "recorder"
    assert rows[-1]["execution_allowed"] == "false"
    report = (tmp_path / "reports" / "kite_data_collection" / "latest_kite_data_collection_report.txt").read_text(encoding="utf-8")
    assert "Operations logged: 2" in report



def test_kite_resolver_dry_run_maps_gold_and_silver(tmp_path):
    result = resolve_kite_instruments(
        tmp_path,
        symbols_text="GOLD-I,SILVER-I",
        exchange="MCX",
        dry_run=True,
        as_of=date(2026, 6, 20),
    )

    assert result.source == "DRY_RUN_SYNTHETIC"
    assert result.all_resolved is True
    mappings = result.by_internal_symbol()
    assert mappings["GOLD-I"].exchange == "MCX"
    assert mappings["GOLD-I"].tradingsymbol == "GOLD26JULFUT"
    assert mappings["SILVER-I"].tradingsymbol == "SILVER26JULFUT"
    assert mappings["GOLD-I"].instrument_token == "900001"


def test_kite_resolver_returns_not_found_safely(tmp_path):
    result = resolve_kite_instruments(
        tmp_path,
        symbols_text="COPPER-I",
        exchange="MCX",
        dry_run=True,
        instruments=[],
        as_of=date(2026, 6, 20),
    )

    assert result.mappings[0].status == "NOT_FOUND"
    assert "no active MCX future" in result.mappings[0].reason
    assert not result.errors


def test_kite_resolver_output_does_not_print_secret_values(tmp_path, monkeypatch, capsys):
    secret_key = "resolver_api_key_secret"
    secret_api = "resolver_api_secret"
    secret_token = "resolver_access_token_secret"
    monkeypatch.setenv("KITE_API_KEY", secret_key)
    monkeypatch.setenv("KITE_API_SECRET", secret_api)
    monkeypatch.setenv("KITE_ACCESS_TOKEN", secret_token)
    monkeypatch.chdir(tmp_path)

    exit_code = resolver_main(["--symbols", "GOLD-I,SILVER-I", "--dry-run", "true"])

    out = capsys.readouterr().out
    assert exit_code == 0
    assert "KITE_API_KEY: PRESENT" in out
    assert "KITE_API_SECRET: PRESENT" in out
    assert "KITE_ACCESS_TOKEN: PRESENT" in out
    assert secret_key not in out
    assert secret_api not in out
    assert secret_token not in out
    assert "GOLD-I" in out
    assert "SILVER-I" in out


def test_kite_readonly_check_resolves_internal_symbol_with_fake_client(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("KITE_API_KEY", "present_key")
    monkeypatch.setenv("KITE_API_SECRET", "present_secret")
    monkeypatch.setenv("KITE_ACCESS_TOKEN", "present_token")

    class FakeKiteClient:
        def instruments(self, exchange=None):
            assert exchange == "MCX"
            return [{
                "instrument_token": 777,
                "exchange": "MCX",
                "tradingsymbol": "GOLD26JULFUT",
                "name": "GOLD",
                "expiry": "2026-07-20",
                "lot_size": 1,
                "tick_size": 1,
                "instrument_type": "FUT",
                "segment": "MCX-FUT",
            }]

        def profile(self):
            return {"user_name": "test"}

        def quote(self, symbols):
            assert symbols == ["MCX:GOLD26JULFUT"]
            return {"MCX:GOLD26JULFUT": _quote()}

    result = run_kite_readonly_check(
        tmp_path,
        symbols_text="GOLD-I",
        dry_run="false",
        configs={"settings": {}, "risk": {}, "instruments": {}},
        kite_client_factory=lambda _api_key, _access_token: FakeKiteClient(),
        as_of=date(2026, 6, 20),
    )

    out = capsys.readouterr().out
    assert result.profile_status == "OK"
    assert result.quote_status == "OK"
    assert result.depth_status == "PRESENT"
    assert result.symbol_resolutions[0].tradingsymbol == "GOLD26JULFUT"
    assert "Resolved Symbol: GOLD-I -> MCX:GOLD26JULFUT (RESOLVED)" in out
    report = result.report_path.read_text(encoding="utf-8")
    assert "SYMBOL RESOLUTION" in report
    assert "tradingsymbol=GOLD26JULFUT" in report


def test_kite_recorder_includes_resolved_symbol_metadata(tmp_path):
    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        configs={"settings": {}, "risk": {}, "instruments": {}},
        now_fn=lambda: datetime(2026, 6, 20, 9, 15),
    )

    assert result.tick_rows_recorded == 1
    tick_path = tmp_path / "data" / "kite_recorded" / "ticks" / "2026-06-20" / "GOLD-I_ticks.csv"
    depth_path = tmp_path / "data" / "kite_recorded" / "depth" / "2026-06-20" / "GOLD-I_depth.csv"
    with tick_path.open(newline="", encoding="utf-8") as f:
        tick_rows = list(csv.DictReader(f))
    with depth_path.open(newline="", encoding="utf-8") as f:
        depth_rows = list(csv.DictReader(f))
    assert tick_rows[0]["symbol"] == "GOLD-I"
    assert tick_rows[0]["internal_symbol"] == "GOLD-I"
    assert tick_rows[0]["kite_exchange"] == "MCX"
    assert tick_rows[0]["kite_tradingsymbol"].startswith("GOLD")
    assert depth_rows[0]["kite_tradingsymbol"] == tick_rows[0]["kite_tradingsymbol"]
    report = result.report_path.read_text(encoding="utf-8")
    assert "SYMBOL RESOLUTION" in report
    assert "Quote check status: OK" in report



def test_kite_resolver_prefers_exact_silver_contract_family(tmp_path):
    instruments = [
        {
            "instrument_token": 1,
            "exchange": "MCX",
            "tradingsymbol": "SILVER10026JUNFUT",
            "name": "SILVER100",
            "expiry": "2026-06-30",
            "lot_size": 1,
            "tick_size": 1,
            "instrument_type": "FUT",
            "segment": "MCX-FUT",
        },
        {
            "instrument_token": 2,
            "exchange": "MCX",
            "tradingsymbol": "SILVER26SEP?UT".replace("?", "F"),
            "name": "SILVER",
            "expiry": "2026-09-04",
            "lot_size": 1,
            "tick_size": 1,
            "instrument_type": "FUT",
            "segment": "MCX-FUT",
        },
    ]

    result = resolve_kite_instruments(
        tmp_path,
        symbols_text="SILVER-I",
        exchange="MCX",
        dry_run=True,
        instruments=instruments,
        as_of=date(2026, 6, 20),
    )

    assert result.mappings[0].status == "RESOLVED"
    assert result.mappings[0].name == "SILVER"
    assert result.mappings[0].tradingsymbol == "SILVER26SEPFUT"



def _quote_without_volume(timestamp: datetime | None = None):
    quote = _quote(timestamp)
    quote.pop("volume_traded", None)
    quote["average_price"] = 149950.0
    return quote


def test_kite_quote_without_volume_traded_records_tick_and_warning(tmp_path):
    class FakeBroker:
        def _missing_read_credentials(self):
            return []

        def get_instruments(self, exchange=None):
            return [{
                "instrument_token": 777,
                "exchange": "MCX",
                "tradingsymbol": "GOLD26JULFUT",
                "name": "GOLD",
                "expiry": "2026-07-20",
                "lot_size": 1,
                "tick_size": 1,
                "instrument_type": "FUT",
                "segment": "MCX-FUT",
            }]

        def get_quote(self, symbols):
            return {"MCX:GOLD26JULFUT": _quote_without_volume(datetime(2026, 6, 20, 9, 15))}

    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=False,
        broker=FakeBroker(),
        configs={"settings": {}, "risk": {}, "instruments": {}},
        now_fn=lambda: datetime(2026, 6, 20, 9, 15),
    )

    assert result.tick_rows_recorded == 1
    assert result.depth_rows_recorded == 5
    assert result.market_data_status == "RECORDED"
    assert "GOLD-I:volume_traded" in result.optional_missing_fields
    assert result.errors == []
    tick_path = tmp_path / "data" / "kite_recorded" / "ticks" / "2026-06-20" / "GOLD-I_ticks.csv"
    with tick_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["ltp"] == "150000.0"
    assert rows[0]["average_price"] == "149950.0"
    assert rows[0]["volume"] == "0"
    report = result.report_path.read_text(encoding="utf-8")
    assert "Optional missing field warnings:" in report
    assert "GOLD-I:volume_traded" in report
    assert "Errors: NONE" in report


def test_kite_depth_records_even_when_tick_volume_missing(tmp_path):
    quote = _quote_without_volume(datetime(2026, 6, 20, 9, 15))
    quote["instrument_token"] = 119445255
    tick = normalize_kite_tick_row("GOLD-I", quote)
    depth = normalize_kite_depth_rows("GOLD-I", quote)

    assert tick["volume"] == 0
    assert len(depth) == 5
    assert depth[0]["bid_price"] == 149999
    assert depth[0]["ask_price"] == 150001


def test_kite_recorder_market_closed_no_live_data_reports_safely(tmp_path, capsys):
    class FakeBroker:
        def _missing_read_credentials(self):
            return []

        def get_instruments(self, exchange=None):
            return []

        def get_quote(self, symbols):
            return {}

    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=False,
        broker=FakeBroker(),
        configs={"settings": {}, "risk": {}, "instruments": {}},
    )

    out = capsys.readouterr().out
    assert result.tick_rows_recorded == 0
    assert result.depth_rows_recorded == 0
    assert result.market_data_status == "NO_LIVE_TICKS"
    assert "No live ticks recorded. This may be normal if market is closed." in out
    assert "Market data status: NO_LIVE_TICKS" in out
    assert result.report_path.exists()
    report = result.report_path.read_text(encoding="utf-8")
    assert "Market data status: NO_LIVE_TICKS" in report
    assert "execution_allowed=false" in report


def test_feature_builder_handles_missing_volume_traded(tmp_path):
    day = datetime(2026, 6, 20).date()
    quote = _quote_without_volume(datetime(2026, 6, 20, 9, 15))
    quote["instrument_token"] = 119445255
    save_rows_dedup(
        kite_depth_path(tmp_path, day, "GOLD-I"),
        KITE_DEPTH_COLUMNS,
        _real_depth_rows("GOLD-I", quote),
        ["timestamp", "symbol", "level", "bid_price", "ask_price"],
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", quote)],
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    assert result.rows_generated == 1
    feature_path = kite_feature_path(tmp_path, day, "GOLD-I")
    with feature_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["volume_burst"] == "0.0"
    report = result.report_path.read_text(encoding="utf-8")
    assert "Missing volume data for GOLD-I" in report
    assert "Errors: NONE" in report



def test_feature_builder_handles_mixed_timezone_timestamps(tmp_path):
    day = datetime(2026, 6, 20).date()
    aware_quote = _quote_without_volume(datetime.fromisoformat("2026-06-20T09:15:00+05:30"))
    aware_quote["instrument_token"] = 119445255
    naive_quote = _quote_without_volume(datetime(2026, 6, 20, 9, 15))
    naive_quote["instrument_token"] = 119445255
    save_rows_dedup(
        kite_depth_path(tmp_path, day, "GOLD-I"),
        KITE_DEPTH_COLUMNS,
        _real_depth_rows("GOLD-I", aware_quote),
        ["timestamp", "symbol", "level", "bid_price", "ask_price"],
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", naive_quote)],
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    assert result.rows_generated == 1
    assert result.errors == []



def test_quote_only_rows_generate_quote_lite_features(tmp_path):
    day = datetime(2026, 6, 20).date()
    tick_rows = []
    for index in range(25):
        quote = _quote_without_volume(datetime(2026, 6, 20, 9, 15 + index))
        quote["last_price"] = 150000.0 + index
        tick_rows.append(normalize_kite_tick_row(
            "GOLD-I",
            quote,
            internal_symbol="GOLD-I",
            kite_exchange="MCX",
            kite_tradingsymbol="GOLD26AUGFUT",
        ))
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        tick_rows,
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    feature_path = kite_feature_path(tmp_path, day, "GOLD-I")
    with feature_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert result.tick_rows_loaded == 25
    assert result.depth_rows_loaded == 0
    assert result.rows_generated == 25
    assert result.feature_mode == "QUOTE_LITE"
    assert result.market_data_status == "PARTIAL_QUOTE"
    assert rows[0]["feature_mode"] == "QUOTE_LITE"
    assert rows[0]["has_depth"] == "false"
    assert rows[0]["has_volume_traded"] == "false"
    assert rows[0]["data_quality"] == "PARTIAL_QUOTE"
    assert rows[-1]["quote_update_count"] == "25"
    assert rows[-1]["rolling_price_change_10"] == "10.0"
    report = result.report_path.read_text(encoding="utf-8")
    assert "Tick rows loaded: 25" in report
    assert "Depth rows loaded: 0" in report
    assert "Feature mode: QUOTE_LITE" in report
    assert "Market data status: PARTIAL_QUOTE" in report
    assert "No usable real Kite depth rows found for GOLD-I" in report


def test_feature_builder_no_input_has_clear_reason(tmp_path):
    day = datetime(2026, 6, 20).date()

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    assert result.tick_rows_loaded == 0
    assert result.depth_rows_loaded == 0
    assert result.rows_generated == 0
    assert result.feature_mode == "NO_FEATURES"
    assert result.market_data_status == "NO_INPUT"
    assert "No tick or depth input rows found" in result.zero_feature_reason
    report = result.report_path.read_text(encoding="utf-8")
    assert "Tick rows loaded: 0" in report
    assert "Depth rows loaded: 0" in report
    assert "Feature mode: NO_FEATURES" in report
    assert "Reason if 0 features: No tick or depth input rows found" in report
    assert "Missing required fields: GOLD-I:tick_or_depth_input" in report


def test_depth_feature_report_includes_input_counts_and_mode(tmp_path):
    day = datetime(2026, 6, 20).date()
    quote = _quote_without_volume(datetime(2026, 6, 20, 9, 15))
    quote["instrument_token"] = 119445255
    save_rows_dedup(
        kite_depth_path(tmp_path, day, "GOLD-I"),
        KITE_DEPTH_COLUMNS,
        _real_depth_rows("GOLD-I", quote),
        ["timestamp", "symbol", "level", "bid_price", "ask_price"],
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", quote)],
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    feature_path = kite_feature_path(tmp_path, day, "GOLD-I")
    with feature_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert result.rows_generated == 1
    assert result.feature_mode == "DEPTH_ORDERFLOW_LITE"
    assert result.market_data_status == "FULL_DEPTH"
    assert rows[0]["data_quality"] == "DEPTH_AVAILABLE"
    assert rows[0]["has_depth"] == "true"
    report = result.report_path.read_text(encoding="utf-8")
    assert "Tick rows loaded: 1" in report
    assert "Depth rows loaded: 5" in report
    assert "Feature mode: DEPTH_ORDERFLOW_LITE" in report
    assert "Market data status: FULL_DEPTH" in report



def _read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _write_feature_rows(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=ORDERFLOW_LITE_COLUMNS)
        writer.writeheader()
        writer.writerows([{column: row.get(column, "") for column in ORDERFLOW_LITE_COLUMNS} for row in rows])


def test_feature_builder_overwrites_stale_output_and_header_only_when_zero_features(tmp_path):
    day = datetime(2026, 6, 20).date()
    feature_path = kite_feature_path(tmp_path, day, "GOLD-I")
    _write_feature_rows(feature_path, [
        {"timestamp": "old-1", "symbol": "GOLD-I", "instrument_token": "100000", "feature_mode": "QUOTE_LITE"},
        {"timestamp": "old-2", "symbol": "GOLD-I", "instrument_token": "119445255", "feature_mode": "DEPTH_ORDERFLOW_LITE"},
    ])
    quote = _real_quote(datetime(2026, 6, 20, 9, 15))
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", quote)],
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    rows = _read_csv_rows(feature_path)
    report = result.report_path.read_text(encoding="utf-8")
    assert result.rows_generated == 0
    assert result.output_csv_data_rows == 0
    assert result.stale_output_rows_removed == 2
    assert rows == []
    assert "INSUFFICIENT_REAL_ROWS" in result.zero_feature_reason
    assert "Features generated in last operation: 0" in report
    assert "Output CSV data row count: 0" in report
    assert "Stale output rows removed: 2" in report


def test_feature_builder_ignores_synthetic_token_by_default(tmp_path):
    day = datetime(2026, 6, 20).date()
    real_rows = []
    for minute in (15, 16):
        quote = _real_quote(datetime(2026, 6, 20, 9, minute))
        quote["last_price"] = 150000 + minute
        real_rows.append(_real_tick_row("GOLD-I", quote))
    synthetic_quote = _quote_without_volume(datetime(2026, 6, 20, 9, 17))
    synthetic_quote["instrument_token"] = 100000
    synthetic_row = normalize_kite_tick_row(
        "GOLD-I",
        synthetic_quote,
        internal_symbol="GOLD-I",
        kite_exchange="MCX",
        kite_tradingsymbol="GOLD26JULFUT",
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [synthetic_row, *real_rows],
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    rows = _read_csv_rows(kite_feature_path(tmp_path, day, "GOLD-I"))
    assert result.rows_generated == 2
    assert result.synthetic_rows_ignored == 1
    assert {row["instrument_token"] for row in rows} == {"119445255"}
    assert {row["kite_tradingsymbol"] for row in rows} == {"GOLD26AUGFUT"}
    assert all(row["feature_mode"] == "QUOTE_LITE" for row in rows)


def test_feature_builder_ignores_dry_run_rows_by_default(tmp_path):
    day = datetime(2026, 6, 20).date()
    path = kite_tick_path(tmp_path, day, "GOLD-I")
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = KITE_TICK_COLUMNS
    real_quote1 = _real_quote(datetime(2026, 6, 20, 9, 15))
    real_quote2 = _real_quote(datetime(2026, 6, 20, 9, 16))
    dry_quote = _real_quote(datetime(2026, 6, 20, 9, 17))
    rows = [
        {**_real_tick_row("GOLD-I", dry_quote), "data_mode": "DRY_RUN", "is_synthetic": "false"},
        {**_real_tick_row("GOLD-I", real_quote1), "data_mode": "LIVE", "is_synthetic": "false"},
        {**_real_tick_row("GOLD-I", real_quote2), "data_mode": "LIVE", "is_synthetic": "false"},
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    feature_rows = _read_csv_rows(kite_feature_path(tmp_path, day, "GOLD-I"))
    assert result.synthetic_rows_ignored == 1
    assert result.rows_generated == 2
    assert len(feature_rows) == 2
    assert all(row["instrument_token"] == "119445255" for row in feature_rows)


def test_feature_builder_real_only_depth_uses_single_resolved_identity(tmp_path):
    day = datetime(2026, 6, 20).date()
    real_quote = _real_quote(datetime(2026, 6, 20, 9, 20))
    synthetic_quote = _quote(datetime(2026, 6, 20, 9, 19))
    synthetic_quote["instrument_token"] = 100000
    synthetic_depth = normalize_kite_depth_rows(
        "GOLD-I",
        synthetic_quote,
        internal_symbol="GOLD-I",
        kite_exchange="MCX",
        kite_tradingsymbol="GOLD26JULFUT",
    )
    save_rows_dedup(
        kite_depth_path(tmp_path, day, "GOLD-I"),
        KITE_DEPTH_COLUMNS,
        synthetic_depth + _real_depth_rows("GOLD-I", real_quote),
        ["timestamp", "symbol", "level", "bid_price", "ask_price"],
    )
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        [_real_tick_row("GOLD-I", real_quote)],
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(tmp_path, symbols_text="GOLD-I", day=day)

    rows = _read_csv_rows(kite_feature_path(tmp_path, day, "GOLD-I"))
    assert result.rows_generated == 1
    assert result.real_depth_rows_used == 5
    assert result.synthetic_rows_ignored == 5
    assert rows[0]["feature_mode"] == "DEPTH_ORDERFLOW_LITE"
    assert rows[0]["data_quality"] == "DEPTH_AVAILABLE"
    assert rows[0]["instrument_token"] == "119445255"
    assert rows[0]["kite_tradingsymbol"] == "GOLD26AUGFUT"


def test_streaming_appender_flushes_incrementally_and_keeps_valid_csv(tmp_path):
    path = tmp_path / "ticks.csv"
    writer = _StreamingCsvAppender(
        path,
        KITE_TICK_COLUMNS,
        ["timestamp", "symbol", "ltp", "received_at"],
        flush_rows=1,
        resume=True,
    )
    row = normalize_kite_tick_row("GOLD-I", _quote(), received_at=datetime(2026, 6, 19, 9, 16))
    assert writer.append_rows([row]) == 1
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 1
    assert rows[0]["symbol"] == "GOLD-I"
    writer.close()


def test_streaming_appender_resume_does_not_duplicate_header(tmp_path):
    path = tmp_path / "ticks.csv"
    first = _StreamingCsvAppender(
        path,
        KITE_TICK_COLUMNS,
        ["timestamp", "symbol", "ltp", "received_at"],
        flush_rows=1,
        resume=True,
    )
    first.append_rows([normalize_kite_tick_row("GOLD-I", _quote(datetime(2026, 6, 19, 9, 15)))])
    first.close()
    second = _StreamingCsvAppender(
        path,
        KITE_TICK_COLUMNS,
        ["timestamp", "symbol", "ltp", "received_at"],
        flush_rows=1,
        resume=True,
    )
    second.append_rows([normalize_kite_tick_row("GOLD-I", _quote(datetime(2026, 6, 19, 9, 16)))])
    second.close()
    lines = path.read_text(encoding="utf-8").splitlines()
    assert sum(1 for line in lines if line.startswith("timestamp,")) == 1
    with path.open(newline="", encoding="utf-8") as f:
        assert len(list(csv.DictReader(f))) == 2


def test_memoryerror_preserves_streamed_rows_and_marks_partial_usable(tmp_path, monkeypatch):
    original = recorder_module._record_quote_snapshot

    def write_then_fail(*args, **kwargs):
        original(*args, **kwargs)
        raise MemoryError()

    monkeypatch.setattr(recorder_module, "_record_quote_snapshot", write_then_fail)
    result = record_kite_live_data(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=5,
        record_depth=True,
        dry_run=True,
        flush_rows=1,
        configs={"settings": {}, "risk": {}, "instruments": {"GOLD-I": {"exchange": "MCX"}}},
        now_fn=lambda: datetime(2026, 6, 19, 9, 15),
    )

    tick_path = kite_tick_path(tmp_path, date(2026, 6, 19), "GOLD-I")
    depth_path = kite_depth_path(tmp_path, date(2026, 6, 19), "GOLD-I")
    assert result.recorder_failed_safely is True
    assert result.partial_data_usable is True
    assert result.tick_rows_recorded == 1
    assert result.depth_rows_recorded == 5
    assert tick_path.exists() and depth_path.exists()
    features = build_kite_orderflow_lite_features(
        tmp_path,
        symbols_text="GOLD-I",
        day=date(2026, 6, 19),
        include_synthetic=True,
    )
    assert features.output_csv_data_rows == features.rows_generated
    assert kite_feature_path(tmp_path, date(2026, 6, 19), "GOLD-I").exists()
    assert "memory_safe_streaming: true" in result.report_path.read_text(encoding="utf-8")
