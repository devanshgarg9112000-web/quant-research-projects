﻿from __future__ import annotations

import csv
from datetime import date, datetime
from pathlib import Path

from src.data_collection.kite_contract_consistency import (
    CONTRACT_MISMATCH_INVESTIGATE,
    MIXED_CONTRACTS_WARNING,
    REAL_CONTRACT_SELECTED,
    evaluate_contract_consistency,
)
from src.data_collection.kite_orderflow_features import build_kite_orderflow_lite_features
from src.data_collection.kite_instrument_resolver import (
    instrument_cache_path,
    save_instruments_cache,
)
from src.data_collection.market_data_schema import (
    KITE_TICK_COLUMNS,
    kite_feature_path,
    kite_tick_path,
    normalize_kite_tick_row,
    save_rows_dedup,
)


def _tick(
    timestamp: datetime,
    *,
    tradingsymbol: str,
    token: int,
    expiry: str,
    data_mode: str = "REAL_READ_ONLY",
    synthetic: bool = False,
    price: float = 150000.0,
) -> dict:
    return normalize_kite_tick_row(
        "GOLD-I",
        {
            "instrument_token": token,
            "timestamp": timestamp,
            "last_price": price,
            "volume_traded": 100,
        },
        received_at=timestamp,
        internal_symbol="GOLD-I",
        kite_exchange="MCX",
        kite_tradingsymbol=tradingsymbol,
        expiry=expiry,
        data_mode=data_mode,
        is_synthetic=synthetic,
    )


def _read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def test_dry_run_synthetic_plus_real_selects_real_contract():
    rows = [
        _tick(
            datetime(2026, 6, 20, 9, 15),
            tradingsymbol="GOLD26JULFUT",
            token=900001,
            expiry="2026-07-20",
            data_mode="DRY_RUN",
            synthetic=True,
        ),
        _tick(
            datetime(2026, 6, 20, 9, 16),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="2026-08-05",
        ),
    ]

    result = evaluate_contract_consistency(rows, internal_symbol="GOLD-I")

    assert result.status == REAL_CONTRACT_SELECTED
    assert result.selected_contract.kite_tradingsymbol == "GOLD26AUGFUT"
    assert result.selected_contract.instrument_token == "119445255"
    assert len(result.synthetic_contracts_ignored) == 1
    assert "GOLD26JULFUT" in result.synthetic_contracts_ignored[0]
    assert result.action_required is False


def test_multiple_real_contracts_require_investigation_unless_allowed():
    rows = [
        _tick(
            datetime(2026, 6, 20, 9, 15),
            tradingsymbol="GOLD26JULFUT",
            token=111,
            expiry="2026-07-20",
        ),
        _tick(
            datetime(2026, 6, 20, 9, 20),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="2026-08-05",
        ),
    ]

    guarded = evaluate_contract_consistency(rows, internal_symbol="GOLD-I")
    explicitly_allowed = evaluate_contract_consistency(
        rows,
        internal_symbol="GOLD-I",
        allow_mixed_contracts=True,
    )

    assert guarded.status == CONTRACT_MISMATCH_INVESTIGATE
    assert guarded.selected_contract.kite_tradingsymbol == "GOLD26AUGFUT"
    assert guarded.action_required is True
    assert len(guarded.ignored_contracts) == 1
    assert explicitly_allowed.status == MIXED_CONTRACTS_WARNING
    assert explicitly_allowed.action_required is False


def test_feature_csv_contains_only_selected_real_contract_by_default(tmp_path):
    day = date(2026, 6, 20)
    rows = [
        _tick(
            datetime(2026, 6, 20, 9, 15),
            tradingsymbol="GOLD26JULFUT",
            token=111,
            expiry="2026-07-20",
            price=149900,
        ),
        _tick(
            datetime(2026, 6, 20, 9, 16),
            tradingsymbol="GOLD26JULFUT",
            token=111,
            expiry="2026-07-20",
            price=149901,
        ),
        _tick(
            datetime(2026, 6, 20, 9, 20),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="2026-08-05",
            price=150000,
        ),
        _tick(
            datetime(2026, 6, 20, 9, 21),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="2026-08-05",
            price=150001,
        ),
        _tick(
            datetime(2026, 6, 20, 9, 22),
            tradingsymbol="GOLD26JULFUT",
            token=900001,
            expiry="2026-07-20",
            data_mode="DRY_RUN",
            synthetic=True,
            price=99999,
        ),
    ]
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        rows,
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(
        tmp_path,
        symbols_text="GOLD-I",
        day=day,
    )

    feature_rows = _read_rows(kite_feature_path(tmp_path, day, "GOLD-I"))
    assert result.contract_consistency_status == CONTRACT_MISMATCH_INVESTIGATE
    assert "GOLD26AUGFUT" in result.selected_contract
    assert result.output_real_contract_count == 1
    assert result.report_csv_contract_match is True
    assert {row["kite_tradingsymbol"] for row in feature_rows} == {"GOLD26AUGFUT"}
    assert {row["instrument_token"] for row in feature_rows} == {"119445255"}
    assert all(row["is_synthetic"] == "false" for row in feature_rows)
    assert "900001" not in {row["instrument_token"] for row in feature_rows}


def test_allow_mixed_contracts_must_be_explicit(tmp_path):
    day = date(2026, 6, 20)
    rows = [
        _tick(
            datetime(2026, 6, 20, 9, 15),
            tradingsymbol="GOLD26JULFUT",
            token=111,
            expiry="2026-07-20",
        ),
        _tick(
            datetime(2026, 6, 20, 9, 16),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="2026-08-05",
        ),
    ]
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        rows,
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(
        tmp_path,
        symbols_text="GOLD-I",
        day=day,
        allow_mixed_contracts=True,
    )

    feature_rows = _read_rows(kite_feature_path(tmp_path, day, "GOLD-I"))
    assert result.contract_consistency_status == MIXED_CONTRACTS_WARNING
    assert result.output_real_contract_count == 2
    assert {row["kite_tradingsymbol"] for row in feature_rows} == {"GOLD26JULFUT", "GOLD26AUGFUT"}


def test_contract_module_has_no_order_execution_path_text():
    module_path = Path(__file__).resolve().parents[1] / "src" / "data_collection" / "kite_contract_consistency.py"
    assert "place_order" not in module_path.read_text(encoding="utf-8")



def test_contract_guard_metadata_complete_when_expiry_exists():
    result = evaluate_contract_consistency(
        [
            _tick(
                datetime(2026, 6, 20, 9, 15),
                tradingsymbol="GOLD26AUGFUT",
                token=119445255,
                expiry="2026-08-05",
            )
        ],
        internal_symbol="GOLD-I",
    )

    assert result.metadata_complete is True
    assert result.missing_contract_fields == ()
    assert result.expiry_missing_warning is False
    assert "expiry=2026-08-05" in result.selected_contract_text


def test_contract_guard_missing_expiry_warns_without_contract_failure():
    result = evaluate_contract_consistency(
        [
            _tick(
                datetime(2026, 6, 20, 9, 15),
                tradingsymbol="GOLD26AUGFUT",
                token=119445255,
                expiry="",
            )
        ],
        internal_symbol="GOLD-I",
    )

    assert result.status == "CONSISTENT"
    assert result.action_required is False
    assert result.metadata_complete is False
    assert result.missing_contract_fields == ("expiry",)
    assert result.expiry_missing_warning is True


def test_resolver_cache_expiry_is_propagated_into_feature_rows(tmp_path):
    day = date(2026, 6, 20)
    save_instruments_cache(
        instrument_cache_path(tmp_path, "MCX"),
        [{
            "instrument_token": "119445255",
            "exchange": "MCX",
            "tradingsymbol": "GOLD26AUGFUT",
            "name": "GOLD",
            "expiry": "2026-08-05",
            "lot_size": "1",
            "tick_size": "1",
            "instrument_type": "FUT",
            "segment": "MCX-FUT",
        }],
    )
    rows = [
        _tick(
            datetime(2026, 6, 20, 9, 15),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="",
            price=150000,
        ),
        _tick(
            datetime(2026, 6, 20, 9, 16),
            tradingsymbol="GOLD26AUGFUT",
            token=119445255,
            expiry="",
            price=150001,
        ),
    ]
    save_rows_dedup(
        kite_tick_path(tmp_path, day, "GOLD-I"),
        KITE_TICK_COLUMNS,
        rows,
        ["timestamp", "symbol", "ltp", "received_at"],
    )

    result = build_kite_orderflow_lite_features(
        tmp_path,
        symbols_text="GOLD-I",
        day=day,
    )

    feature_rows = _read_rows(kite_feature_path(tmp_path, day, "GOLD-I"))
    assert result.expiry_rows_enriched == 2
    assert result.contract_metadata_complete is True
    assert result.expiry_missing_warning is False
    assert "expiry=2026-08-05" in result.selected_contract
    assert {row["expiry"] for row in feature_rows} == {"2026-08-05"}
