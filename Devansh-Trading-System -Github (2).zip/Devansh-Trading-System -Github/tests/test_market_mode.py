from src.data.sample_data import range_sample, trap_sample, trend_down_sample, trend_up_sample
from src.market_context.market_mode import classify_market_mode


def test_market_modes():
    assert classify_market_mode(trend_up_sample()) == "TREND_UP"
    assert classify_market_mode(trend_down_sample()) == "TREND_DOWN"
    assert classify_market_mode(range_sample()) == "RANGE"
    assert classify_market_mode(trap_sample()) == "TRAP_REVERSAL"
