from __future__ import annotations

from datetime import datetime
from pathlib import Path

from src.data_collection.kite_instrument_resolver import instrument_cache_path, save_instruments_cache
from src.data_collection.kite_monday_preflight import run_kite_monday_preflight


def _configs() -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "risk": {},
        "strategies": {},
        "approved_strategies": {},
        "instruments": {"GOLD-I": {"exchange": "MCX"}},
        "alerts": {"enable_whatsapp_alerts": False},
        "forward_validation": {
            "production_alerts_allowed": False,
            "send_research_whatsapp_preview": False,
        },
    }


def test_monday_preflight_dry_run_works_without_credentials(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_monday_preflight(
        tmp_path,
        symbols_text="GOLD-I",
        dry_run=True,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 20, 9, 15),
    )

    output = capsys.readouterr().out
    assert result.success is True
    assert result.status == "READY_READ_ONLY"
    assert result.credential_status == "MISSING"
    assert result.profile_status == "DRY_RUN"
    assert result.quote_status == "DRY_RUN_OK"
    assert result.depth_status == "PRESENT"
    assert result.expiry_available is True
    assert result.safety_flags_ok is True
    assert "READ ONLY CHECK ONLY. NO ORDERS." in output
    report = result.report_path.read_text(encoding="utf-8")
    assert "expiry_available: true" in report
    assert "production_whatsapp_status: BLOCKED" in report
    assert "execution_allowed=false" in report


def test_monday_preflight_dry_run_prefers_cached_real_contract(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)
    save_instruments_cache(
        instrument_cache_path(tmp_path, "MCX"),
        [{
            "instrument_token": "119445255",
            "exchange": "MCX",
            "tradingsymbol": "GOLD26AUGFUT",
            "name": "GOLD",
            "expiry": "2026-08-05",
            "lot_size": "1",
            "tick_size": "1",
            "instrument_type": "FUT",
            "segment": "MCX-FUT",
        }],
    )

    result = run_kite_monday_preflight(
        tmp_path,
        symbols_text="GOLD-I",
        dry_run=True,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 20, 9, 15),
    )

    assert result.success is True
    assert result.expiry_available is True
    assert "GOLD26AUGFUT" in result.selected_contracts[0]
    assert "expiry=2026-08-05" in result.selected_contracts[0]


def test_monday_preflight_real_mode_missing_token_fails_safely(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    def should_not_run(*_args, **_kwargs):
        raise AssertionError("real preflight must stop before external read-only checks")

    result = run_kite_monday_preflight(
        tmp_path,
        symbols_text="GOLD-I",
        dry_run=False,
        configs=_configs(),
        resolver_func=should_not_run,
        readonly_check_func=should_not_run,
    )

    assert result.success is False
    assert result.status == "FAILED_SAFE"
    assert "requires PRESENT Kite credentials" in result.errors[0]
    report = result.report_path.read_text(encoding="utf-8")
    assert "Status: FAILED_SAFE" in report
    assert "Broker Orders: DISABLED" in report


def test_monday_preflight_module_has_no_order_execution_path_text():
    module_path = Path(__file__).resolve().parents[1] / "src" / "data_collection" / "kite_monday_preflight.py"
    text = module_path.read_text(encoding="utf-8")

    assert "place_order" not in text
    assert "execution_allowed=false" in text
