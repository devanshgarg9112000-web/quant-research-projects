﻿from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from src.reports.launch1_readiness_report import (
    HISTORY_PATH,
    LAUNCH1_BLOCKED_DATA_QUALITY,
    LAUNCH1_BLOCKED_SAFETY,
    LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA,
    LAUNCH1_READY_FOR_PAPER_RESEARCH,
    REQUIRED_COMPONENTS,
    generate_launch1_readiness_report,
)


TARGET_MONDAY = "2026-06-22"
HISTORICAL_DATE = "2026-06-20"


def _configs(*, live: bool = False, production_alerts: bool = False) -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": live},
        "forward_validation": {"production_alerts_allowed": production_alerts},
        "approved_strategies": {
            "enabled": True,
            "allow_approved": True,
            "allow_watchlist": False,
        },
    }


def _write_components(base: Path) -> None:
    for path in REQUIRED_COMPONENTS:
        target = base / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("# test component placeholder\n", encoding="utf-8")


def _write_file(base: Path, relative: str, text: str) -> None:
    path = base / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _write_ready_reports(
    base: Path,
    *,
    verifier_date: str = TARGET_MONDAY,
    verdict: str = "DAY_ACCEPTED_FOR_RESEARCH",
    tick_rows: int = 38,
    depth_rows: int = 65,
    feature_rows: int = 1,
) -> None:
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_monday_checklist.txt",
        "\n".join(
            [
                "KITE MONDAY CHECKLIST",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_monday_preflight_report.txt",
        "\n".join(
            [
                "KITE MONDAY PREFLIGHT REPORT",
                "READY_READ_ONLY",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_kite_daily_pipeline_report.txt",
        "\n".join(
            [
                "KITE DAILY PIPELINE REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Feature mode: DEPTH_ORDERFLOW_LITE",
                "Forward-validation decision: RESEARCH_ONLY",
                "",
                "CONTRACT CONSISTENCY",
                "status: REAL_CONTRACT_SELECTED",
                "selected_contract: GOLD-I:MCX:GOLD26AUGFUT instrument_token=119445255 expiry=2026-08-05",
                "",
                "DATA QUALITY GATE",
                "status: READY_FOR_FORWARD_VALIDATION",
                "",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_post_recording_verifier_report.txt",
        "\n".join(
            [
                "KITE POST-RECORDING VERIFIER REPORT",
                f"Date: {verifier_date}",
                "Mode: PAPER",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                f"Tick file: data/kite_recorded/ticks/{verifier_date}/GOLD-I_ticks.csv | exists=true | rows={tick_rows}",
                f"Depth file: data/kite_recorded/depth/{verifier_date}/GOLD-I_depth.csv | exists=true | rows={depth_rows}",
                f"Feature file: data/kite_recorded/features/{verifier_date}/GOLD-I_orderflow_lite.csv | exists=true | rows={feature_rows}",
                "Selected contract: GOLD-I:MCX:GOLD26AUGFUT instrument_token=119445255 expiry=2026-08-05",
                "Synthetic rows found: 0",
                "Mixed contracts found: false",
                "Pipeline contract status: REAL_CONTRACT_SELECTED",
                "Data Quality Gate status: READY_FOR_FORWARD_VALIDATION",
                f"VERDICT: {verdict}",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/forward_validation/latest_forward_validation_summary.txt",
        "\n".join(
            [
                "GOLD-I VWAP REJECTION SHORT FORWARD VALIDATION SUMMARY",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Production WhatsApp Alerts: BLOCKED",
                "Approval Decision: RESEARCH_ONLY",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "config/approved_strategies.yaml",
        "enabled: true\nallow_approved: true\nallow_watchlist: false\n",
    )



def _write_reconciled_target_reports(base: Path) -> None:
    _write_ready_reports(
        base,
        verifier_date=TARGET_MONDAY,
        tick_rows=4327,
        depth_rows=19991,
        feature_rows=3908,
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_kite_daily_pipeline_report.txt",
        "\n".join(
            [
                "KITE DAILY PIPELINE REPORT",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Feature mode: NO_FEATURES",
                "Feature output CSV data rows: 0",
                "Forward-validation decision: RESEARCH_ONLY",
                "",
                "CONTRACT CONSISTENCY",
                "status: NOT_CHECKED",
                "selected_contract: NONE",
                "",
                "DATA QUALITY GATE",
                "status: MARKET_CLOSED_OR_NO_LIVE_DATA",
                "",
                "ERRORS",
                "- Kite live recorder failed safely: MemoryError.",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_data_collection/latest_kite_data_collection_report.txt",
        "\n".join(
            [
                "KITE DATA COLLECTION REPORT",
                "Mode: PAPER",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "",
                "LAST OPERATION",
                "Last operation type: feature_builder",
                "Features generated in last operation: 3908",
                "Tick rows loaded: 4327",
                "Depth rows loaded: 19991",
                "Output CSV data row count: 3908",
                "Feature mode: DEPTH_ORDERFLOW_LITE",
                "Market data status: FULL_DEPTH",
                "Contract consistency status: CONSISTENT",
                "Report/CSV contract match: true",
                "Contract metadata complete: true",
                "Errors: NONE",
                "PAPER MODE ONLY. Kite read-only data calls only. No broker orders were placed.",
            ]
        )
        + "\n",
    )
    _write_file(
        base,
        "reports/kite_daily_pipeline/latest_post_recording_verifier_report.txt",
        "\n".join(
            [
                "KITE POST-RECORDING VERIFIER REPORT",
                f"Date: {TARGET_MONDAY}",
                "Mode: PAPER",
                "Live Trading: DISABLED",
                "Broker Orders: DISABLED",
                "execution_allowed=false",
                "Tick file: data/kite_recorded/ticks/2026-06-22/GOLD-I_ticks.csv | exists=true | rows=4327",
                "Depth file: data/kite_recorded/depth/2026-06-22/GOLD-I_depth.csv | exists=true | rows=19991",
                "Feature file: data/kite_recorded/features/2026-06-22/GOLD-I_orderflow_lite.csv | exists=true | rows=3908",
                "Selected contract: GOLD-I:MCX:GOLD26AUGFUT instrument_token=119445255 expiry=2026-08-05",
                "Synthetic rows found: 0",
                "Mixed contracts found: false",
                "Expected contract match: true",
                "Pipeline contract status: NOT_CHECKED",
                "Data collection contract status: CONSISTENT",
                "Data collection market data status: FULL_DEPTH",
                "Data Quality Gate status: MARKET_CLOSED_OR_NO_LIVE_DATA",
                "Pipeline report status: STALE_OR_FAILED",
                "Data collection report status: CLEAN_FEATURE_BUILDER_REPORT",
                "Feature rebuild reconciliation status: RECONCILED",
                "Authoritative feature source used: DATA_COLLECTION_FEATURE_BUILDER_REPORT",
                "Pipeline report stale/failed: true",
                "Manual feature rebuild reconciled day: true",
                "Forward validation decision: RESEARCH_ONLY",
                "Production WhatsApp status: BLOCKED",
                "VERDICT: DAY_ACCEPTED_FOR_RESEARCH",
                "Production WhatsApp Alerts: BLOCKED",
            ]
        )
        + "\n",
    )

def test_launch1_readiness_report_generated(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 21, 8, 0),
    )

    assert result.report_path.exists()
    assert result.history_path.exists()
    text = result.report_path.read_text(encoding="utf-8")
    assert "LAUNCH 1 READINESS REPORT" in text
    assert "TUESDAY LAUNCH 1 DECISION" in text
    assert "target_validation_date: 2026-06-22" in text
    assert "latest_verifier_date: 2026-06-22" in text
    assert "target_validation_passed: true" in text
    assert "execution_allowed=false" in text
    with (tmp_path / HISTORY_PATH).open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[-1]["target_validation_date"] == TARGET_MONDAY
    assert rows[-1]["latest_verifier_date"] == TARGET_MONDAY
    assert rows[-1]["target_validation_passed"] == "true"
    assert rows[-1]["decision"] == LAUNCH1_READY_FOR_PAPER_RESEARCH
    assert rows[-1]["reason"]


def test_latest_verifier_date_older_than_target_waits_for_monday_data(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=HISTORICAL_DATE)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 21, 8, 0),
    )

    assert result.decision == LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA
    assert result.latest_verifier_date.isoformat() == HISTORICAL_DATE
    assert result.target_validation_date.isoformat() == TARGET_MONDAY
    assert result.target_validation_passed is False
    assert result.readiness_data_basis == "HISTORICAL_OR_TEST_DATA_ONLY"
    assert "target Monday real-market validation has not been completed" in result.decision_reason
    report = result.report_path.read_text(encoding="utf-8")
    assert "Latest verifier date 2026-06-20 is not the target validation date 2026-06-22" in report
    assert "Monday real-market data was accepted" not in report


def test_target_date_accepted_is_ready_for_paper_research(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    assert result.decision == LAUNCH1_READY_FOR_PAPER_RESEARCH
    assert result.target_validation_passed is True
    assert result.verifier_verdict == "DAY_ACCEPTED_FOR_RESEARCH"
    assert result.data_quality_status == "READY_FOR_FORWARD_VALIDATION"
    assert result.tick_rows == 38
    assert result.depth_rows == 65
    assert result.feature_rows == 1
    assert result.forward_validation_decision == "RESEARCH_ONLY"


def test_no_target_date_provided_warns_and_does_not_claim_monday_passed(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=HISTORICAL_DATE)

    result = generate_launch1_readiness_report(
        tmp_path,
        configs=_configs(),
        now_fn=lambda: datetime(2026, 6, 21, 8, 0),
    )

    assert result.target_validation_date.isoformat() == TARGET_MONDAY
    assert result.target_validation_date_explicit is False
    assert result.decision == LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA
    assert result.target_validation_passed is False
    report = result.report_path.read_text(encoding="utf-8")
    assert "target_validation_date_explicit: false" in report
    assert "Target validation date was inferred as the next Monday" in report
    assert "Monday real-market data was accepted" not in report


def test_report_includes_latest_and_target_validation_dates(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=HISTORICAL_DATE)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    report = result.report_path.read_text(encoding="utf-8")
    assert "TARGET VALIDATION DATE" in report
    assert "target_validation_date: 2026-06-22" in report
    assert "latest_verifier_date: 2026-06-20" in report
    assert "target_validation_date_has_passed_verifier: false" in report
    assert "readiness_data_basis: HISTORICAL_OR_TEST_DATA_ONLY" in report


def test_misleading_monday_accepted_phrase_only_after_target_date_passed(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=HISTORICAL_DATE)
    waiting = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )
    waiting_text = waiting.report_path.read_text(encoding="utf-8")
    assert "Monday real-market data was accepted" not in waiting_text

    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)
    ready = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )
    ready_text = ready.report_path.read_text(encoding="utf-8")
    assert ready.decision == LAUNCH1_READY_FOR_PAPER_RESEARCH
    assert "Target Monday real-market validation data was accepted" in ready_text


def test_blocked_safety_decision_still_overrides_target_date(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(live=True),
    )

    assert result.decision == LAUNCH1_BLOCKED_SAFETY
    assert result.safety_ok is False
    assert any("enable_live_trading" in issue for issue in result.safety_issues)


def test_blocked_data_quality_decision_for_target_date_bad_verdict(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY, verdict="DAY_REQUIRES_INVESTIGATION")

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    assert result.decision == LAUNCH1_BLOCKED_DATA_QUALITY
    assert result.verifier_verdict == "DAY_REQUIRES_INVESTIGATION"


def test_research_only_strategy_status_is_clearly_displayed(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    text = result.report_path.read_text(encoding="utf-8")
    assert result.strategy_approval_status == "RESEARCH_ONLY"
    assert "strategy_approval_status: RESEARCH_ONLY" in text
    assert "Readiness for Launch 1 does NOT mean real-money trading." in text
    assert "Current production trading/production alert approval: NOT_APPROVED" in text


def test_data_and_research_modules_do_not_contain_order_execution_call_text():
    root = Path(__file__).resolve().parents[1] / "src"
    checked_roots = [root / "data_collection", root / "research"]
    offenders = [
        path
        for checked_root in checked_roots
        for path in checked_root.rglob("*.py")
        if "place_order" in path.read_text(encoding="utf-8")
    ]

    assert offenders == []


def test_launch1_report_keeps_execution_allowed_false(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    assert result.execution_allowed == "false"
    assert "execution_allowed=false" in result.report_path.read_text(encoding="utf-8")


def test_reconciled_target_date_uses_data_collection_values_not_stale_pipeline(tmp_path):
    _write_components(tmp_path)
    _write_reconciled_target_reports(tmp_path)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    assert result.decision == LAUNCH1_READY_FOR_PAPER_RESEARCH
    assert result.contract_consistency_status == "CONSISTENT"
    assert result.feature_mode == "DEPTH_ORDERFLOW_LITE"
    assert result.data_quality_status == "FULL_DEPTH"
    assert result.feature_rebuild_reconciliation_status == "RECONCILED"
    assert result.authoritative_feature_source == "DATA_COLLECTION_FEATURE_BUILDER_REPORT"
    assert result.pipeline_report_stale_or_failed is True
    assert result.manual_feature_rebuild_reconciled_day is True
    report = result.report_path.read_text(encoding="utf-8")
    assert "RECONCILIATION STATUS" in report
    assert "contract_consistency_status: CONSISTENT" in report
    assert "feature_mode: DEPTH_ORDERFLOW_LITE" in report
    assert "data_quality_status: FULL_DEPTH" in report
    assert "contract_consistency_status: NOT_CHECKED" not in report
    assert "feature_mode: NO_FEATURES" not in report
    assert "data_quality_status: MARKET_CLOSED_OR_NO_LIVE_DATA" not in report


def test_reconciled_target_date_report_warns_about_stale_memoryerror_pipeline(tmp_path):
    _write_components(tmp_path)
    _write_reconciled_target_reports(tmp_path)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    report = result.report_path.read_text(encoding="utf-8")
    assert result.decision == LAUNCH1_READY_FOR_PAPER_RESEARCH
    assert "Long daily pipeline report was stale/failed due MemoryError" in report
    assert "accepted day is based on reconciled post-recording verifier and feature-builder report" in report
    assert "pipeline_report_status: STALE_OR_FAILED" in report
    assert "data_collection_report_status: CLEAN_FEATURE_BUILDER_REPORT" in report
    assert "feature_rebuild_reconciliation_status: RECONCILED" in report
    assert "authoritative_feature_source: DATA_COLLECTION_FEATURE_BUILDER_REPORT" in report
    assert "pipeline_report_stale_or_failed: true" in report
    assert "manual_feature_rebuild_reconciled_day: true" in report

def test_existing_launch1_report_is_explicitly_stage0_not_tradeable_launch1(tmp_path):
    _write_components(tmp_path)
    _write_ready_reports(tmp_path, verifier_date=TARGET_MONDAY)

    result = generate_launch1_readiness_report(
        tmp_path,
        target_validation_date=TARGET_MONDAY,
        configs=_configs(),
    )

    report = result.report_path.read_text(encoding="utf-8")
    assert result.stage0_infrastructure_data_readiness == "READY"
    assert result.tradeable_launch1_readiness == "NOT_READY"
    assert "Stage 0 Infrastructure/Data Readiness: READY" in report
    assert "Tradeable Launch 1: NOT_READY" in report
    assert "means only PAPER/research/data infrastructure readiness" in report
    assert "It does not mean signal generation is reliable." in report
    assert "It does not mean any strategy is approved." in report
    assert "It does not mean real-money manual trading is approved." in report
    assert "This report evaluates Stage 0 infrastructure/data readiness, not tradeable Launch 1." in report

