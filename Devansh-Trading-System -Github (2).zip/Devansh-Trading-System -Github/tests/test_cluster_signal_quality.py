from __future__ import annotations

from datetime import datetime, timedelta

from src.models.signal import Signal
from src.strategies.cluster_signal_quality import (
    ClusterSignalQualityConfig,
    ClusterSignalQualityState,
)


def _signal(
    *,
    side: str = "BUY",
    market_mode: str = "TREND_UP",
    entry: float = 100.0,
    stop: float = 90.0,
    target: float = 120.0,
    trap_strength: float = 0.8,
    zone: float = 100.0,
) -> Signal:
    return Signal(
        symbol="GOLD-I",
        timestamp=datetime(2026, 6, 18, 9, 15),
        strategy_name="MCX Cluster Trap",
        side=side,
        entry_price=entry,
        stop_loss=stop,
        target_price=target,
        reward_risk=2.0,
        score=8.8,
        reason="test",
        market_mode=market_mode,
        key_level=zone,
        setup_type="cluster_imbalance_trap",
        metadata={"trap_strength": trap_strength, "latest_ltq": 2, "cluster_zone": zone},
    )


def test_weak_trap_signal_is_quality_rejected():
    decision = ClusterSignalQualityState().evaluate(
        _signal(trap_strength=0.5),
        datetime(2026, 6, 18, 9, 15),
        ClusterSignalQualityConfig(min_trap_strength=0.65),
    )

    assert decision.accepted is False
    assert "WEAK_TRAP" in decision.reason_codes


def test_bad_stop_distance_is_quality_rejected():
    decision = ClusterSignalQualityState().evaluate(
        _signal(stop=98.0),
        datetime(2026, 6, 18, 9, 15),
        ClusterSignalQualityConfig(min_stop_distance=5.0),
    )

    assert decision.accepted is False
    assert "BAD_STOP_DISTANCE" in decision.reason_codes


def test_bad_target_distance_is_quality_rejected():
    decision = ClusterSignalQualityState().evaluate(
        _signal(target=105.0),
        datetime(2026, 6, 18, 9, 15),
        ClusterSignalQualityConfig(min_target_distance=10.0),
    )

    assert decision.accepted is False
    assert "BAD_TARGET_DISTANCE" in decision.reason_codes


def test_rapid_direction_flip_is_rejected():
    state = ClusterSignalQualityState()
    config = ClusterSignalQualityConfig(direction_flip_cooldown_seconds=300)
    first_time = datetime(2026, 6, 18, 9, 15)

    first = state.evaluate(_signal(side="BUY", market_mode="TREND_UP", zone=100.0), first_time, config)
    second = state.evaluate(
        _signal(side="SELL", market_mode="TREND_DOWN", stop=110.0, target=80.0, zone=110.0),
        first_time + timedelta(seconds=60),
        config,
    )

    assert first.accepted is True
    assert second.accepted is False
    assert "DIRECTION_FLIP" in second.reason_codes


def test_same_zone_repeated_signal_is_rejected():
    state = ClusterSignalQualityState()
    config = ClusterSignalQualityConfig(same_zone_cooldown_seconds=300)
    first_time = datetime(2026, 6, 18, 9, 15)

    first = state.evaluate(_signal(zone=100.0), first_time, config)
    second = state.evaluate(_signal(zone=100.0), first_time + timedelta(seconds=60), config)

    assert first.accepted is True
    assert second.accepted is False
    assert "SAME_ZONE" in second.reason_codes


def test_market_mode_mismatch_is_rejected_when_enabled():
    decision = ClusterSignalQualityState().evaluate(
        _signal(side="BUY", market_mode="TREND_DOWN"),
        datetime(2026, 6, 18, 9, 15),
        ClusterSignalQualityConfig(require_market_mode_alignment=True),
    )

    assert decision.accepted is False
    assert "MARKET_MODE" in decision.reason_codes
