from datetime import date, datetime, timedelta
from pathlib import Path

from src.option_signals.config import load_option_signal_config
from src.option_signals.models import MinuteBar
from src.option_signals.runtime import OptionSignalRuntime
from src.option_signals.telegram_notifier import TelegramNotifier
from src.option_signals.time_utils import IST


class FakeMarketData:
    def __init__(self):
        self.sell = 100.0
        self.buy = 100.0
        self._bars = []
        start = datetime(2026, 10, 5, 9, 40, tzinfo=IST)  # Monday
        price = 25000.0
        for i in range(51):  # last at 10:30
            price += 4.0
            ts = start + timedelta(minutes=i)
            self._bars.append(MinuteBar(ts, price - 1, price + 1, price - 1, price))
        self._optbars = [
            MinuteBar(datetime(2026, 10, 5, 10, 27 + i, tzinfo=IST), 100, 101, 99, 100 + i * 0.1, 1000, 1000)
            for i in range(4)
        ]
        self.instruments = []
        for typ, token in [("CE", 101), ("PE", 102)]:
            self.instruments.append({
                "exchange": "NFO", "name": "NIFTY", "expiry": date(2026, 10, 6), "strike": 25150,
                "instrument_type": typ, "instrument_token": token, "tradingsymbol": f"NIFTYTEST25150{typ}",
                "lot_size": 65, "tick_size": .05,
            })

    def spot_bars(self, underlying, *, now, history_minutes=90):
        return self._bars

    def instrument_master(self, underlying):
        return self.instruments

    def option_bars(self, contract, *, now, history_minutes=10):
        return self._optbars

    def sell_reference(self, contract):
        return self.sell

    def buy_reference(self, contract):
        return self.buy


def test_runtime_combines_same_side_strategies_without_doubling_lots(tmp_path):
    cfg, raw = load_option_signal_config(Path("."))
    market = FakeMarketData()
    rt = OptionSignalRuntime(base_dir=tmp_path, market_data=market, config=cfg, raw_config=raw, notifier=TelegramNotifier(dry_run=True))
    now = datetime(2026, 10, 5, 10, 31, 3, tzinfo=IST)
    signals = rt.evaluate_once(now)
    assert len(signals) == 1
    signal = signals[0]
    assert signal.classification == "DOUBLE_CONFIRMATION"
    assert signal.lots == 3
    assert signal.quantity == 195
    assert len(rt.tracker.positions) == 1


def test_runtime_second_signal_while_open_becomes_shadow(tmp_path):
    cfg, raw = load_option_signal_config(Path("."))
    market = FakeMarketData()
    rt = OptionSignalRuntime(base_dir=tmp_path, market_data=market, config=cfg, raw_config=raw, notifier=TelegramNotifier(dry_run=True))
    first_now = datetime(2026, 10, 5, 10, 31, 3, tzinfo=IST)
    assert rt.evaluate_once(first_now)[0].executable is True
    # Make a new closed bar after cooldown; position is still open.
    last = market._bars[-1]
    market._bars.append(MinuteBar(last.timestamp + timedelta(minutes=8), last.close, last.close + 20, last.close - 1, last.close + 18))
    second = rt.evaluate_once(first_now + timedelta(minutes=8))
    if second:
        assert second[0].executable is False
        assert second[0].classification == "SHADOW"


def test_runtime_rejects_stale_latest_spot_bar(tmp_path):
    cfg, raw = load_option_signal_config(Path("."))
    market = FakeMarketData()
    rt = OptionSignalRuntime(
        base_dir=tmp_path,
        market_data=market,
        config=cfg,
        raw_config=raw,
        notifier=TelegramNotifier(dry_run=True),
    )
    assert rt.evaluate_once(datetime(2026, 10, 5, 10, 32, 3, tzinfo=IST)) == []
    assert rt.tracker.positions == []


def test_runtime_restart_restores_open_position_and_suppresses_same_bar(tmp_path):
    cfg, raw = load_option_signal_config(Path("."))
    market = FakeMarketData()
    now = datetime(2026, 10, 5, 10, 31, 3, tzinfo=IST)
    first = OptionSignalRuntime(
        base_dir=tmp_path,
        market_data=market,
        config=cfg,
        raw_config=raw,
        notifier=TelegramNotifier(dry_run=True),
    )
    signal = first.evaluate_once(now)[0]

    restarted = OptionSignalRuntime(
        base_dir=tmp_path,
        market_data=market,
        config=cfg,
        raw_config=raw,
        notifier=TelegramNotifier(dry_run=True),
    )
    assert [position.signal.signal_id for position in restarted.tracker.positions] == [signal.signal_id]
    assert restarted.evaluate_once(now) == []


def test_exit_deadline_still_warns_when_quote_fails(tmp_path, capsys):
    cfg, raw = load_option_signal_config(Path("."))
    market = FakeMarketData()
    now = datetime(2026, 10, 5, 10, 31, 3, tzinfo=IST)
    rt = OptionSignalRuntime(
        base_dir=tmp_path,
        market_data=market,
        config=cfg,
        raw_config=raw,
        notifier=TelegramNotifier(dry_run=True),
    )
    rt.evaluate_once(now)

    def fail_quote(_contract):
        raise RuntimeError("sensitive upstream detail")

    market.buy_reference = fail_quote
    assert rt.monitor_positions_once(now + timedelta(minutes=31)) == []
    assert rt.monitor_positions_once(now + timedelta(minutes=32)) == []
    output = capsys.readouterr().out
    assert output.count("exit deadline reached but quote is unavailable") == 1
    assert "sensitive upstream detail" not in output
    assert rt.tracker.positions[0].is_open is True
