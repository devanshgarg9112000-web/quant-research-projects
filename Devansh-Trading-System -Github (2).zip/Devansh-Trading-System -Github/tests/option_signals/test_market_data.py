from datetime import datetime, timedelta

from src.option_signals.market_data import KiteReadOnlyOptionData, _best_depth_price, _number
from src.option_signals.time_utils import IST


class FakeBroker:
    def __init__(self, rows):
        self.rows = rows
        self.instrument_calls = 0

    def get_historical_data(self, *_args, **_kwargs):
        return self.rows

    def get_instruments(self, _exchange):
        self.instrument_calls += 1
        return self.rows


def candle(timestamp, open_=100, high=102, low=99, close=101):
    return {
        "date": timestamp,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": 1,
        "oi": 1,
    }


def test_historical_adapter_rejects_previous_day_and_invalid_ohlc():
    now = datetime(2026, 10, 5, 10, 31, 20, tzinfo=IST)
    rows = [
        candle(now - timedelta(days=1)),
        candle(now.replace(minute=29, second=0), high=98, low=99),
        candle(now.replace(minute=30, second=0)),
        candle(now.replace(second=0)),
    ]
    data = KiteReadOnlyOptionData(FakeBroker(rows))
    bars = data._historical_bars(1, now=now, history_minutes=10, oi=False)
    assert [bar.timestamp.minute for bar in bars] == [30]


def test_depth_reference_uses_best_positive_visible_level():
    payload = {
        "depth": {
            "buy": [
                {"price": 99, "quantity": 0},
                {"price": 100, "quantity": 10},
                {"price": 101, "quantity": 5},
            ],
            "sell": [
                {"price": 103, "quantity": 10},
                {"price": 102, "quantity": 5},
            ],
        }
    }
    assert _best_depth_price(payload, "buy") == 101
    assert _best_depth_price(payload, "sell") == 102
    assert _number(float("nan")) is None


def test_instrument_cache_refreshes_when_cached_date_is_stale():
    broker = FakeBroker([{"tradingsymbol": "CURRENT"}])
    data = KiteReadOnlyOptionData(broker)
    data._instruments["NIFTY"] = [{"tradingsymbol": "STALE"}]
    data._instrument_dates["NIFTY"] = datetime(2000, 1, 1).date()
    assert data.instrument_master("NIFTY") == [{"tradingsymbol": "CURRENT"}]
    assert broker.instrument_calls == 1
