from pathlib import Path

import pytest

from src.option_signals.config import OptionSignalConfig, load_option_signal_config
from src.option_signals.telegram_notifier import TelegramNotifier


def test_repository_option_config_is_signal_only():
    cfg, _ = load_option_signal_config(Path("."))
    assert cfg.signal_only is True
    assert cfg.manual_execution_only is True
    assert cfg.lots == 3
    assert cfg.max_open_positions_per_underlying == 1
    assert cfg.double_confirmation_additional_lots == 0


def test_config_rejects_live_execution_semantics():
    with pytest.raises(ValueError):
        OptionSignalConfig.from_mapping({
            "system": {"signal_only": False, "manual_execution_only": True},
            "risk": {"lots_per_signal": 3, "max_open_positions_per_underlying": 1, "double_confirmation_additional_lots": 0},
            "exits": {"stop_percent": .5, "target_percent": .25, "max_hold_minutes": 30},
        })


def test_telegram_dry_run_never_needs_credentials(capsys):
    notifier = TelegramNotifier(enabled=True, dry_run=True)
    assert notifier.send_text("x", "hello") is False
    assert notifier.send_text("x", "hello") is True
    assert capsys.readouterr().out.count("hello") == 1


def test_cli_send_cannot_bypass_disabled_telegram_config(monkeypatch, capsys):
    from src.option_signals.cli import main

    monkeypatch.setenv("TELEGRAM_ALERTS_ENABLED", "true")
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "test-only-token")
    monkeypatch.setenv("TELEGRAM_CHAT_ID", "test-only-chat")
    assert main(["telegram-test", "--send"]) == 1
    assert "FAILED_OR_SKIPPED" in capsys.readouterr().out


def test_option_signal_package_contains_no_place_order_call():
    root = Path("src/option_signals")
    offenders = []
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        if ".place_order(" in text or "place_order(" in text:
            offenders.append(str(path))
    assert offenders == []


def test_frozen_strategy_config_rejects_parameter_drift(tmp_path):
    import yaml

    original = yaml.safe_load(Path("config/option_signals.yaml").read_text(encoding="utf-8"))
    original["strategies"]["cas_router"]["nifty_threshold_bps"] = 7.0
    (tmp_path / "config").mkdir()
    (tmp_path / "config" / "option_signals.yaml").write_text(yaml.safe_dump(original), encoding="utf-8")
    with pytest.raises(ValueError, match="parameter drift"):
        load_option_signal_config(tmp_path)


@pytest.mark.parametrize(
    ("section", "key", "value"),
    [
        ("risk", "lots_per_signal", 4),
        ("risk", "max_signals_per_day", 1),
        ("exits", "stop_percent", 0.40),
        ("exits", "target_percent", 0.30),
        ("exits", "max_hold_minutes", 45),
    ],
)
def test_frozen_common_rules_reject_parameter_drift(tmp_path, section, key, value):
    import yaml

    original = yaml.safe_load(Path("config/option_signals.yaml").read_text(encoding="utf-8"))
    original[section][key] = value
    (tmp_path / "config").mkdir()
    (tmp_path / "config" / "option_signals.yaml").write_text(yaml.safe_dump(original), encoding="utf-8")
    with pytest.raises(ValueError, match="Frozen common"):
        load_option_signal_config(tmp_path)


def test_cli_exposes_read_only_live_check():
    from src.option_signals.cli import build_parser

    args = build_parser().parse_args(["live-check", "--underlying", "NIFTY"])
    assert args.command == "live-check"
    assert args.underlying == "NIFTY"


def test_preflight_does_not_create_authenticated_client(monkeypatch):
    from src.brokers.kite_broker import KiteBroker
    from src.option_signals.cli import main

    monkeypatch.setattr(KiteBroker, "_missing_read_credentials", lambda _self: [])

    def forbidden(_self):
        raise AssertionError("preflight attempted an authenticated/network client")

    monkeypatch.setattr(KiteBroker, "_authenticated_client", forbidden)
    assert main(["preflight"]) == 0
