from datetime import date

import pytest

from src.option_signals.contract_resolver import resolve_immediate_weekly_atm_pair


def row(exchange, name, expiry, strike, typ, token, lot):
    return {
        "exchange": exchange,
        "name": name,
        "expiry": expiry,
        "strike": strike,
        "instrument_type": typ,
        "instrument_token": token,
        "tradingsymbol": f"{name}{expiry.replace('-', '')}{int(strike)}{typ}",
        "lot_size": lot,
        "tick_size": 0.05,
    }


def test_nifty_resolver_uses_actual_nearest_expiry_and_common_atm():
    instruments = []
    for expiry in ["2026-10-06", "2026-10-13"]:
        for strike in [24950, 25000, 25050]:
            instruments += [
                row("NFO", "NIFTY", expiry, strike, "CE", len(instruments) + 1, 65),
                row("NFO", "NIFTY", expiry, strike, "PE", len(instruments) + 2, 65),
            ]
    ce, pe = resolve_immediate_weekly_atm_pair(instruments, underlying="NIFTY", as_of=date(2026, 10, 5), spot=25026)
    assert ce.expiry.isoformat() == "2026-10-06"
    assert pe.expiry == ce.expiry
    assert ce.strike == pe.strike == 25050
    assert ce.exchange == pe.exchange == "NFO"


def test_sensex_resolver_uses_bfo():
    instruments = [
        row("BFO", "SENSEX", "2026-10-08", 80000, "CE", 1, 20),
        row("BFO", "SENSEX", "2026-10-08", 80000, "PE", 2, 20),
    ]
    ce, pe = resolve_immediate_weekly_atm_pair(instruments, underlying="SENSEX", as_of=date(2026, 10, 7), spot=80020)
    assert ce.exchange == "BFO"
    assert pe.lot_size == 20


def test_resolver_rejects_inconsistent_pair_lot_sizes():
    instruments = [
        row("NFO", "NIFTY", "2026-10-06", 25000, "CE", 1, 65),
        row("NFO", "NIFTY", "2026-10-06", 25000, "PE", 2, 75),
    ]
    with pytest.raises(ValueError, match="inconsistent lot sizes"):
        resolve_immediate_weekly_atm_pair(
            instruments, underlying="NIFTY", as_of=date(2026, 10, 5), spot=25000
        )
