from datetime import date, datetime, timedelta

from src.option_signals.models import OptionContract, StrategyIntent
from src.option_signals.position_tracker import ReferencePositionTracker
from src.option_signals.signal_manager import build_entry_signal, classify_intents
from src.option_signals.time_utils import IST


def contract():
    return OptionContract("NIFTY", "NFO", "NIFTYTEST25000PE", 123, date(2026, 10, 6), 25000, "PE", 65)


def intents(ts):
    return [
        StrategyIntent("CAS_ROUTER_V1", "NIFTY", ts, "PE", 25010, "cas"),
        StrategyIntent("NIFTY_EFFICIENCY_TREND_V1", "NIFTY", ts, "PE", 25010, "eff"),
    ]


def test_double_confirmation_is_one_three_lot_signal():
    ts = datetime(2026, 10, 5, 10, 30, tzinfo=IST)
    cls, items = classify_intents(intents(ts))
    assert cls == "DOUBLE_CONFIRMATION"
    sig = build_entry_signal(items, contract=contract(), entry_time=ts + timedelta(minutes=1), entry_reference=100, lots=3, stop_percent=.5, target_percent=.25, max_hold_minutes=30)
    assert sig.classification == "DOUBLE_CONFIRMATION"
    assert sig.lots == 3
    assert sig.quantity == 195
    assert sig.stop_price == 150
    assert sig.target_price == 75


def test_conflicting_intents_do_not_combine():
    ts = datetime(2026, 10, 5, 10, 30, tzinfo=IST)
    a = StrategyIntent("A", "NIFTY", ts, "PE", 1, "a")
    b = StrategyIntent("B", "NIFTY", ts, "CE", 1, "b")
    assert classify_intents([a, b])[0] == "CONFLICT"


def test_reference_tracker_target_and_forced_exit():
    ts = datetime(2026, 10, 5, 10, 30, tzinfo=IST)
    sig = build_entry_signal(intents(ts), contract=contract(), entry_time=ts + timedelta(minutes=1), entry_reference=100, lots=3, stop_percent=.5, target_percent=.25, max_hold_minutes=30)
    tracker = ReferencePositionTracker()
    pos = tracker.open_from_signal(sig)
    alert = tracker.update(pos, timestamp=ts + timedelta(minutes=10), ltp=74)
    assert alert is not None and alert.reason == "TARGET"
    assert alert.reference_pnl_rupees == (100 - 74) * 195


def test_reference_tracker_1515_overrides_price():
    ts = datetime(2026, 10, 5, 14, 59, tzinfo=IST)
    sig = build_entry_signal(intents(ts), contract=contract(), entry_time=ts, entry_reference=100, lots=3, stop_percent=.5, target_percent=.25, max_hold_minutes=30)
    tracker = ReferencePositionTracker()
    pos = tracker.open_from_signal(sig)
    alert = tracker.update(pos, timestamp=datetime(2026, 10, 5, 15, 15, tzinfo=IST), ltp=100)
    assert alert is not None and alert.reason == "FORCED_1515"
