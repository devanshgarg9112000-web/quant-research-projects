from datetime import datetime, timedelta

from src.option_signals.features import efficiency_ratio, failed_breakout_direction, option_combined_return_3m
from src.option_signals.models import MinuteBar
from src.option_signals.strategies import CasRouterStrategy, EfficiencyTrendStrategy
from src.option_signals.time_utils import IST


def bars_from_closes(start, closes):
    return [MinuteBar(start + timedelta(minutes=i), c, c + 1, c - 1, c) for i, c in enumerate(closes)]


def test_efficiency_trend_positive_sells_pe():
    start = datetime(2026, 10, 5, 9, 44, tzinfo=IST)  # Monday; last bar at 10:04
    closes = [25000 + i * 3 for i in range(21)]
    bars = bars_from_closes(start, closes)
    signal = EfficiencyTrendStrategy().evaluate("NIFTY", bars)
    assert signal is not None
    assert signal.option_type == "PE"
    assert signal.metrics["efficiency_ratio"] >= 0.70
    assert signal.metrics["return_bps"] >= 10


def test_efficiency_trend_rejects_chop():
    start = datetime(2026, 10, 5, 9, 44, tzinfo=IST)
    closes = [25000 + (10 if i % 2 else 0) for i in range(21)]
    bars = bars_from_closes(start, closes)
    assert efficiency_ratio(bars, 15) < 0.70
    assert EfficiencyTrendStrategy().evaluate("NIFTY", bars) is None


def test_cas_nifty_positive_momentum_sells_pe():
    start = datetime(2026, 10, 5, 9, 25, tzinfo=IST)
    closes = [25000, 25001, 25002, 25003, 25004, 25020]
    signal = CasRouterStrategy().evaluate("NIFTY", bars_from_closes(start, closes))
    assert signal is not None
    assert signal.option_type == "PE"


def test_sensex_failed_up_break_sells_ce():
    start = datetime(2026, 10, 7, 9, 20, tzinfo=IST)  # Wednesday
    bars = []
    for i in range(25):
        bars.append(MinuteBar(start + timedelta(minutes=i), 80000, 80010, 79990, 80000))
    # Break above prior high, close below prior high.
    bars.append(MinuteBar(start + timedelta(minutes=25), 80005, 80025, 79995, 80005))
    assert failed_breakout_direction(bars, 25) == "CE"
    signal = CasRouterStrategy().evaluate("SENSEX", bars)
    assert signal is not None
    assert signal.option_type == "CE"


def test_sensex_midday_is_excluded():
    start = datetime(2026, 10, 7, 12, 35, tzinfo=IST)
    bars = [MinuteBar(start + timedelta(minutes=i), 80000, 80010, 79990, 80000) for i in range(25)]
    bars.append(MinuteBar(start + timedelta(minutes=25), 80005, 80025, 79995, 80005))
    assert CasRouterStrategy().evaluate("SENSEX", bars) is None


def test_time_based_features_reject_missing_minutes():
    start = datetime(2026, 10, 5, 9, 30, tzinfo=IST)
    bars = bars_from_closes(start, [25000, 25005, 25010, 25015, 25020, 25030])
    bars[-1] = MinuteBar(start + timedelta(minutes=7), 25030, 25031, 25029, 25030)
    assert efficiency_ratio(bars, 5) is None


def test_option_complex_requires_aligned_contiguous_minutes():
    start = datetime(2026, 10, 5, 10, 0, tzinfo=IST)
    ce = bars_from_closes(start, [100, 101, 102, 103])
    pe = bars_from_closes(start, [100, 99, 98, 97])
    pe[-1] = MinuteBar(start + timedelta(minutes=4), 97, 98, 96, 97)
    assert option_combined_return_3m(ce, pe) is None
