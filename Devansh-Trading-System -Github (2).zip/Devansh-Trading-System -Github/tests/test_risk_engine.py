from dataclasses import replace

from src.config_loader import load_configs
from src.data.sample_data import generate_sample_candles
from src.models.signal import Signal
from src.risk.daily_limits import DailyLimitState
from src.risk.risk_engine import RiskEngine
from src.risk.position_sizing import calculate_position_size


def _signal():
    c = generate_sample_candles()[3]
    return Signal(c["symbol"], c["timestamp"], "Test", "BUY", 100.0, 90.0, 120.0, 2.0, 8.0, "test", "RANGE")


def test_risk_engine_rejections_and_quantity():
    configs = load_configs(".")
    engine = RiskEngine(configs["risk"], configs["settings"])
    decision = engine.validate_signal(_signal(), mode="PAPER")
    assert decision.approved
    assert decision.quantity == 50

    bad_stop = replace(_signal(), stop_loss=110.0)
    assert not engine.validate_signal(bad_stop, mode="PAPER").approved

    bad_rr = replace(_signal(), target_price=105.0, reward_risk=0.5)
    assert not engine.validate_signal(bad_rr, mode="PAPER").approved

    limited = RiskEngine(configs["risk"], configs["settings"], DailyLimitState(trades_today=3))
    assert not limited.validate_signal(_signal(), mode="PAPER").approved

    assert not engine.validate_signal(_signal(), mode="LIVE").approved


def _mcx_signal(symbol: str, entry: float, stop: float) -> Signal:
    c = generate_sample_candles()[3]
    side = "BUY" if stop < entry else "SELL"
    target = entry + 2 * abs(entry - stop) if side == "BUY" else entry - 2 * abs(entry - stop)
    return Signal(symbol, c["timestamp"], "MCX Test", side, entry, stop, target, 2.0, 8.8, "test", "RANGE")


def test_gold_instrument_metadata_creates_positive_quantity():
    configs = load_configs(".")
    decision = RiskEngine(
        configs["risk"],
        configs["settings"],
        instruments=configs["instruments"],
    ).validate_signal(_mcx_signal("GOLD-I", 150238, 150599), mode="PAPER")

    assert decision.approved
    assert decision.quantity >= 1
    assert decision.sizing["point_value"] == 1
    assert decision.sizing["lot_size"] == 1


def test_silver_creates_positive_quantity_when_risk_budget_is_enough():
    configs = load_configs(".")
    risk = {**configs["risk"], "risk_per_trade_percent": 2.0}
    decision = RiskEngine(
        risk,
        configs["settings"],
        instruments=configs["instruments"],
    ).validate_signal(_mcx_signal("SILVER-I", 242150, 243145), mode="PAPER")

    assert decision.approved
    assert decision.quantity >= 1
    assert decision.sizing["estimated_risk_amount"] <= decision.sizing["allowed_risk_amount"]


def test_minimum_mcx_quantity_risk_rejects_with_detailed_reason():
    configs = load_configs(".")
    decision = RiskEngine(
        configs["risk"],
        configs["settings"],
        instruments=configs["instruments"],
    ).validate_signal(_mcx_signal("SILVER-I", 242150, 243145), mode="PAPER")

    assert not decision.approved
    assert decision.quantity == 0
    assert decision.sizing["calculated_qty"] == 0
    assert decision.sizing["risk_per_unit"] == 995
    assert decision.sizing["allowed_risk_amount"] == 500
    assert any("risk amount too small for minimum MCX quantity" in reason for reason in decision.reasons)
    assert any("above allowed risk" in reason for reason in decision.reasons)


def test_position_sizing_rounds_down_to_lot_size():
    result = calculate_position_size(
        capital=10000,
        risk_percent=1,
        entry=100,
        stop=86,
        instrument={"exchange": "MCX", "point_value": 1, "min_qty": 5, "lot_size": 5},
    )

    assert result.raw_quantity == 7
    assert result.quantity == 5
    assert result.estimated_risk_amount == 70


def test_zero_quantity_always_has_a_rejection_reason():
    result = calculate_position_size(
        capital=1000,
        risk_percent=1,
        entry=100,
        stop=120,
        instrument={"exchange": "MCX", "point_value": 1, "min_qty": 1, "lot_size": 1},
    )

    assert result.quantity == 0
    assert result.rejection_reason
