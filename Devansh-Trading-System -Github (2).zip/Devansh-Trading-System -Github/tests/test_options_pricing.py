from __future__ import annotations

from datetime import date, datetime

from src.options.black_scholes import black_scholes_price
from src.options.greeks import calculate_greeks
from src.options.implied_volatility import implied_volatility
from src.options.option_chain import filter_nifty_option_symbols, infer_option_type, infer_strike, normalize_expiry, select_strikes_around_atm
from src.strategies.opening_option_mispricing import calculate_time_to_expiry_years


def test_black_scholes_returns_positive_price_for_valid_call():
    price = black_scholes_price(spot=100, strike=100, time_to_expiry_years=30 / 365, risk_free_rate=0.06, volatility=0.20, option_type="CALL")

    assert price > 0


def test_black_scholes_returns_positive_price_for_valid_put():
    price = black_scholes_price(spot=100, strike=100, time_to_expiry_years=30 / 365, risk_free_rate=0.06, volatility=0.20, option_type="PE")

    assert price > 0


def test_black_scholes_invalid_inputs_return_zero():
    assert black_scholes_price(0, 100, 30 / 365, 0.06, 0.20, "CALL") == 0.0
    assert black_scholes_price(100, 100, 0, 0.06, 0.20, "CALL") == 0.0
    assert black_scholes_price(100, 100, 30 / 365, 0.06, 0, "CALL") == 0.0


def test_implied_volatility_returns_positive_value_for_valid_price():
    market_price = black_scholes_price(100, 100, 30 / 365, 0.06, 0.20, "CALL")

    iv = implied_volatility(market_price, 100, 100, 30 / 365, 0.06, "CALL")

    assert iv is not None
    assert 0.15 <= iv <= 0.25


def test_implied_volatility_returns_none_for_invalid_input():
    assert implied_volatility(0, 100, 100, 30 / 365, 0.06, "CALL") is None
    assert implied_volatility(10, 0, 100, 30 / 365, 0.06, "CALL") is None


def test_greeks_returns_required_keys():
    greeks = calculate_greeks(spot=100, strike=100, time_to_expiry_years=30 / 365, risk_free_rate=0.06, volatility=0.20, option_type="PUT")

    assert set(greeks) == {"delta", "gamma", "theta", "vega"}


def test_option_chain_helpers_infer_type_strike_and_atm_strikes():
    assert infer_option_type("NIFTY25JUN23500CE") == "CALL"
    assert infer_option_type("NIFTY25JUN23500PE") == "PUT"
    assert infer_strike("NIFTY25JUN23500CE") == 23500.0
    assert select_strikes_around_atm([23400, 23450, 23500, 23550, 23600], 23510, 1) == [23450.0, 23500.0, 23550.0]


def test_expiry_normalization_accepts_date_datetime_and_string():
    assert normalize_expiry(date(2026, 6, 25)) == "2026-06-25"
    assert normalize_expiry(datetime(2026, 6, 25, 9, 15)) == "2026-06-25"
    assert normalize_expiry("2026-06-25 00:00:00") == "2026-06-25"


def test_time_to_expiry_positive_for_future_and_same_day_expiry():
    future_t = calculate_time_to_expiry_years("2026-06-25", now=datetime(2026, 6, 18, 10, 0))
    same_day_t = calculate_time_to_expiry_years("2026-06-18", now=datetime(2026, 6, 18, 10, 0))

    assert future_t > 0
    assert same_day_t > 0


def test_nifty_filter_excludes_other_indices_and_accepts_kite_nifty_dicts():
    instruments = [
        {"name": "NIFTY", "tradingsymbol": "NIFTY26JUN23500CE", "expiry": date(2026, 6, 25), "strike": 23500, "instrument_type": "CE"},
        {"name": "BANKNIFTY", "tradingsymbol": "BANKNIFTY26JUN50000CE", "expiry": date(2026, 6, 25), "strike": 50000, "instrument_type": "CE"},
        {"name": "FINNIFTY", "tradingsymbol": "FINNIFTY26JUN23500CE", "expiry": date(2026, 6, 25), "strike": 23500, "instrument_type": "CE"},
        {"name": "MIDCPNIFTY", "tradingsymbol": "MIDCPNIFTY26JUN12000PE", "expiry": date(2026, 6, 25), "strike": 12000, "instrument_type": "PE"},
    ]

    selected = filter_nifty_option_symbols(instruments, expiry="2026-06-25", spot=23500, strikes_around_atm=1)

    assert selected == [instruments[0]]


def test_nifty_filter_uses_kite_numeric_strike_for_atm_selection():
    instruments = [
        {"name": "NIFTY", "tradingsymbol": "NIFTYABCLOWCE", "expiry": date(2026, 6, 25), "strike": 23400, "instrument_type": "CE"},
        {"name": "NIFTY", "tradingsymbol": "NIFTYABCATMCE", "expiry": date(2026, 6, 25), "strike": 23500, "instrument_type": "CE"},
        {"name": "NIFTY", "tradingsymbol": "NIFTYABCHIGHCE", "expiry": date(2026, 6, 25), "strike": 23600, "instrument_type": "CE"},
    ]

    selected = filter_nifty_option_symbols(instruments, expiry=date(2026, 6, 25), spot=23510, strikes_around_atm=0)

    assert selected == [instruments[1]]
