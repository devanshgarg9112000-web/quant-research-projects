﻿from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone

from src.alerts.whatsapp_alerts import WhatsAppAlertProvider
from src.config_loader import load_configs
from src.monitors.live_signal_monitor import LiveSignalMonitor
from src.research.forward_validation import (
    FORWARD_STRATEGY,
    analyze_independent_evidence,
    append_ledger_rows,
    assess_forward_approval,
    combine_metrics,
    ledger_path,
    load_ledger,
    make_signal_id,
    record_watchlist_signal_from_row,
    resolve_kite_tick_pending_row,
    resolve_pending_row,
    run_replay_forward_validation,
    summarize_forward_validation,
    update_pending_outcomes,
    _metrics_from_pnls,
)
from src.scoring.strategy_verification import StrategyGateDecision


class WatchlistGate:
    def evaluate(self, row):
        return StrategyGateDecision(
            False,
            "WATCHLIST",
            "research-only watchlist; production alerts blocked",
            "research_lab__gold_i__vrs",
        )


def _pending_row(
    *,
    signal_time: datetime | None = None,
    entry: float = 1000.0,
    stop: float = 1010.0,
    target: float = 980.0,
) -> dict:
    signal_time = signal_time or datetime(2026, 6, 19, 9, 0)
    return {
        "signal_id": make_signal_id("GOLD-I", FORWARD_STRATEGY, signal_time, "SELL", entry, stop, target),
        "date": signal_time.date().isoformat(),
        "symbol": "GOLD-I",
        "strategy": FORWARD_STRATEGY,
        "signal_time": signal_time.isoformat(),
        "side": "SELL",
        "entry": entry,
        "stop": stop,
        "target": target,
        "risk_per_unit": abs(stop - entry),
        "reward_per_unit": abs(entry - target),
        "expected_R": 2.0,
        "vwap_distance": 12.0,
        "atr": 5.0,
        "volume_multiplier": 1.4,
        "market_regime": "TREND_DOWN",
        "signal_score": 7.7,
        "approval_status_at_signal": "WATCHLIST",
        "execution_allowed": "false",
        "alert_mode": "TEST",
        "status": "PENDING",
        "notes": "test pending row",
    }



def _kite_post_lock_row(
    *,
    signal_time: datetime | None = None,
    entry_time: datetime | None = None,
    entry: float = 1000.0,
    stop: float = 1010.0,
    target: float = 980.0,
) -> dict:
    signal_time = signal_time or datetime(2026, 6, 23, 9, 0)
    entry_time = entry_time or signal_time + timedelta(minutes=1)
    row = _pending_row(signal_time=signal_time, entry=entry, stop=stop, target=target)
    row.update(
        {
            "ledger_schema_version": "2_post_lock",
            "lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
            "post_lock": "true",
            "session_id": "GOLD-I_2026-06-23_KITE",
            "provider": "KITE",
            "canonical_family": "gold_vwap_rejection_reclaim_family",
            "canonical_setup": "gold_vwap_rejection_short",
            "entry_time": entry_time.isoformat(),
            "stop_loss": stop,
            "data_role": "FORWARD_VALIDATION",
            "used_for_parameter_tuning": "false",
            "approval_status_at_signal": "RESEARCH_ONLY",
            "alert_mode": "blocked",
            "result": "PENDING",
        }
    )
    return row


def _write_kite_ticks(base, rows: list[tuple[datetime, float]]) -> None:
    path = base / "data" / "kite_recorded" / "ticks" / "2026-06-23" / "GOLD-I_ticks.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["timestamp", "symbol", "ltp", "source"])
        writer.writeheader()
        for timestamp, price in rows:
            writer.writerow({"timestamp": timestamp.isoformat(), "symbol": "GOLD-I", "ltp": price, "source": "KITE"})

def _bar(timestamp: datetime, high: float, low: float, close: float) -> dict:
    return {
        "timestamp": timestamp,
        "symbol": "GOLD-I",
        "open": close,
        "high": high,
        "low": low,
        "close": close,
        "volume": 100,
        "oi": None,
        "source": "TEST",
        "interval": "1minute",
    }


def _write_replay_bars(base):
    source = base / "data" / "historical" / "truedata" / "bars" / "2026-06-04"
    source.mkdir(parents=True)
    path = source / "GOLD-I_1minute_bars.csv"
    start = datetime(2026, 6, 4, 9, 0)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "timestamp",
                "symbol",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "oi",
                "source",
                "interval",
            ],
        )
        writer.writeheader()
        for index in range(30):
            if index < 21:
                close = 100 - index * 0.2
                row = {
                    "open": close + 0.05,
                    "high": close + 0.15,
                    "low": close - 0.10,
                    "close": close,
                    "volume": 100,
                }
            elif index == 21:
                row = {"open": 96, "high": 100, "low": 94.8, "close": 95, "volume": 200}
            else:
                row = {"open": 94, "high": 95, "low": 90, "close": 91, "volume": 120}
            writer.writerow({
                "timestamp": (start + timedelta(minutes=index)).isoformat(),
                "symbol": "GOLD-I",
                **row,
                "oi": "",
                "source": "TEST",
                "interval": "1minute",
            })
    return source.parent


def test_forward_ledger_creation_and_duplicate_prevention(tmp_path):
    row = _pending_row()

    assert append_ledger_rows(tmp_path, [row]) == 1
    assert append_ledger_rows(tmp_path, [row]) == 0

    rows = load_ledger(tmp_path)
    assert ledger_path(tmp_path).exists()
    assert len(rows) == 1
    assert rows[0]["execution_allowed"] == "false"



def test_legacy_ledger_rows_are_normalized_as_pre_lock(tmp_path):
    path = ledger_path(tmp_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["signal_id", "date", "symbol", "strategy", "signal_time", "side", "entry", "stop", "target", "status", "execution_allowed"])
        writer.writeheader()
        writer.writerow({
            "signal_id": "legacy-1",
            "date": "2026-06-19",
            "symbol": "GOLD-I",
            "strategy": FORWARD_STRATEGY,
            "signal_time": "2026-06-19T09:00:00",
            "side": "SELL",
            "entry": "1000",
            "stop": "1010",
            "target": "980",
            "status": "WIN",
            "execution_allowed": "false",
        })

    rows = load_ledger(tmp_path)
    evidence = analyze_independent_evidence(tmp_path, rows)

    assert rows[0]["ledger_schema_version"] == "1_legacy"
    assert rows[0]["lock_version"] == "PRE_LOCK_LEGACY"
    assert rows[0]["post_lock"] == "false"
    assert rows[0]["canonical_family"] == "gold_vwap_rejection_reclaim_family"
    assert rows[0]["canonical_setup"] == "gold_vwap_rejection_short"
    assert rows[0]["data_role"] == "REPLAY_RESEARCH"
    assert evidence.legacy_pre_lock_rows == 1
    assert evidence.completed_independent_post_lock_trades == 0


def test_independent_evidence_counts_only_post_lock_real_forward_rows(tmp_path):
    forward_config = tmp_path / "config" / "forward_validation.yaml"
    forward_config.parent.mkdir(parents=True, exist_ok=True)
    forward_config.write_text(
        "active_lock_version: gold_vwap_v1_20260622\n"
        "active_lock_timestamp: 2026-06-22T00:00:00+05:30\n"
        "recognized_real_providers: [KITE, TRUEDATA]\n",
        encoding="utf-8",
    )
    (tmp_path / "config" / "strategy_identity.yaml").write_text(
        "minimum_forward_trades: 30\nminimum_distinct_sessions: 5\n",
        encoding="utf-8",
    )
    signal_time = datetime(2026, 6, 23, 9, 0)
    row = _pending_row(signal_time=signal_time)
    row.update({
        "provider": "KITE",
        "data_role": "FORWARD_VALIDATION",
        "status": "WIN",
        "result": "WIN",
        "net_pnl_after_costs": "100",
        "used_for_parameter_tuning": "false",
    })

    assert append_ledger_rows(tmp_path, [row]) == 1
    evidence = analyze_independent_evidence(tmp_path, load_ledger(tmp_path))

    assert evidence.completed_independent_post_lock_trades == 1
    assert evidence.distinct_post_lock_sessions == 1
    assert evidence.required_forward_trades == 30
    assert evidence.required_forward_sessions == 5
    assert evidence.independent_provider_breakdown == "KITE=1"


def test_pending_post_lock_summary_count_is_consistent_and_not_completed(tmp_path):
    forward_config = tmp_path / "config" / "forward_validation.yaml"
    forward_config.parent.mkdir(parents=True, exist_ok=True)
    forward_config.write_text(
        "active_lock_version: gold_vwap_v1_20260622\n"
        "active_lock_timestamp: 2026-06-22T00:00:00+05:30\n"
        "recognized_real_providers: [KITE, TRUEDATA]\n",
        encoding="utf-8",
    )
    (tmp_path / "config" / "strategy_identity.yaml").write_text(
        "minimum_forward_trades: 30\nminimum_distinct_sessions: 5\n",
        encoding="utf-8",
    )
    signal_time = datetime(2026, 6, 23, 9, 0)
    row = _pending_row(signal_time=signal_time)
    row.update({
        "provider": "KITE",
        "data_role": "FORWARD_VALIDATION",
        "status": "PENDING",
        "result": "PENDING",
        "used_for_parameter_tuning": "false",
        "approval_status_at_signal": "RESEARCH_ONLY",
    })

    assert append_ledger_rows(tmp_path, [row]) == 1
    result = summarize_forward_validation(tmp_path)
    report_text = result.summary_path.read_text(encoding="utf-8")

    assert result.evidence.pending_post_lock_rows == 1
    assert result.evidence.completed_independent_post_lock_trades == 0
    assert result.forward.trades == 0
    assert result.decision.status == "RESEARCH_ONLY"
    assert "Pending Post-lock Rows: 1" in report_text
    assert "Pending independent post-lock trades: 1" in report_text
    assert "Pending trades: 0" not in report_text
    assert "Completed Independent Post-lock Trades: 0" in report_text
    assert "execution_allowed=false" in report_text


def test_kite_tick_pending_sell_win_uses_entry_time_and_ignores_exact_entry_tick(tmp_path):
    signal_time = datetime(2026, 6, 23, 9, 0)
    entry_time = signal_time + timedelta(minutes=1)
    row = _kite_post_lock_row(signal_time=signal_time, entry_time=entry_time)
    _write_kite_ticks(
        tmp_path,
        [
            (signal_time + timedelta(seconds=30), 970.0),
            (entry_time, 1015.0),
            (entry_time + timedelta(seconds=1), 1000.0),
            (entry_time + timedelta(seconds=2), 979.0),
            (entry_time + timedelta(seconds=3), 1015.0),
        ],
    )

    resolved, reason = resolve_kite_tick_pending_row(tmp_path, row)

    assert reason == "resolved"
    assert resolved["status"] == "WIN"
    assert resolved["result"] == "WIN"
    assert resolved["exit_time"] == "2026-06-23T09:01:02"
    assert resolved["exit_price"] == 980.0
    assert resolved["gross_pnl"] == 20.0
    assert resolved["net_pnl_after_costs"] != ""
    assert resolved["R_multiple"] != ""
    assert resolved["mfe"] == 21.0
    assert resolved["mae"] == 15.0
    assert resolved["execution_allowed"] == "false"


def test_kite_tick_pending_sell_loss_when_stop_tick_precedes_target(tmp_path):
    entry_time = datetime(2026, 6, 23, 9, 1)
    row = _kite_post_lock_row(entry_time=entry_time)
    _write_kite_ticks(
        tmp_path,
        [
            (entry_time + timedelta(seconds=1), 1001.0),
            (entry_time + timedelta(seconds=2), 1011.0),
            (entry_time + timedelta(seconds=3), 979.0),
        ],
    )

    resolved, reason = resolve_kite_tick_pending_row(tmp_path, row)

    assert reason == "resolved"
    assert resolved["status"] == "LOSS"
    assert resolved["exit_time"] == "2026-06-23T09:01:02"
    assert resolved["exit_price"] == 1010.0
    assert resolved["mfe"] == 21.0
    assert resolved["mae"] == 11.0


def test_kite_tick_pending_no_hit_stays_pending(tmp_path):
    entry_time = datetime(2026, 6, 23, 9, 1)
    row = _kite_post_lock_row(entry_time=entry_time)
    _write_kite_ticks(
        tmp_path,
        [
            (entry_time + timedelta(seconds=1), 1001.0),
            (entry_time + timedelta(seconds=2), 999.0),
        ],
    )

    resolved, reason = resolve_kite_tick_pending_row(tmp_path, row)

    assert reason == "still_pending"
    assert resolved["status"] == "PENDING"
    assert resolved["result"] == "PENDING"
    assert resolved["exit_time"] == ""
    assert resolved["mfe"] == 1.0
    assert resolved["mae"] == 1.0


def test_update_pending_outcomes_resolves_kite_row_and_counts_completed_evidence(tmp_path):
    entry_time = datetime(2026, 6, 23, 9, 1)
    row = _kite_post_lock_row(entry_time=entry_time)
    _write_kite_ticks(tmp_path, [(entry_time + timedelta(seconds=1), 979.0)])

    assert append_ledger_rows(tmp_path, [row]) == 1
    result = update_pending_outcomes(tmp_path)
    rows = load_ledger(tmp_path)

    assert result.pending_update.checked == 1
    assert result.pending_update.resolved == 1
    assert rows[0]["status"] == "WIN"
    assert rows[0]["result"] == "WIN"
    assert rows[0]["execution_allowed"] == "false"
    assert result.evidence.completed_independent_post_lock_trades == 1
    assert result.evidence.pending_post_lock_rows == 0

def test_pending_trade_update_target_hit_before_stop():
    signal_time = datetime(2026, 6, 19, 9, 0)
    row = _pending_row(signal_time=signal_time)
    bars = [
        _bar(signal_time, high=1015, low=975, close=990),
        _bar(signal_time + timedelta(minutes=1), high=1002, low=979, close=981),
        _bar(signal_time + timedelta(minutes=2), high=1015, low=990, close=1005),
    ]

    resolved = resolve_pending_row(row, bars)

    assert resolved["status"] == "WIN"
    assert resolved["exit_time"].startswith("2026-06-19T09:01:00")


def test_pending_trade_update_stop_hit_before_target():
    signal_time = datetime(2026, 6, 19, 9, 0)
    row = _pending_row(signal_time=signal_time)
    bars = [
        _bar(signal_time + timedelta(minutes=1), high=1011, low=990, close=1007),
        _bar(signal_time + timedelta(minutes=2), high=1002, low=979, close=981),
    ]

    resolved = resolve_pending_row(row, bars)

    assert resolved["status"] == "LOSS"
    assert resolved["exit_price"] == 1010.0


def test_pending_trade_end_exit_handling():
    signal_time = datetime(2026, 6, 19, 9, 0)
    row = _pending_row(signal_time=signal_time)
    bars = [
        _bar(signal_time + timedelta(minutes=1), high=1005, low=990, close=997),
        _bar(signal_time + timedelta(minutes=2), high=1004, low=991, close=995),
    ]

    resolved = resolve_pending_row(row, bars)

    assert resolved["status"] == "END_EXIT"
    assert resolved["exit_price"] == 995.0


def test_low_forward_trade_count_remains_research_only():
    historical = _metrics_from_pnls([100.0] * 20)
    forward = _metrics_from_pnls([100.0] * 29)

    decision = assess_forward_approval(historical, forward, combine_metrics(historical, forward))

    assert decision.status == "RESEARCH_ONLY"
    assert "Independent post-lock forward trades are 29" in decision.reason


def test_approval_candidate_requires_total_forward_sample_and_sessions():
    forward = _metrics_from_pnls([100.0] * 30)
    enough_historical = _metrics_from_pnls([100.0] * 10)

    low_sessions = assess_forward_approval(
        enough_historical,
        forward,
        combine_metrics(enough_historical, forward),
        distinct_sessions=4,
    )
    candidate = assess_forward_approval(
        enough_historical,
        forward,
        combine_metrics(enough_historical, forward),
        distinct_sessions=5,
    )

    assert low_sessions.status == "RESEARCH_ONLY"
    assert "Independent post-lock sessions are 4" in low_sessions.reason
    assert candidate.status == "APPROVAL_CANDIDATE"
    assert "manual review" in candidate.reason


def test_forward_validation_config_blocks_production_alerts():
    config = load_configs(".")["forward_validation"]

    assert config["enabled"] is True
    assert config["record_watchlist_signals"] is True
    assert config["send_research_whatsapp_preview"] is False
    assert config["production_alerts_allowed"] is False
    assert config["symbols"] == ["GOLD-I"]


def test_research_only_alert_label_if_preview_enabled(tmp_path):
    provider = WhatsAppAlertProvider(tmp_path, config={"research_watchlist_enabled": True})
    row = {
        "symbol": "GOLD-I",
        "strategy": "VWAP Rejection Short",
        "status": "ACCEPTED_PAPER_SIGNAL",
        "strategy_verification_status": "WATCHLIST",
        "strategy_verification_reason": "Forward validation only",
        "execution_allowed": False,
    }

    assert provider.preview_research_watchlist(row) is True
    text = provider.research_watchlist_preview_path.read_text(encoding="utf-8")
    assert text.startswith("RESEARCH ONLY - DO NOT TRADE")
    assert "Algo Trading: DISABLED" in text


def test_replay_forward_validation_generates_ledger_and_summary(tmp_path):
    bar_dir = _write_replay_bars(tmp_path)
    configs = {
        "risk": {"capital": 100000, "risk_per_trade_percent": 0.5},
        "instruments": {"GOLD-I": {"lot_size": 1, "min_qty": 1, "point_value": 1}},
    }

    result = run_replay_forward_validation(
        base_dir=tmp_path,
        strategy=FORWARD_STRATEGY,
        symbol="GOLD-I",
        bar_dir=str(bar_dir),
        from_date="2026-06-04",
        to_date="2026-06-04",
        configs=configs,
    )

    assert result.ledger_path.exists()
    assert result.summary_path.exists()
    assert result.total_ledger_rows == 1
    assert result.decision.status == "RESEARCH_ONLY"
    assert "execution_allowed=false" in result.summary_path.read_text(encoding="utf-8")


def test_monitor_records_watchlist_signal_to_forward_ledger(tmp_path):
    configs = load_configs(".")
    configs["forward_validation"] = {
        "enabled": True,
        "symbols": ["GOLD-I"],
        "record_watchlist_signals": True,
        "send_research_whatsapp_preview": False,
        "production_alerts_allowed": False,
    }
    monitor = LiveSignalMonitor(
        tmp_path,
        configs,
        ["GOLD-I"],
        "replay",
        scan_interval=60,
        window_seconds=300,
        strategy_gate=WatchlistGate(),
    )
    scan_time = datetime(2026, 6, 19, 9, 5, tzinfo=timezone.utc)
    row = {
        "symbol": "GOLD-I",
        "status": "ACCEPTED_PAPER_SIGNAL",
        "signal_time": scan_time.isoformat(),
        "direction": "SELL",
        "strategy": "VWAP Rejection Short",
        "entry": 1000.0,
        "stop": 1010.0,
        "target": 980.0,
        "score": 7.7,
        "market_mode": "TREND_DOWN",
        "key_reason": "watchlist validation signal",
        "execution_allowed": False,
    }

    result = monitor._append_new_candidates([row], scan_time)

    assert result[-1] == 1
    assert row["candidate_strategy_check"] == "GOLD-I VWAP Rejection Short"
    assert row["candidate_status"] == "SETUP_RECORDED"
    assert row["forward_validation_ledger_updated"] == "YES"
    rows = load_ledger(tmp_path)
    assert rows[0]["status"] == "PENDING"
    assert rows[0]["provider"] == "TRUEDATA"
    assert rows[0]["approval_status_at_signal"] == "WATCHLIST"
    assert rows[0]["alert_mode"] == "blocked"
    assert rows[0]["execution_allowed"] == "false"


def test_record_watchlist_signal_refuses_production_alert_override(tmp_path):
    scan_time = datetime(2026, 6, 19, 9, 5)
    row = {
        "symbol": "GOLD-I",
        "status": "ACCEPTED_PAPER_SIGNAL",
        "direction": "SELL",
        "strategy": "VWAP Rejection Short",
        "entry": 1000.0,
        "stop": 1010.0,
        "target": 980.0,
        "execution_allowed": False,
    }

    recorded = record_watchlist_signal_from_row(
        tmp_path,
        row,
        scan_time=scan_time,
        alert_mode="whatsapp-dry-run",
        config={"enabled": True, "production_alerts_allowed": True},
    )

    assert recorded is False
    assert load_ledger(tmp_path) == []



def test_monitor_research_preview_only_when_explicitly_enabled(tmp_path):
    scan_time = datetime(2026, 6, 19, 9, 5, tzinfo=timezone.utc)
    row = {
        "symbol": "GOLD-I",
        "status": "ACCEPTED_PAPER_SIGNAL",
        "signal_time": scan_time.isoformat(),
        "direction": "SELL",
        "strategy": "VWAP Rejection Short",
        "entry": 1000.0,
        "stop": 1010.0,
        "target": 980.0,
        "score": 7.7,
        "market_mode": "TREND_DOWN",
        "key_reason": "watchlist validation signal",
        "execution_allowed": False,
    }

    disabled_configs = load_configs(".")
    disabled_configs["forward_validation"] = {
        "enabled": True,
        "symbols": ["GOLD-I"],
        "record_watchlist_signals": True,
        "send_research_whatsapp_preview": False,
        "production_alerts_allowed": False,
    }
    disabled_configs["alerts"] = {
        "whatsapp": {
            "enabled": False,
            "dry_run": True,
            "manual_execution_only": True,
            "research_watchlist_enabled": True,
        }
    }
    disabled_monitor = LiveSignalMonitor(
        tmp_path / "disabled",
        disabled_configs,
        ["GOLD-I"],
        "replay",
        scan_interval=60,
        window_seconds=300,
        alert_channel="whatsapp-dry-run",
        strategy_gate=WatchlistGate(),
    )

    disabled_monitor._append_new_candidates([dict(row)], scan_time)

    disabled_preview = (
        tmp_path
        / "disabled"
        / "reports"
        / "alerts"
        / "latest_whatsapp_research_watchlist_preview.txt"
    )
    assert not disabled_preview.exists()
    assert not (
        tmp_path / "disabled" / "reports" / "alerts" / "latest_whatsapp_alert_preview.txt"
    ).exists()

    enabled_configs = load_configs(".")
    enabled_configs["forward_validation"] = {
        "enabled": True,
        "symbols": ["GOLD-I"],
        "record_watchlist_signals": True,
        "send_research_whatsapp_preview": True,
        "production_alerts_allowed": False,
    }
    enabled_configs["alerts"] = {
        "whatsapp": {
            "enabled": False,
            "dry_run": True,
            "manual_execution_only": True,
            "research_watchlist_enabled": True,
        }
    }
    enabled_monitor = LiveSignalMonitor(
        tmp_path / "enabled",
        enabled_configs,
        ["GOLD-I"],
        "kite",
        scan_interval=60,
        window_seconds=300,
        alert_channel="whatsapp-dry-run",
        strategy_gate=WatchlistGate(),
    )

    enabled_monitor._append_new_candidates([dict(row)], scan_time)

    preview = (
        tmp_path
        / "enabled"
        / "reports"
        / "alerts"
        / "latest_whatsapp_research_watchlist_preview.txt"
    )
    assert preview.exists()
    preview_text = preview.read_text(encoding="utf-8")
    assert "RESEARCH ONLY - DO NOT TRADE" in preview_text
    assert "execution_allowed=false" in preview_text
    assert not (tmp_path / "enabled" / "reports" / "alerts" / "latest_whatsapp_alert_preview.txt").exists()
    ledger_rows = load_ledger(tmp_path / "enabled")
    assert ledger_rows[0]["provider"] == "KITE"
    assert ledger_rows[0]["alert_mode"] == "research_only"

