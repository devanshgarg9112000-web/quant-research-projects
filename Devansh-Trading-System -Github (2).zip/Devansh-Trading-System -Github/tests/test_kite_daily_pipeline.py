from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

from src.data_collection.kite_daily_pipeline import (
    RUN_LOG_PATH,
    run_kite_daily_pipeline,
)
from src.data_collection.kite_data_quality_gate import (
    FEATURE_GENERATION_PROBLEM,
    MARKET_CLOSED_OR_NO_LIVE_DATA,
    READY_FOR_FORWARD_VALIDATION,
    TOKEN_OR_CREDENTIAL_PROBLEM,
)
from src.data_collection.kite_instrument_resolver import KiteInstrumentMapping
from src.data_collection.kite_live_recorder import KiteRecordingResult
from src.data_collection.kite_orderflow_features import KiteOrderFlowFeatureResult
from src.data_collection.market_data_schema import (
    KITE_DEPTH_COLUMNS,
    KITE_TICK_COLUMNS,
    kite_depth_path,
    kite_tick_path,
)


def _minimal_configs() -> dict:
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "risk": {},
        "strategies": {},
        "approved_strategies": {},
        "instruments": {"GOLD-I": {"exchange": "MCX"}},
        "alerts": {"enable_whatsapp_alerts": False},
        "forward_validation": {
            "production_alerts_allowed": False,
            "send_research_whatsapp_preview": False,
        },
    }


def _fixed_now() -> datetime:
    return datetime(2026, 6, 20, 9, 15)


def test_kite_daily_pipeline_dry_run_completes_without_credentials(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
    )

    assert result.success is True
    assert result.credential_status == "MISSING"
    assert result.recorder_tick_rows == 1
    assert result.recorder_depth_rows == 5
    assert result.feature_rows_generated == result.feature_output_csv_data_rows
    assert result.production_whatsapp_status == "BLOCKED"
    assert result.data_quality.status == FEATURE_GENERATION_PROBLEM
    assert result.report_path.exists()
    report = result.report_path.read_text(encoding="utf-8")
    assert "KITE DAILY PIPELINE REPORT" in report
    assert "dry_run: true" in report
    assert "CONTRACT CONSISTENCY" in report
    assert "status: DRY_RUN_SYNTHETIC_ONLY" in report
    assert "selected_contract:" in report
    assert "expiry=" in report
    assert "action_required: false" in report
    assert "metadata_complete: true" in report
    assert "expiry_missing_warning: no" in report
    assert "DATA QUALITY GATE" in report
    assert "usable_for_forward_validation: false" in report
    assert "execution_allowed=false" in report
    assert "No broker orders were placed." in report


def test_kite_daily_pipeline_real_mode_missing_token_fails_before_recording(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    def recorder_should_not_run(*_args, **_kwargs):
        raise AssertionError("recorder should not run when real mode credentials are missing")

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=False,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
        recorder_func=recorder_should_not_run,
    )

    assert result.success is False
    assert result.recorder_tick_rows == 0
    assert result.recorder_depth_rows == 0
    assert result.step_status["recorder"] == "SKIPPED"
    assert "stopped safely before recording" in result.errors[0]
    assert result.data_quality.status == TOKEN_OR_CREDENTIAL_PROBLEM
    report = result.report_path.read_text(encoding="utf-8")
    assert "credential_status: MISSING" in report
    assert "ERRORS" in report


def test_kite_daily_pipeline_calls_steps_in_order(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)
    calls: list[str] = []

    def fake_resolver(*_args, **_kwargs):
        calls.append("resolver")
        return SimpleNamespace(
            mappings=[
                KiteInstrumentMapping(
                    internal_symbol="GOLD-I",
                    status="RESOLVED",
                    exchange="MCX",
                    tradingsymbol="GOLD26AUGFUT",
                    instrument_token="119445255",
                )
            ],
            source="TEST",
            errors=[],
        )

    def fake_readonly(*_args, **_kwargs):
        calls.append("readonly")
        return SimpleNamespace(quote_status="OK", depth_status="PRESENT", errors=[], report_path=tmp_path / "readonly.txt")

    def fake_recorder(*_args, **_kwargs):
        calls.append("recorder")
        return KiteRecordingResult(
            operation_type="recorder",
            quote_status="OK",
            depth_status="PRESENT",
            market_data_status="RECORDED",
            tick_rows_recorded=2,
            depth_rows_recorded=10,
            files=[tmp_path / "ticks.csv", tmp_path / "depth.csv"],
        )

    def fake_features(*_args, **_kwargs):
        calls.append("features")
        return KiteOrderFlowFeatureResult(
            rows_generated=2,
            output_csv_data_rows=2,
            feature_mode="DEPTH_ORDERFLOW_LITE",
            market_data_status="FULL_DEPTH",
            files=[tmp_path / "features.csv"],
        )

    def fake_bridge(*_args, **_kwargs):
        calls.append("bridge")
        return SimpleNamespace(
            status="NO_SETUP",
            reason="No setup.",
            candles_built=4,
            candidates_found=0,
            ledger_rows_added=0,
            duplicate_signals_skipped=0,
            warnings=[],
        )

    def fake_forward(*_args, **_kwargs):
        calls.append("forward")
        return SimpleNamespace(
            decision=SimpleNamespace(status="RESEARCH_ONLY", reason="Minimum forward sample not met."),
            ledger_path=tmp_path / "ledger.csv",
            summary_path=tmp_path / "summary.txt",
        )

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
        resolver_func=fake_resolver,
        readonly_check_func=fake_readonly,
        recorder_func=fake_recorder,
        feature_builder_func=fake_features,
        vwap_bridge_func=fake_bridge,
        forward_summary_func=fake_forward,
    )

    assert calls == ["resolver", "readonly", "recorder", "features", "bridge", "forward"]
    assert result.success is True
    assert result.forward_validation_decision == "RESEARCH_ONLY"
    assert result.feature_rows_generated == 2
    assert result.feature_output_csv_data_rows == 2
    assert result.data_quality.status == READY_FOR_FORWARD_VALIDATION


def test_kite_daily_pipeline_report_and_run_log_are_written(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
    )

    log_path = tmp_path / RUN_LOG_PATH
    assert result.report_path.exists()
    assert log_path.exists()
    with log_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 1
    assert rows[0]["symbols"] == "GOLD-I"
    assert rows[0]["dry_run"] == "true"
    assert rows[0]["execution_allowed"] == "false"
    assert rows[0]["production_whatsapp_status"] == "BLOCKED"
    assert rows[0]["data_quality_status"] == FEATURE_GENERATION_PROBLEM
    assert rows[0]["needs_investigation"] == "true"


def test_kite_daily_pipeline_market_closed_partial_quote_does_not_crash(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    def fake_recorder(*_args, **_kwargs):
        return KiteRecordingResult(
            operation_type="recorder",
            quote_status="OK",
            depth_status="MISSING",
            market_data_status="NO_LIVE_TICKS",
            tick_rows_recorded=0,
            depth_rows_recorded=0,
        )

    def fake_features(*_args, **_kwargs):
        return KiteOrderFlowFeatureResult(
            rows_generated=0,
            output_csv_data_rows=0,
            feature_mode="NO_FEATURES",
            market_data_status="NO_INPUT",
            zero_feature_reason="INSUFFICIENT_REAL_ROWS",
        )

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
        recorder_func=fake_recorder,
        feature_builder_func=fake_features,
    )

    assert result.success is True
    assert result.recorder_market_data_status == "NO_LIVE_TICKS"
    assert result.data_quality.status == MARKET_CLOSED_OR_NO_LIVE_DATA
    assert any("MARKET_CLOSED_POSSIBLE" in warning for warning in result.warnings)
    report = result.report_path.read_text(encoding="utf-8")
    assert "Recorder market data status: NO_LIVE_TICKS" in report
    assert "MARKET_CLOSED_POSSIBLE" in report
    assert "Feature reason: INSUFFICIENT_REAL_ROWS" in report


def test_kite_daily_pipeline_feature_count_and_report_count_match(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
    )

    assert result.feature_rows_generated == result.feature_output_csv_data_rows
    report = result.report_path.read_text(encoding="utf-8")
    assert f"Feature rows generated: {result.feature_rows_generated}" in report
    assert f"Feature output CSV data rows: {result.feature_output_csv_data_rows}" in report


def test_kite_daily_pipeline_forward_validation_summary_included(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
    )

    assert result.forward_validation_decision == "RESEARCH_ONLY"
    report = result.report_path.read_text(encoding="utf-8")
    assert "Strategy: GOLD-I VWAP Rejection Short" in report
    assert "Forward-validation decision: RESEARCH_ONLY" in report
    assert "Automatic approval: DISABLED" in report
    assert "DATA QUALITY GATE" in report
    assert "status:" in report
    assert "next_action:" in report


def test_kite_daily_pipeline_module_has_no_order_path_text():
    module_path = Path(__file__).resolve().parents[1] / "src" / "data_collection" / "kite_daily_pipeline.py"
    text = module_path.read_text(encoding="utf-8")

    assert "place_order" not in text
    assert "execution_allowed=false" in text


def _pipeline_test_resolver(*_args, **_kwargs):
    return SimpleNamespace(
        mappings=[
            KiteInstrumentMapping(
                internal_symbol="GOLD-I",
                exchange="MCX",
                tradingsymbol="GOLD26AUGFUT",
                instrument_token=119445255,
                expiry="2026-08-05",
                name="GOLD",
                lot_size=1,
                tick_size=1.0,
                status="RESOLVED",
                reason="test",
            )
        ],
        source="TEST",
        errors=[],
    )


def _pipeline_test_readonly(*_args, **_kwargs):
    return SimpleNamespace(quote_status="OK", depth_status="PRESENT", errors=[], report_path=None)


def _pipeline_test_features(*_args, **_kwargs):
    return KiteOrderFlowFeatureResult(
        rows_generated=1,
        output_csv_data_rows=1,
        feature_mode="DEPTH_ORDERFLOW_LITE",
        market_data_status="FULL_DEPTH",
        contract_consistency_status="CONSISTENT",
        report_csv_contract_match=True,
        files=[],
    )


def _pipeline_test_forward(*_args, **_kwargs):
    return SimpleNamespace(
        decision=SimpleNamespace(status="RESEARCH_ONLY", reason="test"),
        ledger_path=None,
        summary_path=None,
    )


def test_chunked_pipeline_aggregates_chunk_counts(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)
    durations: list[int] = []

    def fake_recorder(*_args, **kwargs):
        durations.append(kwargs["duration_seconds"])
        return KiteRecordingResult(
            operation_type="recorder",
            market_data_status="RECORDED",
            tick_rows_recorded=1,
            depth_rows_recorded=5,
            recorder_completed_normally=True,
            memory_safe_streaming=True,
        )

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=5,
        chunk_seconds=2,
        flush_rows=10,
        resume=True,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
        resolver_func=_pipeline_test_resolver,
        readonly_check_func=_pipeline_test_readonly,
        recorder_func=fake_recorder,
        feature_builder_func=_pipeline_test_features,
        forward_summary_func=_pipeline_test_forward,
    )

    assert durations == [2, 2, 1]
    assert result.chunked_recording_enabled is True
    assert result.chunks_attempted == 3
    assert result.chunks_completed == 3
    assert result.recorder_tick_rows == 3
    assert result.recorder_depth_rows == 15
    report = result.report_path.read_text(encoding="utf-8")
    assert "memory_safe_streaming: true" in report
    assert "chunks_attempted: 3" in report
    assert "chunks_completed: 3" in report


def test_pipeline_memoryerror_recounts_partial_files_and_continues_features(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)
    day = _fixed_now().date()

    def failing_recorder(base, *_args, **_kwargs):
        tick_path = kite_tick_path(base, day, "GOLD-I")
        depth_path = kite_depth_path(base, day, "GOLD-I")
        tick_path.parent.mkdir(parents=True, exist_ok=True)
        depth_path.parent.mkdir(parents=True, exist_ok=True)
        with tick_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=KITE_TICK_COLUMNS)
            writer.writeheader()
            writer.writerow({column: "" for column in KITE_TICK_COLUMNS} | {"timestamp": "2026-06-20 09:15:00", "symbol": "GOLD-I", "ltp": "150000"})
        with depth_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=KITE_DEPTH_COLUMNS)
            writer.writeheader()
            writer.writerow({column: "" for column in KITE_DEPTH_COLUMNS} | {"timestamp": "2026-06-20 09:15:00", "symbol": "GOLD-I", "level": "1"})
        raise MemoryError()

    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=10,
        chunk_seconds=5,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
        resolver_func=_pipeline_test_resolver,
        readonly_check_func=_pipeline_test_readonly,
        recorder_func=failing_recorder,
        feature_builder_func=_pipeline_test_features,
        forward_summary_func=_pipeline_test_forward,
    )

    assert result.recorder_failed_safely is True
    assert result.partial_data_usable is True
    assert result.recorder_tick_rows == 1
    assert result.recorder_depth_rows == 1
    assert result.step_status["recorder"] == "FAILED_SAFE_PARTIAL_USABLE"
    assert result.step_status["feature_builder"] == "SUCCESS"
    report = result.report_path.read_text(encoding="utf-8")
    assert "recorder_failed_safely: true" in report
    assert "partial_data_usable: true" in report
    assert "rows_written_tick: 1" in report
    assert "rows_written_depth: 1" in report


def test_existing_pipeline_command_defaults_remain_compatible(tmp_path, monkeypatch):
    monkeypatch.delenv("KITE_API_KEY", raising=False)
    monkeypatch.delenv("KITE_API_SECRET", raising=False)
    monkeypatch.delenv("KITE_ACCESS_TOKEN", raising=False)
    result = run_kite_daily_pipeline(
        tmp_path,
        symbols_text="GOLD-I",
        duration_seconds=0,
        record_depth=True,
        dry_run=True,
        now_fn=_fixed_now,
        configs=_minimal_configs(),
    )
    assert result.memory_safe_streaming is True
    assert result.chunked_recording_enabled is False
    assert result.chunks_attempted == 1
    assert "execution_allowed=false" in result.report_path.read_text(encoding="utf-8")
