from __future__ import annotations

from src.strategy_lab.config import NEEDS_MORE_DATA, PHASE6A_BACKTEST_CANDIDATE, REJECTED, WATCHLIST
from src.strategy_lab.strategy_decay import STABLE_ACROSS_YEARS
from src.strategy_lab.validation_gates import evaluate_validation_gates


def _passing_metrics() -> dict:
    return {
        "trades": 120,
        "win_rate": 0.52,
        "net_points": 1200,
        "profit_factor": 1.7,
        "expectancy": 10,
        "validation_net_points": 250,
        "oos_net_points": 300,
        "holdout_net_points": 200,
        "removing_best_trade_net": 900,
        "removing_best_month_net": 700,
        "cost_2x_net_points": 1000,
        "cost_3x_net_points": 800,
        "max_loss_streak": 4,
        "max_drawdown": 250,
    }


def test_rejects_high_win_rate_but_negative_expectancy():
    metrics = _passing_metrics()
    metrics.update({"win_rate": 0.9, "net_points": -10, "expectancy": -0.1})

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == REJECTED
    assert result.passed is False


def test_rejects_too_few_trades_as_needs_more_data():
    metrics = _passing_metrics()
    metrics["trades"] = 20

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == NEEDS_MORE_DATA
    assert result.passed is False


def test_never_returns_real_money_ready_decision():
    forbidden = "REAL" + "_MONEY_READY"

    result = evaluate_validation_gates(_passing_metrics(), min_trades=80)

    assert result.decision == PHASE6A_BACKTEST_CANDIDATE
    assert result.decision != forbidden


def test_phase6a_candidate_only_when_all_gates_pass():
    result = evaluate_validation_gates(_passing_metrics(), min_trades=80)

    assert result.decision == PHASE6A_BACKTEST_CANDIDATE
    assert result.passed is True


def test_phase6a_blocked_when_recent_2025_2026_net_is_negative():
    metrics = _passing_metrics()
    metrics.update(
        {
            "recent_net_points": -1.0,
            "2025_2026_net_points": -1.0,
            "stability_label": STABLE_ACROSS_YEARS,
            "decay_label": STABLE_ACROSS_YEARS,
        }
    )

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == REJECTED
    assert result.passed is False
    assert "2025_2026_net_points negative" in result.reasons


def test_inverse_like_metrics_can_be_rejected_independently():
    metrics = _passing_metrics()
    metrics["profit_factor"] = 1.0

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == REJECTED


def test_inverse_like_metrics_can_be_watchlist_independently():
    metrics = _passing_metrics()
    metrics["holdout_net_points"] = 0

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == WATCHLIST
