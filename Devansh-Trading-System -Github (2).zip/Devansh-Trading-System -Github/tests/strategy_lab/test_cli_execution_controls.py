from __future__ import annotations

import csv
from datetime import datetime, timedelta
from pathlib import Path

from src.strategy_lab.cli import run_strategy_lab
from src.strategy_lab.config import StrategyLabConfig


def _write_symbol_fixture(data_dir: Path, symbol: str = "NIFTY", rows: int = 40) -> Path:
    path = data_dir / f"{symbol}_FUT_test.csv"
    start = datetime(2026, 1, 1, 9, 16)
    lines = ["timestamp,open,high,low,close,volume"]
    for index in range(rows):
        timestamp = start + timedelta(minutes=index)
        open_price = 100.0 + index * 0.1
        high = open_price + 1.0
        low = open_price - 1.0
        close = open_price + 0.2
        lines.append(f"{timestamp:%Y-%m-%d %H:%M:%S},{open_price:.2f},{high:.2f},{low:.2f},{close:.2f},100")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def test_validate_only_writes_validation_summary_without_strategy_search(tmp_path, capsys):
    _write_symbol_fixture(tmp_path)
    output_dir = tmp_path / "out"

    paths = run_strategy_lab(
        StrategyLabConfig(
            data_dir=tmp_path,
            symbols=("NIFTY",),
            output_dir=output_dir,
            validate_only=True,
            progress_every=1,
        )
    )

    captured = capsys.readouterr().out
    validation_path = output_dir / "data_validation_summary.csv"

    assert paths["data_validation"] == validation_path
    assert (output_dir / "file_mapping_report.csv").exists()
    assert validation_path.exists()
    assert not (output_dir / "all_candidates_ranked.csv").exists()
    assert not (output_dir / "strategy_lab_v3_master_report.txt").exists()
    assert "file mapping started" in captured
    assert "file mapping completed" in captured
    assert "data loading started symbol=NIFTY" in captured
    assert "validation completed symbol=NIFTY" in captured
    assert "session filtering symbol=NIFTY" in captured
    assert "strategy search skipped" in captured
    assert "execution_allowed=false" in captured


def test_benchmark_mode_writes_runtime_report(tmp_path):
    _write_symbol_fixture(tmp_path)
    output_dir = tmp_path / "benchmark"

    run_strategy_lab(
        StrategyLabConfig(
            data_dir=tmp_path,
            symbols=("NIFTY",),
            output_dir=output_dir,
            benchmark=True,
            include_inverse=True,
            max_variants=2,
            max_bars=20,
        )
    )

    rows = _read_csv(output_dir / "runtime_benchmark_report.csv")

    assert rows[0]["symbol"] == "NIFTY"
    assert rows[0]["status"] == "BENCHMARK_COMPLETED"
    assert int(rows[0]["backtests_sampled"]) == 4
    assert "average_seconds_per_backtest" in rows[0]
    assert "estimated_seconds_for_max_variants_with_inverse" in rows[0]


def test_save_every_writes_symbol_partial_candidates_and_safe_reports(tmp_path, capsys):
    _write_symbol_fixture(tmp_path)
    output_dir = tmp_path / "search"

    run_strategy_lab(
        StrategyLabConfig(
            data_dir=tmp_path,
            symbols=("NIFTY",),
            output_dir=output_dir,
            max_variants=2,
            save_every=1,
            progress_every=1,
            max_bars=20,
        )
    )

    captured = capsys.readouterr().out
    partial_rows = _read_csv(output_dir / "partial_candidates_NIFTY.csv")
    candidate_rows = _read_csv(output_dir / "all_candidates_ranked.csv")
    master_lines = set((output_dir / "strategy_lab_v3_master_report.txt").read_text(encoding="utf-8").splitlines())

    assert len(partial_rows) == 2
    assert (output_dir / "all_candidates_ranked.csv").exists()
    assert (output_dir / "NIFTY_best_report.txt").exists()
    assert (output_dir / "NIFTY_yearwise_metrics.csv").exists()
    assert (output_dir / "NIFTY_recent_period_metrics.csv").exists()
    assert (output_dir / "NIFTY_strategy_decay_report.csv").exists()
    assert (output_dir / "NIFTY_walk_forward_windows.csv").exists()
    assert (output_dir / "NIFTY_walk_forward_summary.csv").exists()
    assert "stability_label" in candidate_rows[0]
    assert "recent_net_points" in candidate_rows[0]
    assert "walk_forward_label" in candidate_rows[0]
    assert "walk_forward_test_net_points_total" in candidate_rows[0]
    assert "usable_walk_forward_windows" in candidate_rows[0]
    assert "recent_window_status" in candidate_rows[0]
    assert "walk_forward_block_reason" in candidate_rows[0]
    assert "strategy generation count symbol=NIFTY" in captured
    assert "symbol search started symbol=NIFTY" in captured
    assert "variant progress symbol=NIFTY 1/2" in captured
    assert "partial candidates saved symbol=NIFTY variants=1" in captured
    assert "symbol search completed symbol=NIFTY" in captured
    assert "NOT_REAL_MONEY_READY" in master_lines
    assert "REAL_MONEY_READY" not in master_lines


def test_strategy_lab_execution_controls_add_no_broker_or_alert_sending_imports():
    root = Path(__file__).resolve().parents[2] / "src" / "strategy_lab"
    text = "\n".join(path.read_text(encoding="utf-8") for path in root.rglob("*.py")).lower()
    forbidden_order_word = "place" + "_order"
    forbidden = [
        forbidden_order_word,
        "from src." + "brokers",
        "import kite" + "connect",
        "send_" + "whatsapp",
        "tele" + "gram",
    ]

    for item in forbidden:
        assert item not in text
