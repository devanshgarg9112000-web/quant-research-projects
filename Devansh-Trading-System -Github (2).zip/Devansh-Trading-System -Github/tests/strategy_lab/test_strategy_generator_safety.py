from __future__ import annotations

import json
from pathlib import Path

from src.strategy_lab.strategy_generator import expand_strategy_orientations, generate_strategy_variants
from src.strategy_lab.strategy_primitives import INVERSE, ORIGINAL, inverse_strategy_variant


def test_same_seed_produces_same_variants():
    first = generate_strategy_variants(max_variants=20, random_seed=42)
    second = generate_strategy_variants(max_variants=20, random_seed=42)

    assert [item.strategy_id for item in first] == [item.strategy_id for item in second]
    assert [item.params_json for item in first] == [item.params_json for item in second]


def test_different_seed_can_produce_different_variants():
    first = generate_strategy_variants(max_variants=20, random_seed=42)
    second = generate_strategy_variants(max_variants=20, random_seed=43)

    assert [item.strategy_id for item in first] != [item.strategy_id for item in second]


def test_generated_strategies_have_params_json_and_no_lookahead_flags():
    variants = generate_strategy_variants(max_variants=30, random_seed=7)

    assert variants
    for variant in variants:
        params = json.loads(variant.params_json)
        assert isinstance(params, dict)
        assert params["orientation"] == ORIGINAL
        assert variant.lookahead_flags == ()
        assert variant.has_lookahead is False


def test_include_inverse_creates_inverse_variants_with_metadata():
    originals = generate_strategy_variants(max_variants=5, random_seed=42)
    expanded = expand_strategy_orientations(originals, include_inverse=True)
    inverse_rows = [item for item in expanded if item.orientation == INVERSE]

    assert len(originals) == 5
    assert len(inverse_rows) == 5
    assert inverse_rows[0].strategy_id == originals[0].strategy_id + "__INVERSE"
    inverse_params = json.loads(inverse_rows[0].params_json)
    original_params = json.loads(originals[0].params_json)
    assert original_params["orientation"] == ORIGINAL
    assert inverse_params["orientation"] == INVERSE
    assert inverse_params["inverse_of"] == originals[0].strategy_id


def test_strategy_orientation_inverse_only_returns_inverse_versions():
    originals = generate_strategy_variants(max_variants=4, random_seed=42)
    expanded = expand_strategy_orientations(originals, strategy_orientation="inverse")

    assert len(expanded) == 4
    assert all(item.orientation == INVERSE for item in expanded)
    assert all(item.strategy_id.endswith("__INVERSE") for item in expanded)


def test_inverse_long_becomes_short_and_short_becomes_long():
    long_variant = generate_strategy_variants(max_variants=1, random_seed=1)[0]
    long_variant = type(long_variant)(
        strategy_id="manual_long",
        family=long_variant.family,
        side="LONG",
        params=long_variant.params,
        orientation=ORIGINAL,
        signal_side="LONG",
    )
    short_variant = type(long_variant)(
        strategy_id="manual_short",
        family=long_variant.family,
        side="SHORT",
        params=long_variant.params,
        orientation=ORIGINAL,
        signal_side="SHORT",
    )

    assert inverse_strategy_variant(long_variant).side == "SHORT"
    assert inverse_strategy_variant(short_variant).side == "LONG"


def test_strategy_lab_introduces_no_broker_or_alert_sending_imports():
    root = Path(__file__).resolve().parents[2] / "src" / "strategy_lab"
    text = "\n".join(path.read_text(encoding="utf-8") for path in root.rglob("*.py"))
    forbidden_order_word = "place" + "_order"
    forbidden = [
        forbidden_order_word,
        "from src." + "brokers",
        "import kite" + "connect",
        "send_" + "whatsapp",
        "tele" + "gram",
    ]

    for item in forbidden:
        assert item not in text.lower()
