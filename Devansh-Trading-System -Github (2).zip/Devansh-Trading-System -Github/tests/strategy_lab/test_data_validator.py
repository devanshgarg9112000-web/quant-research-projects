from __future__ import annotations

import pandas as pd

from src.strategy_lab.data_validator import DATA_REJECTED, DATA_USABLE, validate_raw_data


def test_data_validator_detects_bad_rows_and_duplicates():
    frame = pd.DataFrame(
        [
            {"timestamp": "2026-01-01 09:16", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 10},
            {"timestamp": "2026-01-01 09:16", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 10},
            {"timestamp": "2026-01-01 09:17", "open": 100, "high": 99, "low": 98, "close": 100, "volume": -1},
            {"timestamp": "2026-01-01 09:18", "open": 100, "high": 101, "low": 99, "close": 100, "volume": 0},
        ]
    )

    summary = validate_raw_data(frame, "NIFTY")

    assert summary.decision == DATA_USABLE
    assert summary.rows_raw == 4
    assert summary.duplicate_timestamps == 1
    assert summary.bad_ohlc_rows == 1
    assert summary.negative_volume_rows == 1
    assert summary.zero_volume_rows == 1


def test_data_validator_rejects_missing_required_price_columns():
    frame = pd.DataFrame(
        [
            {"timestamp": "2026-01-01 09:16", "high": 101, "low": 99, "close": 100, "volume": 10},
        ]
    )

    summary = validate_raw_data(frame, "NIFTY")

    assert summary.decision == DATA_REJECTED
    assert "open" in summary.missing_required_columns

