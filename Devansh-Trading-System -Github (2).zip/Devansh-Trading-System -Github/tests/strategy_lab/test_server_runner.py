from __future__ import annotations

import csv
from pathlib import Path

from src.strategy_lab.server_runner import (
    COMPLETED,
    COMPLETED_MARKER,
    FAILED,
    MASTER_REPORT,
    SKIPPED_RESUME,
    ServerRunnerConfig,
    aggregate_completed_reports,
    build_symbol_command,
    run_server_runner,
    server_safety_lines,
)


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _command_value(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def _write_completed_symbol_folder(root: Path, symbol: str, decision: str = "WATCHLIST") -> Path:
    output_dir = root / symbol
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / MASTER_REPORT).write_text("RESEARCH_ONLY\nBACKTEST_ONLY\nNOT_REAL_MONEY_READY\n", encoding="utf-8")
    (output_dir / COMPLETED_MARKER).write_text("RUN_COMPLETED\nexecution_allowed=false\n", encoding="utf-8")
    (output_dir / "all_candidates_ranked.csv").write_text(
        "symbol,strategy_id,decision,net_points,walk_forward_label,walk_forward_test_net_points_total,"
        "walk_forward_pass_rate,usable_walk_forward_windows,insufficient_walk_forward_windows,"
        "recent_window_status,walk_forward_block_reason,gate_reasons\n"
        f"{symbol},{symbol.lower()}_demo,{decision},10,WALK_FORWARD_PASS,40,1.0,4,0,PASS,NONE,NONE\n",
        encoding="utf-8",
    )
    (output_dir / "phase6a_candidates.csv").write_text(
        "symbol,strategy_id,decision,net_points\n"
        f"{symbol},{symbol.lower()}_phase,PHASE6A_BACKTEST_CANDIDATE,20\n",
        encoding="utf-8",
    )
    (output_dir / "watchlist_candidates.csv").write_text(
        "symbol,strategy_id,decision,net_points\n"
        f"{symbol},{symbol.lower()}_watch,WATCHLIST,5\n",
        encoding="utf-8",
    )
    (output_dir / "original_vs_inverse_comparison.csv").write_text(
        "symbol,original_strategy_id,inverse_strategy_id,better_orientation\n"
        f"{symbol},{symbol.lower()}_original,{symbol.lower()}_inverse,INVERSE\n",
        encoding="utf-8",
    )
    (output_dir / f"{symbol}_yearwise_metrics.csv").write_text(
        "symbol,strategy_id,year,trades,net_points,profit_factor,win_rate,max_drawdown,max_loss_streak,avg_trade,best_trade,worst_trade\n"
        f"{symbol},{symbol.lower()}_demo,2026,10,10,2.0,0.6,3,2,1,4,-2\n",
        encoding="utf-8",
    )
    (output_dir / f"{symbol}_strategy_decay_report.csv").write_text(
        "symbol,strategy_id,stability_label,decay_label,recent_net_points\n"
        f"{symbol},{symbol.lower()}_demo,STABLE_ACROSS_YEARS,STABLE_ACROSS_YEARS,10\n",
        encoding="utf-8",
    )
    (output_dir / f"{symbol}_walk_forward_windows.csv").write_text(
        "symbol,strategy_id,window_id,test_net_points,status\n"
        f"{symbol},{symbol.lower()}_demo,WF_2024_2025_TEST_2026,10,PASS\n",
        encoding="utf-8",
    )
    (output_dir / f"{symbol}_walk_forward_summary.csv").write_text(
        "symbol,strategy_id,walk_forward_windows_total,walk_forward_windows_passed,walk_forward_windows_failed,"
        "walk_forward_pass_rate,walk_forward_test_net_points_total,walk_forward_recent_window_status,"
        "walk_forward_label,usable_walk_forward_windows,insufficient_walk_forward_windows,"
        "recent_window_status,walk_forward_block_reason\n"
        f"{symbol},{symbol.lower()}_demo,4,4,0,1.0,40,PASS,WALK_FORWARD_PASS,4,0,PASS,NONE\n",
        encoding="utf-8",
    )
    return output_dir


def test_server_runner_command_construction_targets_symbol_output_and_safe_cli():
    config = ServerRunnerConfig(
        data_dir=Path("data/third_party/raw"),
        symbols=("NIFTY",),
        output_root=Path("reports/strategy_lab/server_run"),
        max_variants=1000,
        include_inverse=True,
        random_seed=7,
        top_n=50,
        save_every=100,
        progress_every=25,
        cost_points=1.5,
        max_bars=50000,
        python_executable="python",
    )

    command = build_symbol_command(config, "NIFTY")

    assert command[:3] == ["python", "-m", "src.strategy_lab.cli"]
    assert _command_value(command, "--symbols") == "NIFTY"
    assert _command_value(command, "--output-dir").endswith("server_run\\NIFTY") or _command_value(
        command, "--output-dir"
    ).endswith("server_run/NIFTY")
    assert _command_value(command, "--include-inverse") == "true"
    assert _command_value(command, "--max-variants") == "1000"
    assert _command_value(command, "--save-every") == "100"
    assert _command_value(command, "--progress-every") == "25"
    assert _command_value(command, "--max-bars") == "50000"
    assert "execution_allowed=false" in server_safety_lines()


def test_server_runner_resume_skips_completed_symbol(tmp_path):
    _write_completed_symbol_folder(tmp_path, "NIFTY")
    calls: list[list[str]] = []

    def fake_runner(command: list[str], stdout_path: Path, stderr_path: Path) -> int:
        calls.append(command)
        return 1

    run_server_runner(
        ServerRunnerConfig(
            data_dir=tmp_path,
            symbols=("NIFTY",),
            output_root=tmp_path,
            resume=True,
            python_executable="python",
        ),
        process_runner=fake_runner,
    )

    rows = _read_csv(tmp_path / "server_runner_status.csv")

    assert calls == []
    assert rows[0]["symbol"] == "NIFTY"
    assert rows[0]["status"] == SKIPPED_RESUME


def test_server_runner_records_failure_and_continues_remaining_symbols(tmp_path):
    calls: list[str] = []

    def fake_runner(command: list[str], stdout_path: Path, stderr_path: Path) -> int:
        symbol = _command_value(command, "--symbols")
        output_dir = Path(_command_value(command, "--output-dir"))
        calls.append(symbol)
        stdout_path.write_text(f"{symbol} stdout\n", encoding="utf-8")
        stderr_path.write_text("", encoding="utf-8")
        if symbol == "BAD":
            return 7
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / MASTER_REPORT).write_text("RESEARCH_ONLY\nBACKTEST_ONLY\nNOT_REAL_MONEY_READY\n", encoding="utf-8")
        (output_dir / "all_candidates_ranked.csv").write_text(
            "symbol,strategy_id,decision,net_points\nGOOD,good_demo,WATCHLIST,1\n",
            encoding="utf-8",
        )
        return 0

    run_server_runner(
        ServerRunnerConfig(
            data_dir=tmp_path,
            symbols=("BAD", "GOOD"),
            output_root=tmp_path / "run",
            workers=1,
            resume=False,
            python_executable="python",
        ),
        process_runner=fake_runner,
    )

    rows = {row["symbol"]: row for row in _read_csv(tmp_path / "run" / "server_runner_status.csv")}

    assert calls == ["BAD", "GOOD"]
    assert rows["BAD"]["status"] == FAILED
    assert rows["BAD"]["return_code"] == "7"
    assert rows["GOOD"]["status"] == COMPLETED
    assert "applied_cost_points=0.0" in rows["GOOD"]["notes"]
    assert (tmp_path / "run" / "GOOD" / COMPLETED_MARKER).exists()
    assert (tmp_path / "run" / "logs" / "BAD.out.txt").exists()
    assert (tmp_path / "run" / "logs" / "GOOD.out.txt").exists()


def test_server_runner_aggregation_uses_only_completed_symbol_folders(tmp_path):
    _write_completed_symbol_folder(tmp_path, "NIFTY")
    _write_completed_symbol_folder(tmp_path, "BANKNIFTY")
    incomplete = tmp_path / "GOLD"
    incomplete.mkdir()
    (incomplete / "all_candidates_ranked.csv").write_text(
        "symbol,strategy_id,decision,net_points\nGOLD,gold_demo,WATCHLIST,999\n",
        encoding="utf-8",
    )

    paths = aggregate_completed_reports(
        tmp_path,
        ("NIFTY", "BANKNIFTY", "GOLD"),
        status_rows=[
            {"symbol": "NIFTY", "status": COMPLETED, "notes": "applied_cost_points=2.0 cost_source=COST_PROFILE"},
            {"symbol": "BANKNIFTY", "status": COMPLETED, "notes": "applied_cost_points=8.0 cost_source=COST_PROFILE"},
            {"symbol": "GOLD", "status": FAILED},
        ],
    )

    all_rows = _read_csv(paths["combined_all_candidates"])
    phase_rows = _read_csv(paths["combined_phase6a"])
    watch_rows = _read_csv(paths["combined_watchlist"])
    comparison_rows = _read_csv(paths["combined_original_vs_inverse"])
    yearwise_rows = _read_csv(paths["combined_yearwise_metrics"])
    decay_rows = _read_csv(paths["combined_strategy_decay_report"])
    walk_forward_windows = _read_csv(paths["combined_walk_forward_windows"])
    walk_forward_summary = _read_csv(paths["combined_walk_forward_summary"])
    summary = paths["combined_master_summary"].read_text(encoding="utf-8").splitlines()

    assert {row["symbol"] for row in all_rows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in phase_rows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in watch_rows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in comparison_rows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in yearwise_rows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in decay_rows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in walk_forward_windows} == {"NIFTY", "BANKNIFTY"}
    assert {row["symbol"] for row in walk_forward_summary} == {"NIFTY", "BANKNIFTY"}
    assert "GOLD" not in {row["symbol"] for row in all_rows}
    assert "completed_symbols: 2" in summary
    assert "failed_symbols: 1" in summary
    assert "stable_strategies_count: 2" in summary
    assert "walk_forward_pass_count: 2" in summary
    assert "walk_forward_recent_insufficient_count: 0" in summary
    assert "strategies_blocked_due_to_walk_forward_failure: 0" in summary
    assert "- NIFTY: nifty_demo label=WALK_FORWARD_PASS test_net=40 pass_rate=1.0 decision=WATCHLIST" in summary
    assert "- NIFTY: applied_cost_points=2.0 cost_source=COST_PROFILE" in summary
    assert "- BANKNIFTY: applied_cost_points=8.0 cost_source=COST_PROFILE" in summary
    assert "execution_allowed=false" in summary


def test_server_runner_adds_no_broker_execution_or_alert_sending_imports():
    text = (Path(__file__).resolve().parents[2] / "src" / "strategy_lab" / "server_runner.py").read_text(
        encoding="utf-8"
    )
    lowered = text.lower()
    forbidden_order_word = "place" + "_order"
    forbidden = [
        forbidden_order_word,
        "from src." + "brokers",
        "import kite" + "connect",
        "send_" + "whatsapp",
    ]

    for item in forbidden:
        assert item not in lowered
    assert '"REAL_MONEY_READY"' not in text
    assert "'REAL_MONEY_READY'" not in text
