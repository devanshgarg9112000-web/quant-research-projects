from __future__ import annotations

from src.strategy_lab.cli import build_parser, config_from_args


def test_cli_include_inverse_flag_maps_to_both_mode():
    args = build_parser().parse_args(
        [
            "--data-dir",
            "data/third_party/raw",
            "--symbols",
            "NIFTY",
            "--include-inverse",
            "true",
            "--strategy-orientation",
            "original",
            "--max-variants",
            "1000",
        ]
    )

    config = config_from_args(args)

    assert config.include_inverse is True
    assert config.strategy_orientation == "original"
    assert config.max_variants == 1000


def test_cli_strategy_orientation_inverse_flag_is_supported():
    args = build_parser().parse_args(
        [
            "--data-dir",
            "data/third_party/raw",
            "--symbols",
            "NIFTY",
            "--strategy-orientation",
            "inverse",
        ]
    )

    config = config_from_args(args)

    assert config.include_inverse is False
    assert config.strategy_orientation == "inverse"

