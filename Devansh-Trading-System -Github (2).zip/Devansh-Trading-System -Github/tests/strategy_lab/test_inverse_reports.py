from __future__ import annotations

import csv

import pandas as pd

from src.strategy_lab.report_writer import write_strategy_lab_reports


def test_inverse_reports_create_comparison_and_inverse_candidate_files(tmp_path):
    original_id = "demo_long_abc"
    inverse_id = original_id + "__INVERSE"
    rows = [
        {
            "symbol": "NIFTY",
            "strategy_id": original_id,
            "base_strategy_id": original_id,
            "orientation": "ORIGINAL",
            "inverse_of": "",
            "family": "demo",
            "side": "LONG",
            "params_json": '{"orientation":"ORIGINAL"}',
            "decision": "REJECTED",
            "net_points": -10.0,
            "profit_factor": 0.7,
            "win_rate": 0.4,
            "trades": 100,
        },
        {
            "symbol": "NIFTY",
            "strategy_id": inverse_id,
            "base_strategy_id": original_id,
            "orientation": "INVERSE",
            "inverse_of": original_id,
            "family": "demo",
            "side": "SHORT",
            "params_json": '{"orientation":"INVERSE","inverse_of":"demo_long_abc"}',
            "decision": "WATCHLIST",
            "net_points": 25.0,
            "profit_factor": 1.4,
            "win_rate": 0.51,
            "trades": 100,
        },
    ]

    paths = write_strategy_lab_reports(
        tmp_path,
        data_summaries=[{"symbol": "NIFTY", "decision": "DATA_USABLE"}],
        candidate_rows=rows,
        base_variants_generated=1,
        inverse_variants_generated=1,
        total_backtests_attempted=2,
        include_inverse=True,
        strategy_orientation="both",
        trades_by_symbol={"NIFTY": pd.DataFrame()},
        monthly_by_symbol={"NIFTY": pd.DataFrame()},
        split_by_symbol={"NIFTY": pd.DataFrame()},
        cost_by_symbol={"NIFTY": pd.DataFrame()},
        portfolio_summary={},
    )

    assert paths["inverse_candidates"].exists()
    assert paths["original_vs_inverse"].exists()
    with paths["inverse_candidates"].open(newline="", encoding="utf-8") as f:
        inverse_rows = list(csv.DictReader(f))
    with paths["original_vs_inverse"].open(newline="", encoding="utf-8") as f:
        comparison_rows = list(csv.DictReader(f))
    master = paths["master"].read_text(encoding="utf-8")

    assert inverse_rows[0]["orientation"] == "INVERSE"
    assert comparison_rows[0]["original_strategy_id"] == original_id
    assert comparison_rows[0]["inverse_strategy_id"] == inverse_id
    assert comparison_rows[0]["better_orientation"] in {"INVERSE", "MIXED_NEEDS_REVIEW"}
    assert "base_variants_generated: 1" in master
    assert "inverse_variants_generated: 1" in master
    assert "include_inverse: true" in master
    assert "BACKTEST_ONLY" in master
    assert "RESEARCH_ONLY" in master
    assert "NOT_REAL_MONEY_READY" in master
    assert "execution_allowed=false" in master

