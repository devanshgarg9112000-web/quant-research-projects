from __future__ import annotations

import csv

import pytest

from src.strategy_lab.data_loader import (
    AMBIGUOUS_DATA_FILE,
    DATA_FILE_FOUND,
    DATA_FILE_NOT_FOUND,
    parse_file_symbol,
    resolve_symbol_file,
    write_file_mapping_report,
)
from src.strategy_lab.session_profiles import resolve_session_profile


@pytest.mark.parametrize(
    ("requested_symbol", "filename"),
    [
        ("NIFTY", "BANKNIFTY_FUT_1min.csv"),
        ("GOLD", "GOLDMI_FUT_1min.csv"),
        ("CRUDE", "CRUDMI_FUT_1min.csv"),
        ("SILVER", "SILMIN_FUT_1min.csv"),
    ],
)
def test_file_mapping_uses_exact_symbol_before_fut_marker(tmp_path, requested_symbol: str, filename: str):
    (tmp_path / filename).write_text("timestamp,open,high,low,close\n", encoding="utf-8")

    mapping = resolve_symbol_file(tmp_path, requested_symbol)

    assert mapping.status == DATA_FILE_NOT_FOUND
    assert mapping.matched_file is None


def test_file_mapping_selects_exact_symbol_only(tmp_path):
    (tmp_path / "BANKNIFTY_FUT_1min.csv").write_text("timestamp,open,high,low,close\n", encoding="utf-8")
    exact = tmp_path / "NIFTY_FUT_1min.csv"
    exact.write_text("timestamp,open,high,low,close\n", encoding="utf-8")

    mapping = resolve_symbol_file(tmp_path, "nifty")

    assert mapping.status == DATA_FILE_FOUND
    assert mapping.matched_file == exact
    assert mapping.parsed_file_symbol == "NIFTY"


def test_file_mapping_rejects_empty_requested_symbol(tmp_path):
    (tmp_path / "random.csv").write_text("timestamp,open,high,low,close\n", encoding="utf-8")

    mapping = resolve_symbol_file(tmp_path, "")

    assert mapping.status == DATA_FILE_NOT_FOUND
    assert mapping.matched_file is None


def test_file_mapping_marks_multiple_exact_matches_ambiguous(tmp_path):
    (tmp_path / "NIFTY_FUT_1min.csv").write_text("timestamp,open,high,low,close\n", encoding="utf-8")
    nested = tmp_path / "nested"
    nested.mkdir()
    (nested / "NIFTY_FUT_5min.csv").write_text("timestamp,open,high,low,close\n", encoding="utf-8")

    mapping = resolve_symbol_file(tmp_path, "NIFTY")

    assert mapping.status == AMBIGUOUS_DATA_FILE
    assert mapping.matched_file is None


def test_parse_file_symbol_reads_text_before_fut_marker():
    assert parse_file_symbol("GOLD_FUT_2026_08_14.csv") == "GOLD"
    assert parse_file_symbol("GOLDMI_FUT_2026_08_14.csv") == "GOLDMI"
    assert parse_file_symbol("GOLD_2026_08_14.csv") == ""


def test_file_mapping_report_columns_and_statuses(tmp_path):
    (tmp_path / "GOLDMI_FUT_1min.csv").write_text("timestamp,open,high,low,close\n", encoding="utf-8")
    mappings = [resolve_symbol_file(tmp_path, "GOLD")]
    report_path = write_file_mapping_report(tmp_path / "file_mapping_report.csv", mappings)

    with report_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    assert list(rows[0]) == ["requested_symbol", "matched_file", "parsed_file_symbol", "status", "notes"]
    assert rows[0]["requested_symbol"] == "GOLD"
    assert rows[0]["status"] == DATA_FILE_NOT_FOUND


@pytest.mark.parametrize("symbol", ["ALUMIN", "ALUMINIUM", "CRUDMI", "CRUDEMI", "CRUDEM", "SILMIN", "SILVERMI", "SILVERM"])
def test_missing_mcx_aliases_resolve_to_mcx_non_agri_session(symbol: str):
    profile = resolve_session_profile(symbol)

    assert profile is not None
    assert profile.name == "MCX_NON_AGRI"
