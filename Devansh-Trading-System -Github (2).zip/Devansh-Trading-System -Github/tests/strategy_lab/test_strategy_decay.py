from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

from src.strategy_lab.config import NOT_REAL_MONEY_READY
from src.strategy_lab.report_writer import write_strategy_lab_reports
from src.strategy_lab.strategy_decay import (
    OLD_EDGE_ONLY,
    ONE_MONTH_DEPENDENT,
    ONE_YEAR_DEPENDENT,
    RECENTLY_WORKING_NEEDS_FORWARD_DATA,
    STABLE_ACROSS_YEARS,
    STRATEGY_DECAYED,
    UNSTABLE_REJECT,
    analyze_strategy_decay,
    calendar_year_metrics,
)


def _trades(year: int, month: int, values: list[float]) -> list[dict]:
    start = datetime(year, month, 1, 9, 16)
    rows = []
    for index, value in enumerate(values):
        entry_time = start + timedelta(days=index % 20, minutes=index)
        rows.append(
            {
                "symbol": "NIFTY",
                "strategy_id": "demo",
                "entry_time": entry_time.isoformat(),
                "exit_time": (entry_time + timedelta(minutes=5)).isoformat(),
                "gross_points": value,
                "net_points": value,
            }
        )
    return rows


def test_yearwise_metrics_calculation():
    rows = _trades(2024, 1, [10, -5, 20]) + _trades(2025, 1, [-10, 30])

    yearwise = calendar_year_metrics(rows, {"symbol": "NIFTY", "strategy_id": "demo"})

    by_year = {int(row["year"]): row for _, row in yearwise.iterrows()}

    assert by_year[2024]["trades"] == 3
    assert by_year[2024]["net_points"] == 25
    assert by_year[2024]["profit_factor"] == 6
    assert by_year[2024]["win_rate"] == 0.666667
    assert by_year[2024]["max_drawdown"] == 5
    assert by_year[2025]["worst_trade"] == -10
    assert list(yearwise.columns)[-9:] == [
        "trades",
        "net_points",
        "profit_factor",
        "win_rate",
        "max_drawdown",
        "max_loss_streak",
        "avg_trade",
        "best_trade",
        "worst_trade",
    ]


def test_strategy_decayed_label_when_recent_years_turn_negative():
    rows = (
        _trades(2023, 1, [10] * 10)
        + _trades(2024, 1, [10] * 10)
        + _trades(2025, 1, [-5] * 10)
        + _trades(2026, 1, [-5] * 10)
    )

    result = analyze_strategy_decay(rows, symbol="NIFTY", strategy_id="decayed")

    assert result.summary["stability_label"] == UNSTABLE_REJECT
    assert result.summary["decay_label"] == STRATEGY_DECAYED
    assert result.summary["recent_net_points"] == -100


def test_recent_working_needs_forward_data_label_when_only_2026_positive():
    rows = _trades(2026, 1, [5] * 20)

    result = analyze_strategy_decay(rows, symbol="NIFTY", strategy_id="recent_only")

    assert result.summary["stability_label"] == RECENTLY_WORKING_NEEDS_FORWARD_DATA
    assert result.summary["decay_label"] == RECENTLY_WORKING_NEEDS_FORWARD_DATA
    assert result.summary["2026_net_points"] == 100


def test_one_year_dependency_detection():
    rows = (
        _trades(2023, 1, [10] * 10)
        + _trades(2024, 1, [1] * 10)
        + _trades(2025, 1, [1] * 10)
        + _trades(2026, 1, [1] * 10)
    )

    result = analyze_strategy_decay(rows, symbol="NIFTY", strategy_id="one_year")

    assert result.summary["decay_label"] == ONE_YEAR_DEPENDENT
    assert result.summary["year_dependency_ratio"] > 0.65


def test_one_month_dependency_detection():
    rows = (
        _trades(2024, 1, [10] * 14)
        + _trades(2024, 2, [-10] * 5)
        + _trades(2025, 1, [6] * 10)
        + _trades(2026, 1, [5] * 10)
    )

    result = analyze_strategy_decay(rows, symbol="NIFTY", strategy_id="one_month")

    assert result.summary["decay_label"] == ONE_MONTH_DEPENDENT
    assert result.summary["month_dependency_ratio"] > 0.50
    assert result.summary["year_dependency_ratio"] < 0.65


def test_stable_across_years_label():
    rows = _trades(2024, 1, [10] * 10) + _trades(2025, 1, [10] * 10) + _trades(2026, 1, [10] * 10)

    result = analyze_strategy_decay(rows, symbol="NIFTY", strategy_id="stable")

    assert result.summary["stability_label"] == STABLE_ACROSS_YEARS
    assert result.summary["decay_label"] == STABLE_ACROSS_YEARS
    assert result.summary["positive_years"] == 3


def test_strategy_decay_reports_are_created(tmp_path):
    candidate = {
        "symbol": "NIFTY",
        "strategy_id": "stable",
        "base_strategy_id": "stable",
        "orientation": "ORIGINAL",
        "inverse_of": "",
        "family": "demo",
        "side": "LONG",
        "params_json": "{}",
        "decision": "WATCHLIST",
        "net_points": 300,
        "profit_factor": 2.0,
        "win_rate": 0.6,
        "trades": 30,
        "positive_years": 3,
        "negative_years": 0,
        "best_year": 2026,
        "worst_year": 2024,
        "recent_net_points": 200,
        "recent_profit_factor": 999.0,
        "stability_label": STABLE_ACROSS_YEARS,
        "decay_label": STABLE_ACROSS_YEARS,
        "year_dependency_ratio": 0.333333,
        "month_dependency_ratio": 0.333333,
    }

    paths = write_strategy_lab_reports(
        tmp_path,
        data_summaries=[{"symbol": "NIFTY", "decision": "DATA_USABLE"}],
        candidate_rows=[candidate],
        trades_by_symbol={"NIFTY": pd.DataFrame()},
        monthly_by_symbol={"NIFTY": pd.DataFrame()},
        split_by_symbol={"NIFTY": pd.DataFrame()},
        cost_by_symbol={"NIFTY": pd.DataFrame()},
        yearwise_by_symbol={"NIFTY": pd.DataFrame([{"symbol": "NIFTY", "strategy_id": "stable", "year": 2026}])},
        recent_by_symbol={"NIFTY": pd.DataFrame([{"symbol": "NIFTY", "strategy_id": "stable"}])},
        decay_by_symbol={"NIFTY": pd.DataFrame([candidate])},
        portfolio_summary={},
    )

    master = paths["master"].read_text(encoding="utf-8")

    assert paths["NIFTY_yearwise_metrics"].exists()
    assert paths["NIFTY_recent_period_metrics"].exists()
    assert paths["NIFTY_strategy_decay_report"].exists()
    assert "STABILITY / DECAY" in master
    assert "decayed_strategies_count: 0" in master
    assert "recent_only_strategies_count: 0" in master
    assert NOT_REAL_MONEY_READY in master
    assert OLD_EDGE_ONLY not in master
