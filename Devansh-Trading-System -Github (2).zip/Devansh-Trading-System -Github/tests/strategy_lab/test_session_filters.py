from __future__ import annotations

from datetime import time

import pandas as pd

from src.strategy_lab.config import NEEDS_SESSION_PROFILE
from src.strategy_lab.session_filters import apply_valid_market_session_filter


def _frame(times: list[str]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {"timestamp": timestamp, "open": 100, "high": 101, "low": 99, "close": 100, "volume": 10}
            for timestamp in times
        ]
    )


def test_nse_session_excludes_before_0916_and_after_1529():
    result = apply_valid_market_session_filter(
        _frame(["2026-01-01 09:15", "2026-01-01 09:16", "2026-01-01 15:29", "2026-01-01 15:30"]),
        "NIFTY",
    )

    assert list(result.filtered["timestamp"].dt.strftime("%H:%M")) == ["09:16", "15:29"]
    assert result.profile_name == "NSE_FNO"
    assert result.rejected_out_of_session_rows == 2


def test_mcx_session_excludes_before_0900_and_allows_late_detected_close():
    result = apply_valid_market_session_filter(
        _frame(["2026-01-02 08:59", "2026-01-02 09:00", "2026-01-02 23:30", "2026-01-02 23:54"]),
        "GOLD",
        forced_exit_buffer_minutes=5,
    )
    trading_day = result.filtered["timestamp"].dt.date.iloc[0]

    assert list(result.filtered["timestamp"].dt.strftime("%H:%M")) == ["09:00", "23:30", "23:54"]
    assert result.profile_name == "MCX_NON_AGRI"
    assert result.session_by_day[trading_day].session_end == time(23, 54)
    assert result.forced_exit_by_day[trading_day] == time(23, 49)


def test_unknown_symbol_without_profile_is_skipped():
    result = apply_valid_market_session_filter(_frame(["2026-01-01 09:16"]), "UNKNOWNXYZ")

    assert result.decision == NEEDS_SESSION_PROFILE
    assert result.filtered.empty


def test_forced_exit_buffer_is_separate_from_data_filtering():
    result = apply_valid_market_session_filter(
        _frame(["2026-01-02 09:00", "2026-01-02 23:54"]),
        "SILVER",
        forced_exit_buffer_minutes=10,
    )
    trading_day = result.filtered["timestamp"].dt.date.iloc[0]

    assert list(result.filtered["timestamp"].dt.strftime("%H:%M")) == ["09:00", "23:54"]
    assert result.session_by_day[trading_day].session_end == time(23, 54)
    assert result.forced_exit_by_day[trading_day] == time(23, 44)

