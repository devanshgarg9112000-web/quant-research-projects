from __future__ import annotations

from datetime import datetime, timedelta

import pandas as pd

from src.strategy_lab.config import NEEDS_MORE_DATA, PHASE6A_BACKTEST_CANDIDATE, REJECTED
from src.strategy_lab.report_writer import write_strategy_lab_reports
from src.strategy_lab.validation_gates import evaluate_validation_gates
from src.strategy_lab.walk_forward_validation import (
    FAIL,
    INSUFFICIENT_DATA,
    PASS,
    WALK_FORWARD_FAIL,
    WALK_FORWARD_INSUFFICIENT_DATA,
    WALK_FORWARD_MIXED,
    WALK_FORWARD_PASS,
    WALK_FORWARD_RECENT_INSUFFICIENT,
    aggregate_walk_forward_summary,
    analyze_walk_forward_validation,
)


def _coverage(start: str = "2021-01-01", end: str = "2026-12-31") -> pd.DataFrame:
    return pd.DataFrame({"timestamp": [pd.Timestamp(start), pd.Timestamp(end)]})


def _trades(year: int, values: list[float]) -> list[dict]:
    start = datetime(year, 1, 3, 9, 16)
    return [
        {
            "symbol": "NIFTY",
            "strategy_id": "demo",
            "entry_time": (start + timedelta(days=index)).isoformat(),
            "gross_points": value,
            "net_points": value,
        }
        for index, value in enumerate(values)
    ]


def _passing_metrics() -> dict:
    return {
        "trades": 120,
        "win_rate": 0.52,
        "net_points": 1200,
        "profit_factor": 1.7,
        "expectancy": 10,
        "validation_net_points": 250,
        "oos_net_points": 300,
        "holdout_net_points": 200,
        "removing_best_trade_net": 900,
        "removing_best_month_net": 700,
        "cost_2x_net_points": 1000,
        "cost_3x_net_points": 800,
        "max_loss_streak": 4,
        "max_drawdown": 250,
    }


def test_walk_forward_window_generation_uses_preferred_windows():
    result = analyze_walk_forward_validation(
        _trades(2021, [10]) + _trades(2022, [10]) + _trades(2023, [10]),
        data=_coverage(),
        symbol="NIFTY",
        strategy_id="demo",
    )

    assert list(result.windows["window_id"]) == [
        "WF_2021_2022_TEST_2023",
        "WF_2022_2023_TEST_2024",
        "WF_2023_2024_TEST_2025",
        "WF_2024_2025_TEST_2026",
    ]
    assert result.summary["walk_forward_windows_total"] == 4


def test_pass_fail_and_insufficient_windows_are_classified():
    trades = (
        _trades(2021, [10, -1])
        + _trades(2022, [10, -1])
        + _trades(2023, [12, -2])
        + _trades(2024, [-5, -5])
        + _trades(2025, [10, -2])
    )

    result = analyze_walk_forward_validation(
        trades,
        data=_coverage("2021-01-01", "2025-12-31"),
        symbol="NIFTY",
        strategy_id="demo",
    )
    by_id = {row["window_id"]: row["status"] for _, row in result.windows.iterrows()}

    assert by_id["WF_2021_2022_TEST_2023"] == PASS
    assert by_id["WF_2022_2023_TEST_2024"] == FAIL
    assert by_id["WF_2024_2025_TEST_2026"] == INSUFFICIENT_DATA
    assert result.summary["walk_forward_label"] == WALK_FORWARD_FAIL
    assert result.summary["walk_forward_block_reason"] == "RECENT_WINDOW_INSUFFICIENT_WITH_PRIOR_FAILURES"


def test_zero_test_trades_window_is_insufficient_data_not_fail():
    result = analyze_walk_forward_validation(
        _trades(2021, [10, -1]) + _trades(2022, [10, -1]) + _trades(2024, [10, -1]),
        data=_coverage(),
        symbol="NIFTY",
        strategy_id="demo",
    )
    first_window = result.windows.loc[result.windows["window_id"] == "WF_2021_2022_TEST_2023"].iloc[0]

    assert first_window["test_trades"] == 0
    assert first_window["test_net_points"] == 0.0
    assert first_window["status"] == INSUFFICIENT_DATA


def test_all_insufficient_windows_get_insufficient_walk_forward_label():
    result = analyze_walk_forward_validation(
        [],
        data=_coverage(),
        symbol="NIFTY",
        strategy_id="demo",
    )

    assert set(result.windows["status"]) == {INSUFFICIENT_DATA}
    assert result.summary["walk_forward_windows_passed"] == 0
    assert result.summary["walk_forward_windows_failed"] == 0
    assert result.summary["usable_walk_forward_windows"] == 0
    assert result.summary["walk_forward_label"] == WALK_FORWARD_INSUFFICIENT_DATA
    assert result.summary["walk_forward_block_reason"] == "NO_USABLE_WALK_FORWARD_WINDOWS"


def test_aggregate_pass_rate_and_dependency_label():
    windows = [
        {"status": PASS, "test_net_points": 100, "test_end": "2023-12-31"},
        {"status": PASS, "test_net_points": 10, "test_end": "2024-12-31"},
        {"status": FAIL, "test_net_points": -5, "test_end": "2025-12-31"},
        {"status": PASS, "test_net_points": 1, "test_end": "2026-12-31"},
    ]

    summary = aggregate_walk_forward_summary(windows, {"symbol": "NIFTY", "strategy_id": "demo"})

    assert summary["walk_forward_windows_total"] == 4
    assert summary["walk_forward_windows_passed"] == 3
    assert summary["walk_forward_windows_failed"] == 1
    assert summary["walk_forward_pass_rate"] == 0.75
    assert summary["walk_forward_label"] == WALK_FORWARD_MIXED


def test_mostly_failed_usable_windows_get_fail_label_even_with_insufficient_windows():
    windows = [
        {"status": FAIL, "test_net_points": -20, "test_end": "2023-12-31"},
        {"status": FAIL, "test_net_points": -10, "test_end": "2024-12-31"},
        {"status": PASS, "test_net_points": 5, "test_end": "2025-12-31"},
        {"status": INSUFFICIENT_DATA, "test_net_points": 0, "test_trades": 0, "test_end": "2026-12-31"},
    ]

    summary = aggregate_walk_forward_summary(windows)

    assert summary["usable_walk_forward_windows"] == 3
    assert summary["insufficient_walk_forward_windows"] == 1
    assert summary["failed_walk_forward_windows"] == 2
    assert summary["passed_walk_forward_windows"] == 1
    assert summary["recent_window_year"] == "2026"
    assert summary["recent_window_test_trades"] == 0
    assert summary["recent_window_status"] == INSUFFICIENT_DATA
    assert summary["walk_forward_label"] == WALK_FORWARD_FAIL
    assert summary["walk_forward_block_reason"] == "RECENT_WINDOW_INSUFFICIENT_WITH_PRIOR_FAILURES"


def test_recent_insufficient_label_when_earlier_usable_windows_have_no_failures():
    windows = [
        {"status": PASS, "test_net_points": 20, "test_end": "2023-12-31"},
        {"status": PASS, "test_net_points": 15, "test_end": "2024-12-31"},
        {"status": INSUFFICIENT_DATA, "test_net_points": 0, "test_trades": 0, "test_end": "2025-12-31"},
        {"status": INSUFFICIENT_DATA, "test_net_points": 0, "test_trades": 0, "test_end": "2026-12-31"},
    ]

    summary = aggregate_walk_forward_summary(windows)

    assert summary["walk_forward_label"] == WALK_FORWARD_RECENT_INSUFFICIENT
    assert summary["walk_forward_block_reason"] == "RECENT_WINDOW_INSUFFICIENT"


def test_walk_forward_all_windows_pass_label():
    windows = [
        {"status": PASS, "test_net_points": 10, "test_end": "2023-12-31"},
        {"status": PASS, "test_net_points": 9, "test_end": "2024-12-31"},
        {"status": PASS, "test_net_points": 8, "test_end": "2025-12-31"},
        {"status": PASS, "test_net_points": 7, "test_end": "2026-12-31"},
    ]

    summary = aggregate_walk_forward_summary(windows)

    assert summary["walk_forward_label"] == WALK_FORWARD_PASS


def test_latest_walk_forward_failure_blocks_phase6a():
    metrics = _passing_metrics()
    metrics.update(
        {
            "walk_forward_windows_total": 4,
            "walk_forward_windows_passed": 3,
            "walk_forward_windows_failed": 1,
            "walk_forward_pass_rate": 0.75,
            "walk_forward_test_net_points_total": 100,
            "walk_forward_recent_window_status": FAIL,
            "walk_forward_label": WALK_FORWARD_FAIL,
        }
    )

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == REJECTED
    assert "walk-forward recent test window failed" in result.reasons


def test_walk_forward_pass_allows_phase6a_when_existing_gates_pass():
    metrics = _passing_metrics()
    metrics.update(
        {
            "walk_forward_windows_total": 4,
            "walk_forward_windows_passed": 4,
            "walk_forward_windows_failed": 0,
            "walk_forward_pass_rate": 1.0,
            "walk_forward_test_net_points_total": 400,
            "walk_forward_recent_window_status": PASS,
            "walk_forward_label": WALK_FORWARD_PASS,
        }
    )

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == PHASE6A_BACKTEST_CANDIDATE


def test_total_walk_forward_test_net_not_positive_blocks_phase6a():
    metrics = _passing_metrics()
    metrics.update(
        {
            "walk_forward_windows_total": 4,
            "walk_forward_windows_passed": 2,
            "walk_forward_windows_failed": 2,
            "walk_forward_pass_rate": 0.5,
            "walk_forward_test_net_points_total": 0,
            "walk_forward_recent_window_status": PASS,
            "walk_forward_label": WALK_FORWARD_FAIL,
        }
    )

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == REJECTED
    assert "walk-forward total test net not positive" in result.reasons


def test_limited_walk_forward_data_returns_needs_more_data_not_phase6a():
    metrics = _passing_metrics()
    metrics.update(
        {
            "walk_forward_windows_total": 4,
            "walk_forward_windows_passed": 3,
            "walk_forward_windows_failed": 0,
            "walk_forward_pass_rate": 0.75,
            "walk_forward_test_net_points_total": 300,
            "walk_forward_recent_window_status": INSUFFICIENT_DATA,
            "walk_forward_label": WALK_FORWARD_INSUFFICIENT_DATA,
        }
    )

    result = evaluate_validation_gates(metrics, min_trades=80)

    assert result.decision == NEEDS_MORE_DATA
    assert result.decision != PHASE6A_BACKTEST_CANDIDATE
    assert result.passed is False


def test_non_pass_walk_forward_labels_do_not_approve_phase6a():
    for label in [WALK_FORWARD_FAIL, WALK_FORWARD_MIXED, WALK_FORWARD_INSUFFICIENT_DATA, WALK_FORWARD_RECENT_INSUFFICIENT]:
        metrics = _passing_metrics()
        metrics.update(
            {
                "walk_forward_windows_total": 4,
                "walk_forward_windows_passed": 1,
                "walk_forward_windows_failed": 1,
                "walk_forward_pass_rate": 0.5,
                "walk_forward_test_net_points_total": 100,
                "walk_forward_recent_window_status": PASS if label != WALK_FORWARD_INSUFFICIENT_DATA else INSUFFICIENT_DATA,
                "walk_forward_label": label,
            }
        )

        result = evaluate_validation_gates(metrics, min_trades=80)

        assert result.decision != PHASE6A_BACKTEST_CANDIDATE
        assert result.passed is False


def test_walk_forward_reports_are_created(tmp_path):
    candidate = {
        "symbol": "NIFTY",
        "strategy_id": "wf_pass",
        "base_strategy_id": "wf_pass",
        "orientation": "ORIGINAL",
        "inverse_of": "",
        "family": "demo",
        "side": "LONG",
        "params_json": "{}",
        "decision": "WATCHLIST",
        "net_points": 300,
        "profit_factor": 2.0,
        "win_rate": 0.6,
        "trades": 30,
        "walk_forward_windows_total": 4,
        "walk_forward_windows_passed": 4,
        "walk_forward_windows_failed": 0,
        "walk_forward_pass_rate": 1.0,
        "walk_forward_test_net_points_total": 100,
        "walk_forward_test_profit_factor": 999.0,
        "walk_forward_recent_window_status": PASS,
        "walk_forward_label": WALK_FORWARD_PASS,
        "usable_walk_forward_windows": 4,
        "insufficient_walk_forward_windows": 0,
        "failed_walk_forward_windows": 0,
        "passed_walk_forward_windows": 4,
        "recent_window_year": 2026,
        "recent_window_test_trades": 10,
        "recent_window_test_net_points": 100,
        "recent_window_status": PASS,
        "walk_forward_block_reason": "NONE",
    }

    paths = write_strategy_lab_reports(
        tmp_path,
        data_summaries=[{"symbol": "NIFTY", "decision": "DATA_USABLE"}],
        candidate_rows=[candidate],
        trades_by_symbol={"NIFTY": pd.DataFrame()},
        monthly_by_symbol={"NIFTY": pd.DataFrame()},
        split_by_symbol={"NIFTY": pd.DataFrame()},
        cost_by_symbol={"NIFTY": pd.DataFrame()},
        walk_forward_windows_by_symbol={
            "NIFTY": pd.DataFrame(
                [{"symbol": "NIFTY", "strategy_id": "wf_pass", "status": PASS, "test_net_points": 100}]
            )
        },
        walk_forward_summary_by_symbol={"NIFTY": pd.DataFrame([candidate])},
        portfolio_summary={},
    )

    master = paths["master"].read_text(encoding="utf-8")

    assert paths["NIFTY_walk_forward_windows"].exists()
    assert paths["NIFTY_walk_forward_summary"].exists()
    assert "WALK-FORWARD VALIDATION" in master
    assert "walk_forward_pass_count: 1" in master
