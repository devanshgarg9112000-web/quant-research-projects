from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

from src.strategy_lab.cli import run_strategy_lab
from src.strategy_lab.config import StrategyLabConfig
from src.strategy_lab.cost_profiles import COST_PROFILE, FALLBACK_COST_POINTS, load_cost_profile, resolve_symbol_cost
from src.strategy_lab.server_runner import ServerRunnerConfig, build_symbol_command


def _write_symbol_fixture(data_dir: Path, symbol: str = "NIFTY", rows: int = 40) -> Path:
    path = data_dir / f"{symbol}_FUT_test.csv"
    start = datetime(2026, 1, 1, 9, 16)
    lines = ["timestamp,open,high,low,close,volume"]
    for index in range(rows):
        timestamp = start + timedelta(minutes=index)
        open_price = 100.0 + index * 0.1
        high = open_price + 1.0
        low = open_price - 1.0
        close = open_price + 0.2
        lines.append(f"{timestamp:%Y-%m-%d %H:%M:%S},{open_price:.2f},{high:.2f},{low:.2f},{close:.2f},100")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _write_cost_profile(path: Path, symbols: dict[str, float]) -> Path:
    items = ", ".join(f'"{symbol}": {{"cost_points": {value}}}' for symbol, value in symbols.items())
    path.write_text(f'{{"version": "TEST_COST_PROFILE", "symbols": {{{items}}}}}', encoding="utf-8")
    return path


def _command_value(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def test_default_per_symbol_cost_profile_loads_research_costs():
    profile = load_cost_profile(Path("config") / "strategy_lab_cost_profiles.json")

    assert profile["NIFTY"] == 2.0
    assert profile["BANKNIFTY"] == 8.0
    assert profile["GOLD"] == 30.0
    assert profile["SILVER"] == 60.0
    assert profile["CRUDMI"] == 0.75


def test_missing_cost_profile_symbol_falls_back_with_warning():
    applied = resolve_symbol_cost("GOLD", 4.5, {"NIFTY": 2.0})

    assert applied.cost_points == 4.5
    assert applied.source == FALLBACK_COST_POINTS
    assert "cost profile missing symbol GOLD" in applied.warning


def test_server_runner_passes_symbol_specific_cost_points(tmp_path):
    profile_path = _write_cost_profile(tmp_path / "costs.json", {"NIFTY": 3.25, "GOLD": 31.5})
    config = ServerRunnerConfig(
        data_dir=tmp_path,
        symbols=("NIFTY", "GOLD"),
        output_root=tmp_path / "run",
        cost_points=0.5,
        cost_profile=profile_path,
        python_executable="python",
    )

    nifty_command = build_symbol_command(config, "NIFTY")
    gold_command = build_symbol_command(config, "GOLD")

    assert _command_value(nifty_command, "--cost-points") == "3.25"
    assert _command_value(gold_command, "--cost-points") == "31.5"
    assert _command_value(nifty_command, "--cost-profile") == str(profile_path)


def test_strategy_lab_reports_include_applied_cost(tmp_path):
    _write_symbol_fixture(tmp_path)
    profile_path = _write_cost_profile(tmp_path / "costs.json", {"NIFTY": 3.25})
    output_dir = tmp_path / "out"

    run_strategy_lab(
        StrategyLabConfig(
            data_dir=tmp_path,
            symbols=("NIFTY",),
            output_dir=output_dir,
            max_variants=1,
            cost_points=0.5,
            cost_profile=profile_path,
            max_bars=20,
        )
    )

    master = (output_dir / "strategy_lab_v3_master_report.txt").read_text(encoding="utf-8")
    best = (output_dir / "NIFTY_best_report.txt").read_text(encoding="utf-8")

    assert "APPLIED COSTS" in master
    assert "- NIFTY: applied_cost_points=3.25 cost_profile_source=COST_PROFILE" in master
    assert "applied_cost_points: 3.25" in best
    assert "cost_profile_source: COST_PROFILE" in best
    assert "NOT_REAL_MONEY_READY" in master
    assert COST_PROFILE in best


def test_cost_profile_changes_add_no_broker_order_or_ready_text():
    root = Path(__file__).resolve().parents[2] / "src" / "strategy_lab"
    text = "\n".join(path.read_text(encoding="utf-8") for path in root.rglob("*.py"))
    lowered = text.lower()
    forbidden_order_word = "place" + "_order"
    ready_text = "REAL" + "_MONEY_READY"

    assert forbidden_order_word not in lowered
    assert "from src." + "brokers" not in lowered
    assert "import kite" + "connect" not in lowered
    assert f'"{ready_text}"' not in text
    assert f"'{ready_text}'" not in text
