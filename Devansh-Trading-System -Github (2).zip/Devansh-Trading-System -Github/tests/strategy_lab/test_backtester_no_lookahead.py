from __future__ import annotations

from datetime import date, time

import pandas as pd

from src.strategy_lab.backtester import backtest_strategy
from src.strategy_lab.session_filters import apply_valid_market_session_filter
from src.strategy_lab.strategy_primitives import inverse_strategy_variant, make_strategy_variant


def _bars(rows: list[tuple[str, float, float, float, float, float]]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {"timestamp": timestamp, "open": open_, "high": high, "low": low, "close": close, "volume": volume}
            for timestamp, open_, high, low, close, volume in rows
        ]
    )


def test_entry_is_next_candle_not_signal_candle():
    frame = _bars(
        [
            ("2026-01-01 09:16", 100, 200, 99, 101, 10),
            ("2026-01-01 09:17", 110, 111, 109, 110, 10),
            ("2026-01-01 09:18", 110, 112, 109, 111, 10),
        ]
    )
    variant = make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 50, "target_points": 1})
    signals = pd.Series([True, False, False])

    result = backtest_strategy(
        frame,
        variant,
        symbol="NIFTY",
        cost_points=0,
        signal_series=signals,
        session_close_by_day={date(2026, 1, 1): time(15, 29)},
    )

    assert len(result.trades) == 1
    assert result.trades[0].signal_time.strftime("%H:%M") == "09:16"
    assert result.trades[0].entry_time.strftime("%H:%M") == "09:17"
    assert result.trades[0].entry_price == 110


def test_same_entry_candle_target_and_sl_uses_stop_first():
    frame = _bars(
        [
            ("2026-01-01 09:16", 100, 101, 99, 100, 10),
            ("2026-01-01 09:17", 100, 106, 94, 100, 10),
            ("2026-01-01 09:18", 100, 101, 99, 100, 10),
        ]
    )
    variant = make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 5, "target_points": 5})

    result = backtest_strategy(
        frame,
        variant,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False]),
        session_close_by_day={date(2026, 1, 1): time(15, 29)},
    )

    assert result.trades[0].exit_reason == "STOP_LOSS"
    assert result.trades[0].exit_price == 95


def test_zero_volume_entry_candle_is_skipped():
    frame = _bars(
        [
            ("2026-01-01 09:16", 100, 101, 99, 100, 10),
            ("2026-01-01 09:17", 100, 101, 99, 100, 0),
            ("2026-01-01 09:18", 100, 101, 99, 100, 10),
        ]
    )
    variant = make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 5, "target_points": 5})

    result = backtest_strategy(frame, variant, symbol="NIFTY", cost_points=0, signal_series=pd.Series([True, False, False]))

    assert result.trades == []


def test_forced_exit_uses_configured_session_close():
    frame = _bars(
        [
            ("2026-01-01 09:16", 100, 101, 99, 100, 10),
            ("2026-01-01 09:17", 100, 101, 99, 100, 10),
            ("2026-01-01 09:18", 100, 101, 99, 100, 10),
            ("2026-01-01 09:19", 100, 101, 99, 100.5, 10),
        ]
    )
    variant = make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 50, "target_points": 50, "max_hold_minutes": 120})

    result = backtest_strategy(
        frame,
        variant,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False, False]),
        session_close_by_day={date(2026, 1, 1): time(9, 19)},
        forced_exit_buffer_minutes=0,
    )

    assert result.trades[0].exit_reason == "FORCED_EXIT"
    assert result.trades[0].exit_time.strftime("%H:%M") == "09:19"


def test_inverse_entry_is_next_candle_and_recalculates_short_risk():
    frame = _bars(
        [
            ("2026-01-01 09:16", 100, 101, 99, 100, 10),
            ("2026-01-01 09:17", 100, 104, 96, 101, 10),
            ("2026-01-01 09:18", 101, 102, 94, 95, 10),
        ]
    )
    original = make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 5, "target_points": 3})
    inverse = inverse_strategy_variant(original)

    original_result = backtest_strategy(
        frame,
        original,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False]),
        session_close_by_day={date(2026, 1, 1): time(15, 29)},
    )
    inverse_result = backtest_strategy(
        frame,
        inverse,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False]),
        session_close_by_day={date(2026, 1, 1): time(15, 29)},
    )

    trade = inverse_result.trades[0]
    assert trade.side == "SHORT"
    assert trade.signal_time.strftime("%H:%M") == "09:16"
    assert trade.entry_time.strftime("%H:%M") == "09:17"
    assert trade.entry_price == 100
    assert trade.sl == 105
    assert trade.target == 97
    assert trade.exit_price != original_result.trades[0].exit_price


def test_inverse_stop_first_zero_volume_and_forced_exit_rules():
    original = make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 5, "target_points": 5, "max_hold_minutes": 120})
    inverse = inverse_strategy_variant(original)
    both_hit = _bars(
        [
            ("2026-01-01 09:16", 100, 101, 99, 100, 10),
            ("2026-01-01 09:17", 100, 106, 94, 100, 10),
            ("2026-01-01 09:18", 100, 101, 99, 100, 10),
        ]
    )

    both_hit_result = backtest_strategy(
        both_hit,
        inverse,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False]),
        session_close_by_day={date(2026, 1, 1): time(15, 29)},
    )
    zero_volume_result = backtest_strategy(
        _bars(
            [
                ("2026-01-01 09:16", 100, 101, 99, 100, 10),
                ("2026-01-01 09:17", 100, 101, 99, 100, 0),
                ("2026-01-01 09:18", 100, 101, 99, 100, 10),
            ]
        ),
        inverse,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False]),
    )
    forced_exit_result = backtest_strategy(
        _bars(
            [
                ("2026-01-01 09:16", 100, 101, 99, 100, 10),
                ("2026-01-01 09:17", 100, 101, 99, 100, 10),
                ("2026-01-01 09:18", 100, 101, 99, 100, 10),
            ]
        ),
        inverse,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False, False]),
        session_close_by_day={date(2026, 1, 1): time(9, 18)},
        forced_exit_buffer_minutes=0,
    )

    assert both_hit_result.trades[0].exit_reason == "STOP_LOSS"
    assert both_hit_result.trades[0].exit_price == 105
    assert zero_volume_result.trades == []
    assert forced_exit_result.trades[0].exit_reason == "FORCED_EXIT"


def test_inverse_uses_filtered_market_session_data():
    raw = _bars(
        [
            ("2026-01-01 09:16", 100, 101, 99, 100, 10),
            ("2026-01-01 09:17", 100, 101, 99, 100, 10),
            ("2026-01-01 15:30", 100, 150, 50, 100, 10),
        ]
    )
    filtered = apply_valid_market_session_filter(raw, "NIFTY").filtered
    inverse = inverse_strategy_variant(make_strategy_variant("time_of_day_momentum", "LONG", {"sl_points": 5, "target_points": 5}))

    result = backtest_strategy(
        filtered,
        inverse,
        symbol="NIFTY",
        cost_points=0,
        signal_series=pd.Series([True, False]),
        session_close_by_day={date(2026, 1, 1): time(15, 29)},
    )

    assert all(trade.exit_time.strftime("%H:%M") != "15:30" for trade in result.trades)
