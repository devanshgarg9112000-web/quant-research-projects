from __future__ import annotations

from pathlib import Path

from src.data_collection.kite_data_quality_gate import (
    FEATURE_GENERATION_PROBLEM,
    INVESTIGATE_BEFORE_NEXT_RUN,
    MARKET_CLOSED_OR_NO_LIVE_DATA,
    READY_FOR_FORWARD_VALIDATION,
    SYMBOL_RESOLUTION_PROBLEM,
    TOKEN_OR_CREDENTIAL_PROBLEM,
    USABLE_QUOTE_ONLY,
    KiteDataQualityInput,
    evaluate_kite_data_quality,
)


def _quality_input(**overrides) -> KiteDataQualityInput:
    values = {
        "dry_run": False,
        "credential_status": "PRESENT",
        "symbol_resolution_status": "RESOLVED",
        "quote_check_status": "OK",
        "depth_check_status": "PRESENT",
        "market_data_status": "FULL_DEPTH",
        "tick_rows_recorded": 100,
        "depth_rows_recorded": 500,
        "feature_rows_generated": 100,
        "feature_output_csv_data_rows": 100,
        "feature_mode": "DEPTH_ORDERFLOW_LITE",
        "synthetic_rows_ignored": 20,
        "stale_rows_removed": 5,
        "forward_validation_decision": "RESEARCH_ONLY",
        "synthetic_rows_used": 0,
    }
    values.update(overrides)
    return KiteDataQualityInput(**values)


def test_healthy_tick_depth_features_are_ready_for_forward_validation():
    result = evaluate_kite_data_quality(_quality_input())

    assert result.status == READY_FOR_FORWARD_VALIDATION
    assert result.usable_for_forward_validation is True
    assert result.usable_for_orderflow_features is True
    assert result.needs_investigation is False
    assert "RESEARCH_ONLY" in result.reason


def test_tick_only_is_usable_quote_only():
    result = evaluate_kite_data_quality(
        _quality_input(
            depth_check_status="MISSING",
            market_data_status="PARTIAL_QUOTE",
            depth_rows_recorded=0,
            feature_rows_generated=25,
            feature_output_csv_data_rows=25,
            feature_mode="QUOTE_LITE",
        )
    )

    assert result.status == USABLE_QUOTE_ONLY
    assert result.usable_for_forward_validation is True
    assert result.usable_for_orderflow_features is False
    assert result.needs_investigation is False


def test_no_ticks_reports_market_closed_or_no_live_data():
    result = evaluate_kite_data_quality(
        _quality_input(
            market_data_status="NO_LIVE_TICKS",
            tick_rows_recorded=0,
            depth_rows_recorded=0,
            feature_rows_generated=0,
            feature_output_csv_data_rows=0,
            feature_mode="NO_FEATURES",
        )
    )

    assert result.status == MARKET_CLOSED_OR_NO_LIVE_DATA
    assert "No live tick rows" in result.reason
    assert result.needs_investigation is False


def test_missing_token_in_real_mode_is_credential_problem():
    result = evaluate_kite_data_quality(
        _quality_input(
            dry_run=False,
            credential_status="MISSING",
            tick_rows_recorded=0,
            depth_rows_recorded=0,
            feature_rows_generated=0,
            feature_output_csv_data_rows=0,
        )
    )

    assert result.status == TOKEN_OR_CREDENTIAL_PROBLEM
    assert result.needs_investigation is True
    assert "token" in result.next_action.lower()


def test_unresolved_symbol_is_resolution_problem():
    result = evaluate_kite_data_quality(
        _quality_input(
            symbol_resolution_status="NOT_FOUND",
            tick_rows_recorded=0,
            depth_rows_recorded=0,
            feature_rows_generated=0,
            feature_output_csv_data_rows=0,
        )
    )

    assert result.status == SYMBOL_RESOLUTION_PROBLEM
    assert result.needs_investigation is True


def test_zero_features_with_tick_and_depth_is_feature_problem():
    result = evaluate_kite_data_quality(
        _quality_input(
            feature_rows_generated=0,
            feature_output_csv_data_rows=0,
            feature_mode="NO_FEATURES",
        )
    )

    assert result.status == FEATURE_GENERATION_PROBLEM
    assert result.usable_for_orderflow_features is False
    assert "feature builder" in result.next_action.lower()


def test_report_csv_count_mismatch_needs_investigation():
    result = evaluate_kite_data_quality(
        _quality_input(
            feature_rows_generated=5,
            feature_output_csv_data_rows=4,
        )
    )

    assert result.status == INVESTIGATE_BEFORE_NEXT_RUN
    assert result.needs_investigation is True
    assert "does not match" in result.reason


def test_contract_mismatch_downgrades_data_quality_gate():
    result = evaluate_kite_data_quality(
        _quality_input(
            contract_consistency_status="CONTRACT_MISMATCH_INVESTIGATE",
            feature_output_real_contract_count=1,
            report_csv_contract_match=True,
        )
    )

    assert result.status == INVESTIGATE_BEFORE_NEXT_RUN
    assert result.needs_investigation is True
    assert "contract" in result.reason.lower()


def test_real_mode_synthetic_rows_used_needs_investigation():
    result = evaluate_kite_data_quality(_quality_input(synthetic_rows_used=1))

    assert result.status == INVESTIGATE_BEFORE_NEXT_RUN
    assert "synthetic" in result.reason.lower()


def test_kite_data_collection_modules_have_no_order_execution_path_text():
    data_collection_dir = Path(__file__).resolve().parents[1] / "src" / "data_collection"

    for module_path in data_collection_dir.glob("kite_*.py"):
        assert "place_order" not in module_path.read_text(encoding="utf-8")
