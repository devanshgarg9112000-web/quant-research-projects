from src.data.sample_data import generate_sample_candles
from src.indicators.volume_profile import calculate_volume_profile


def test_volume_profile_returns_core_levels():
    profile = calculate_volume_profile(generate_sample_candles())
    assert profile["poc"]
    assert profile["vah"] >= profile["val"]
