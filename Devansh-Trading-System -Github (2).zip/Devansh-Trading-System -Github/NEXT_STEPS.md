# Next Steps

## Completed Modules

- Paper-first `python run.py` flow using deterministic sample candles and ticks.
- Core config files for settings, risk, instruments, and strategies.
- Dataclass models for signals, trades, orders, and candles.
- Indicators for VWAP, key levels, opening range, support/resistance, approximate volume profile, delta, CVD, cluster, absorption, and order flow.
- Market regime routing and strategy engine with candidate, rejection, and conflict-resolution output.
- Risk engine with kill-switch, daily limit, reward-risk, quantity, spread, and live-trading gates.
- Paper broker, journal logging, console/Telegram fallback alerting, and disabled-by-default WhatsApp trade alerts.
- Backtest engine with combined system report and individual strategy-wise review flags.
- Safe manual Kite daily login helper:
  - `python -m src.brokers.kite_broker --login`
  - `python -m src.brokers.kite_broker --test-profile`
  - `python -m src.brokers.kite_broker --test-quote --symbols "NSE:RELIANCE,NSE:INFY"`
  - Saves the generated login URL and daily access token locally under `.tokens`, while printing only masked token/API-key previews.
  - Read-only Kite commands may fetch profile, margins, positions, quotes, and instruments summary. They do not place orders.
- Kite order dry-run preview:
  - `python -m src.execution.kite_order_preview --symbol "NSE:RELIANCE" --side BUY --quantity 1 --order-type MARKET`
  - Validates order fields and prints a preview only. It does not call Kite `place_order`.
- NIFTY pre-open / opening option mispricing scanner:
  - `python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry 2026-06-25 --default-iv 0.18`
  - `python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry 2026-06-25 --default-iv 0.18 --use-kite-quotes --strikes-around-atm 5`
  - `python -m src.scanners.nifty_preopen_scanner --list-kite-nifty-options --spot 23500`
  - `python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --strikes-around-atm 5`
  - `python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --auto-spot --strikes-around-atm 5`
  - `python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --auto-spot --strikes-around-atm 5 --save-report`
  - Uses Black-Scholes fair-value estimates, quote/depth filters, and dry-run scanner rows only.
  - Default mode uses safe sample snapshots. Kite mode uses read-only instruments/quotes after manual Kite login. Auto spot reads `NSE:NIFTY 50` through read-only quotes. Neither mode places orders.
  - Prints model status, approximate ATM implied IV, default IV input, effective IV used, and IV source.
  - In Kite quote mode, valid ATM CE/PE market-implied IV is used for pricing; `--default-iv` is the fallback if market IV cannot be calculated.
  - Marks every row `execution_allowed=false`; SELL rows are `hedge_required=true` and blocked as dry-run only.
  - Includes an opening spike limit-order planner using visible bid/ask depth, configured tick size, model-fair exit reference, and estimated gross edge.
  - Planner prices do not guarantee fills. Visible orders can be cancelled, disappear, or move before matching.
  - Saves the latest text and CSV scanner reports under `reports/scanner_reports/`.
  - Warning mode prints a short reason and suppresses rows by default when reference price/IV still looks miscalibrated.
- TrueData WebSocket/REST integration based on uploaded docs, still disabled by default.
- TrueData unit tests are isolated from local `.env` credentials and do not open real network connections.
- TrueData PAPER live-data run mode:
  - `python run.py --data-feed truedata --symbols "NIFTY-I,RELIANCE" --seconds 60`
  - Collects normalized live ticks, builds short candles/order-flow features, and does not place broker orders.
- TrueData PAPER live-data reporting:
  - Prints a final run summary.
  - Saves `reports/daily_trade_reports/latest_live_paper_report.txt`.
  - Refreshes `reports/daily_trade_reports/latest_paper_signals.csv` with `live_trading=false` for PAPER signals.
  - Appends `FINAL PAPER SIGNAL DASHBOARD` and saves dedicated text/CSV dashboard files.
  - Records normalized ticks to `data/ticks/latest_truedata_ticks.csv`.
  - Appends deduped daily per-symbol tick files under `data/ticks/daily/YYYY-MM-DD/SYMBOL_ticks.csv` for future multi-day backtests.
- Replay PAPER mode:
  - `python run.py --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I"`
  - Fast development path: filters requested symbols, rebuilds the same candles/order-flow/cluster features, runs the same PAPER strategy and risk path, and never places broker orders.
  - Reports the resolved tick file and keeps `execution_allowed=false`.
  - Prints the final PAPER dashboard for fast accepted/rejected/no-signal review.
- Launch 1 strategy-wise saved-tick backtest runner:
  - `python -m src.backtesting.strategy_backtest_runner --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --strategies all --exit-at-end true`
  - Multi-day daily tick directory example: `python -m src.backtesting.strategy_backtest_runner --tick-dir data\ticks\daily --symbols "GOLD-I,SILVER-I" --strategies all`
  - Historical TrueData tick directory example: `python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I,SILVER-I" --strategies all`
  - Historical Kite/TrueData bar directory example: `python -m src.backtesting.strategy_backtest_runner --bar-dir data\historical\kite\candles --symbols "NSE:NIFTY 50" --strategies all`
  - Single strategy example: `python -m src.backtesting.strategy_backtest_runner --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --strategies cluster_imbalance_trap`
  - Realistic cluster example: `python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I" --strategies cluster_imbalance_trap --exit-at-end true --one-trade-at-a-time true --signal-cooldown-seconds 300 --max-trades-per-day 20 --slippage-points 5 --cost-per-trade 50 --entry-delay-ticks 1`
  - Quality-filtered four-day example: `python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I" --strategies cluster_imbalance_trap --from-date 2026-06-15 --to-date 2026-06-18 --exit-at-end true --one-trade-at-a-time true --signal-cooldown-seconds 300 --max-trades-per-day 20 --slippage-points 5 --cost-per-trade 50 --entry-delay-ticks 1 --min-score 8.8 --min-trap-strength 0.7 --same-zone-cooldown-seconds 300 --direction-flip-cooldown-seconds 300`
  - Rebuilds the same 15-second replay candles, runs one strategy at a time, applies the existing risk engine, and simulates PAPER-only target/stop/open/END_EXIT outcomes.
  - Applies cluster signal-quality checks before risk: score, trap strength, LTQ/volume, stop/target distance, market-mode alignment, direction-flip cooldown, and same-zone cooldown.
  - Reports raw signals, quality accepted/rejected counts, reason-specific counters, risk rejections, accepted trades, and `SIGNAL_FILTERING_ACTIVE`.
  - Defaults to one active trade at a time, 300-second cooldown, 20 trades/day, and one future tick entry delay; repeated candidates are counted as `overlap_skipped`, `cooldown_skipped`, or `daily_limit_skipped`.
  - Trade rows include entry time, outcome, adjusted entry/exit, gross/net PnL, cost, MFE, and MAE; `--exit-at-end true` closes unfinished trades at the final available tick.
  - Saves `reports/backtests/latest_strategy_backtest_summary.csv`, `reports/backtests/latest_strategy_backtest_trades.csv`, and `reports/backtests/latest_strategy_backtest_report.txt`.
  - Marks weak sample sizes as `INSUFFICIENT_SAMPLE` and excessive repeated raw signals as `HIGH_SIGNAL_FREQUENCY_WARNING`; a tiny saved tick file or inflated raw win rate is only a mechanics check, not proof that a strategy works.
  - Broker orders remain disabled and `execution_allowed=false`.
- Launch 1 strategy verification:
  - Generates `reports/strategy_verification/latest_strategy_approval_report.txt` and `.csv`.
  - APPROVED requires positive net PnL, PF >= 1.30, at least 20 trades, and no severe frequency/overfitting warning.
  - WhatsApp delivery is gated by `config/approved_strategies.yaml`; WATCHLIST is blocked by default and REJECTED/unknown strategies are always blocked.
  - Bar diagnostics are saved under `reports/strategy_diagnostics/` and distinguish schema, indicator, score, cluster-gate, and risk causes.
- Launch 1 historical data downloader:
  - TrueData ticks: `python -m src.data_collection.historical_data_downloader --source truedata --data-type ticks --symbols "GOLD-I,SILVER-I" --from-date 2026-06-01 --to-date 2026-06-18`
  - TrueData bars: `python -m src.data_collection.historical_data_downloader --source truedata --data-type bars --symbols "GOLD-I,SILVER-I" --from-date 2026-06-01 --to-date 2026-06-18 --interval 1minute`
  - Kite candles: `python -m src.data_collection.historical_data_downloader --source kite --data-type candles --symbols "NSE:NIFTY 50,NFO:NIFTY..." --from-date 2026-06-01 --to-date 2026-06-18 --interval minute`
  - Saves normalized historical files under `data/historical/truedata/ticks`, `data/historical/truedata/bars`, and `data/historical/kite/candles`.
  - TrueData historical ticks are preferred for cluster/imbalance/order-flow research. Kite historical candles are for candle-based strategy validation.
  - Downloader is read-only, skips duplicates, prints file paths/row counts only, never prints credentials, and never places broker orders.
- MCX lot-aware PAPER sizing:
  - Reads `point_value`, `min_qty`, and `lot_size` from `config/instruments.yaml`.
  - Rounds quantity down to a valid lot without exceeding the configured risk budget.
  - Rejects the signal with detailed sizing fields when minimum-quantity risk is too high.
  - Remains manual-review only with no automatic execution and `execution_allowed=false`.
- Launch 1 all-day PAPER signal monitor:
  - Replay: `python -m src.monitors.live_signal_monitor --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --scan-interval 60`
  - TrueData: `python -m src.monitors.live_signal_monitor --data-feed truedata --symbols "GOLD-I,SILVER-I" --scan-interval 60 --window-seconds 300 --record-ticks`
  - Reuses the existing strategy/risk engine, writes `reports/signals/live_signal_log.csv`, and refreshes `reports/signals/latest_live_signal_dashboard.txt`.
  - `--record-ticks` refreshes `data/ticks/latest_truedata_ticks.csv` and appends deduped daily files under `data/ticks/daily/`.
  - Suppresses duplicate accepted/rejected log rows for five minutes.
  - Remains PAPER-only and manual-execution-only with broker orders disabled and `execution_allowed=false`.
  - Workflow: run monitor → receive/log signal → manually review → manually execute elsewhere if desired → no algo orders.
  - WhatsApp dry-run: add `--alert-channel whatsapp-dry-run`.
  - Writes `reports/alerts/latest_whatsapp_alert_preview.txt` and `reports/alerts/whatsapp_alert_log.csv`.
  - Optional live WhatsApp requires `config/alerts.yaml` plus `ENABLE_WHATSAPP_ALERTS=true` and environment-only Cloud API credentials.
  - WhatsApp is notification-only; it never authorizes or triggers an order.
  - Bounded replay test: add `--max-runtime-seconds 180 --heartbeat-interval-seconds 60`.
  - Omit `--max-runtime-seconds` for continuous TrueData monitoring; stop safely with Ctrl+C.
  - Optional `--log-file reports\signals\monitor_console.log` copies console output.
  - Heartbeat: `reports/signals/latest_monitor_heartbeat.txt`.
  - Sanitized scan errors: `reports/signals/monitor_error_log.csv`; one failed scan does not stop later safe scans.
  - WhatsApp dry-run heartbeat/error previews remain local files only.
- Cluster / footprint / imbalance diagnostics:
  - `python -m src.indicators.cluster_diagnostics --symbols "GOLD-I,SILVER-I" --seconds 300 --bucket-seconds 15`
  - Saves `reports/daily_trade_reports/latest_cluster_diagnostics.txt`.
  - Records normalized ticks to `data/ticks/latest_truedata_ticks.csv` and appends daily tick files.
  - Labels inferred volume-at-price and imbalance values as `ESTIMATED`.

## Pending Modules

- Production-grade Kite order placement remains intentionally blocked.
- Real TrueData stream checks are manual only:
  - `python -m src.data_feeds.truedata_feed --test-connection`
  - `python -m src.data_feeds.truedata_feed --test-stream --symbols "NIFTY-I,RELIANCE" --seconds 30`
- Real historical candle and tick data ingestion.
- Broker/session health monitor.
- More complete transaction-cost, slippage, and brokerage modeling.
- Walk-forward, out-of-sample, and longer-period backtest validation.
- Replay UI or visual review tooling.

## How To Run

```powershell
python run.py
pytest
```

The project includes `pytest.ini`, so `pytest` works from the project root without setting `PYTHONPATH` manually.

For the exact verification requested after the TrueData test isolation fix:

```powershell
python run.py
python -m pytest -q
python -m src.data_feeds.truedata_feed --test-connection
```

TrueData PAPER live-data mode:

```powershell
python run.py --data-feed truedata --symbols "NIFTY-I,RELIANCE" --seconds 60
```

Replay saved TrueData ticks in PAPER mode:

```powershell
python run.py --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I"
```

Strategy-wise saved-tick PAPER backtest:

```powershell
python -m src.backtesting.strategy_backtest_runner --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --strategies all --exit-at-end true
python -m src.backtesting.strategy_backtest_runner --tick-dir data\ticks\daily --symbols "GOLD-I,SILVER-I" --strategies all
python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I,SILVER-I" --strategies all
python -m src.backtesting.strategy_backtest_runner --bar-dir data\historical\kite\candles --symbols "NSE:NIFTY 50" --strategies all
python -m src.backtesting.strategy_backtest_runner --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --strategies cluster_imbalance_trap
```

Development cadence:

- Replay saved ticks and review the final dashboard for fast repeated MCX signal testing.
- Run the Strategy Research Lab with a chronological 70/30 train/validation split before promoting any new strategy. Treat validation failure, low samples, high-frequency output, and train/validation divergence as blockers rather than tuning targets.
- Use the focused GOLD-I VWAP rejection deep dive before revisiting its WATCHLIST status. Require complete sessions, at least 20 combined trades, positive out-of-sample evidence, and profitable nearby parameter settings; never promote a five-trade result.
- Run strategy-wise saved-tick or daily-directory backtests with quality, overlap, cooldown, and daily-limit controls; treat `INSUFFICIENT_SAMPLE` and `HIGH_SIGNAL_FREQUENCY_WARNING` as hard warnings.
- Download larger historical TrueData tick datasets before judging cluster/imbalance performance; use Kite candles only for candle-based strategy validation.
- Run TrueData live for 30-60 seconds only as the final smoke test.
- Run the TrueData monitor with `--record-ticks` during Launch 1 to build full-day tick files.
- Reserve a 900-second TrueData PAPER capture for final verification, then replay or backtest the saved session.
- Use the monitor dashboard for all-day PAPER observation; stop it with Ctrl+C.

Cluster diagnostics:

```powershell
python -m src.indicators.cluster_diagnostics --symbols "GOLD-I,SILVER-I" --seconds 300 --bucket-seconds 15
```

Kite manual login and read-only checks:

```powershell
python -m src.brokers.kite_broker --login
python -m src.brokers.kite_broker --test-profile
python -m src.brokers.kite_broker --test-quote --symbols "NSE:RELIANCE,NSE:INFY"
```

Kite-first data collection after the TrueData trial:

```powershell
python -m src.data_collection.kite_live_recorder --symbols "GOLD-I" --duration-seconds 3600 --record-depth true
python -m src.data_collection.kite_historical_downloader --symbols "GOLD-I" --from-date 2026-06-01 --to-date 2026-06-19 --interval minute
python -m src.data_collection.kite_orderflow_features --symbols "GOLD-I" --date 2026-06-19
```

Review `reports\kite_data_collection\latest_kite_data_collection_report.txt` after each command. Kite forward-validation rows must stay research-only with `provider=KITE`, `execution_allowed=false`, and production alerts blocked.

Kite order dry-run preview:

```powershell
python -m src.execution.kite_order_preview --symbol "NSE:RELIANCE" --side BUY --quantity 1 --order-type MARKET
```

NIFTY pre-open option mispricing scanner:

```powershell
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry 2026-06-25 --default-iv 0.18
python -m src.scanners.nifty_preopen_scanner --list-kite-nifty-options --spot 23500
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry 2026-06-25 --default-iv 0.18 --use-kite-quotes --strikes-around-atm 5
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --strikes-around-atm 5
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --auto-spot --strikes-around-atm 5
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --auto-spot --strikes-around-atm 5 --save-report
```

## When TrueData Docs And Trial Details Arrive

- Confirm the exact auth flow, REST endpoints, WebSocket/TCP streaming method, symbol format, and rate limits from official TrueData material.
- Add credentials only to `.env`.
- Keep `enable_true_data: false` until sample-mode and paper-mode checks still pass.
- Validate tick quality, bid/ask availability, timestamp ordering, duplicate ticks, and reconnect behavior before using order-flow strategies.
- Use replay mode as the default fast development loop without reconnecting to TrueData and without any broker order path.
- Use short live tests for connectivity/data-normalization smoke checks; reserve 900-second captures for final verification.
- Keep automated tests mocked/isolated. Real TrueData connections should be made only through the explicit manual commands above.
- WhatsApp alerts remain disabled by default. Enable later only through config plus `.env` credentials after PAPER reports are stable.
- Do not treat estimated cluster diagnostics as proof of institutional footprint quality; use them to decide whether deeper tick/depth capture is needed.
- Kite read-only checks are for connectivity validation only. They are not permission to enable live trading or order placement.
- Kite order preview is dry-run only. It validates and displays a payload but does not place a real order.
- The NIFTY pre-open scanner is dry-run only. Kite quote mode needs a valid local daily Kite token from `python -m src.brokers.kite_broker --login`; missing or expired sessions should be handled by rerunning login/read-only setup. Manual spot/default IV can create false signals. Prefer `--auto-spot` in Kite mode. Kite mode now calibrates fair-value pricing with ATM market-implied IV when available and falls back to `--default-iv` only when IV cannot be calculated. The opening spike planner estimates a visible-depth limit price and model-fair exit reference, but does not guarantee a fill; visible orders may disappear or be cancelled. Option SELL rows are blocked and hedge-required; no naked option selling or automatic execution is supported. Treat `Model Status: WARNING` and its `Warning Reason` as a hard manual-review warning. Fair value is model-based and can be wrong; opening books can be misleading due to cancellations, thin depth, spread changes, IV changes, and slippage.

## Safety Warnings

- Sample backtest results are not proof of profitability.
- Strategy Research Lab ranking is PAPER research only. An apparently profitable training result is not approval unless validation and combined results also pass the strict gate; isolated research IDs do not authorize WhatsApp alerts.
- Strategy-wise saved-tick backtests from a small CSV are not proof of profitability; they are Launch 1 PAPER diagnostics only.
- High raw signal counts or high raw win rates can be misleading if repeated/overlapping candidates are not filtered; use the realistic backtest controls and review skipped-signal counts.
- Cluster quality rejection is a PAPER research filter, not permission to execute. Review quality reasons, risk output, and market context manually.
- Live trading is disabled by default.
- Replay is PAPER only and must not be treated as live execution.
- The final signal dashboard is PAPER-only summary output, not an execution interface; automatic execution remains disabled.
- The Launch 1 all-day monitor is PAPER-only and manual-execution-only. Its CSV is a signal observation log, not an order queue.
- MCX lot-aware sizing is PAPER guidance only. A minimum quantity can still be rejected when its stop risk exceeds the allowed risk amount.
- Kite profile and quote checks are read-only; no broker orders should be placed from these commands.
- Kite order preview is not a live order command.
- NIFTY option scanner rows are research diagnostics only, not live order instructions.
- Scanner SELL rows require a hedge and are never execution-ready; naked option selling is not supported.
- A model warning means the scanner is not execution-ready; calibrated spot/forward reference, IV sanity, liquidity filters, and manual review are required.
- Do not enable live trading until real-data backtests, walk-forward checks, broker-session checks, paper trading, and risk logs have been reviewed.
- No credentials should be committed or shared.
