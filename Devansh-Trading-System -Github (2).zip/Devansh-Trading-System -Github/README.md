# Devansh Trading System

Devansh Trading System is a paper-first modular Python trading system for Indian markets. It is built for safe research, sample-data execution, backtesting, paper trading, and future broker integration after proper approvals, credentials, and live checks.

## Safety First

Live trading is disabled by default. The default mode is `PAPER`, the default broker is `PaperBroker`, and real order placement is blocked unless every live-trading guard is explicitly enabled and approved.

The first run does not need Kite, TrueData, Telegram, or WhatsApp credentials.

## Windows Setup

```powershell
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
python run.py
pytest
```

## Environment

Copy `.env.example` to `.env` only when you are ready to add credentials. Never commit `.env`.

WhatsApp alerts are disabled by default. To use them later, set both `config/settings.yaml` `enable_whatsapp_alerts: true` and `.env` `WHATSAPP_ALERTS_ENABLED=true`, then add the Twilio WhatsApp credentials. WhatsApp only sends trade messages; it never places trades.

## Kite Connect

Kite support is limited to safe manual login and read-only account/data checks. No Selenium login automation is used, and no order command is available.

Add Kite credentials only to local `.env`:

```text
KITE_API_KEY=
KITE_API_SECRET=
KITE_ACCESS_TOKEN=
```

Manual daily login:

```powershell
python -m src.brokers.kite_broker --login
```

This generates the official Kite login URL, saves the full URL locally under `.tokens`, prints only a masked preview, and asks you to manually paste the `request_token` or redirected URL. The access token is saved locally for the trading day and is never printed in full.

Read-only profile check:

```powershell
python -m src.brokers.kite_broker --test-profile
```

Read-only quote check:

```powershell
python -m src.brokers.kite_broker --test-quote --symbols "NSE:RELIANCE,NSE:INFY"
```

These commands may read profile, margins, positions, quotes, and an instruments summary if available. They do not place orders.

Kite order dry-run preview:

```powershell
python -m src.execution.kite_order_preview --symbol "NSE:RELIANCE" --side BUY --quantity 1 --order-type MARKET
```

The preview validates symbol, side, quantity, order type, and optional LIMIT price, then prints the Kite-style order payload in plain English. It is dry-run only and does not call Kite `place_order`. Live trading stays disabled by default with `ENABLE_LIVE_TRADING=false` and `I_UNDERSTAND_LIVE_TRADING_RISK=false`.

## NIFTY Pre-Open Option Scanner

The NIFTY pre-open / opening option mispricing scanner is decision-support only. It estimates Black-Scholes fair value for option quotes around ATM and flags visible bid/ask prices that look far from model value. It is not execution-ready and never places orders.

Sample/mock quote mode:

```powershell
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry 2026-06-25 --default-iv 0.18
```

Kite read-only quote mode:

```powershell
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry 2026-06-25 --default-iv 0.18 --use-kite-quotes --strikes-around-atm 5
```

List available Kite NIFTY option expiries and ATM instruments:

```powershell
python -m src.scanners.nifty_preopen_scanner --list-kite-nifty-options --spot 23500
```

Kite read-only quote mode with automatic nearest expiry:

```powershell
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --strikes-around-atm 5
```

Kite read-only quote mode with automatic spot/index reference:

```powershell
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --auto-spot --strikes-around-atm 5
```

Morning scanner command with saved reports:

```powershell
python -m src.scanners.nifty_preopen_scanner --underlying NIFTY --spot 23500 --previous-close 23360 --expiry auto --default-iv 0.18 --use-kite-quotes --auto-spot --strikes-around-atm 5 --save-report
```

Default scanner mode uses safe sample option quote snapshots, so it works without live Kite market data. Kite quote mode requires the manual Kite login/read-only setup first. If the token is missing or expired, rerun `python -m src.brokers.kite_broker --login` and verify with `python -m src.brokers.kite_broker --test-quote --symbols "NSE:RELIANCE"`.

Manual `--spot` and `--default-iv` can create false mispricing rows when the market reference is wrong. In Kite mode, prefer `--auto-spot` so the scanner reads `NSE:NIFTY 50` through Kite's read-only quote API. The scanner prints either `Quote Source: SAMPLE MOCK` or `Quote Source: KITE READ-ONLY`, spot source, approximate ATM IV, `Default IV Input`, `Effective IV Used`, `IV Source`, active liquidity filters, `Model Status`, `SCANNER ONLY - NOT EXECUTION READY`, and `DRY RUN ONLY. No orders were placed.` It never calls Kite `place_order`.

`--default-iv` is the fallback volatility input. When Kite read-only quotes provide enough ATM CE/PE prices, the scanner estimates ATM implied volatility from market mid prices and uses that market-implied IV for Black-Scholes fair-value pricing. If both CE and PE IVs are valid, it uses their average. If only one side is valid, it uses that side. If no market IV can be calculated, it falls back to `--default-iv` and prints `IV Source: DEFAULT FALLBACK`.

Option SELL rows are explicitly blocked as scanner-only and marked `Hedge Required: true`. No naked option selling is supported. Option BUY rows also remain `Execution Allowed: false` until a separate execution workflow, hedge policy, and risk review are built.

The opening spike limit-order planner adds dry-run guidance for each opportunity. For an overpriced SELL row, it estimates a limit near the visible buyer bid minus the configured tick offset and shows a model-fair exit reference and expected gross edge. For an underpriced BUY row, it estimates a limit near the visible seller ask plus the tick offset. This is visible-depth planning, not NSE pre-open auction matching and not an execution instruction.

The planner does not guarantee a fill. Visible bids and asks can be cancelled, disappear, move before matching, or represent thin opening liquidity. Every planned row remains `execution_allowed=false`; SELL rows remain `hedge_required=true`. No naked option selling or automatic execution is available.

Scanner reports are saved by default under:

```text
reports/scanner_reports/latest_nifty_preopen_scanner_report.txt
reports/scanner_reports/latest_nifty_preopen_scanner_report.csv
```

If `Model Status: WARNING` appears, fair value reference appears miscalibrated and rows are suppressed by default. The report prints a short `Warning Reason`, such as straddle premium mismatch, broad-side mispricing, missing IV, or expiry/time issue. Possible causes include wrong spot, wrong IV, wrong expiry, futures/forward mismatch, pre-open illiquidity, cancellations, thin depth, wide spreads, IV changes, and slippage. Treat scanner rows as research diagnostics only, not trade instructions.

## Strategy Ideas

The system combines a trend-following core with retail-trap filters, VWAP, approximate volume profile, delta, CVD, cluster imbalance, absorption, and market-regime routing. Strategies can be enabled or disabled in `config/strategies.yaml`.

Core regimes:

- `TREND_UP`
- `TREND_DOWN`
- `RANGE`
- `TRAP_REVERSAL`
- `HIGH_VOLATILITY_NEWS`
- `UNCLEAR`

## Backtest Terms

Entry is the simulated fill price. Exit is where the test closes the trade. SL means stop loss. Target is the intended profit exit. R-multiple is profit or loss divided by initial trade risk. Win rate is winning trades divided by total trades. Expectancy is average profit or loss per trade. Profit factor is gross profit divided by gross loss. Max drawdown is the largest equity decline from a prior peak. Slippage and brokerage are placeholders in this MVP. Lookahead bias means using future candles to make a past decision. Overfitting means tuning too closely to past data. Out-of-sample testing checks the logic on data not used for tuning.

## Backtest Reports

Reports are saved in `reports/backtest_reports/`. Each report shows:

- Full combined system performance.
- Individual strategy-wise performance.
- Review flags for weak strategies, including `WEAK_SAMPLE`, `POOR_EXPECTANCY`, `POOR_PROFIT_FACTOR`, and `HIGH_DRAWDOWN`.

If a strategy is repeatedly weak on real historical data, disable it in `config/strategies.yaml`.

### Launch 1 Strategy-Wise Saved-Tick Backtests

Run fast PAPER-only strategy checks against the latest saved normalized TrueData ticks:

```powershell
python -m src.backtesting.strategy_backtest_runner --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --strategies all --exit-at-end true
python -m src.backtesting.strategy_backtest_runner --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --strategies cluster_imbalance_trap
python -m src.backtesting.strategy_backtest_runner --tick-dir data\ticks\daily --symbols "GOLD-I,SILVER-I" --strategies all
python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I,SILVER-I" --strategies all
python -m src.backtesting.strategy_backtest_runner --bar-dir data\historical\kite\candles --symbols "NSE:NIFTY 50" --strategies all
python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I" --strategies cluster_imbalance_trap --exit-at-end true --one-trade-at-a-time true --signal-cooldown-seconds 300 --max-trades-per-day 20 --slippage-points 5 --cost-per-trade 50 --entry-delay-ticks 1
python -m src.backtesting.strategy_backtest_runner --tick-dir data\historical\truedata\ticks --symbols "GOLD-I" --strategies cluster_imbalance_trap --from-date 2026-06-15 --to-date 2026-06-18 --exit-at-end true --one-trade-at-a-time true --signal-cooldown-seconds 300 --max-trades-per-day 20 --slippage-points 5 --cost-per-trade 50 --entry-delay-ticks 1 --min-score 8.8 --min-trap-strength 0.7 --same-zone-cooldown-seconds 300 --direction-flip-cooldown-seconds 300
```

The runner rebuilds the same 15-second candles used by replay/monitor mode, runs one selected strategy at a time, applies the existing risk engine and MCX lot-aware sizing, then simulates PAPER outcomes only: target hit, stop hit, or open/unfinished. Use `--exit-at-end true` to close unfinished trades at the last available tick and mark them `END_EXIT`. Trade rows include entry/exit timestamps, `outcome`, gross/net PnL, cost, MFE, MAE, risk status, and `execution_allowed=false`. It does not import or call any broker order path.

Realistic controls are enabled by default: one active trade at a time, 300-second signal cooldown, maximum 20 accepted trades per day, and one future tick of entry delay. You can tune them with `--one-trade-at-a-time`, `--signal-cooldown-seconds`, `--max-trades-per-day`, `--slippage-points`, `--cost-per-trade`, and `--entry-delay-ticks`. Skipped repeated candidates are counted as `overlap_skipped`, `cooldown_skipped`, or `daily_limit_skipped`; summary PnL uses net PnL after slippage and cost.

The `cluster_imbalance_trap` quality gate runs before the risk engine. It rejects low-score or weak-trap candidates, low LTQ/volume, unreasonable stop/target distances, market-mode mismatches, rapid direction flips, and repeated same-zone signals. Defaults live under `cluster_imbalance_trap_quality` in `config/strategies.yaml`; backtests can override score, trap strength, and cooldowns with `--min-score`, `--min-trap-strength`, `--same-zone-cooldown-seconds`, and `--direction-flip-cooldown-seconds`. Reports show raw signals, quality-accepted signals, quality rejection counters, risk rejections, and accepted trades. `SIGNAL_FILTERING_ACTIVE` confirms the quality gate materially reduced candidates.

Reports are refreshed here:

- `reports/backtests/latest_strategy_backtest_summary.csv`
- `reports/backtests/latest_strategy_backtest_trades.csv`
- `reports/backtests/latest_strategy_backtest_report.txt`

Small saved tick samples are useful for debugging mechanics, not for trusting profitability. Rows with fewer than the minimum sample are marked `INSUFFICIENT_SAMPLE`. If raw signals fire more than 100 times per day, or far more often than accepted trades, the report marks `HIGH_SIGNAL_FREQUENCY_WARNING`. Excess raw candidates create repeated exposure, selection bias, unrealistic fills, and inflated win rates even when only a handful become valid trades. Treat Launch 1 backtests and quality-filtered signals as PAPER/manual-review diagnostics only: `execution_allowed=false`, live trading disabled, broker orders disabled, and manual execution only.

### Launch 1 Strategy Verification and WhatsApp Gate

Generate the conservative approval report from tick and bar summary CSV files:

```powershell
python -m src.scoring.strategy_verification --summary-csv reports\today_truedata_tasks\<run>\tick_cluster_backtest_summary.csv --summary-csv reports\backtests\latest_strategy_backtest_summary.csv
python -m src.backtesting.bar_strategy_diagnostics --bar-dir data\historical\truedata\bars --symbols "GOLD-I,SILVER-I" --from-date 2026-06-04 --to-date 2026-06-19
```

`APPROVED` requires positive net PnL after costs, profit factor at least 1.30, at least 20 trades, and no severe frequency/overfitting warnings. Low samples remain `WATCHLIST` or `REJECTED` with LOW confidence. WhatsApp alerts read `config/approved_strategies.yaml`: approved strategies are allowed, watchlist strategies are blocked by default, and rejected/missing strategies are logged as `blocked_by_strategy_verification`. This gate controls notifications only and never enables broker execution.

## Strategy Research Lab

Run the controlled PAPER-only research grid over normalized TrueData bars and inventory the available tick coverage:

```powershell
python -m src.research.strategy_research_lab --symbols "GOLD-I,SILVER-I" --bar-dir data\historical\truedata\bars --tick-dir data\historical\truedata\ticks --from-date 2026-06-04 --to-date 2026-06-19
```

The lab tests conservative VWAP reclaim/rejection, failed-breakout trap, opening-range breakout, trend-pullback, and range/POC-retest variants. It uses a small six-profile parameter grid, chronological 70/30 train/validation dates, next-bar entry, one active trade, five-minute cooldown, daily trade caps, five-point slippage, and 50 units of cost per trade.

Reports are saved to:

- `reports/strategy_research/latest_strategy_research_report.csv`
- `reports/strategy_research/latest_strategy_research_report.txt`

Approval requires positive train, validation, and combined performance; validation and combined profit factor of at least 1.30; sufficient trades; and no severe frequency or overfitting warning. Low samples stay `WATCHLIST`. Bar-derived POC research remains watchlist-only until independently validated with stable tick/volume-profile evidence. Research rows use isolated approval IDs, so a research result cannot silently unlock runtime WhatsApp signals.

Focused GOLD-I VWAP rejection research:

```powershell
python -m src.research.vwap_rejection_deep_dive --symbol GOLD-I --bar-dir data\historical\truedata\bars --from-date 2026-06-04 --to-date 2026-06-19
```

This produces a trade ledger, chronological train/validation analysis, one-factor-at-a-time sensitivity checks, and a research playbook under `reports/strategy_research/`. The deep dive closes unfinished intraday trades at the final available bar of the same session and flags sparse sessions, low samples, fragile parameters, and one-big-trade concentration. Optional watchlist alert previews are explicitly labeled `RESEARCH ONLY - DO NOT TRADE` and remain disabled by default through `alerts.whatsapp.research_watchlist_enabled: false`.

### Launch 1 Historical Data Downloader

Use the read-only historical downloader to build larger datasets before trusting any backtest:

```powershell
python -m src.data_collection.historical_data_downloader --source truedata --data-type ticks --symbols "GOLD-I,SILVER-I" --from-date 2026-06-01 --to-date 2026-06-18
python -m src.data_collection.historical_data_downloader --source truedata --data-type bars --symbols "GOLD-I,SILVER-I" --from-date 2026-06-01 --to-date 2026-06-18 --interval 1minute
python -m src.data_collection.historical_data_downloader --source kite --data-type candles --symbols "NSE:NIFTY 50,NFO:NIFTY..." --from-date 2026-06-01 --to-date 2026-06-18 --interval minute
```

TrueData historical ticks are preferred for cluster, imbalance, order-flow, trap, and footprint-style research because those strategies need tick/bid/ask context. TrueData bars and Kite historical candles are for candle-based strategies only. Kite access remains read-only and requires the manual Kite login/token setup; the downloader never calls `place_order`.

Normalized historical files are saved under:

- `data/historical/truedata/ticks/YYYY-MM-DD/SYMBOL_ticks.csv`
- `data/historical/truedata/bars/YYYY-MM-DD/SYMBOL_1minute_bars.csv`
- `data/historical/kite/candles/YYYY-MM-DD/SYMBOL_minute_candles.csv`

The downloader writes normalized columns, skips duplicate rows, prints only file paths and row counts, and never prints credentials or tokens.

## TrueData

TrueData integration is available for PAPER live-data observation and uses only the uploaded TrueData documentation. Default `python run.py` still uses sample data.

Manual connection checks:

```powershell
python -m src.data_feeds.truedata_feed --test-connection
python -m src.data_feeds.truedata_feed --test-stream --symbols "NIFTY-I,RELIANCE" --seconds 30
```

Run PAPER mode with live TrueData ticks, without any broker order:

```powershell
python run.py --data-feed truedata --symbols "NIFTY-I,RELIANCE" --seconds 60
```

This prints `TrueData PAPER live-data mode. Broker orders disabled.`, collects normalized ticks, builds short live candles and order-flow features, and only prints/paper-simulates signals.

Each TrueData PAPER live-data run also records normalized raw ticks to:

```text
data/ticks/latest_truedata_ticks.csv
```

TrueData PAPER captures also append deduped per-symbol daily tick files for future multi-day backtesting:

```text
data/ticks/daily/YYYY-MM-DD/GOLD-I_ticks.csv
data/ticks/daily/YYYY-MM-DD/SILVER-I_ticks.csv
```

Daily rows include timestamp, symbol, LTP, LTQ, bid/ask, bid/ask quantity, source, and received time. Duplicate rows with the same timestamp, symbol, LTP, and LTQ are skipped.

At the end of each TrueData PAPER live-data run, the system prints and saves:

- `reports/daily_trade_reports/latest_live_paper_report.txt`
- `reports/daily_trade_reports/latest_paper_signals.csv`
- `reports/daily_trade_reports/latest_paper_signal_dashboard.txt`
- `reports/daily_trade_reports/latest_paper_signal_dashboard.csv`

The CSV is refreshed each run and uses `live_trading=false` unless live trading is truly enabled. WhatsApp alerts are not enabled automatically; enable them later only by setting `enable_whatsapp_alerts: true` in config and `WHATSAPP_ALERTS_ENABLED=true` with credentials in `.env`.

The final `FINAL PAPER SIGNAL DASHBOARD` gives one compact row-style section per symbol: accepted PAPER signal, risk rejection, or no signal. Use the replay dashboard for fast review during development. Use a short TrueData PAPER run only as the final live-data smoke test. The dashboard is PAPER-only, always keeps `execution_allowed=false`, and never triggers automatic execution.

Replay saved ticks in PAPER mode:

```powershell
python run.py --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I"
```

Replay mode is the fast development loop for MCX signal work. It filters the saved normalized tick CSV to the requested symbols, rebuilds the same 15-second candles and order-flow/cluster features used by TrueData PAPER mode, runs the same market-mode, strategy, risk, and paper-signal path, and refreshes the paper report files. Its output includes the resolved tick-file path and always states `PAPER MODE ONLY. No broker orders were placed.` It never places Kite or broker orders, never bypasses the risk engine, and saved signal rows keep `execution_allowed=false`.

Recommended validation cadence:

- Use saved-tick replay repeatedly while developing and tuning signal logic.
- Use a short 30-60 second TrueData PAPER run as a connection and normalization smoke test.
- Use a 900-second TrueData PAPER capture only for final session-quality verification, then reuse that saved CSV through replay.

### MCX PAPER Position Sizing

GOLD-I and SILVER-I use instrument metadata from `config/instruments.yaml`, including point value, minimum quantity, and lot size. PAPER quantity is rounded down to a valid lot and must remain within the configured risk-per-trade budget.

Minimum quantity does not override risk controls. If even one minimum MCX quantity would risk more than the allowed amount, the signal is rejected with the full sizing breakdown. This is PAPER analysis only: `execution_allowed=false`, there is no automatic execution, and every signal requires manual review.

### Launch 1: All-Day PAPER Signal Monitor

Fast saved-session monitor scan:

```powershell
python -m src.monitors.live_signal_monitor --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --scan-interval 60
```

Launch 1 WhatsApp preview:

```powershell
python -m src.monitors.live_signal_monitor --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --scan-interval 60 --alert-channel whatsapp-dry-run
```

Continuous TrueData PAPER monitor:

```powershell
python -m src.monitors.live_signal_monitor --data-feed truedata --symbols "GOLD-I,SILVER-I" --scan-interval 60 --window-seconds 300 --record-ticks
```

Bounded safety test before an all-day run:

```powershell
python -m src.monitors.live_signal_monitor --data-feed replay --tick-file data\ticks\latest_truedata_ticks.csv --symbols "GOLD-I,SILVER-I" --scan-interval 60 --max-runtime-seconds 180 --heartbeat-interval-seconds 60 --alert-channel whatsapp-dry-run
```

Example one-hour TrueData PAPER session:

```powershell
python -m src.monitors.live_signal_monitor --data-feed truedata --symbols "GOLD-I,SILVER-I" --scan-interval 60 --window-seconds 300 --max-runtime-seconds 3600 --heartbeat-interval-seconds 60 --alert-channel whatsapp-dry-run --log-file reports\signals\monitor_console.log
```

Replay performs one deterministic scan and exits. TrueData mode runs until interrupted, initially collecting the requested window and then refreshing on the scan interval. Add `--record-ticks` during TrueData monitoring to refresh `data/ticks/latest_truedata_ticks.csv` and append deduped daily files under `data/ticks/daily/`. The monitor reuses the existing strategy, cluster, risk, and lot-aware sizing path. Identical accepted or risk-rejected candidates are not appended again within five minutes.

Monitor reports:

- `reports/signals/live_signal_log.csv`
- `reports/signals/latest_live_signal_dashboard.txt`
- `reports/signals/latest_monitor_heartbeat.txt`
- `reports/signals/monitor_error_log.csv`

`--max-runtime-seconds` stops the monitor safely after the requested duration. Omit it for continuous TrueData monitoring. `--heartbeat-interval-seconds` defaults to 300 seconds; set it to `0` to disable heartbeat files. `--log-file` optionally copies console output to a file.

Stop an unbounded monitor with Ctrl+C. The monitor catches the interruption, writes a final heartbeat, and prints a final summary. A failed scan is sanitized, added to `monitor_error_log.csv`, and the next scan continues when safe. WhatsApp dry-run mode also writes separate heartbeat/error previews under `reports/alerts/`; it never sends a network message.

WhatsApp dry-run reports:

- `reports/alerts/latest_whatsapp_alert_preview.txt`
- `reports/alerts/whatsapp_alert_log.csv`

Launch 1 operating workflow:

1. Run the monitor for all-day PAPER observation.
2. Receive and log accepted, rejected, or no-signal results.
3. Manually review the setup, market context, cluster status, and risk sizing.
4. Manually execute elsewhere only if desired and independently approved by the user.
5. No algorithmic orders are sent by this system.

The monitor is PAPER-only and manual-execution-only. It never calls Kite order placement, never bypasses risk checks, keeps `execution_allowed=false`, and has no automatic execution. WhatsApp delivery may be added later as a notification channel, but it must not become an order channel.

`--alert-channel` defaults to `none`. Use `whatsapp-dry-run` for Launch 1 preview/logging without any network send. Optional `whatsapp-live` remains disabled by default and requires both `config/alerts.yaml` `whatsapp.enabled: true` and `ENABLE_WHATSAPP_ALERTS=true`, plus environment-only values for `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN`, and `WHATSAPP_TO_NUMBER`. Tokens are never printed or hardcoded. WhatsApp is a notification channel only; manual review and manual execution remain mandatory.

## Cluster Diagnostics

Run a dedicated TrueData PAPER diagnostic for cluster, footprint, and imbalance quality:

```powershell
python -m src.indicators.cluster_diagnostics --symbols "GOLD-I,SILVER-I" --seconds 300 --bucket-seconds 15
```

The report is saved to:

```text
reports/daily_trade_reports/latest_cluster_diagnostics.txt
```

Cluster diagnostics also records normalized ticks to `data/ticks/latest_truedata_ticks.csv` and appends daily tick files, so the same session can be replayed afterward or included in multi-day backtests.

The diagnostic labels bid/ask volume-at-price and imbalance as `ESTIMATED` when inferred from LTP versus bid/ask. It also states clearly when tick count, bid/ask coverage, or volume-at-price detail is not sufficient for reliable cluster analysis.

## Before Live Trading

Before any live trading, you must collect real historical data, run backtests and walk-forward checks, paper trade for several days, verify logs and reports, confirm broker sessions, confirm data quality, confirm all risk limits, and start with tiny controlled size only after all live flags are intentionally enabled.

No profitability is claimed.

## Kite-first data collection after TrueData trial

Kite support is read-only and PAPER/manual-signal only. It records market data, candles, and derived OrderFlow Lite features; it never places broker orders.

Safe commands:

```powershell
python -m src.data_collection.kite_live_recorder --symbols "GOLD-I" --duration-seconds 3600 --record-depth true
python -m src.data_collection.kite_historical_downloader --symbols "GOLD-I" --from-date 2026-06-01 --to-date 2026-06-19 --interval minute
python -m src.data_collection.kite_orderflow_features --symbols "GOLD-I" --date 2026-06-19
```

Outputs:

- `data/kite_recorded/ticks/YYYY-MM-DD/SYMBOL_ticks.csv`
- `data/kite_recorded/depth/YYYY-MM-DD/SYMBOL_depth.csv`
- `data/kite_recorded/features/YYYY-MM-DD/SYMBOL_orderflow_lite.csv`
- `data/historical/kite/bars/YYYY-MM-DD/SYMBOL_bars.csv`
- `reports/kite_data_collection/latest_kite_data_collection_report.txt`

Kite watchlist signals can be recorded into the forward-validation ledger with `provider=KITE`, `execution_allowed=false`, and production alerts blocked.

## Weekly Option Sell Signal System (Forward Validation)

A separate read-only weekly-options signal subsystem is available under `src/option_signals/`. It implements the frozen CAS Router and NIFTY Efficiency Trend research candidates for manual forward validation. It does **not** place broker orders or alter the legacy live-trading safety gates.

Start with:

```powershell
python -m src.option_signals.cli self-test
python -m src.option_signals.cli preflight
python -m src.option_signals.cli live-check --underlying NIFTY
python -m src.option_signals.cli run --poll-seconds 3
```

See:

- `docs/OPTION_SIGNAL_SYSTEM.md` for the exact frozen strategy/runtime specification.
- `docs/LIVE_OPTION_SIGNAL_RUNBOOK_2026-10-05.md` for the first live-market validation sequence.
- `docs/CODEX_OPTION_SIGNALS_PROMPTS.md` for the minimal Codex workflow.
