"""Option pricing and chain helpers for dry-run scanners."""
