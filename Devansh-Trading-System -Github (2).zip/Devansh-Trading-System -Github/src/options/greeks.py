from __future__ import annotations

import math

from src.options.black_scholes import _normalize_option_type


ZERO_GREEKS = {"delta": 0.0, "gamma": 0.0, "theta": 0.0, "vega": 0.0}


def calculate_greeks(
    spot: float,
    strike: float,
    time_to_expiry_years: float,
    risk_free_rate: float,
    volatility: float,
    option_type: str,
) -> dict:
    """Return standard Black-Scholes delta/gamma/theta/vega approximations."""

    try:
        spot = float(spot)
        strike = float(strike)
        time_to_expiry_years = float(time_to_expiry_years)
        risk_free_rate = float(risk_free_rate)
        volatility = float(volatility)
        opt = _normalize_option_type(option_type)
        if opt is None or spot <= 0 or strike <= 0 or time_to_expiry_years <= 0 or volatility <= 0:
            return dict(ZERO_GREEKS)
        sqrt_t = math.sqrt(time_to_expiry_years)
        d1 = (math.log(spot / strike) + (risk_free_rate + 0.5 * volatility * volatility) * time_to_expiry_years) / (volatility * sqrt_t)
        d2 = d1 - volatility * sqrt_t
        pdf = _norm_pdf(d1)
        discount = math.exp(-risk_free_rate * time_to_expiry_years)
        gamma = pdf / (spot * volatility * sqrt_t)
        vega = spot * pdf * sqrt_t / 100.0
        if opt == "CALL":
            delta = _norm_cdf(d1)
            theta = (-(spot * pdf * volatility) / (2 * sqrt_t) - risk_free_rate * strike * discount * _norm_cdf(d2)) / 365.0
        else:
            delta = _norm_cdf(d1) - 1.0
            theta = (-(spot * pdf * volatility) / (2 * sqrt_t) + risk_free_rate * strike * discount * _norm_cdf(-d2)) / 365.0
        return {
            "delta": round(delta, 4),
            "gamma": round(gamma, 6),
            "theta": round(theta, 4),
            "vega": round(vega, 4),
        }
    except Exception:
        return dict(ZERO_GREEKS)


def _norm_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def _norm_pdf(value: float) -> float:
    return math.exp(-0.5 * value * value) / math.sqrt(2.0 * math.pi)
