from __future__ import annotations

import math


def black_scholes_price(
    spot: float,
    strike: float,
    time_to_expiry_years: float,
    risk_free_rate: float,
    volatility: float,
    option_type: str,
) -> float:
    """Return Black-Scholes theoretical option price rounded to 2 decimals."""

    try:
        spot = float(spot)
        strike = float(strike)
        time_to_expiry_years = float(time_to_expiry_years)
        risk_free_rate = float(risk_free_rate)
        volatility = float(volatility)
        opt = _normalize_option_type(option_type)
        if opt is None or spot <= 0 or strike <= 0 or time_to_expiry_years <= 0 or volatility <= 0:
            return 0.0
        sqrt_t = math.sqrt(time_to_expiry_years)
        d1 = (math.log(spot / strike) + (risk_free_rate + 0.5 * volatility * volatility) * time_to_expiry_years) / (volatility * sqrt_t)
        d2 = d1 - volatility * sqrt_t
        discount = math.exp(-risk_free_rate * time_to_expiry_years)
        if opt == "CALL":
            price = spot * _norm_cdf(d1) - strike * discount * _norm_cdf(d2)
        else:
            price = strike * discount * _norm_cdf(-d2) - spot * _norm_cdf(-d1)
        return round(max(price, 0.0), 2)
    except Exception:
        return 0.0


def _normalize_option_type(option_type: str) -> str | None:
    value = str(option_type or "").strip().upper()
    if value in {"CALL", "CE"}:
        return "CALL"
    if value in {"PUT", "PE"}:
        return "PUT"
    return None


def _norm_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))
