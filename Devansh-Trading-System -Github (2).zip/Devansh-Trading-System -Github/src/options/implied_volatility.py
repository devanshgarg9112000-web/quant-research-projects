from __future__ import annotations

from src.options.black_scholes import black_scholes_price


def implied_volatility(
    market_price,
    spot,
    strike,
    time_to_expiry_years,
    risk_free_rate,
    option_type,
) -> float | None:
    """Estimate Black-Scholes implied volatility with a simple bisection search."""

    try:
        market_price = float(market_price)
        spot = float(spot)
        strike = float(strike)
        time_to_expiry_years = float(time_to_expiry_years)
        risk_free_rate = float(risk_free_rate)
    except (TypeError, ValueError):
        return None
    if market_price <= 0 or spot <= 0 or strike <= 0 or time_to_expiry_years <= 0:
        return None
    low = 0.0001
    high = 5.0
    low_price = black_scholes_price(spot, strike, time_to_expiry_years, risk_free_rate, low, option_type)
    high_price = black_scholes_price(spot, strike, time_to_expiry_years, risk_free_rate, high, option_type)
    if market_price < low_price or market_price > high_price:
        return None
    for _ in range(80):
        mid = (low + high) / 2.0
        price = black_scholes_price(spot, strike, time_to_expiry_years, risk_free_rate, mid, option_type)
        if abs(price - market_price) < 0.01:
            return round(mid, 4)
        if price < market_price:
            low = mid
        else:
            high = mid
    estimate = (low + high) / 2.0
    return round(estimate, 4) if estimate > 0 else None
