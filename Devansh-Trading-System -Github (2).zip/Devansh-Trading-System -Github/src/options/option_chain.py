from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any


def infer_option_type(symbol: str) -> str:
    text = str(symbol or "").strip().upper()
    if text.endswith("CE") or text.endswith("CALL") or text in {"CE", "CALL"}:
        return "CALL"
    if text.endswith("PE") or text.endswith("PUT") or text in {"PE", "PUT"}:
        return "PUT"
    return "UNKNOWN"


def infer_strike(symbol: str) -> float | None:
    text = str(symbol or "").strip().upper()
    if not text:
        return None
    match = re.search(r"(\d+(?:\.\d+)?)(?:CE|PE|CALL|PUT)$", text)
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            return None
    numbers = re.findall(r"\d+(?:\.\d+)?", text)
    if not numbers:
        return None
    try:
        return float(numbers[-1])
    except ValueError:
        return None


def select_strikes_around_atm(strikes: list[float], spot: float, strikes_around_atm: int) -> list[float]:
    clean = sorted({float(strike) for strike in strikes if _is_positive_number(strike)})
    if not clean:
        return []
    try:
        spot = float(spot)
    except (TypeError, ValueError):
        return clean
    width = max(int(strikes_around_atm), 0)
    nearest_index = min(range(len(clean)), key=lambda index: abs(clean[index] - spot))
    start = max(0, nearest_index - width)
    end = min(len(clean), nearest_index + width + 1)
    return clean[start:end]


def filter_nifty_option_symbols(instruments_or_symbols, expiry=None, spot=None, strikes_around_atm=10):
    items = list(instruments_or_symbols or [])
    normalized_expiry = normalize_expiry(expiry) if expiry else None
    candidates = []
    strikes = []
    for item in items:
        symbol = _symbol_from_item(item)
        if not _is_nifty_option_item(item):
            continue
        if normalized_expiry and not _expiry_matches(item, symbol, normalized_expiry):
            continue
        strike = _strike_from_item(item, symbol)
        if strike is not None:
            strikes.append(strike)
        candidates.append((item, strike))
    if spot is None:
        return [item for item, _strike in candidates]
    selected_strikes = set(select_strikes_around_atm(strikes, float(spot), int(strikes_around_atm)))
    return [item for item, strike in candidates if strike in selected_strikes]


def normalize_expiry(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value).strip()
    if not text:
        return None
    if text.lower() == "auto":
        return "auto"
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text[:10], fmt).date().isoformat()
        except ValueError:
            continue
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text[:10]):
        return text[:10]
    return text


def option_type_from_instrument(item: Any) -> str:
    if isinstance(item, dict):
        raw_type = str(item.get("instrument_type") or item.get("option_type") or "").strip().upper()
        if raw_type in {"CE", "CALL"}:
            return "CALL"
        if raw_type in {"PE", "PUT"}:
            return "PUT"
    return infer_option_type(_symbol_from_item(item))


def get_instrument_expiry(item: Any) -> str | None:
    if isinstance(item, dict):
        return normalize_expiry(item.get("expiry"))
    return None


def get_instrument_strike(item: Any) -> float | None:
    return _strike_from_item(item, _symbol_from_item(item))


def get_available_expiries(instruments_or_symbols) -> list[str]:
    expiries = {
        expiry
        for item in instruments_or_symbols or []
        if _is_nifty_option_item(item)
        for expiry in [get_instrument_expiry(item)]
        if expiry
    }
    return sorted(expiries)


def _symbol_from_item(item: Any) -> str:
    if isinstance(item, dict):
        return str(item.get("tradingsymbol") or item.get("symbol") or item.get("name") or "")
    return str(item or "")


def _strike_from_item(item: Any, symbol: str) -> float | None:
    if isinstance(item, dict) and item.get("strike") is not None:
        try:
            return float(item.get("strike"))
        except (TypeError, ValueError):
            return None
    return infer_strike(symbol)


def _is_nifty_option_item(item: Any) -> bool:
    symbol = _symbol_from_item(item)
    text = str(symbol or "").strip().upper()
    if text.startswith(("BANKNIFTY", "FINNIFTY", "MIDCPNIFTY")):
        return False
    if isinstance(item, dict):
        name = str(item.get("name") or item.get("underlying") or item.get("underlying_symbol") or "").strip().upper()
        if name and name != "NIFTY":
            return False
        if name == "NIFTY":
            return option_type_from_instrument(item) in {"CALL", "PUT"}
    return text.startswith("NIFTY") and option_type_from_instrument(item) in {"CALL", "PUT"}


def _expiry_matches(item: Any, symbol: str, expiry: str) -> bool:
    item_expiry = get_instrument_expiry(item)
    if item_expiry:
        return item_expiry == expiry
    compact = str(expiry).replace("-", "").upper()
    return compact in symbol.upper() or expiry.upper() in symbol.upper()


def _is_positive_number(value: Any) -> bool:
    try:
        return float(value) > 0
    except (TypeError, ValueError):
        return False
