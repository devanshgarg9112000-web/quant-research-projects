from __future__ import annotations

import os
from pathlib import Path
from typing import Any


def load_dotenv_file(base_dir: Path | str = ".") -> None:
    """Load .env without requiring python-dotenv during sample runs."""

    env_path = Path(base_dir) / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


def _parse_value(raw: str) -> Any:
    value = raw.strip()
    low = value.lower()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [
            item.strip().strip("\"'")
            for item in inner.split(",")
            if item.strip()
        ]
    if low in {"true", "false"}:
        return low == "true"
    if low in {"null", "none"}:
        return None
    try:
        if "." in value:
            return float(value)
        return int(value)
    except ValueError:
        return value


def load_yaml(path: Path | str) -> dict[str, Any]:
    """Small YAML reader for this project's simple config files.

    PyYAML is listed in requirements, but the sample project can still run before
    dependencies are installed.
    """

    path = Path(path)
    data: dict[str, Any] = {}
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        if not raw_line.startswith(" ") and line.endswith(":"):
            key = line[:-1].strip()
            data[key] = {}
            current = data[key]
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        if raw_line.startswith(" ") and current is not None:
            current[key.strip()] = _parse_value(value)
        else:
            data[key.strip()] = _parse_value(value)
            current = None
    return data


def load_configs(base_dir: Path | str = ".") -> dict[str, Any]:
    base = Path(base_dir)
    load_dotenv_file(base)
    strategies_yaml = load_yaml(base / "config" / "strategies.yaml")
    return {
        "settings": load_yaml(base / "config" / "settings.yaml"),
        "risk": load_yaml(base / "config" / "risk.yaml"),
        "strategies": strategies_yaml.get("strategies", strategies_yaml),
        "strategy_quality": strategies_yaml.get("cluster_imbalance_trap_quality", {}),
        "approved_strategies": load_yaml(base / "config" / "approved_strategies.yaml"),
        "instruments": load_yaml(base / "config" / "instruments.yaml"),
        "alerts": load_yaml(base / "config" / "alerts.yaml"),
        "forward_validation": load_yaml(base / "config" / "forward_validation.yaml")
        if (base / "config" / "forward_validation.yaml").exists()
        else {},
    }
