from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from src.strategy_lab.config import (
    ALLOWED_DECISIONS,
    NEEDS_MORE_DATA,
    PHASE6A_BACKTEST_CANDIDATE,
    REJECTED,
    WATCHLIST,
)
from src.strategy_lab.strategy_decay import (
    INSUFFICIENT_YEARWISE_TRADES,
    OLD_EDGE_ONLY,
    ONE_MONTH_DEPENDENT,
    ONE_YEAR_DEPENDENT,
    RECENTLY_WORKING_NEEDS_FORWARD_DATA,
    STRATEGY_DECAYED,
    UNSTABLE_REJECT,
)
from src.strategy_lab.walk_forward_validation import (
    FAIL,
    WALK_FORWARD_FAIL,
    WALK_FORWARD_INSUFFICIENT_DATA,
    WALK_FORWARD_MIXED,
    WALK_FORWARD_PASS,
    WALK_FORWARD_RECENT_INSUFFICIENT,
)


@dataclass
class ValidationGateResult:
    decision: str
    passed: bool
    reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "passed": self.passed,
            "reasons": "; ".join(self.reasons) if self.reasons else "NONE",
        }


def evaluate_validation_gates(
    metrics: dict[str, Any],
    *,
    min_trades: int = 80,
    max_loss_streak: int = 8,
    max_drawdown_points: float = 10_000.0,
    lookahead_flags: list[str] | tuple[str, ...] | None = None,
) -> ValidationGateResult:
    reasons: list[str] = []
    if lookahead_flags:
        return _result(REJECTED, ["lookahead flags present"])
    trades = int(metrics.get("trades", 0) or 0)
    if trades < int(min_trades):
        return _result(NEEDS_MORE_DATA, [f"trades {trades} below minimum {min_trades}"])
    if float(metrics.get("net_points", 0.0) or 0.0) <= 0:
        reasons.append("full net points not positive after costs")
    if float(metrics.get("expectancy", 0.0) or 0.0) <= 0:
        reasons.append("expectancy not positive")
    if float(metrics.get("profit_factor", 0.0) or 0.0) < 1.35:
        reasons.append("profit factor below 1.35")
    for key in ("validation_net_points", "oos_net_points", "holdout_net_points"):
        if float(metrics.get(key, 0.0) or 0.0) <= 0:
            reasons.append(f"{key} not positive")
    if float(metrics.get("removing_best_trade_net", 0.0) or 0.0) <= 0:
        reasons.append("removing best trade kills profitability")
    if float(metrics.get("removing_best_month_net", 0.0) or 0.0) <= 0:
        reasons.append("removing best month kills profitability")
    if float(metrics.get("cost_2x_net_points", 0.0) or 0.0) <= 0:
        reasons.append("2x cost sensitivity is not positive")
    if int(metrics.get("max_loss_streak", 0) or 0) > int(max_loss_streak):
        reasons.append("max loss streak above limit")
    if float(metrics.get("max_drawdown", 0.0) or 0.0) > float(max_drawdown_points):
        reasons.append("max drawdown above limit")
    _add_yearwise_stability_reasons(metrics, reasons)
    _add_walk_forward_reasons(metrics, reasons)
    if reasons:
        if _only_needs_more_data_reasons(reasons):
            return _result(NEEDS_MORE_DATA, reasons)
        soft_keys = {
            "holdout_net_points not positive",
            "oos_net_points not positive",
            "recent-only edge needs forward data",
        }
        if all(reason in soft_keys for reason in reasons):
            return _result(WATCHLIST, reasons)
        return _result(REJECTED, reasons)
    return _result(PHASE6A_BACKTEST_CANDIDATE, [])


def _result(decision: str, reasons: list[str]) -> ValidationGateResult:
    if decision not in ALLOWED_DECISIONS:
        decision = REJECTED
        reasons = [*reasons, "invalid decision blocked"]
    return ValidationGateResult(decision=decision, passed=decision == PHASE6A_BACKTEST_CANDIDATE, reasons=reasons)


def _add_yearwise_stability_reasons(metrics: dict[str, Any], reasons: list[str]) -> None:
    if "recent_net_points" not in metrics and "2025_2026_net_points" not in metrics:
        return
    recent_net = float(metrics.get("recent_net_points", metrics.get("2025_2026_net_points", 0.0)) or 0.0)
    if recent_net < 0:
        reasons.append("2025_2026_net_points negative")
    decay_label = str(metrics.get("decay_label") or metrics.get("stability_label") or "")
    if decay_label == RECENTLY_WORKING_NEEDS_FORWARD_DATA:
        reasons.append("recent-only edge needs forward data")
    elif decay_label == STRATEGY_DECAYED:
        reasons.append("strategy decayed in recent years")
    elif decay_label == OLD_EDGE_ONLY:
        reasons.append("old edge only")
    elif decay_label == ONE_YEAR_DEPENDENT:
        reasons.append("one year dependent")
    elif decay_label == ONE_MONTH_DEPENDENT:
        reasons.append("one month dependent")
    elif decay_label == INSUFFICIENT_YEARWISE_TRADES:
        reasons.append("insufficient yearwise trades")
    elif decay_label == UNSTABLE_REJECT:
        reasons.append("unstable yearwise performance")


def _add_walk_forward_reasons(metrics: dict[str, Any], reasons: list[str]) -> None:
    if "walk_forward_label" not in metrics:
        return
    label = str(metrics.get("walk_forward_label") or "")
    recent_status = str(metrics.get("walk_forward_recent_window_status") or "")
    test_net = float(metrics.get("walk_forward_test_net_points_total", 0.0) or 0.0)
    pass_rate = float(metrics.get("walk_forward_pass_rate", 0.0) or 0.0)
    if label == WALK_FORWARD_PASS:
        return
    if recent_status == "INSUFFICIENT_DATA":
        reasons.append("walk-forward recent test window insufficient")
    if label == WALK_FORWARD_INSUFFICIENT_DATA:
        reasons.append("walk-forward insufficient data")
        return
    if recent_status == FAIL:
        reasons.append("walk-forward recent test window failed")
    if test_net <= 0:
        reasons.append("walk-forward total test net not positive")
    if pass_rate < 0.5:
        reasons.append("walk-forward pass rate below 0.5")
    if label == WALK_FORWARD_MIXED:
        reasons.append("walk-forward mixed or dependent")
    elif label == WALK_FORWARD_FAIL:
        reasons.append("walk-forward failed")
    elif label == WALK_FORWARD_RECENT_INSUFFICIENT:
        reasons.append("walk-forward recent insufficient")
    else:
        reasons.append("walk-forward label not approved")


def _only_needs_more_data_reasons(reasons: list[str]) -> bool:
    allowed = {
        "walk-forward insufficient data",
        "walk-forward recent test window insufficient",
        "walk-forward recent insufficient",
        "holdout_net_points not positive",
        "oos_net_points not positive",
        "recent-only edge needs forward data",
    }
    return "walk-forward insufficient data" in reasons and all(reason in allowed for reason in reasons)
