from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, time

import pandas as pd

from src.strategy_lab.config import NEEDS_SESSION_PROFILE
from src.strategy_lab.session_profiles import (
    SessionBounds,
    forced_exit_time,
    resolve_session_profile,
    session_bounds_for_day,
)


@dataclass
class SessionFilterResult:
    symbol: str
    filtered: pd.DataFrame
    decision: str
    profile_name: str = ""
    rejected_out_of_session_rows: int = 0
    rejected_invalid_rows: int = 0
    session_by_day: dict[date, SessionBounds] = field(default_factory=dict)
    forced_exit_by_day: dict[date, time] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)


def apply_valid_market_session_filter(
    df: pd.DataFrame,
    symbol: str,
    *,
    session_start: time | None = None,
    session_end: time | None = None,
    auto_session_profile: bool = True,
    use_full_valid_session: bool = True,
    forced_exit_buffer_minutes: int = 5,
) -> SessionFilterResult:
    if "timestamp" not in df.columns:
        return SessionFilterResult(symbol, df.iloc[0:0].copy(), "DATA_REJECTED", warnings=["timestamp column missing"])
    data = df.copy()
    data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce")
    data = data.dropna(subset=["timestamp"]).sort_values("timestamp", kind="mergesort")
    manual_mode = bool(session_start and session_end)
    profile = resolve_session_profile(symbol) if auto_session_profile else None
    if profile is None and not manual_mode:
        return SessionFilterResult(
            symbol=symbol,
            filtered=data.iloc[0:0].copy(),
            decision=NEEDS_SESSION_PROFILE,
            warnings=[f"{symbol}: missing session profile."],
        )
    invalid_mask = invalid_candle_mask(data)
    session_mask = pd.Series(False, index=data.index)
    session_by_day: dict[date, SessionBounds] = {}
    forced_by_day: dict[date, time] = {}
    for trading_day, day_rows in data.groupby(data["timestamp"].dt.date, sort=True):
        bounds = session_bounds_for_day(
            symbol,
            trading_day,
            timestamps=[item.to_pydatetime() for item in day_rows["timestamp"]],
            profile=profile,
            manual_start=session_start,
            manual_end=session_end,
            use_full_valid_session=use_full_valid_session,
        )
        if bounds is None:
            continue
        session_by_day[trading_day] = bounds
        forced_by_day[trading_day] = forced_exit_time(bounds.session_end, forced_exit_buffer_minutes)
        times = day_rows["timestamp"].dt.time
        session_mask.loc[day_rows.index] = (times >= bounds.session_start) & (times <= bounds.session_end)
    out_of_session = (~session_mask) & (~data["timestamp"].isna())
    filtered = data.loc[session_mask & ~invalid_mask].copy().reset_index(drop=True)
    decision = "DATA_USABLE" if not filtered.empty else "DATA_REJECTED"
    profile_name = "MANUAL" if manual_mode else (profile.name if profile else "")
    return SessionFilterResult(
        symbol=symbol,
        filtered=filtered,
        decision=decision,
        profile_name=profile_name,
        rejected_out_of_session_rows=int(out_of_session.sum()),
        rejected_invalid_rows=int((session_mask & invalid_mask).sum()),
        session_by_day=session_by_day,
        forced_exit_by_day=forced_by_day,
    )


def invalid_candle_mask(df: pd.DataFrame) -> pd.Series:
    required = ["open", "high", "low", "close"]
    mask = pd.Series(False, index=df.index)
    missing = [column for column in required if column not in df.columns]
    if missing:
        return pd.Series(True, index=df.index)
    prices = df[required].apply(pd.to_numeric, errors="coerce")
    mask |= prices.isna().any(axis=1)
    mask |= (prices <= 0).any(axis=1)
    mask |= prices["high"] < prices[["open", "close", "low"]].max(axis=1)
    mask |= prices["low"] > prices[["open", "close", "high"]].min(axis=1)
    if "volume" in df.columns:
        volume = pd.to_numeric(df["volume"], errors="coerce")
        mask |= volume < 0
    return mask
