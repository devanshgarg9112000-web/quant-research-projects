from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from src.strategy_lab.metrics import max_drawdown, max_loss_streak


STABLE_ACROSS_YEARS = "STABLE_ACROSS_YEARS"
RECENTLY_WORKING_NEEDS_FORWARD_DATA = "RECENTLY_WORKING_NEEDS_FORWARD_DATA"
STRATEGY_DECAYED = "STRATEGY_DECAYED"
OLD_EDGE_ONLY = "OLD_EDGE_ONLY"
ONE_YEAR_DEPENDENT = "ONE_YEAR_DEPENDENT"
ONE_MONTH_DEPENDENT = "ONE_MONTH_DEPENDENT"
INSUFFICIENT_YEARWISE_TRADES = "INSUFFICIENT_YEARWISE_TRADES"
UNSTABLE_REJECT = "UNSTABLE_REJECT"

RECENT_YEARS = (2025, 2026)
MIN_YEARWISE_TRADES = 20
MIN_RECENT_TRADES = 10
YEAR_DEPENDENCY_THRESHOLD = 0.65
MONTH_DEPENDENCY_THRESHOLD = 0.50

YEARWISE_COLUMNS = [
    "symbol",
    "strategy_id",
    "orientation",
    "family",
    "side",
    "year",
    "trades",
    "net_points",
    "profit_factor",
    "win_rate",
    "max_drawdown",
    "max_loss_streak",
    "avg_trade",
    "best_trade",
    "worst_trade",
]

RECENT_COLUMNS = [
    "symbol",
    "strategy_id",
    "orientation",
    "family",
    "side",
    "2025_net_points",
    "2026_net_points",
    "2025_2026_net_points",
    "recent_profit_factor",
    "recent_trades",
    "recent_win_rate",
]

DECAY_COLUMNS = [
    "symbol",
    "strategy_id",
    "orientation",
    "family",
    "side",
    "positive_years",
    "negative_years",
    "best_year",
    "worst_year",
    "2025_net_points",
    "2026_net_points",
    "2025_2026_net_points",
    "recent_net_points",
    "recent_profit_factor",
    "recent_trades",
    "recent_win_rate",
    "stability_label",
    "decay_label",
    "year_dependency_ratio",
    "month_dependency_ratio",
]


@dataclass(frozen=True)
class StrategyDecayResult:
    yearwise: pd.DataFrame
    recent: dict[str, Any]
    summary: dict[str, Any]


def analyze_strategy_decay(
    trades: pd.DataFrame | list[dict[str, Any]],
    *,
    symbol: str,
    strategy_id: str,
    family: str = "",
    side: str = "",
    orientation: str = "",
) -> StrategyDecayResult:
    frame = _prepare_trades(trades)
    metadata = {
        "symbol": symbol,
        "strategy_id": strategy_id,
        "orientation": orientation,
        "family": family,
        "side": side,
    }
    yearwise = calendar_year_metrics(frame, metadata)
    recent = recent_period_metrics(frame, metadata)
    summary = strategy_decay_summary(frame, yearwise, recent, metadata)
    return StrategyDecayResult(yearwise=yearwise, recent=recent, summary=summary)


def calendar_year_metrics(frame: pd.DataFrame | list[dict[str, Any]], metadata: dict[str, Any] | None = None) -> pd.DataFrame:
    data = _prepare_trades(frame)
    meta = metadata or {}
    if data.empty:
        return pd.DataFrame(columns=YEARWISE_COLUMNS)
    rows = []
    for year, group in data.groupby(data["entry_time"].dt.year, sort=True):
        rows.append({**_metadata(meta), "year": int(year), **_trade_metrics(group)})
    return pd.DataFrame(rows, columns=YEARWISE_COLUMNS)


def recent_period_metrics(frame: pd.DataFrame | list[dict[str, Any]], metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    data = _prepare_trades(frame)
    meta = _metadata(metadata or {})
    if data.empty:
        return {
            **meta,
            "2025_net_points": 0.0,
            "2026_net_points": 0.0,
            "2025_2026_net_points": 0.0,
            "recent_profit_factor": 0.0,
            "recent_trades": 0,
            "recent_win_rate": 0.0,
        }
    year = data["entry_time"].dt.year
    recent = data.loc[year.isin(RECENT_YEARS)].copy()
    net_2025 = _year_net(data, 2025)
    net_2026 = _year_net(data, 2026)
    metrics = _trade_metrics(recent) if not recent.empty else _empty_trade_metrics()
    return {
        **meta,
        "2025_net_points": net_2025,
        "2026_net_points": net_2026,
        "2025_2026_net_points": round(net_2025 + net_2026, 6),
        "recent_profit_factor": metrics["profit_factor"],
        "recent_trades": metrics["trades"],
        "recent_win_rate": metrics["win_rate"],
    }


def strategy_decay_summary(
    frame: pd.DataFrame | list[dict[str, Any]],
    yearwise: pd.DataFrame,
    recent: dict[str, Any],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    data = _prepare_trades(frame)
    meta = _metadata(metadata or {})
    positive_years = int((yearwise["net_points"] > 0).sum()) if not yearwise.empty else 0
    negative_years = int((yearwise["net_points"] < 0).sum()) if not yearwise.empty else 0
    best_year = int(yearwise.sort_values("net_points", ascending=False).iloc[0]["year"]) if not yearwise.empty else ""
    worst_year = int(yearwise.sort_values("net_points", ascending=True).iloc[0]["year"]) if not yearwise.empty else ""
    recent_net = float(recent["2025_2026_net_points"])
    net_2025 = float(recent["2025_net_points"])
    net_2026 = float(recent["2026_net_points"])
    year_dependency_ratio = _dependency_ratio(yearwise["net_points"]) if not yearwise.empty else 0.0
    month_dependency_ratio = _month_dependency_ratio(data)
    old_net = _old_net(yearwise)
    stability_label, decay_label = _classify_decay(
        total_trades=len(data),
        positive_years=positive_years,
        negative_years=negative_years,
        old_net=old_net,
        recent_net=recent_net,
        net_2025=net_2025,
        net_2026=net_2026,
        recent_trades=int(recent["recent_trades"]),
        year_dependency_ratio=year_dependency_ratio,
        month_dependency_ratio=month_dependency_ratio,
    )
    return {
        **meta,
        "positive_years": positive_years,
        "negative_years": negative_years,
        "best_year": best_year,
        "worst_year": worst_year,
        "2025_net_points": net_2025,
        "2026_net_points": net_2026,
        "2025_2026_net_points": recent_net,
        "recent_net_points": recent_net,
        "recent_profit_factor": recent["recent_profit_factor"],
        "recent_trades": recent["recent_trades"],
        "recent_win_rate": recent["recent_win_rate"],
        "stability_label": stability_label,
        "decay_label": decay_label,
        "year_dependency_ratio": round(year_dependency_ratio, 6),
        "month_dependency_ratio": round(month_dependency_ratio, 6),
    }


def _classify_decay(
    *,
    total_trades: int,
    positive_years: int,
    negative_years: int,
    old_net: float,
    recent_net: float,
    net_2025: float,
    net_2026: float,
    recent_trades: int,
    year_dependency_ratio: float,
    month_dependency_ratio: float,
) -> tuple[str, str]:
    if net_2026 > 0 and positive_years == 1 and net_2025 <= 0 and old_net <= 0:
        return RECENTLY_WORKING_NEEDS_FORWARD_DATA, RECENTLY_WORKING_NEEDS_FORWARD_DATA
    if total_trades < MIN_YEARWISE_TRADES:
        return INSUFFICIENT_YEARWISE_TRADES, INSUFFICIENT_YEARWISE_TRADES
    if old_net > 0 and recent_net < 0:
        return UNSTABLE_REJECT, STRATEGY_DECAYED
    if old_net > 0 and recent_net <= 0:
        return UNSTABLE_REJECT, OLD_EDGE_ONLY
    if year_dependency_ratio >= YEAR_DEPENDENCY_THRESHOLD and positive_years > 0:
        return UNSTABLE_REJECT, ONE_YEAR_DEPENDENT
    if month_dependency_ratio >= MONTH_DEPENDENCY_THRESHOLD:
        return UNSTABLE_REJECT, ONE_MONTH_DEPENDENT
    if positive_years >= 2 and negative_years == 0 and recent_net > 0 and recent_trades >= MIN_RECENT_TRADES:
        return STABLE_ACROSS_YEARS, STABLE_ACROSS_YEARS
    if recent_net > 0:
        return RECENTLY_WORKING_NEEDS_FORWARD_DATA, RECENTLY_WORKING_NEEDS_FORWARD_DATA
    return UNSTABLE_REJECT, UNSTABLE_REJECT


def _prepare_trades(trades: pd.DataFrame | list[dict[str, Any]]) -> pd.DataFrame:
    frame = pd.DataFrame(trades).copy()
    if frame.empty or "entry_time" not in frame or "net_points" not in frame:
        return pd.DataFrame(columns=["entry_time", "net_points"])
    frame["entry_time"] = pd.to_datetime(frame["entry_time"], errors="coerce")
    frame["net_points"] = pd.to_numeric(frame["net_points"], errors="coerce").fillna(0.0)
    if "gross_points" not in frame:
        frame["gross_points"] = frame["net_points"]
    frame["gross_points"] = pd.to_numeric(frame["gross_points"], errors="coerce").fillna(frame["net_points"])
    return frame.dropna(subset=["entry_time"]).sort_values("entry_time", kind="mergesort").reset_index(drop=True)


def _trade_metrics(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return _empty_trade_metrics()
    net = pd.to_numeric(frame["net_points"], errors="coerce").fillna(0.0)
    wins = net.loc[net > 0]
    losses = net.loc[net < 0]
    gross_win = float(wins.sum())
    gross_loss = float(losses.sum())
    return {
        "trades": int(len(frame)),
        "net_points": round(float(net.sum()), 6),
        "profit_factor": round(gross_win / abs(gross_loss), 6) if gross_loss < 0 else (999.0 if gross_win > 0 else 0.0),
        "win_rate": round(float((net > 0).mean()), 6),
        "max_drawdown": round(max_drawdown(net), 6),
        "max_loss_streak": max_loss_streak(net),
        "avg_trade": round(float(net.mean()), 6),
        "best_trade": round(float(net.max()), 6),
        "worst_trade": round(float(net.min()), 6),
    }


def _empty_trade_metrics() -> dict[str, Any]:
    return {
        "trades": 0,
        "net_points": 0.0,
        "profit_factor": 0.0,
        "win_rate": 0.0,
        "max_drawdown": 0.0,
        "max_loss_streak": 0,
        "avg_trade": 0.0,
        "best_trade": 0.0,
        "worst_trade": 0.0,
    }


def _year_net(data: pd.DataFrame, year: int) -> float:
    part = data.loc[data["entry_time"].dt.year == year, "net_points"]
    return round(float(part.sum()), 6) if not part.empty else 0.0


def _dependency_ratio(values: pd.Series) -> float:
    positive = pd.to_numeric(values, errors="coerce").fillna(0.0).clip(lower=0)
    total = float(positive.sum())
    if total <= 0:
        return 0.0
    return float(positive.max()) / total


def _month_dependency_ratio(data: pd.DataFrame) -> float:
    if data.empty:
        return 0.0
    month_net = data.groupby(data["entry_time"].dt.to_period("M"))["net_points"].sum()
    return _dependency_ratio(month_net)


def _old_net(yearwise: pd.DataFrame) -> float:
    if yearwise.empty:
        return 0.0
    old = yearwise.loc[pd.to_numeric(yearwise["year"], errors="coerce") < 2025, "net_points"]
    return round(float(old.sum()), 6) if not old.empty else 0.0


def _metadata(metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": metadata.get("symbol", ""),
        "strategy_id": metadata.get("strategy_id", ""),
        "orientation": metadata.get("orientation", ""),
        "family": metadata.get("family", ""),
        "side": metadata.get("side", ""),
    }
