from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any

import pandas as pd

from src.strategy_lab.metrics import max_drawdown, max_loss_streak


PASS = "PASS"
FAIL = "FAIL"
INSUFFICIENT_DATA = "INSUFFICIENT_DATA"

WALK_FORWARD_PASS = "WALK_FORWARD_PASS"
WALK_FORWARD_MIXED = "WALK_FORWARD_MIXED"
WALK_FORWARD_FAIL = "WALK_FORWARD_FAIL"
WALK_FORWARD_INSUFFICIENT_DATA = "WALK_FORWARD_INSUFFICIENT_DATA"
WALK_FORWARD_RECENT_INSUFFICIENT = "WALK_FORWARD_RECENT_INSUFFICIENT"

MIN_TEST_PROFIT_FACTOR = 1.0
MIN_TRAIN_TRADES = 1
MIN_TEST_TRADES = 1
WINDOW_PROFIT_DEPENDENCY_THRESHOLD = 0.70

WALK_FORWARD_WINDOWS = (
    ("WF_2021_2022_TEST_2023", "2021-01-01", "2022-12-31", "2023-01-01", "2023-12-31"),
    ("WF_2022_2023_TEST_2024", "2022-01-01", "2023-12-31", "2024-01-01", "2024-12-31"),
    ("WF_2023_2024_TEST_2025", "2023-01-01", "2024-12-31", "2025-01-01", "2025-12-31"),
    ("WF_2024_2025_TEST_2026", "2024-01-01", "2025-12-31", "2026-01-01", "2026-12-31"),
)

WALK_FORWARD_WINDOW_COLUMNS = [
    "symbol",
    "strategy_id",
    "orientation",
    "family",
    "side",
    "window_id",
    "train_start",
    "train_end",
    "test_start",
    "test_end",
    "train_trades",
    "test_trades",
    "train_net_points",
    "test_net_points",
    "train_profit_factor",
    "test_profit_factor",
    "train_win_rate",
    "test_win_rate",
    "test_max_drawdown",
    "test_max_loss_streak",
    "status",
]

WALK_FORWARD_SUMMARY_COLUMNS = [
    "symbol",
    "strategy_id",
    "orientation",
    "family",
    "side",
    "walk_forward_windows_total",
    "walk_forward_windows_passed",
    "walk_forward_windows_failed",
    "walk_forward_pass_rate",
    "walk_forward_test_net_points_total",
    "walk_forward_test_profit_factor",
    "walk_forward_recent_window_status",
    "walk_forward_label",
    "usable_walk_forward_windows",
    "insufficient_walk_forward_windows",
    "failed_walk_forward_windows",
    "passed_walk_forward_windows",
    "recent_window_year",
    "recent_window_test_trades",
    "recent_window_test_net_points",
    "recent_window_status",
    "walk_forward_block_reason",
]


@dataclass(frozen=True)
class WalkForwardValidationResult:
    windows: pd.DataFrame
    summary: dict[str, Any]


def analyze_walk_forward_validation(
    trades: pd.DataFrame | list[dict[str, Any]],
    *,
    data: pd.DataFrame | None = None,
    symbol: str,
    strategy_id: str,
    family: str = "",
    side: str = "",
    orientation: str = "",
) -> WalkForwardValidationResult:
    trade_frame = _prepare_trades(trades)
    timestamps = _coverage_timestamps(data, trade_frame)
    metadata = {
        "symbol": symbol,
        "strategy_id": strategy_id,
        "orientation": orientation,
        "family": family,
        "side": side,
    }
    window_rows = [
        _window_row(trade_frame, timestamps, metadata, window)
        for window in WALK_FORWARD_WINDOWS
    ]
    windows = pd.DataFrame(window_rows, columns=WALK_FORWARD_WINDOW_COLUMNS)
    summary = aggregate_walk_forward_summary(windows, metadata)
    return WalkForwardValidationResult(windows=windows, summary=summary)


def aggregate_walk_forward_summary(
    windows: pd.DataFrame | list[dict[str, Any]],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    frame = pd.DataFrame(windows)
    meta = _metadata(metadata or {})
    if frame.empty:
        return _empty_summary(meta)
    eligible = frame.loc[frame["status"] != INSUFFICIENT_DATA].copy()
    total_windows = int(len(frame))
    passed = int((eligible["status"] == PASS).sum()) if not eligible.empty else 0
    failed = int((eligible["status"] == FAIL).sum()) if not eligible.empty else 0
    usable = passed + failed
    insufficient = total_windows - usable
    pass_rate = round(passed / usable, 6) if usable else 0.0
    test_net = pd.to_numeric(eligible["test_net_points"], errors="coerce").fillna(0.0) if not eligible.empty else pd.Series(dtype=float)
    total_test_net = round(float(test_net.sum()), 6) if not test_net.empty else 0.0
    recent_window = _recent_window(frame)
    recent_status = str(recent_window.get("status", INSUFFICIENT_DATA)) if recent_window else INSUFFICIENT_DATA
    test_pf = _aggregate_test_profit_factor(eligible)
    label = _walk_forward_label(
        total=total_windows,
        passed=passed,
        failed=failed,
        insufficient=insufficient,
        usable=usable,
        pass_rate=pass_rate,
        test_net=test_net,
        total_test_net=total_test_net,
        recent_status=recent_status,
    )
    block_reason = _walk_forward_block_reason(
        label=label,
        usable=usable,
        failed=failed,
        passed=passed,
        recent_status=recent_status,
        total_test_net=total_test_net,
        pass_rate=pass_rate,
    )
    return {
        **meta,
        "walk_forward_windows_total": total_windows,
        "walk_forward_windows_passed": passed,
        "walk_forward_windows_failed": failed,
        "walk_forward_pass_rate": pass_rate,
        "walk_forward_test_net_points_total": total_test_net,
        "walk_forward_test_profit_factor": test_pf,
        "walk_forward_recent_window_status": recent_status,
        "walk_forward_label": label,
        "usable_walk_forward_windows": usable,
        "insufficient_walk_forward_windows": insufficient,
        "failed_walk_forward_windows": failed,
        "passed_walk_forward_windows": passed,
        "recent_window_year": _recent_window_year(recent_window),
        "recent_window_test_trades": _recent_window_value(recent_window, "test_trades", 0),
        "recent_window_test_net_points": _recent_window_value(recent_window, "test_net_points", 0.0),
        "recent_window_status": recent_status,
        "walk_forward_block_reason": block_reason,
    }


def _window_row(
    trades: pd.DataFrame,
    timestamps: pd.Series,
    metadata: dict[str, Any],
    window: tuple[str, str, str, str, str],
) -> dict[str, Any]:
    window_id, train_start_text, train_end_text, test_start_text, test_end_text = window
    train_start = pd.Timestamp(train_start_text)
    train_end = pd.Timestamp(train_end_text)
    test_start = pd.Timestamp(test_start_text)
    test_end = pd.Timestamp(test_end_text)
    has_train_data = _has_coverage(timestamps, train_start.date(), train_end.date())
    has_test_data = _has_coverage(timestamps, test_start.date(), test_end.date())
    train = _between(trades, train_start, train_end)
    test = _between(trades, test_start, test_end)
    train_metrics = _trade_metrics(train)
    test_metrics = _trade_metrics(test)
    status = _window_status(has_train_data, has_test_data, train_metrics, test_metrics)
    return {
        **_metadata(metadata),
        "window_id": window_id,
        "train_start": train_start.date().isoformat(),
        "train_end": train_end.date().isoformat(),
        "test_start": test_start.date().isoformat(),
        "test_end": test_end.date().isoformat(),
        "train_trades": train_metrics["trades"],
        "test_trades": test_metrics["trades"],
        "train_net_points": train_metrics["net_points"],
        "test_net_points": test_metrics["net_points"],
        "train_profit_factor": train_metrics["profit_factor"],
        "test_profit_factor": test_metrics["profit_factor"],
        "train_win_rate": train_metrics["win_rate"],
        "test_win_rate": test_metrics["win_rate"],
        "test_max_drawdown": test_metrics["max_drawdown"],
        "test_max_loss_streak": test_metrics["max_loss_streak"],
        "status": status,
    }


def _window_status(
    has_train_data: bool,
    has_test_data: bool,
    train_metrics: dict[str, Any],
    test_metrics: dict[str, Any],
) -> str:
    if not has_train_data or not has_test_data:
        return INSUFFICIENT_DATA
    if train_metrics["trades"] < MIN_TRAIN_TRADES or test_metrics["trades"] < MIN_TEST_TRADES:
        return INSUFFICIENT_DATA
    if test_metrics["net_points"] > 0 and test_metrics["profit_factor"] >= MIN_TEST_PROFIT_FACTOR:
        return PASS
    return FAIL


def _walk_forward_label(
    *,
    total: int,
    passed: int,
    failed: int,
    insufficient: int,
    usable: int,
    pass_rate: float,
    test_net: pd.Series,
    total_test_net: float,
    recent_status: str,
) -> str:
    if total <= 0:
        return WALK_FORWARD_INSUFFICIENT_DATA
    if usable <= 0:
        return WALK_FORWARD_INSUFFICIENT_DATA
    if recent_status == FAIL or total_test_net <= 0 or pass_rate < 0.5:
        return WALK_FORWARD_FAIL
    if recent_status == INSUFFICIENT_DATA and failed > 0:
        return WALK_FORWARD_FAIL
    if failed > passed:
        return WALK_FORWARD_FAIL
    if failed > 0:
        return WALK_FORWARD_MIXED
    if recent_status == INSUFFICIENT_DATA:
        return WALK_FORWARD_RECENT_INSUFFICIENT
    if insufficient > 0:
        return WALK_FORWARD_MIXED
    if _single_window_dependency_ratio(test_net) >= WINDOW_PROFIT_DEPENDENCY_THRESHOLD:
        return WALK_FORWARD_MIXED
    if failed == 0 and passed == total:
        return WALK_FORWARD_PASS
    return WALK_FORWARD_MIXED


def _prepare_trades(trades: pd.DataFrame | list[dict[str, Any]]) -> pd.DataFrame:
    frame = pd.DataFrame(trades).copy()
    if frame.empty or "entry_time" not in frame or "net_points" not in frame:
        return pd.DataFrame(columns=["entry_time", "net_points", "gross_points"])
    frame["entry_time"] = pd.to_datetime(frame["entry_time"], errors="coerce")
    frame["net_points"] = pd.to_numeric(frame["net_points"], errors="coerce").fillna(0.0)
    if "gross_points" not in frame:
        frame["gross_points"] = frame["net_points"]
    frame["gross_points"] = pd.to_numeric(frame["gross_points"], errors="coerce").fillna(frame["net_points"])
    return frame.dropna(subset=["entry_time"]).sort_values("entry_time", kind="mergesort").reset_index(drop=True)


def _coverage_timestamps(data: pd.DataFrame | None, trades: pd.DataFrame) -> pd.Series:
    if data is not None and "timestamp" in data:
        timestamps = pd.to_datetime(data["timestamp"], errors="coerce").dropna()
        if not timestamps.empty:
            return timestamps
    if "entry_time" in trades:
        return pd.to_datetime(trades["entry_time"], errors="coerce").dropna()
    return pd.Series(dtype="datetime64[ns]")


def _has_coverage(timestamps: pd.Series, start: date, end: date) -> bool:
    if timestamps.empty:
        return False
    days = timestamps.dt.date
    return bool(days.min() <= start and days.max() >= end)


def _between(trades: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    if trades.empty:
        return trades.copy()
    days = trades["entry_time"].dt.date
    return trades.loc[(days >= start.date()) & (days <= end.date())].copy()


def _trade_metrics(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return _empty_trade_metrics()
    net = pd.to_numeric(frame["net_points"], errors="coerce").fillna(0.0)
    wins = net.loc[net > 0]
    losses = net.loc[net < 0]
    gross_win = float(wins.sum())
    gross_loss = float(losses.sum())
    return {
        "trades": int(len(frame)),
        "net_points": round(float(net.sum()), 6),
        "profit_factor": round(gross_win / abs(gross_loss), 6) if gross_loss < 0 else (999.0 if gross_win > 0 else 0.0),
        "win_rate": round(float((net > 0).mean()), 6),
        "max_drawdown": round(max_drawdown(net), 6),
        "max_loss_streak": max_loss_streak(net),
    }


def _empty_trade_metrics() -> dict[str, Any]:
    return {
        "trades": 0,
        "net_points": 0.0,
        "profit_factor": 0.0,
        "win_rate": 0.0,
        "max_drawdown": 0.0,
        "max_loss_streak": 0,
    }


def _aggregate_test_profit_factor(eligible: pd.DataFrame) -> float:
    if eligible.empty:
        return 0.0
    values = pd.to_numeric(eligible["test_net_points"], errors="coerce").fillna(0.0)
    gross_win = float(values.loc[values > 0].sum())
    gross_loss = float(values.loc[values < 0].sum())
    return round(gross_win / abs(gross_loss), 6) if gross_loss < 0 else (999.0 if gross_win > 0 else 0.0)


def _recent_window(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {}
    recent = frame.sort_values("test_end").iloc[-1]
    return recent.to_dict()


def _recent_window_year(recent_window: dict[str, Any]) -> str:
    value = recent_window.get("test_end")
    if value is None or value == "":
        return ""
    timestamp = pd.Timestamp(value)
    return str(timestamp.year)


def _recent_window_value(recent_window: dict[str, Any], key: str, default: Any) -> Any:
    value = recent_window.get(key, default)
    return default if pd.isna(value) else value


def _walk_forward_block_reason(
    *,
    label: str,
    usable: int,
    failed: int,
    passed: int,
    recent_status: str,
    total_test_net: float,
    pass_rate: float,
) -> str:
    if label == WALK_FORWARD_PASS:
        return "NONE"
    if usable <= 0:
        return "NO_USABLE_WALK_FORWARD_WINDOWS"
    if recent_status == INSUFFICIENT_DATA:
        if failed > 0:
            return "RECENT_WINDOW_INSUFFICIENT_WITH_PRIOR_FAILURES"
        return "RECENT_WINDOW_INSUFFICIENT"
    if recent_status == FAIL:
        return "RECENT_WINDOW_FAILED"
    if total_test_net <= 0:
        return "TOTAL_USABLE_TEST_NET_NOT_POSITIVE"
    if pass_rate < 0.5 or failed > passed:
        return "MOST_USABLE_WINDOWS_FAILED"
    if failed > 0:
        return "MIXED_USABLE_WINDOWS"
    return "WALK_FORWARD_NOT_STRICT_PASS"


def _single_window_dependency_ratio(test_net: pd.Series) -> float:
    if test_net.empty:
        return 0.0
    positive = pd.to_numeric(test_net, errors="coerce").fillna(0.0).clip(lower=0)
    total = float(positive.sum())
    if total <= 0:
        return 0.0
    return float(positive.max()) / total


def _empty_summary(metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        **metadata,
        "walk_forward_windows_total": 0,
        "walk_forward_windows_passed": 0,
        "walk_forward_windows_failed": 0,
        "walk_forward_pass_rate": 0.0,
        "walk_forward_test_net_points_total": 0.0,
        "walk_forward_test_profit_factor": 0.0,
        "walk_forward_recent_window_status": INSUFFICIENT_DATA,
        "walk_forward_label": WALK_FORWARD_INSUFFICIENT_DATA,
        "usable_walk_forward_windows": 0,
        "insufficient_walk_forward_windows": 0,
        "failed_walk_forward_windows": 0,
        "passed_walk_forward_windows": 0,
        "recent_window_year": "",
        "recent_window_test_trades": 0,
        "recent_window_test_net_points": 0.0,
        "recent_window_status": INSUFFICIENT_DATA,
        "walk_forward_block_reason": "NO_USABLE_WALK_FORWARD_WINDOWS",
    }


def _metadata(metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": metadata.get("symbol", ""),
        "strategy_id": metadata.get("strategy_id", ""),
        "orientation": metadata.get("orientation", ""),
        "family": metadata.get("family", ""),
        "side": metadata.get("side", ""),
    }
