from __future__ import annotations

import random
from typing import Iterable

from src.strategy_lab.strategy_primitives import LONG, SHORT, StrategyVariant, inverse_strategy_variant, make_strategy_variant


STRATEGY_FAMILIES = (
    "orb_breakout",
    "orb_failure",
    "donchian_breakout",
    "donchian_failure",
    "vwap_reclaim",
    "vwap_rejection",
    "vwap_trend_pullback",
    "ema_trend_pullback",
    "ema_crossover_with_filters",
    "rsi_mean_reversion",
    "rsi_trend_continuation",
    "bollinger_reversal",
    "bollinger_squeeze_breakout",
    "previous_day_high_low_breakout",
    "previous_day_high_low_trap",
    "gap_fade",
    "gap_continuation",
    "time_of_day_momentum",
    "afternoon_reversal",
    "range_compression_breakout",
    "volume_spike_continuation",
    "volume_spike_reversal",
    "trend_day_continuation",
    "range_day_mean_reversion",
    "hybrid_combo",
)


def generate_strategy_variants(
    *,
    max_variants: int,
    random_seed: int = 42,
    families: Iterable[str] | None = None,
) -> list[StrategyVariant]:
    rng = random.Random(random_seed)
    selected_families = tuple(families or STRATEGY_FAMILIES)
    selected_families = tuple(family for family in selected_families if family in STRATEGY_FAMILIES)
    if not selected_families:
        selected_families = STRATEGY_FAMILIES
    variants: list[StrategyVariant] = []
    seen: set[str] = set()
    attempts = 0
    limit = max(0, int(max_variants))
    while len(variants) < limit and attempts < limit * 20 + 100:
        attempts += 1
        family = rng.choice(selected_families)
        side = rng.choice((LONG, SHORT))
        params = _random_params(rng, family)
        variant = make_strategy_variant(family, side, params)
        if variant.strategy_id in seen:
            continue
        seen.add(variant.strategy_id)
        variants.append(variant)
    return variants


def expand_strategy_orientations(
    variants: list[StrategyVariant],
    *,
    strategy_orientation: str = "original",
    include_inverse: bool = False,
) -> list[StrategyVariant]:
    orientation = str(strategy_orientation or "original").strip().lower()
    if include_inverse:
        orientation = "both"
    if orientation not in {"original", "inverse", "both"}:
        orientation = "original"
    output: list[StrategyVariant] = []
    for variant in variants:
        if orientation in {"original", "both"}:
            output.append(variant)
        if orientation in {"inverse", "both"}:
            output.append(inverse_strategy_variant(variant))
    return output


def _random_params(rng: random.Random, family: str) -> dict:
    params = {
        "lookback": rng.choice([10, 15, 20, 30, 45, 60]),
        "threshold": rng.choice([0.0, 1.0, 2.0, 5.0, 10.0]),
        "sl_points": rng.choice([20.0, 35.0, 50.0, 75.0, 100.0]),
        "target_points": rng.choice([30.0, 50.0, 75.0, 100.0, 150.0]),
        "sl_atr_multiple": rng.choice([0.0, 0.8, 1.0, 1.5, 2.0]),
        "target_atr_multiple": rng.choice([0.0, 1.0, 1.5, 2.0, 3.0]),
        "max_hold_minutes": rng.choice([15, 30, 45, 60, 120]),
        "volume_filter": rng.choice([False, True]),
        "trend_filter": rng.choice([False, True]),
        "vwap_filter": rng.choice([False, True]),
        "gap_filter": rng.choice([False, True]),
        "min_volume_ratio": rng.choice([1.0, 1.2, 1.5, 2.0]),
        "max_gap_pct": rng.choice([0.005, 0.01, 0.02]),
    }
    if family.startswith("rsi"):
        params["rsi_low"] = rng.choice([20, 25, 30, 35])
        params["rsi_high"] = rng.choice([65, 70, 75, 80])
    if "gap" in family:
        params["gap_threshold"] = rng.choice([0.002, 0.003, 0.005, 0.01])
    if "compression" in family or "squeeze" in family:
        params["compression"] = rng.choice([0.5, 0.6, 0.7, 0.8])
    if "volume_spike" in family:
        params["volume_spike"] = rng.choice([1.3, 1.5, 2.0, 2.5])
    if family == "hybrid_combo":
        primitive_count = rng.choice([2, 3, 4])
        params["primitives"] = rng.sample(
            [item for item in STRATEGY_FAMILIES if item != "hybrid_combo"],
            primitive_count,
        )
    if rng.choice([False, True]):
        params["entry_start"] = rng.choice(["09:16", "09:30", "10:00", "13:00"])
        params["entry_end"] = rng.choice(["11:30", "14:30", "15:15", "23:00"])
    return params
