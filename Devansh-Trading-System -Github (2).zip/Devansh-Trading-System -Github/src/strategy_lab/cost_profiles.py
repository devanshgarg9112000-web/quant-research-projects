from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


COST_PROFILE = "COST_PROFILE"
FALLBACK_COST_POINTS = "FALLBACK_COST_POINTS"


@dataclass(frozen=True)
class AppliedCost:
    symbol: str
    cost_points: float
    source: str
    warning: str = ""

    def note(self) -> str:
        text = f"applied_cost_points={self.cost_points} cost_source={self.source}"
        return f"{text} warning={self.warning}" if self.warning else text


def load_cost_profile(path: Path | str) -> dict[str, float]:
    source = Path(path)
    raw = json.loads(source.read_text(encoding="utf-8"))
    symbols = raw.get("symbols", raw) if isinstance(raw, dict) else {}
    if not isinstance(symbols, dict):
        raise ValueError("cost profile must contain an object or a symbols object")
    output: dict[str, float] = {}
    for raw_symbol, raw_value in symbols.items():
        symbol = str(raw_symbol or "").strip().upper()
        if not symbol:
            continue
        if isinstance(raw_value, dict):
            value = raw_value.get("cost_points")
        else:
            value = raw_value
        if value is None:
            continue
        output[symbol] = float(value)
    return output


def resolve_symbol_cost(
    symbol: str,
    fallback_cost_points: float,
    profile: dict[str, float] | None = None,
) -> AppliedCost:
    requested = str(symbol or "").strip().upper()
    fallback = float(fallback_cost_points or 0.0)
    profile_provided = profile is not None
    costs = profile or {}
    if requested in costs:
        return AppliedCost(symbol=requested, cost_points=float(costs[requested]), source=COST_PROFILE)
    warning = ""
    if profile_provided:
        warning = f"cost profile missing symbol {requested}; using fallback cost_points={fallback}"
    return AppliedCost(symbol=requested, cost_points=fallback, source=FALLBACK_COST_POINTS, warning=warning)


def cost_profile_warnings(applied_costs: dict[str, AppliedCost]) -> list[str]:
    return [cost.warning for cost in applied_costs.values() if cost.warning]
