from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd


SPLITS = {
    "train": ("1900-01-01", "2023-12-31"),
    "validation": ("2024-01-01", "2024-12-31"),
    "oos": ("2025-01-01", "2025-12-31"),
    "holdout": ("2026-01-01", "2100-12-31"),
}


@dataclass
class MetricsBundle:
    metrics: dict[str, Any]
    monthly: pd.DataFrame
    yearly: pd.DataFrame
    split: pd.DataFrame
    cost_sensitivity: pd.DataFrame


def calculate_metrics(trades: pd.DataFrame | list[dict[str, Any]], *, cost_points: float = 0.0) -> MetricsBundle:
    frame = pd.DataFrame(trades)
    if frame.empty:
        empty_metrics = _empty_metrics()
        return MetricsBundle(empty_metrics, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
    frame = frame.copy()
    frame["entry_time"] = pd.to_datetime(frame["entry_time"])
    frame["exit_time"] = pd.to_datetime(frame["exit_time"])
    frame["gross_points"] = pd.to_numeric(frame["gross_points"], errors="coerce").fillna(0.0)
    frame["net_points"] = pd.to_numeric(frame["net_points"], errors="coerce").fillna(0.0)
    wins = frame.loc[frame["net_points"] > 0, "net_points"]
    losses = frame.loc[frame["net_points"] < 0, "net_points"]
    gross_win = float(wins.sum())
    gross_loss = float(losses.sum())
    monthly = _period_metrics(frame, "M")
    yearly = _period_metrics(frame, "Y")
    split = split_metrics(frame)
    sensitivity = cost_sensitivity_metrics(frame, cost_points=cost_points)
    net = float(frame["net_points"].sum())
    best_trade = float(frame["net_points"].max())
    worst_trade = float(frame["net_points"].min())
    removing_best_month_net = _removing_best_period_net(monthly, net)
    metrics = {
        "trades": int(len(frame)),
        "win_rate": round(float((frame["net_points"] > 0).mean()), 6),
        "net_points": round(net, 6),
        "gross_points": round(float(frame["gross_points"].sum()), 6),
        "profit_factor": round(gross_win / abs(gross_loss), 6) if gross_loss < 0 else (999.0 if gross_win > 0 else 0.0),
        "expectancy": round(float(frame["net_points"].mean()), 6),
        "avg_win": round(float(wins.mean()), 6) if not wins.empty else 0.0,
        "avg_loss": round(float(losses.mean()), 6) if not losses.empty else 0.0,
        "max_drawdown": round(max_drawdown(frame["net_points"]), 6),
        "max_loss_streak": max_loss_streak(frame["net_points"]),
        "best_trade": round(best_trade, 6),
        "worst_trade": round(worst_trade, 6),
        "removing_best_trade_net": round(net - max(best_trade, 0.0), 6),
        "removing_best_month_net": round(removing_best_month_net, 6),
        "train_net_points": _split_value(split, "train", "net_points"),
        "validation_net_points": _split_value(split, "validation", "net_points"),
        "oos_net_points": _split_value(split, "oos", "net_points"),
        "holdout_net_points": _split_value(split, "holdout", "net_points"),
        "cost_1x_net_points": _sensitivity_value(sensitivity, "1x", "net_points"),
        "cost_2x_net_points": _sensitivity_value(sensitivity, "2x", "net_points"),
        "cost_3x_net_points": _sensitivity_value(sensitivity, "3x", "net_points"),
    }
    return MetricsBundle(metrics, monthly, yearly, split, sensitivity)


def split_metrics(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for name, (start, end) in SPLITS.items():
        mask = (frame["entry_time"] >= pd.Timestamp(start)) & (frame["entry_time"] <= pd.Timestamp(end))
        part = frame.loc[mask]
        rows.append({
            "split": name,
            "trades": int(len(part)),
            "net_points": round(float(part["net_points"].sum()), 6) if not part.empty else 0.0,
            "gross_points": round(float(part["gross_points"].sum()), 6) if not part.empty else 0.0,
            "win_rate": round(float((part["net_points"] > 0).mean()), 6) if not part.empty else 0.0,
        })
    return pd.DataFrame(rows)


def cost_sensitivity_metrics(frame: pd.DataFrame, *, cost_points: float) -> pd.DataFrame:
    rows = []
    gross = pd.to_numeric(frame["gross_points"], errors="coerce").fillna(0.0)
    for label, multiplier in (("1x", 1), ("2x", 2), ("3x", 3)):
        net = gross - float(cost_points) * multiplier
        rows.append({
            "cost_multiplier": label,
            "cost_points": float(cost_points) * multiplier,
            "trades": int(len(frame)),
            "net_points": round(float(net.sum()), 6),
            "expectancy": round(float(net.mean()), 6) if len(net) else 0.0,
        })
    return pd.DataFrame(rows)


def max_drawdown(series: pd.Series) -> float:
    cumulative = series.cumsum()
    peak = cumulative.cummax()
    drawdown = cumulative - peak
    return abs(float(drawdown.min())) if not drawdown.empty else 0.0


def max_loss_streak(series: pd.Series) -> int:
    current = 0
    worst = 0
    for value in series:
        if value < 0:
            current += 1
            worst = max(worst, current)
        else:
            current = 0
    return worst


def _period_metrics(frame: pd.DataFrame, frequency: str) -> pd.DataFrame:
    period = frame["entry_time"].dt.to_period(frequency).astype(str)
    grouped = frame.groupby(period)
    return grouped.agg(
        trades=("net_points", "size"),
        net_points=("net_points", "sum"),
        gross_points=("gross_points", "sum"),
    ).reset_index(names="period")


def _removing_best_period_net(monthly: pd.DataFrame, net: float) -> float:
    if monthly.empty:
        return net
    best = float(monthly["net_points"].max())
    return net - max(best, 0.0)


def _split_value(split: pd.DataFrame, name: str, column: str) -> float:
    row = split.loc[split["split"] == name]
    return float(row.iloc[0][column]) if not row.empty else 0.0


def _sensitivity_value(sensitivity: pd.DataFrame, label: str, column: str) -> float:
    row = sensitivity.loc[sensitivity["cost_multiplier"] == label]
    return float(row.iloc[0][column]) if not row.empty else 0.0


def _empty_metrics() -> dict[str, Any]:
    return {
        "trades": 0,
        "win_rate": 0.0,
        "net_points": 0.0,
        "gross_points": 0.0,
        "profit_factor": 0.0,
        "expectancy": 0.0,
        "avg_win": 0.0,
        "avg_loss": 0.0,
        "max_drawdown": 0.0,
        "max_loss_streak": 0,
        "best_trade": 0.0,
        "worst_trade": 0.0,
        "removing_best_trade_net": 0.0,
        "removing_best_month_net": 0.0,
        "train_net_points": 0.0,
        "validation_net_points": 0.0,
        "oos_net_points": 0.0,
        "holdout_net_points": 0.0,
        "cost_1x_net_points": 0.0,
        "cost_2x_net_points": 0.0,
        "cost_3x_net_points": 0.0,
    }

