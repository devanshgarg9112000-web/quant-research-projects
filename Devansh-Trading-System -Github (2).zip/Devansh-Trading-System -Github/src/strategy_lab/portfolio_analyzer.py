from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


@dataclass
class PortfolioAnalysis:
    trades_per_day: pd.DataFrame
    overlapping_trades: int = 0
    same_direction_commodity_exposure: int = 0
    same_direction_index_exposure: int = 0
    worst_daily_pnl: float = 0.0
    max_daily_loss_streak: int = 0
    correlation_warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "overlapping_trades": self.overlapping_trades,
            "same_direction_commodity_exposure": self.same_direction_commodity_exposure,
            "same_direction_index_exposure": self.same_direction_index_exposure,
            "worst_daily_pnl": self.worst_daily_pnl,
            "max_daily_loss_streak": self.max_daily_loss_streak,
            "correlation_warnings": "; ".join(self.correlation_warnings) if self.correlation_warnings else "NONE",
        }


def analyze_portfolio(trades: pd.DataFrame) -> PortfolioAnalysis:
    if trades.empty:
        return PortfolioAnalysis(pd.DataFrame())
    frame = trades.copy()
    frame["entry_time"] = pd.to_datetime(frame["entry_time"])
    frame["exit_time"] = pd.to_datetime(frame["exit_time"])
    frame["trade_day"] = frame["entry_time"].dt.date
    daily = frame.groupby("trade_day").agg(trades=("net_points", "size"), daily_pnl=("net_points", "sum")).reset_index()
    worst_daily = float(daily["daily_pnl"].min()) if not daily.empty else 0.0
    warnings = []
    if (daily["trades"] >= 5).any():
        warnings.append("many scripts triggered together on at least one day")
    return PortfolioAnalysis(
        trades_per_day=daily,
        overlapping_trades=count_overlaps(frame),
        same_direction_commodity_exposure=_same_direction_group_count(frame, _commodity_symbols()),
        same_direction_index_exposure=_same_direction_group_count(frame, {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"}),
        worst_daily_pnl=round(worst_daily, 6),
        max_daily_loss_streak=_loss_streak(daily["daily_pnl"]),
        correlation_warnings=warnings,
    )


def count_overlaps(frame: pd.DataFrame) -> int:
    count = 0
    rows = frame.sort_values("entry_time").to_dict("records")
    for index, left in enumerate(rows):
        for right in rows[index + 1:]:
            if right["entry_time"] >= left["exit_time"]:
                break
            count += 1
    return count


def _same_direction_group_count(frame: pd.DataFrame, symbols: set[str]) -> int:
    selected = frame.loc[frame["symbol"].str.upper().isin(symbols)]
    if selected.empty:
        return 0
    grouped = selected.groupby(["trade_day", "side"]).size()
    return int((grouped >= 2).sum())


def _loss_streak(series: pd.Series) -> int:
    current = 0
    worst = 0
    for value in series:
        if value < 0:
            current += 1
            worst = max(worst, current)
        else:
            current = 0
    return worst


def _commodity_symbols() -> set[str]:
    return {"GOLD", "GOLDM", "GOLDMI", "SILVER", "SILVERM", "SILVERMI", "CRUDE", "CRUDEM", "COPPER", "ZINC", "LEAD", "NICKEL", "NATGAS"}

