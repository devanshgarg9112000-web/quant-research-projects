from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import time
from typing import Any

import pandas as pd


LONG = "LONG"
SHORT = "SHORT"
ORIGINAL = "ORIGINAL"
INVERSE = "INVERSE"


@dataclass(frozen=True)
class StrategyVariant:
    strategy_id: str
    family: str
    side: str
    params: dict[str, Any] = field(default_factory=dict)
    lookahead_flags: tuple[str, ...] = ()
    orientation: str = ORIGINAL
    signal_side: str = ""
    inverse_of: str = ""

    @property
    def params_json(self) -> str:
        payload = dict(self.params)
        payload["orientation"] = self.orientation
        if self.orientation == INVERSE:
            payload["inverse_of"] = self.inverse_of
        return json.dumps(payload, sort_keys=True, separators=(",", ":"))

    @property
    def has_lookahead(self) -> bool:
        return bool(self.lookahead_flags)


def make_strategy_variant(family: str, side: str, params: dict[str, Any]) -> StrategyVariant:
    params = dict(params)
    params.pop("orientation", None)
    params.pop("inverse_of", None)
    side = side.upper()
    payload = json.dumps({"family": family, "side": side, "params": params}, sort_keys=True)
    strategy_id = f"{family}_{side.lower()}_{hashlib.sha1(payload.encode('utf-8')).hexdigest()[:12]}"
    return StrategyVariant(
        strategy_id=strategy_id,
        family=family,
        side=side,
        params=params,
        orientation=ORIGINAL,
        signal_side=side,
    )


def inverse_strategy_variant(variant: StrategyVariant) -> StrategyVariant:
    inverse_side = SHORT if variant.side == LONG else LONG
    return StrategyVariant(
        strategy_id=f"{variant.strategy_id}__INVERSE",
        family=variant.family,
        side=inverse_side,
        params=dict(variant.params),
        lookahead_flags=variant.lookahead_flags,
        orientation=INVERSE,
        signal_side=variant.signal_side or variant.side,
        inverse_of=variant.strategy_id,
    )


def build_signals(df: pd.DataFrame, variant: StrategyVariant) -> pd.Series:
    family = variant.family
    side = variant.signal_side or variant.side
    params = variant.params
    close = df["close"]
    open_ = df["open"]
    high = df["high"]
    low = df["low"]
    lookback = int(params.get("lookback", 20))
    threshold = float(params.get("threshold", 0.0))
    previous_close = close.shift(1)
    rolling_high = high.rolling(lookback, min_periods=1).max().shift(1)
    rolling_low = low.rolling(lookback, min_periods=1).min().shift(1)
    signal = pd.Series(False, index=df.index)
    if family == "orb_breakout":
        signal = close > (df["opening_range_high"] + threshold) if side == LONG else close < (df["opening_range_low"] - threshold)
    elif family == "orb_failure":
        signal = (
            (high.shift(1) > df["opening_range_high"].shift(1)) & (close < df["opening_range_high"])
            if side == SHORT
            else (low.shift(1) < df["opening_range_low"].shift(1)) & (close > df["opening_range_low"])
        )
    elif family == "donchian_breakout":
        signal = close > (rolling_high + threshold) if side == LONG else close < (rolling_low - threshold)
    elif family == "donchian_failure":
        signal = (
            (high.shift(1) > rolling_high.shift(1)) & (close < rolling_high)
            if side == SHORT
            else (low.shift(1) < rolling_low.shift(1)) & (close > rolling_low)
        )
    elif family == "vwap_reclaim":
        signal = (previous_close < df["vwap"].shift(1)) & (close > df["vwap"]) if side == LONG else (previous_close > df["vwap"].shift(1)) & (close < df["vwap"])
    elif family == "vwap_rejection":
        signal = (high >= df["vwap"]) & (close < df["vwap"]) if side == SHORT else (low <= df["vwap"]) & (close > df["vwap"])
    elif family == "vwap_trend_pullback":
        signal = (close > df["vwap"]) & (df["ema_9"] > df["ema_21"]) if side == LONG else (close < df["vwap"]) & (df["ema_9"] < df["ema_21"])
    elif family == "ema_trend_pullback":
        signal = (low <= df["ema_21"]) & (close > df["ema_9"]) if side == LONG else (high >= df["ema_21"]) & (close < df["ema_9"])
    elif family == "ema_crossover_with_filters":
        signal = (df["ema_9"] > df["ema_21"]) & (df["ema_9"].shift(1) <= df["ema_21"].shift(1)) if side == LONG else (df["ema_9"] < df["ema_21"]) & (df["ema_9"].shift(1) >= df["ema_21"].shift(1))
    elif family == "rsi_mean_reversion":
        signal = df["rsi_14"] < float(params.get("rsi_low", 30)) if side == LONG else df["rsi_14"] > float(params.get("rsi_high", 70))
    elif family == "rsi_trend_continuation":
        signal = (df["rsi_14"] > 55) & (close > df["ema_21"]) if side == LONG else (df["rsi_14"] < 45) & (close < df["ema_21"])
    elif family == "bollinger_reversal":
        signal = close < df["bb_lower"] if side == LONG else close > df["bb_upper"]
    elif family == "bollinger_squeeze_breakout":
        squeeze = df["bb_width"] < df["bb_width"].rolling(lookback, min_periods=1).quantile(0.25)
        signal = squeeze & (close > df["bb_upper"]) if side == LONG else squeeze & (close < df["bb_lower"])
    elif family == "previous_day_high_low_breakout":
        signal = close > df["previous_day_high"] if side == LONG else close < df["previous_day_low"]
    elif family == "previous_day_high_low_trap":
        signal = (high > df["previous_day_high"]) & (close < df["previous_day_high"]) if side == SHORT else (low < df["previous_day_low"]) & (close > df["previous_day_low"])
    elif family == "gap_fade":
        signal = df["gap_pct"] < -float(params.get("gap_threshold", 0.003)) if side == LONG else df["gap_pct"] > float(params.get("gap_threshold", 0.003))
    elif family == "gap_continuation":
        signal = (df["gap_pct"] > float(params.get("gap_threshold", 0.003))) & (close > open_) if side == LONG else (df["gap_pct"] < -float(params.get("gap_threshold", 0.003))) & (close < open_)
    elif family == "time_of_day_momentum":
        signal = close > previous_close if side == LONG else close < previous_close
    elif family == "afternoon_reversal":
        afternoon = df["minute_of_day"] >= 13 * 60
        signal = afternoon & (close < df["bb_lower"]) if side == LONG else afternoon & (close > df["bb_upper"])
    elif family == "range_compression_breakout":
        compressed = df["range_compression"] < float(params.get("compression", 0.7))
        signal = compressed.shift(1).fillna(False) & (close > rolling_high) if side == LONG else compressed.shift(1).fillna(False) & (close < rolling_low)
    elif family == "volume_spike_continuation":
        spike = df["volume_spike_ratio"] >= float(params.get("volume_spike", 1.5))
        signal = spike & (close > previous_close) if side == LONG else spike & (close < previous_close)
    elif family == "volume_spike_reversal":
        spike = df["volume_spike_ratio"] >= float(params.get("volume_spike", 1.5))
        signal = spike & (close < previous_close) if side == LONG else spike & (close > previous_close)
    elif family == "trend_day_continuation":
        trend = (close > df["vwap"]) & (df["ema_9"] > df["ema_21"])
        signal = trend & (close > rolling_high) if side == LONG else (~trend) & (close < rolling_low)
    elif family == "range_day_mean_reversion":
        flat = df["atr_normalized_distance"].abs() < 1.0
        signal = flat & (close < df["bb_lower"]) if side == LONG else flat & (close > df["bb_upper"])
    elif family == "hybrid_combo":
        signal = _hybrid_signal(df, variant)
    return _apply_filters(df, signal.fillna(False).astype(bool), variant)


def _hybrid_signal(df: pd.DataFrame, variant: StrategyVariant) -> pd.Series:
    primitives = variant.params.get("primitives") or ["vwap_reclaim", "ema_trend_pullback"]
    pieces = []
    for primitive in primitives:
        child = StrategyVariant(
            "child",
            primitive,
            variant.side,
            {**variant.params, "primitives": []},
            orientation=variant.orientation,
            signal_side=variant.signal_side or variant.side,
            inverse_of=variant.inverse_of,
        )
        pieces.append(build_signals(df, child))
    if not pieces:
        return pd.Series(False, index=df.index)
    signal = pieces[0]
    for piece in pieces[1:]:
        signal = signal & piece
    return signal


def _apply_filters(df: pd.DataFrame, signal: pd.Series, variant: StrategyVariant) -> pd.Series:
    params = variant.params
    signal_side = variant.signal_side or variant.side
    if params.get("volume_filter"):
        signal &= df["volume_spike_ratio"] >= float(params.get("min_volume_ratio", 1.0))
    if params.get("trend_filter"):
        if signal_side == LONG:
            signal &= df["ema_9"] >= df["ema_21"]
        else:
            signal &= df["ema_9"] <= df["ema_21"]
    if params.get("vwap_filter"):
        if signal_side == LONG:
            signal &= df["close"] >= df["vwap"]
        else:
            signal &= df["close"] <= df["vwap"]
    if params.get("gap_filter"):
        signal &= df["gap_pct"].abs() <= float(params.get("max_gap_pct", 0.02))
    allowed_days = params.get("day_of_week_filter")
    if allowed_days:
        signal &= df["day_of_week"].isin(set(allowed_days))
    start = _parse_time(params.get("entry_start"))
    end = _parse_time(params.get("entry_end"))
    if start and end:
        times = df["timestamp"].dt.time
        signal &= (times >= start) & (times <= end)
    return signal.fillna(False).astype(bool)


def _parse_time(value: str | None) -> time | None:
    if not value:
        return None
    hour, minute = str(value).split(":", 1)
    return time(int(hour), int(minute))
