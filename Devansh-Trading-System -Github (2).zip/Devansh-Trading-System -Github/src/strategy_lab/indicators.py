from __future__ import annotations

import numpy as np
import pandas as pd


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy().sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    for column in ("open", "high", "low", "close", "volume"):
        data[column] = pd.to_numeric(data[column], errors="coerce")
    day = data["timestamp"].dt.date
    data["returns"] = data["close"].pct_change().fillna(0.0)
    data["atr_14"] = atr(data, 14)
    data["ema_9"] = data["close"].ewm(span=9, adjust=False).mean()
    data["ema_21"] = data["close"].ewm(span=21, adjust=False).mean()
    data["sma_20"] = data["close"].rolling(20, min_periods=1).mean()
    data["sma_50"] = data["close"].rolling(50, min_periods=1).mean()
    data["rsi_14"] = rsi(data["close"], 14)
    data["vwap"] = intraday_vwap(data)
    data["rolling_high_20"] = data["high"].rolling(20, min_periods=1).max()
    data["rolling_low_20"] = data["low"].rolling(20, min_periods=1).min()
    data["opening_range_high"] = opening_range(data, "high", 15)
    data["opening_range_low"] = opening_range(data, "low", 15)
    daily = data.groupby(day, sort=True).agg(day_high=("high", "max"), day_low=("low", "min"), day_close=("close", "last"))
    daily["previous_day_high"] = daily["day_high"].shift(1)
    daily["previous_day_low"] = daily["day_low"].shift(1)
    daily["previous_day_close"] = daily["day_close"].shift(1)
    data = data.join(daily[["previous_day_high", "previous_day_low", "previous_day_close"]], on=day)
    first_open = data.groupby(day)["open"].transform("first")
    data["gap_pct"] = ((first_open - data["previous_day_close"]) / data["previous_day_close"]).replace([np.inf, -np.inf], np.nan)
    data["bb_mid"] = data["close"].rolling(20, min_periods=1).mean()
    bb_std = data["close"].rolling(20, min_periods=1).std(ddof=0).fillna(0.0)
    data["bb_upper"] = data["bb_mid"] + 2.0 * bb_std
    data["bb_lower"] = data["bb_mid"] - 2.0 * bb_std
    data["bb_width"] = data["bb_upper"] - data["bb_lower"]
    data["volume_sma_20"] = data["volume"].rolling(20, min_periods=1).mean()
    data["volume_spike_ratio"] = (data["volume"] / data["volume_sma_20"].replace(0, np.nan)).fillna(0.0)
    candle_range = (data["high"] - data["low"]).clip(lower=0)
    data["range_compression"] = (
        candle_range / candle_range.rolling(20, min_periods=1).mean().replace(0, np.nan)
    ).fillna(1.0)
    first_timestamp = data.groupby(day)["timestamp"].transform("first")
    data["intraday_minutes_from_open"] = ((data["timestamp"] - first_timestamp).dt.total_seconds() / 60).astype(int)
    data["minute_of_day"] = data["timestamp"].dt.hour * 60 + data["timestamp"].dt.minute
    data["day_of_week"] = data["timestamp"].dt.dayofweek
    data["distance_from_vwap"] = data["close"] - data["vwap"]
    data["atr_normalized_distance"] = data["distance_from_vwap"] / data["atr_14"].replace(0, np.nan)
    return data


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = pd.to_numeric(df["high"], errors="coerce")
    low = pd.to_numeric(df["low"], errors="coerce")
    close = pd.to_numeric(df["close"], errors="coerce")
    previous_close = close.shift(1)
    true_range = pd.concat(
        [
            high - low,
            (high - previous_close).abs(),
            (low - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return true_range.rolling(period, min_periods=1).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(period, min_periods=1).mean()
    loss = (-delta.clip(upper=0)).rolling(period, min_periods=1).mean()
    rs = gain / loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).fillna(50.0)


def intraday_vwap(df: pd.DataFrame) -> pd.Series:
    typical = (df["high"] + df["low"] + df["close"]) / 3.0
    volume = df["volume"].clip(lower=0).fillna(0.0)
    day = df["timestamp"].dt.date
    pv = (typical * volume).groupby(day).cumsum()
    vv = volume.groupby(day).cumsum()
    return (pv / vv.replace(0, np.nan)).fillna(df["close"])


def opening_range(df: pd.DataFrame, column: str, minutes: int) -> pd.Series:
    day = df["timestamp"].dt.date
    within = df["intraday_minutes_from_open"] <= minutes if "intraday_minutes_from_open" in df else None
    if within is None:
        first_timestamp = df.groupby(day)["timestamp"].transform("first")
        within = ((df["timestamp"] - first_timestamp).dt.total_seconds() / 60) <= minutes
    values = df[column].where(within)
    if column == "low":
        return values.groupby(day).cummin().groupby(day).ffill()
    return values.groupby(day).cummax().groupby(day).ffill()

