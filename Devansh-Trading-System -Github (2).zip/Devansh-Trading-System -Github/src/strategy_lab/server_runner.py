from __future__ import annotations

import argparse
import csv
import os
import shlex
import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import Callable

from src.strategy_lab.config import BACKTEST_ONLY, NOT_REAL_MONEY_READY, RESEARCH_ONLY, parse_bool, parse_symbols
from src.strategy_lab.cost_profiles import load_cost_profile, resolve_symbol_cost
from src.strategy_lab.strategy_decay import (
    OLD_EDGE_ONLY,
    RECENTLY_WORKING_NEEDS_FORWARD_DATA,
    STABLE_ACROSS_YEARS,
    STRATEGY_DECAYED,
)
from src.strategy_lab.walk_forward_validation import (
    WALK_FORWARD_FAIL,
    WALK_FORWARD_INSUFFICIENT_DATA,
    WALK_FORWARD_MIXED,
    WALK_FORWARD_PASS,
    WALK_FORWARD_RECENT_INSUFFICIENT,
)


PENDING = "PENDING"
RUNNING = "RUNNING"
COMPLETED = "COMPLETED"
FAILED = "FAILED"
SKIPPED_RESUME = "SKIPPED_RESUME"

COMPLETED_MARKER = "RUN_COMPLETED.txt"
MASTER_REPORT = "strategy_lab_v3_master_report.txt"

STATUS_COLUMNS = [
    "symbol",
    "status",
    "start_time",
    "end_time",
    "elapsed_seconds",
    "return_code",
    "output_dir",
    "command",
    "notes",
]

ProcessRunner = Callable[[list[str], Path, Path], int]


@dataclass(frozen=True)
class ServerRunnerConfig:
    data_dir: Path
    symbols: tuple[str, ...]
    output_root: Path
    max_variants: int = 1000
    include_inverse: bool = False
    random_seed: int = 42
    top_n: int = 100
    save_every: int = 100
    progress_every: int = 100
    cost_points: float = 0.0
    cost_profile: Path | None = None
    max_bars: int | None = None
    workers: int = 2
    resume: bool = True
    python_executable: str = field(default_factory=lambda: sys.executable)


def server_safety_lines() -> list[str]:
    return [
        RESEARCH_ONLY,
        BACKTEST_ONLY,
        NOT_REAL_MONEY_READY,
        "Live Trading DISABLED",
        "Broker Orders DISABLED",
        "Production WhatsApp BLOCKED",
        "execution_allowed=false",
    ]


def run_server_runner(
    config: ServerRunnerConfig,
    *,
    process_runner: ProcessRunner | None = None,
) -> dict[str, Path]:
    process_runner = process_runner or _run_subprocess
    output_root = Path(config.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    logs_dir = output_root / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    status_path = output_root / "server_runner_status.csv"
    lock = threading.Lock()
    rows_by_symbol = _initial_status_rows(config)

    for line in server_safety_lines():
        print(line)
    print(
        f"SERVER PARALLEL RUNNER V1 symbols={len(config.symbols)} "
        f"workers={_worker_count(config.workers)} output_root={output_root}",
        flush=True,
    )

    pending_symbols: list[str] = []
    for symbol in config.symbols:
        output_dir = symbol_output_dir(config, symbol)
        output_dir.mkdir(parents=True, exist_ok=True)
        command = build_symbol_command(config, symbol)
        row = rows_by_symbol[symbol]
        row["output_dir"] = str(output_dir)
        row["command"] = command_to_text(command)
        if config.resume and is_completed_symbol_output(output_dir):
            now = _now()
            row.update(
                {
                    "status": SKIPPED_RESUME,
                    "start_time": now,
                    "end_time": now,
                    "elapsed_seconds": "0.000",
                    "return_code": "0",
                    "notes": _append_note(row.get("notes", ""), "completed marker and master report found"),
                }
            )
            print(f"[server] skipped resume symbol={symbol}", flush=True)
            continue
        notes = _rerun_notes(output_dir)
        if notes:
            row["notes"] = _append_note(row.get("notes", ""), notes)
        pending_symbols.append(symbol)
    write_status_csv(status_path, [rows_by_symbol[symbol] for symbol in config.symbols])

    def update_status(symbol: str, updates: dict[str, str]) -> None:
        with lock:
            rows_by_symbol[symbol].update(updates)
            write_status_csv(status_path, [rows_by_symbol[item] for item in config.symbols])

    with ThreadPoolExecutor(max_workers=_worker_count(config.workers)) as executor:
        futures = {
            executor.submit(
                _run_symbol_job,
                config,
                symbol,
                process_runner,
                logs_dir,
                rows_by_symbol[symbol]["notes"],
                update_status,
            ): symbol
            for symbol in pending_symbols
        }
        for future in as_completed(futures):
            symbol = futures[future]
            try:
                future.result()
            except Exception as exc:
                update_status(
                    symbol,
                    {
                        "status": FAILED,
                        "end_time": _now(),
                        "return_code": "",
                        "notes": _append_note(
                            rows_by_symbol[symbol].get("notes", ""),
                            f"runner exception: {type(exc).__name__}: {exc}",
                        ),
                    },
                )
                print(f"[server] failed symbol={symbol} reason=runner exception", flush=True)

    status_rows = [rows_by_symbol[symbol] for symbol in config.symbols]
    combined_paths = aggregate_completed_reports(output_root, config.symbols, status_rows=status_rows)
    write_status_csv(status_path, status_rows)
    completed = sum(1 for row in status_rows if row["status"] == COMPLETED)
    skipped = sum(1 for row in status_rows if row["status"] == SKIPPED_RESUME)
    failed = sum(1 for row in status_rows if row["status"] == FAILED)
    print(
        f"[server] finished completed={completed} skipped_resume={skipped} failed={failed} "
        f"status_report={status_path}",
        flush=True,
    )
    return {"status": status_path, **combined_paths}


def build_symbol_command(config: ServerRunnerConfig, symbol: str) -> list[str]:
    applied_cost = _resolve_config_cost(config, symbol)
    command = [
        str(config.python_executable),
        "-m",
        "src.strategy_lab.cli",
        "--data-dir",
        str(config.data_dir),
        "--symbols",
        symbol,
        "--output-dir",
        str(symbol_output_dir(config, symbol)),
        "--max-variants",
        str(int(config.max_variants)),
        "--include-inverse",
        str(bool(config.include_inverse)).lower(),
        "--random-seed",
        str(int(config.random_seed)),
        "--top-n",
        str(int(config.top_n)),
        "--save-every",
        str(int(config.save_every)),
        "--progress-every",
        str(int(config.progress_every)),
        "--cost-points",
        str(float(applied_cost.cost_points)),
    ]
    if config.cost_profile:
        command.extend(["--cost-profile", str(config.cost_profile)])
    if config.max_bars is not None:
        command.extend(["--max-bars", str(int(config.max_bars))])
    return command


def aggregate_completed_reports(
    output_root: Path | str,
    symbols: tuple[str, ...] | list[str],
    *,
    status_rows: list[dict[str, str]] | None = None,
) -> dict[str, Path]:
    root = Path(output_root)
    paths = {
        "combined_all_candidates": root / "combined_all_candidates_ranked.csv",
        "combined_phase6a": root / "combined_phase6a_candidates.csv",
        "combined_watchlist": root / "combined_watchlist_candidates.csv",
        "combined_original_vs_inverse": root / "combined_original_vs_inverse_comparison.csv",
        "combined_yearwise_metrics": root / "combined_yearwise_metrics.csv",
        "combined_strategy_decay_report": root / "combined_strategy_decay_report.csv",
        "combined_walk_forward_windows": root / "combined_walk_forward_windows.csv",
        "combined_walk_forward_summary": root / "combined_walk_forward_summary.csv",
        "combined_master_summary": root / "combined_master_summary.txt",
    }
    completed_symbols = [symbol for symbol in symbols if is_completed_symbol_output(root / safe_symbol(symbol))]
    all_candidate_rows = _read_completed_rows(root, completed_symbols, "all_candidates_ranked.csv")
    decay_rows = _read_completed_symbol_rows(root, completed_symbols, "_strategy_decay_report.csv")
    walk_forward_rows = _read_completed_symbol_rows(root, completed_symbols, "_walk_forward_summary.csv")
    _write_combined_csv(
        paths["combined_all_candidates"],
        all_candidate_rows,
    )
    _write_combined_csv(
        paths["combined_phase6a"],
        _read_completed_rows(root, completed_symbols, "phase6a_candidates.csv"),
    )
    _write_combined_csv(
        paths["combined_watchlist"],
        _read_completed_rows(root, completed_symbols, "watchlist_candidates.csv"),
    )
    _write_combined_csv(
        paths["combined_original_vs_inverse"],
        _read_completed_rows(root, completed_symbols, "original_vs_inverse_comparison.csv"),
    )
    _write_combined_csv(
        paths["combined_yearwise_metrics"],
        _read_completed_symbol_rows(root, completed_symbols, "_yearwise_metrics.csv"),
    )
    _write_combined_csv(paths["combined_strategy_decay_report"], decay_rows)
    _write_combined_csv(
        paths["combined_walk_forward_windows"],
        _read_completed_symbol_rows(root, completed_symbols, "_walk_forward_windows.csv"),
    )
    _write_combined_csv(paths["combined_walk_forward_summary"], walk_forward_rows)
    _write_combined_master_summary(
        paths["combined_master_summary"],
        symbols,
        completed_symbols,
        status_rows or [],
        decay_rows=decay_rows,
        walk_forward_rows=walk_forward_rows,
        candidate_rows=all_candidate_rows,
    )
    return paths


def write_status_csv(path: Path | str, rows: list[dict[str, str]]) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=STATUS_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in STATUS_COLUMNS})
    return output


def is_completed_symbol_output(output_dir: Path | str) -> bool:
    base = Path(output_dir)
    return (base / COMPLETED_MARKER).exists() and (base / MASTER_REPORT).exists()


def symbol_output_dir(config: ServerRunnerConfig, symbol: str) -> Path:
    return Path(config.output_root) / safe_symbol(symbol)


def safe_symbol(symbol: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(symbol).upper())


def command_to_text(command: list[str]) -> str:
    if os.name == "nt":
        return subprocess.list2cmdline(command)
    return shlex.join(command)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Strategy Lab V3 server/laptop parallel runner.")
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--symbols", nargs="+", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--max-variants", type=int, default=1000)
    parser.add_argument("--include-inverse", default="false")
    parser.add_argument("--random-seed", type=int, default=42)
    parser.add_argument("--top-n", type=int, default=100)
    parser.add_argument("--save-every", type=int, default=100)
    parser.add_argument("--progress-every", type=int, default=100)
    parser.add_argument("--cost-points", type=float, default=0.0)
    parser.add_argument("--cost-profile")
    parser.add_argument("--max-bars", type=int)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--resume", default="true")
    parser.add_argument("--python-executable", default=sys.executable)
    return parser


def config_from_args(args: argparse.Namespace) -> ServerRunnerConfig:
    return ServerRunnerConfig(
        data_dir=Path(args.data_dir),
        symbols=parse_symbols(args.symbols),
        output_root=Path(args.output_root),
        max_variants=args.max_variants,
        include_inverse=parse_bool(args.include_inverse, default=False),
        random_seed=args.random_seed,
        top_n=args.top_n,
        save_every=args.save_every,
        progress_every=args.progress_every,
        cost_points=args.cost_points,
        cost_profile=Path(args.cost_profile) if args.cost_profile else None,
        max_bars=args.max_bars,
        workers=args.workers,
        resume=parse_bool(args.resume, default=True),
        python_executable=args.python_executable,
    )


def main(argv: list[str] | None = None) -> int:
    config = config_from_args(build_parser().parse_args(argv))
    paths = run_server_runner(config)
    return 1 if _status_has_failures(paths["status"]) else 0


def _run_symbol_job(
    config: ServerRunnerConfig,
    symbol: str,
    process_runner: ProcessRunner,
    logs_dir: Path,
    starting_notes: str,
    update_status: Callable[[str, dict[str, str]], None],
) -> None:
    command = build_symbol_command(config, symbol)
    output_dir = symbol_output_dir(config, symbol)
    stdout_path = logs_dir / f"{safe_symbol(symbol)}.out.txt"
    stderr_path = logs_dir / f"{safe_symbol(symbol)}.err.txt"
    start_time = _now()
    started = perf_counter()
    update_status(
        symbol,
        {
            "status": RUNNING,
            "start_time": start_time,
            "end_time": "",
            "elapsed_seconds": "",
            "return_code": "",
            "output_dir": str(output_dir),
            "command": command_to_text(command),
            "notes": starting_notes,
        },
    )
    print(f"[server] running symbol={symbol} output_dir={output_dir}", flush=True)
    return_code = ""
    status = FAILED
    notes = starting_notes
    try:
        code = int(process_runner(command, stdout_path, stderr_path))
        return_code = str(code)
        if code == 0 and (output_dir / MASTER_REPORT).exists():
            _write_completed_marker(output_dir, symbol)
            status = COMPLETED
            notes = _append_note(notes, "RUN_COMPLETED marker written")
        elif code == 0:
            notes = _append_note(notes, "missing master report after successful subprocess")
        else:
            notes = _append_note(notes, f"subprocess failed return_code={code}")
    except Exception as exc:
        notes = _append_note(notes, f"subprocess exception: {type(exc).__name__}: {exc}")
        stderr_path.parent.mkdir(parents=True, exist_ok=True)
        with stderr_path.open("a", encoding="utf-8") as f:
            f.write(notes + "\n")
    elapsed = perf_counter() - started
    update_status(
        symbol,
        {
            "status": status,
            "end_time": _now(),
            "elapsed_seconds": f"{elapsed:.3f}",
            "return_code": return_code,
            "notes": notes,
        },
    )
    print(
        f"[server] {status.lower()} symbol={symbol} elapsed={elapsed:.1f}s "
        f"return_code={return_code or 'NA'}",
        flush=True,
    )


def _run_subprocess(command: list[str], stdout_path: Path, stderr_path: Path) -> int:
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    with stdout_path.open("w", encoding="utf-8") as stdout_file, stderr_path.open("w", encoding="utf-8") as stderr_file:
        completed = subprocess.run(command, stdout=stdout_file, stderr=stderr_file, text=True)
    return int(completed.returncode)


def _initial_status_rows(config: ServerRunnerConfig) -> dict[str, dict[str, str]]:
    rows = {}
    for symbol in config.symbols:
        rows[symbol] = {
            "symbol": symbol,
            "status": PENDING,
            "start_time": "",
            "end_time": "",
            "elapsed_seconds": "",
            "return_code": "",
            "output_dir": str(symbol_output_dir(config, symbol)),
            "command": command_to_text(build_symbol_command(config, symbol)),
            "notes": _resolve_config_cost(config, symbol).note(),
        }
    return rows


def _read_completed_rows(root: Path, symbols: list[str], filename: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for symbol in symbols:
        path = root / safe_symbol(symbol) / filename
        if not path.exists():
            continue
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                row.setdefault("symbol", symbol)
                if not row.get("symbol"):
                    row["symbol"] = symbol
                rows.append(row)
    return rows


def _read_completed_symbol_rows(root: Path, symbols: list[str], suffix: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for symbol in symbols:
        path = root / safe_symbol(symbol) / f"{safe_symbol(symbol)}{suffix}"
        if not path.exists():
            continue
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                row.setdefault("symbol", symbol)
                if not row.get("symbol"):
                    row["symbol"] = symbol
                rows.append(row)
    return rows


def _write_combined_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    columns: list[str] = []
    for row in rows:
        for column in row:
            if column not in columns:
                columns.append(column)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in columns})


def _write_combined_master_summary(
    path: Path,
    requested_symbols: tuple[str, ...] | list[str],
    completed_symbols: list[str],
    status_rows: list[dict[str, str]],
    *,
    decay_rows: list[dict[str, str]] | None = None,
    walk_forward_rows: list[dict[str, str]] | None = None,
    candidate_rows: list[dict[str, str]] | None = None,
) -> None:
    counts: dict[str, int] = {}
    for row in status_rows:
        status = row.get("status", "")
        counts[status] = counts.get(status, 0) + 1
    failed_symbols = [row["symbol"] for row in status_rows if row.get("status") == FAILED]
    applied_cost_lines = _format_status_costs(status_rows)
    decay_rows = decay_rows or []
    stable_count = sum(1 for row in decay_rows if row.get("stability_label") == STABLE_ACROSS_YEARS)
    decayed_count = sum(1 for row in decay_rows if row.get("decay_label") in {STRATEGY_DECAYED, OLD_EDGE_ONLY})
    recent_only_count = sum(1 for row in decay_rows if row.get("decay_label") == RECENTLY_WORKING_NEEDS_FORWARD_DATA)
    walk_forward_rows = walk_forward_rows or []
    walk_forward_pass_count = sum(1 for row in walk_forward_rows if row.get("walk_forward_label") == WALK_FORWARD_PASS)
    walk_forward_mixed_count = sum(1 for row in walk_forward_rows if row.get("walk_forward_label") == WALK_FORWARD_MIXED)
    walk_forward_fail_count = sum(1 for row in walk_forward_rows if row.get("walk_forward_label") == WALK_FORWARD_FAIL)
    walk_forward_insufficient_count = sum(
        1 for row in walk_forward_rows if row.get("walk_forward_label") == WALK_FORWARD_INSUFFICIENT_DATA
    )
    walk_forward_recent_insufficient_count = sum(
        1 for row in walk_forward_rows if row.get("walk_forward_label") == WALK_FORWARD_RECENT_INSUFFICIENT
    )
    candidate_rows = candidate_rows or []
    blocked_walk_forward_count = sum(
        1 for row in candidate_rows if "walk-forward" in str(row.get("gate_reasons", "")).lower()
    )
    best_walk_forward_lines = _format_top_walk_forward_rows(candidate_rows)
    lines = [
        "SERVER PARALLEL RUNNER V1 COMBINED MASTER SUMMARY",
        *server_safety_lines(),
        "",
        f"requested_symbols: {len(requested_symbols)}",
        f"completed_symbols: {len(completed_symbols)}",
        f"failed_symbols: {len(failed_symbols)}",
        f"skipped_resume_symbols: {counts.get(SKIPPED_RESUME, 0)}",
        "",
        "COMPLETED SYMBOLS",
        *(completed_symbols if completed_symbols else ["NONE"]),
        "",
        "FAILED SYMBOLS",
        *(failed_symbols if failed_symbols else ["NONE"]),
        "",
        "APPLIED COSTS",
        *(applied_cost_lines if applied_cost_lines else ["NONE"]),
        "",
        "STABILITY / DECAY",
        f"stable_strategies_count: {stable_count}",
        f"decayed_strategies_count: {decayed_count}",
        f"recent_only_strategies_count: {recent_only_count}",
        "",
        "WALK-FORWARD VALIDATION",
        f"walk_forward_pass_count: {walk_forward_pass_count}",
        f"walk_forward_mixed_count: {walk_forward_mixed_count}",
        f"walk_forward_fail_count: {walk_forward_fail_count}",
        f"walk_forward_insufficient_count: {walk_forward_insufficient_count}",
        f"walk_forward_recent_insufficient_count: {walk_forward_recent_insufficient_count}",
        f"strategies_blocked_due_to_walk_forward_failure: {blocked_walk_forward_count}",
        "BEST WALK-FORWARD STRATEGIES",
        *(best_walk_forward_lines if best_walk_forward_lines else ["NONE"]),
        "",
        "FINAL STATUS",
        RESEARCH_ONLY,
        BACKTEST_ONLY,
        NOT_REAL_MONEY_READY,
        "execution_allowed=false",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_completed_marker(output_dir: Path, symbol: str) -> Path:
    marker = output_dir / COMPLETED_MARKER
    lines = [
        "RUN_COMPLETED",
        f"symbol={symbol}",
        f"completed_at={_now()}",
        RESEARCH_ONLY,
        BACKTEST_ONLY,
        NOT_REAL_MONEY_READY,
        "execution_allowed=false",
    ]
    marker.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return marker


def _rerun_notes(output_dir: Path) -> str:
    if (output_dir / COMPLETED_MARKER).exists():
        return "completed marker exists but master report missing; rerunning"
    partials = list(output_dir.glob("partial_candidates_*.csv"))
    if partials:
        return "RERUN_REQUIRED_PARTIAL_FOUND; rerunning without deleting existing files"
    if output_dir.exists() and any(output_dir.iterdir()):
        return "existing incomplete output found; rerunning without deleting existing files"
    return ""


def _status_has_failures(path: Path) -> bool:
    if not path.exists():
        return True
    with path.open(newline="", encoding="utf-8") as f:
        return any(row.get("status") == FAILED for row in csv.DictReader(f))


def _append_note(existing: str, note: str) -> str:
    return f"{existing}; {note}" if existing else note


def _resolve_config_cost(config: ServerRunnerConfig, symbol: str):
    profile = load_cost_profile(config.cost_profile) if config.cost_profile else None
    return resolve_symbol_cost(symbol, config.cost_points, profile)


def _format_status_costs(status_rows: list[dict[str, str]]) -> list[str]:
    rows = []
    for row in status_rows:
        notes = row.get("notes", "")
        if "applied_cost_points=" in notes:
            rows.append(f"- {row.get('symbol', '')}: {notes}")
    return rows


def _format_top_walk_forward_rows(candidate_rows: list[dict[str, str]], limit: int = 10) -> list[str]:
    rows = [
        row
        for row in candidate_rows
        if row.get("walk_forward_label") in {WALK_FORWARD_PASS, WALK_FORWARD_MIXED}
    ]
    rows.sort(key=lambda row: _as_float(row.get("walk_forward_test_net_points_total")), reverse=True)
    return [
        f"- {row.get('symbol', '')}: {row.get('strategy_id', '')} label={row.get('walk_forward_label', '')} "
        f"test_net={row.get('walk_forward_test_net_points_total', '')} "
        f"pass_rate={row.get('walk_forward_pass_rate', '')} decision={row.get('decision', '')}"
        for row in rows[:limit]
    ]


def _as_float(value: object) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _worker_count(workers: int) -> int:
    return max(1, int(workers or 2))


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


if __name__ == "__main__":
    raise SystemExit(main())
