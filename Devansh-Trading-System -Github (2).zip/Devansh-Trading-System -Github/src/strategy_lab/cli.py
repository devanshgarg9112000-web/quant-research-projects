from __future__ import annotations

import argparse
from pathlib import Path
from time import perf_counter

from src.strategy_lab.config import (
    StrategyLabConfig,
    families_tuple,
    parse_bool,
    parse_symbols,
    parse_time,
    safety_lines,
)


def run_strategy_lab(config: StrategyLabConfig) -> dict[str, Path]:
    import pandas as pd

    from src.strategy_lab.cost_profiles import load_cost_profile, resolve_symbol_cost
    from src.strategy_lab.data_loader import DATA_FILE_FOUND, load_csv, resolve_symbol_file, write_file_mapping_report
    from src.strategy_lab.data_validator import DataValidationSummary, validate_and_filter_data
    from src.strategy_lab.report_writer import (
        write_data_validation_summary,
        write_runtime_benchmark_report,
        write_strategy_lab_reports,
    )

    run_started = perf_counter()
    print("STRATEGY LAB V3")
    for line in safety_lines():
        print(line)
    progress_every = max(1, int(config.progress_every or 100))
    include_inverse = config.include_inverse
    strategy_orientation = "both" if config.include_inverse else config.strategy_orientation.lower()
    data_summaries: list[dict] = []
    usable_by_symbol: dict[str, pd.DataFrame] = {}
    candidate_rows: list[dict] = []
    best_trades_by_symbol: dict[str, pd.DataFrame] = {}
    monthly_by_symbol: dict[str, pd.DataFrame] = {}
    split_by_symbol: dict[str, pd.DataFrame] = {}
    cost_metrics_by_symbol: dict[str, pd.DataFrame] = {}
    all_phase_trades = []
    base_variants_generated = 0
    inverse_variants_generated = 0
    total_backtests_attempted = 0

    def log(message: str) -> None:
        print(f"[elapsed {_format_duration(perf_counter() - run_started)}] {message}", flush=True)

    cost_profile = load_cost_profile(config.cost_profile) if config.cost_profile else None
    if config.cost_profile:
        log(f"cost profile loaded path={config.cost_profile} entries={len(cost_profile or {})}")
    applied_costs_by_symbol = {
        symbol: resolve_symbol_cost(symbol, config.cost_points, cost_profile) for symbol in config.symbols
    }
    for applied_cost in applied_costs_by_symbol.values():
        if applied_cost.warning:
            log(f"WARNING {applied_cost.warning}")
        log(f"cost applied symbol={applied_cost.symbol} {applied_cost.note()}")

    log(f"file mapping started symbols={len(config.symbols)} data_dir={config.data_dir}")
    file_mappings = [resolve_symbol_file(config.data_dir, symbol) for symbol in config.symbols]
    file_mapping_path = write_file_mapping_report(Path(config.output_dir) / "file_mapping_report.csv", file_mappings)
    data_validation_path = write_data_validation_summary(config.output_dir, data_summaries)
    log(f"file mapping completed report={file_mapping_path}")
    for symbol, mapping in zip(config.symbols, file_mappings):
        applied_cost = applied_costs_by_symbol[symbol]
        if mapping.status != DATA_FILE_FOUND or mapping.matched_file is None:
            summary = DataValidationSummary(symbol=symbol, decision=mapping.status, warnings=[mapping.notes])
            data_summaries.append(_summary_with_cost(summary, applied_cost))
            data_validation_path = write_data_validation_summary(config.output_dir, data_summaries)
            log(f"data loading skipped symbol={symbol} status={mapping.status} notes={mapping.notes}")
            continue
        load_started = perf_counter()
        log(f"data loading started symbol={symbol} file={mapping.matched_file}")
        raw = load_csv(mapping.matched_file, default_symbol=symbol)
        log(
            f"data loading completed symbol={symbol} rows={len(raw)} "
            f"elapsed={_format_duration(perf_counter() - load_started)}"
        )
        validation_started = perf_counter()
        log(f"validation started symbol={symbol}")
        usable, summary = validate_and_filter_data(
            raw,
            symbol,
            session_start=config.session_start,
            session_end=config.session_end,
            auto_session_profile=config.auto_session_profile,
            use_full_valid_session=config.use_full_valid_session,
            forced_exit_buffer_minutes=config.forced_exit_buffer_minutes,
        )
        data_summaries.append(_summary_with_cost(summary, applied_cost))
        data_validation_path = write_data_validation_summary(config.output_dir, data_summaries)
        log(
            f"validation completed symbol={symbol} decision={summary.decision} "
            f"raw_rows={summary.rows_raw} filtered_rows={summary.rows_after_valid_session_filter} "
            f"elapsed={_format_duration(perf_counter() - validation_started)}"
        )
        log(
            f"session filtering symbol={symbol} rows_after_valid_session_filter={summary.rows_after_valid_session_filter} "
            f"rejected_out_of_session_rows={summary.rejected_out_of_session_rows} "
            f"rejected_invalid_rows={summary.rejected_invalid_rows} profile={summary.session_profile_used}"
        )
        if summary.decision != "DATA_USABLE" or usable.empty:
            continue
        if config.max_bars and int(config.max_bars) > 0 and len(usable) > int(config.max_bars):
            before = len(usable)
            usable = usable.tail(int(config.max_bars)).reset_index(drop=True)
            log(f"max-bars applied symbol={symbol} rows_before={before} rows_after={len(usable)}")
        usable_by_symbol[symbol] = usable

    if config.validate_only:
        log("validate-only completed; strategy search skipped")
        print("execution_allowed=false")
        return {"file_mapping": file_mapping_path, "data_validation": data_validation_path}

    from src.strategy_lab.backtester import backtest_strategy
    from src.strategy_lab.indicators import add_indicators
    from src.strategy_lab.metrics import calculate_metrics
    from src.strategy_lab.portfolio_analyzer import analyze_portfolio
    from src.strategy_lab.strategy_generator import expand_strategy_orientations, generate_strategy_variants
    from src.strategy_lab.strategy_decay import DECAY_COLUMNS, RECENT_COLUMNS, YEARWISE_COLUMNS, analyze_strategy_decay
    from src.strategy_lab.validation_gates import evaluate_validation_gates
    from src.strategy_lab.walk_forward_validation import (
        WALK_FORWARD_SUMMARY_COLUMNS,
        WALK_FORWARD_WINDOW_COLUMNS,
        analyze_walk_forward_validation,
    )

    if config.benchmark:
        benchmark_rows = []
        benchmark_base_count = min(max(1, int(config.max_variants or 0)), 10) if int(config.max_variants or 0) > 0 else 0
        log(f"benchmark mode enabled sample_base_variants={benchmark_base_count}; normal search skipped")
        for symbol in config.symbols:
            usable = usable_by_symbol.get(symbol)
            applied_cost = applied_costs_by_symbol[symbol]
            if usable is None or usable.empty or benchmark_base_count <= 0:
                benchmark_rows.append(_benchmark_skip_row(symbol, config, "NO_USABLE_DATA_OR_VARIANTS", applied_cost))
                benchmark_path = write_runtime_benchmark_report(config.output_dir, benchmark_rows)
                log(f"benchmark skipped symbol={symbol} report={benchmark_path}")
                continue
            enriched = add_indicators(usable)
            base_variants = generate_strategy_variants(
                max_variants=benchmark_base_count,
                random_seed=config.random_seed,
                families=config.families or None,
            )
            variants = expand_strategy_orientations(
                base_variants,
                strategy_orientation=strategy_orientation,
                include_inverse=config.include_inverse,
            )
            original_count = sum(1 for variant in variants if variant.orientation == "ORIGINAL")
            inverse_count = sum(1 for variant in variants if variant.orientation == "INVERSE")
            log(
                f"benchmark started symbol={symbol} variants={len(variants)} "
                f"original={original_count} inverse={inverse_count} bars={len(enriched)}"
            )
            symbol_started = perf_counter()
            for variant in variants:
                result = backtest_strategy(
                    enriched,
                    variant,
                    symbol=symbol,
                    cost_points=applied_cost.cost_points,
                    forced_exit_buffer_minutes=config.forced_exit_buffer_minutes,
                )
                trades = result.trades_frame()
                calculate_metrics(trades, cost_points=applied_cost.cost_points)
            elapsed = perf_counter() - symbol_started
            avg_seconds = elapsed / len(variants) if variants else 0.0
            estimated_seconds = avg_seconds * max(0, int(config.max_variants or 0)) * 2
            benchmark_rows.append(
                {
                    "symbol": symbol,
                    "status": "BENCHMARK_COMPLETED",
                    "applied_cost_points": applied_cost.cost_points,
                    "cost_profile_source": applied_cost.source,
                    "bars_used": len(enriched),
                    "base_variants_sampled": len(base_variants),
                    "backtests_sampled": len(variants),
                    "original_variants_sampled": original_count,
                    "inverse_variants_sampled": inverse_count,
                    "seconds_total": round(elapsed, 6),
                    "average_seconds_per_backtest": round(avg_seconds, 6),
                    "max_variants": int(config.max_variants or 0),
                    "estimated_seconds_for_max_variants_with_inverse": round(estimated_seconds, 6),
                    "estimated_minutes_for_max_variants_with_inverse": round(estimated_seconds / 60, 6),
                }
            )
            benchmark_path = write_runtime_benchmark_report(config.output_dir, benchmark_rows)
            log(
                f"benchmark completed symbol={symbol} avg_seconds_per_backtest={avg_seconds:.6f} "
                f"estimated_inverse_runtime={_format_duration(estimated_seconds)} report={benchmark_path}"
            )
        print("execution_allowed=false")
        return {
            "file_mapping": file_mapping_path,
            "data_validation": data_validation_path,
            "runtime_benchmark": Path(config.output_dir) / "runtime_benchmark_report.csv",
        }

    paths: dict[str, Path] = {"file_mapping": file_mapping_path, "data_validation": data_validation_path}
    yearwise_rows_by_symbol: dict[str, list[dict]] = {}
    recent_rows_by_symbol: dict[str, list[dict]] = {}
    decay_rows_by_symbol: dict[str, list[dict]] = {}
    walk_forward_windows_by_symbol: dict[str, list[dict]] = {}
    walk_forward_summary_by_symbol: dict[str, list[dict]] = {}
    for symbol in config.symbols:
        usable = usable_by_symbol.get(symbol)
        applied_cost = applied_costs_by_symbol[symbol]
        if usable is None or usable.empty:
            continue
        enriched = add_indicators(usable)
        base_variants = generate_strategy_variants(
            max_variants=config.max_variants,
            random_seed=config.random_seed,
            families=config.families or None,
        )
        base_variants_generated += len(base_variants)
        variants = expand_strategy_orientations(
            base_variants,
            strategy_orientation=strategy_orientation,
            include_inverse=config.include_inverse,
        )
        original_count = sum(1 for variant in variants if variant.orientation == "ORIGINAL")
        inverse_count = sum(1 for variant in variants if variant.orientation == "INVERSE")
        inverse_variants_generated += inverse_count
        total_backtests_attempted += len(variants)
        log(
            f"strategy generation count symbol={symbol} base_variants={len(base_variants)} "
            f"expanded_variants={len(variants)} original={original_count} inverse={inverse_count}"
        )
        log(f"symbol search started symbol={symbol} variants={len(variants)} bars={len(enriched)}")
        symbol_rows = []
        best_row = None
        best_bundle = None
        best_trades = pd.DataFrame()
        symbol_started = perf_counter()
        for index, variant in enumerate(variants, start=1):
            result = backtest_strategy(
                enriched,
                variant,
                symbol=symbol,
                cost_points=applied_cost.cost_points,
                forced_exit_buffer_minutes=config.forced_exit_buffer_minutes,
            )
            trades = result.trades_frame()
            bundle = calculate_metrics(trades, cost_points=applied_cost.cost_points)
            decay = analyze_strategy_decay(
                trades,
                symbol=symbol,
                strategy_id=variant.strategy_id,
                family=variant.family,
                side=variant.side,
                orientation=variant.orientation,
            )
            yearwise_rows_by_symbol.setdefault(symbol, []).extend(decay.yearwise.to_dict("records"))
            recent_rows_by_symbol.setdefault(symbol, []).append(decay.recent)
            decay_rows_by_symbol.setdefault(symbol, []).append(decay.summary)
            walk_forward = analyze_walk_forward_validation(
                trades,
                data=enriched,
                symbol=symbol,
                strategy_id=variant.strategy_id,
                family=variant.family,
                side=variant.side,
                orientation=variant.orientation,
            )
            walk_forward_windows_by_symbol.setdefault(symbol, []).extend(walk_forward.windows.to_dict("records"))
            walk_forward_summary_by_symbol.setdefault(symbol, []).append(walk_forward.summary)
            metrics_for_gate = {**bundle.metrics, **decay.summary, **walk_forward.summary}
            gate = evaluate_validation_gates(
                metrics_for_gate,
                min_trades=config.min_trades,
                max_loss_streak=config.max_loss_streak,
                max_drawdown_points=config.max_drawdown_points,
                lookahead_flags=result.lookahead_flags,
            )
            row = {
                "symbol": symbol,
                "strategy_id": variant.strategy_id,
                "base_strategy_id": variant.inverse_of or variant.strategy_id,
                "orientation": variant.orientation,
                "inverse_of": variant.inverse_of,
                "family": variant.family,
                "side": variant.side,
                "params_json": variant.params_json,
                "applied_cost_points": applied_cost.cost_points,
                "cost_profile_source": applied_cost.source,
                "cost_profile_warning": applied_cost.warning,
                "decision": gate.decision,
                "gate_reasons": "; ".join(gate.reasons) if gate.reasons else "NONE",
                **bundle.metrics,
                **_candidate_decay_fields(decay.summary),
                **_candidate_walk_forward_fields(walk_forward.summary),
            }
            candidate_rows.append(row)
            symbol_rows.append(row)
            if gate.passed and not trades.empty:
                all_phase_trades.append(trades)
            if best_row is None or float(row.get("net_points", 0.0)) > float(best_row.get("net_points", 0.0)):
                best_row = row
                best_bundle = bundle
                best_trades = trades
            if config.save_every and index % config.save_every == 0:
                partial_path = _save_partial_candidates(config.output_dir, symbol, symbol_rows)
                log(f"partial candidates saved symbol={symbol} variants={index} path={partial_path}")
            if index == len(variants) or index % progress_every == 0:
                elapsed = perf_counter() - symbol_started
                avg_seconds = elapsed / index if index else 0.0
                remaining_seconds = avg_seconds * max(0, len(variants) - index)
                log(
                    f"variant progress symbol={symbol} {index}/{len(variants)} "
                    f"elapsed={_format_duration(elapsed)} avg_seconds_per_backtest={avg_seconds:.4f} "
                    f"estimated_remaining={_format_duration(remaining_seconds)}"
                )
        if best_row and best_bundle:
            best_trades_by_symbol[symbol] = best_trades
            monthly_by_symbol[symbol] = best_bundle.monthly
            split_by_symbol[symbol] = best_bundle.split
            cost_metrics_by_symbol[symbol] = best_bundle.cost_sensitivity
        portfolio_frame = pd.concat(all_phase_trades, ignore_index=True) if all_phase_trades else pd.DataFrame()
        portfolio = analyze_portfolio(portfolio_frame).to_dict()
        paths = write_strategy_lab_reports(
            config.output_dir,
            data_summaries=data_summaries,
            candidate_rows=candidate_rows,
            base_variants_generated=base_variants_generated,
            inverse_variants_generated=inverse_variants_generated,
            total_backtests_attempted=total_backtests_attempted,
            include_inverse=include_inverse,
            strategy_orientation=strategy_orientation,
            trades_by_symbol=best_trades_by_symbol,
            monthly_by_symbol=monthly_by_symbol,
            split_by_symbol=split_by_symbol,
            cost_by_symbol=cost_metrics_by_symbol,
            yearwise_by_symbol=_frames_by_symbol(yearwise_rows_by_symbol, columns=YEARWISE_COLUMNS),
            recent_by_symbol=_frames_by_symbol(recent_rows_by_symbol, columns=RECENT_COLUMNS),
            decay_by_symbol=_frames_by_symbol(decay_rows_by_symbol, columns=DECAY_COLUMNS),
            walk_forward_windows_by_symbol=_frames_by_symbol(
                walk_forward_windows_by_symbol,
                columns=WALK_FORWARD_WINDOW_COLUMNS,
            ),
            walk_forward_summary_by_symbol=_frames_by_symbol(
                walk_forward_summary_by_symbol,
                columns=WALK_FORWARD_SUMMARY_COLUMNS,
            ),
            portfolio_summary=portfolio,
        )
        log(
            f"symbol search completed symbol={symbol} variants={len(symbol_rows)} "
            f"elapsed={_format_duration(perf_counter() - symbol_started)} reports_flushed=true"
        )
    portfolio_frame = pd.concat(all_phase_trades, ignore_index=True) if all_phase_trades else pd.DataFrame()
    portfolio = analyze_portfolio(portfolio_frame).to_dict()
    paths = write_strategy_lab_reports(
        config.output_dir,
        data_summaries=data_summaries,
        candidate_rows=candidate_rows,
        base_variants_generated=base_variants_generated,
        inverse_variants_generated=inverse_variants_generated,
        total_backtests_attempted=total_backtests_attempted,
        include_inverse=include_inverse,
        strategy_orientation=strategy_orientation,
        trades_by_symbol=best_trades_by_symbol,
        monthly_by_symbol=monthly_by_symbol,
        split_by_symbol=split_by_symbol,
        cost_by_symbol=cost_metrics_by_symbol,
        yearwise_by_symbol=_frames_by_symbol(yearwise_rows_by_symbol, columns=YEARWISE_COLUMNS),
        recent_by_symbol=_frames_by_symbol(recent_rows_by_symbol, columns=RECENT_COLUMNS),
        decay_by_symbol=_frames_by_symbol(decay_rows_by_symbol, columns=DECAY_COLUMNS),
        walk_forward_windows_by_symbol=_frames_by_symbol(
            walk_forward_windows_by_symbol,
            columns=WALK_FORWARD_WINDOW_COLUMNS,
        ),
        walk_forward_summary_by_symbol=_frames_by_symbol(
            walk_forward_summary_by_symbol,
            columns=WALK_FORWARD_SUMMARY_COLUMNS,
        ),
        portfolio_summary=portfolio,
    )
    print(f"Report: {paths['master']}")
    log(f"strategy lab completed elapsed={_format_duration(perf_counter() - run_started)}")
    print("execution_allowed=false")
    return paths


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Strategy Lab V3 research-only backtester.")
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--symbols", nargs="+", required=True)
    parser.add_argument("--session-start")
    parser.add_argument("--session-end")
    parser.add_argument("--auto-session-profile", default="true")
    parser.add_argument("--use-full-valid-session", default="true")
    parser.add_argument("--max-variants", type=int, default=1000)
    parser.add_argument("--include-inverse", default="false")
    parser.add_argument("--strategy-orientation", default="original", choices=["original", "inverse", "both"])
    parser.add_argument("--random-seed", type=int, default=42)
    parser.add_argument("--top-n", type=int, default=100)
    parser.add_argument("--families", nargs="*")
    parser.add_argument("--min-trades", type=int, default=80)
    parser.add_argument("--cost-points", type=float, default=0.0)
    parser.add_argument("--cost-profile")
    parser.add_argument("--output-dir", default=str(Path("reports") / "strategy_lab" / "v3"))
    parser.add_argument("--save-every", type=int, default=0)
    parser.add_argument("--progress-every", type=int, default=100)
    parser.add_argument("--validate-only", default="false")
    parser.add_argument("--benchmark", default="false")
    parser.add_argument("--max-bars", type=int)
    return parser


def config_from_args(args: argparse.Namespace) -> StrategyLabConfig:
    return StrategyLabConfig(
        data_dir=Path(args.data_dir),
        symbols=parse_symbols(args.symbols),
        output_dir=Path(args.output_dir),
        session_start=parse_time(args.session_start),
        session_end=parse_time(args.session_end),
        auto_session_profile=parse_bool(args.auto_session_profile, default=True),
        use_full_valid_session=parse_bool(args.use_full_valid_session, default=True),
        max_variants=args.max_variants,
        include_inverse=parse_bool(args.include_inverse, default=False),
        strategy_orientation=args.strategy_orientation,
        random_seed=args.random_seed,
        top_n=args.top_n,
        families=families_tuple(args.families),
        min_trades=args.min_trades,
        cost_points=args.cost_points,
        cost_profile=Path(args.cost_profile) if args.cost_profile else None,
        save_every=args.save_every,
        progress_every=args.progress_every,
        validate_only=parse_bool(args.validate_only, default=False),
        benchmark=parse_bool(args.benchmark, default=False),
        max_bars=args.max_bars,
    )


def _save_partial_candidates(output_dir: Path, symbol: str, rows: list[dict]) -> Path:
    import pandas as pd

    path = Path(output_dir) / f"partial_candidates_{_safe_symbol(symbol)}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False)
    return path


def _summary_with_cost(summary, applied_cost) -> dict:
    data = summary.to_dict()
    warnings = data.get("warnings", "")
    if applied_cost.warning:
        data["warnings"] = f"{warnings}; {applied_cost.warning}" if warnings else applied_cost.warning
    data["applied_cost_points"] = applied_cost.cost_points
    data["cost_profile_source"] = applied_cost.source
    return data


def _candidate_decay_fields(summary: dict) -> dict:
    keys = [
        "positive_years",
        "negative_years",
        "best_year",
        "worst_year",
        "2025_net_points",
        "2026_net_points",
        "2025_2026_net_points",
        "recent_net_points",
        "recent_profit_factor",
        "recent_trades",
        "recent_win_rate",
        "stability_label",
        "decay_label",
        "year_dependency_ratio",
        "month_dependency_ratio",
    ]
    return {key: summary.get(key, "") for key in keys}


def _candidate_walk_forward_fields(summary: dict) -> dict:
    keys = [
        "walk_forward_windows_total",
        "walk_forward_windows_passed",
        "walk_forward_windows_failed",
        "walk_forward_pass_rate",
        "walk_forward_test_net_points_total",
        "walk_forward_test_profit_factor",
        "walk_forward_recent_window_status",
        "walk_forward_label",
        "usable_walk_forward_windows",
        "insufficient_walk_forward_windows",
        "failed_walk_forward_windows",
        "passed_walk_forward_windows",
        "recent_window_year",
        "recent_window_test_trades",
        "recent_window_test_net_points",
        "recent_window_status",
        "walk_forward_block_reason",
    ]
    return {key: summary.get(key, "") for key in keys}


def _frames_by_symbol(rows_by_symbol: dict[str, list[dict]], *, columns: list[str]) -> dict:
    import pandas as pd

    return {symbol: pd.DataFrame(rows, columns=columns) for symbol, rows in rows_by_symbol.items()}


def _benchmark_skip_row(symbol: str, config: StrategyLabConfig, status: str, applied_cost) -> dict:
    return {
        "symbol": symbol,
        "status": status,
        "applied_cost_points": applied_cost.cost_points,
        "cost_profile_source": applied_cost.source,
        "bars_used": 0,
        "base_variants_sampled": 0,
        "backtests_sampled": 0,
        "original_variants_sampled": 0,
        "inverse_variants_sampled": 0,
        "seconds_total": 0.0,
        "average_seconds_per_backtest": 0.0,
        "max_variants": int(config.max_variants or 0),
        "estimated_seconds_for_max_variants_with_inverse": 0.0,
        "estimated_minutes_for_max_variants_with_inverse": 0.0,
    }


def _format_duration(seconds: float) -> str:
    seconds = max(0.0, float(seconds or 0.0))
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes, rem = divmod(seconds, 60)
    if minutes < 60:
        return f"{int(minutes)}m {rem:.0f}s"
    hours, minutes = divmod(minutes, 60)
    return f"{int(hours)}h {int(minutes)}m"


def _safe_symbol(symbol: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(symbol))


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        run_strategy_lab(config_from_args(args))
    except ModuleNotFoundError as exc:
        if exc.name in {"pandas", "numpy"}:
            print("STRATEGY LAB V3")
            for line in safety_lines():
                print(line)
            print(f"Missing dependency: {exc.name}. Install the project requirements before running large research jobs.")
            print("No backtest was run.")
            return 2
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
