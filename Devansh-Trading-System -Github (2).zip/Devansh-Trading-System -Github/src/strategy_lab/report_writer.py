from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from src.strategy_lab.config import (
    BACKTEST_ONLY,
    NOT_REAL_MONEY_READY,
    PHASE6A_BACKTEST_CANDIDATE,
    REJECTED,
    RESEARCH_ONLY,
    WATCHLIST,
    safety_lines,
)
from src.strategy_lab.strategy_decay import (
    OLD_EDGE_ONLY,
    RECENTLY_WORKING_NEEDS_FORWARD_DATA,
    STABLE_ACROSS_YEARS,
    STRATEGY_DECAYED,
)
from src.strategy_lab.walk_forward_validation import (
    WALK_FORWARD_FAIL,
    WALK_FORWARD_INSUFFICIENT_DATA,
    WALK_FORWARD_MIXED,
    WALK_FORWARD_PASS,
    WALK_FORWARD_RECENT_INSUFFICIENT,
)


def write_strategy_lab_reports(
    output_dir: Path | str,
    *,
    data_summaries: list[dict[str, Any]],
    candidate_rows: list[dict[str, Any]],
    base_variants_generated: int = 0,
    inverse_variants_generated: int = 0,
    total_backtests_attempted: int = 0,
    include_inverse: bool = False,
    strategy_orientation: str = "original",
    trades_by_symbol: dict[str, pd.DataFrame],
    monthly_by_symbol: dict[str, pd.DataFrame],
    split_by_symbol: dict[str, pd.DataFrame],
    cost_by_symbol: dict[str, pd.DataFrame],
    portfolio_summary: dict[str, Any] | None = None,
    yearwise_by_symbol: dict[str, pd.DataFrame] | None = None,
    recent_by_symbol: dict[str, pd.DataFrame] | None = None,
    decay_by_symbol: dict[str, pd.DataFrame] | None = None,
    walk_forward_windows_by_symbol: dict[str, pd.DataFrame] | None = None,
    walk_forward_summary_by_symbol: dict[str, pd.DataFrame] | None = None,
) -> dict[str, Path]:
    base = Path(output_dir)
    base.mkdir(parents=True, exist_ok=True)
    candidates = pd.DataFrame(candidate_rows)
    data_summary = pd.DataFrame(data_summaries)
    yearwise_by_symbol = yearwise_by_symbol or {}
    recent_by_symbol = recent_by_symbol or {}
    decay_by_symbol = decay_by_symbol or {}
    walk_forward_windows_by_symbol = walk_forward_windows_by_symbol or {}
    walk_forward_summary_by_symbol = walk_forward_summary_by_symbol or {}
    paths = {
        "master": base / "strategy_lab_v3_master_report.txt",
        "summary": base / "strategy_lab_v3_summary.csv",
        "data_validation": base / "data_validation_summary.csv",
        "all_candidates": base / "all_candidates_ranked.csv",
        "rejected": base / "rejected_candidates.csv",
        "watchlist": base / "watchlist_candidates.csv",
        "phase6a": base / "phase6a_candidates.csv",
        "inverse_candidates": base / "inverse_strategy_candidates.csv",
        "original_vs_inverse": base / "original_vs_inverse_comparison.csv",
    }
    _write_csv(paths["summary"], candidates)
    _write_csv(paths["data_validation"], data_summary)
    ranked = candidates.sort_values(["decision", "net_points"], ascending=[True, False]) if not candidates.empty and "net_points" in candidates else candidates
    _write_csv(paths["all_candidates"], ranked)
    _write_csv(paths["rejected"], _decision_frame(candidates, REJECTED))
    _write_csv(paths["watchlist"], _decision_frame(candidates, WATCHLIST))
    _write_csv(paths["phase6a"], _decision_frame(candidates, PHASE6A_BACKTEST_CANDIDATE))
    _write_csv(paths["inverse_candidates"], _orientation_frame(candidates, "INVERSE"))
    _write_csv(paths["original_vs_inverse"], _comparison_frame(candidates))
    best_by_symbol = _best_rows(candidates)
    for symbol, best in best_by_symbol.items():
        safe = _safe_symbol(symbol)
        best_report = base / f"{safe}_best_report.txt"
        best_trades = base / f"{safe}_best_trades.csv"
        monthly = base / f"{safe}_monthly_metrics.csv"
        split = base / f"{safe}_split_metrics.csv"
        cost = base / f"{safe}_cost_sensitivity.csv"
        _write_best_report(best_report, symbol, best)
        _write_csv(best_trades, trades_by_symbol.get(symbol, pd.DataFrame()))
        _write_csv(monthly, monthly_by_symbol.get(symbol, pd.DataFrame()))
        _write_csv(split, split_by_symbol.get(symbol, pd.DataFrame()))
        _write_csv(cost, cost_by_symbol.get(symbol, pd.DataFrame()))
        paths[f"{symbol}_best_report"] = best_report
        paths[f"{symbol}_best_trades"] = best_trades
        paths[f"{symbol}_monthly_metrics"] = monthly
        paths[f"{symbol}_split_metrics"] = split
        paths[f"{symbol}_cost_sensitivity"] = cost
    for symbol, frame in sorted(yearwise_by_symbol.items()):
        safe = _safe_symbol(symbol)
        path = base / f"{safe}_yearwise_metrics.csv"
        _write_csv(path, frame)
        paths[f"{symbol}_yearwise_metrics"] = path
    for symbol, frame in sorted(recent_by_symbol.items()):
        safe = _safe_symbol(symbol)
        path = base / f"{safe}_recent_period_metrics.csv"
        _write_csv(path, frame)
        paths[f"{symbol}_recent_period_metrics"] = path
    for symbol, frame in sorted(decay_by_symbol.items()):
        safe = _safe_symbol(symbol)
        path = base / f"{safe}_strategy_decay_report.csv"
        _write_csv(path, frame)
        paths[f"{symbol}_strategy_decay_report"] = path
    for symbol, frame in sorted(walk_forward_windows_by_symbol.items()):
        safe = _safe_symbol(symbol)
        path = base / f"{safe}_walk_forward_windows.csv"
        _write_csv(path, frame)
        paths[f"{symbol}_walk_forward_windows"] = path
    for symbol, frame in sorted(walk_forward_summary_by_symbol.items()):
        safe = _safe_symbol(symbol)
        path = base / f"{safe}_walk_forward_summary.csv"
        _write_csv(path, frame)
        paths[f"{symbol}_walk_forward_summary"] = path
    _write_master_report(
        paths["master"],
        data_summaries,
        candidates,
        portfolio_summary or {},
        base_variants_generated=base_variants_generated,
        inverse_variants_generated=inverse_variants_generated,
        total_backtests_attempted=total_backtests_attempted,
        include_inverse=include_inverse,
        strategy_orientation=strategy_orientation,
    )
    return paths


def write_data_validation_summary(output_dir: Path | str, data_summaries: list[dict[str, Any]]) -> Path:
    path = Path(output_dir) / "data_validation_summary.csv"
    _write_csv(path, pd.DataFrame(data_summaries))
    return path


def write_runtime_benchmark_report(output_dir: Path | str, rows: list[dict[str, Any]]) -> Path:
    path = Path(output_dir) / "runtime_benchmark_report.csv"
    _write_csv(path, pd.DataFrame(rows))
    return path


def _write_master_report(
    path: Path,
    data_summaries: list[dict[str, Any]],
    candidates: pd.DataFrame,
    portfolio: dict[str, Any],
    *,
    base_variants_generated: int,
    inverse_variants_generated: int,
    total_backtests_attempted: int,
    include_inverse: bool,
    strategy_orientation: str,
) -> None:
    decisions = candidates["decision"].value_counts().to_dict() if not candidates.empty and "decision" in candidates else {}
    original_count = _orientation_count(candidates, "ORIGINAL")
    inverse_count = _orientation_count(candidates, "INVERSE")
    best_original = _best_by_orientation(candidates, "ORIGINAL")
    best_inverse = _best_by_orientation(candidates, "INVERSE")
    comparison = _comparison_frame(candidates)
    applied_costs = _format_applied_costs(candidates)
    stable_rows = _format_top_stable_rows(candidates)
    decayed_count = _label_count(candidates, "decay_label", {STRATEGY_DECAYED, OLD_EDGE_ONLY})
    recent_only_count = _label_count(candidates, "decay_label", {RECENTLY_WORKING_NEEDS_FORWARD_DATA})
    rejected_recent_failure_count = _rejected_due_to_recent_period_failure(candidates)
    walk_forward_pass_count = _label_count(candidates, "walk_forward_label", {WALK_FORWARD_PASS})
    walk_forward_mixed_count = _label_count(candidates, "walk_forward_label", {WALK_FORWARD_MIXED})
    walk_forward_fail_count = _label_count(candidates, "walk_forward_label", {WALK_FORWARD_FAIL})
    walk_forward_insufficient_count = _label_count(candidates, "walk_forward_label", {WALK_FORWARD_INSUFFICIENT_DATA})
    walk_forward_recent_insufficient_count = _label_count(
        candidates,
        "walk_forward_label",
        {WALK_FORWARD_RECENT_INSUFFICIENT},
    )
    best_walk_forward_rows = _format_top_walk_forward_rows(candidates)
    blocked_walk_forward_count = _blocked_due_to_walk_forward(candidates)
    lines = [
        "STRATEGY LAB V3 MASTER REPORT",
        *safety_lines(),
        "",
        "Purpose: professional multi-script strategy research and backtesting only.",
        "Validation gates never approve real-money trading.",
        "",
        "DATA SUMMARY",
        f"symbols_checked: {len(data_summaries)}",
        f"usable_symbols: {sum(1 for item in data_summaries if item.get('decision') == 'DATA_USABLE')}",
        "",
        "CANDIDATE SUMMARY",
        f"base_variants_generated: {base_variants_generated}",
        f"inverse_variants_generated: {inverse_variants_generated}",
        f"total_backtests_attempted: {total_backtests_attempted}",
        f"include_inverse: {str(include_inverse).lower()}",
        f"strategy_orientation: {strategy_orientation}",
        f"total_variants_tested: {len(candidates)}",
        f"original_variants_tested: {original_count}",
        f"inverse_variants_tested: {inverse_count}",
        f"rejected: {decisions.get(REJECTED, 0)}",
        f"watchlist: {decisions.get(WATCHLIST, 0)}",
        f"phase6a_candidates: {decisions.get(PHASE6A_BACKTEST_CANDIDATE, 0)}",
        "",
        "APPLIED COSTS",
        *(applied_costs if applied_costs else ["NONE"]),
        "",
        "STABILITY / DECAY",
        f"best_stable_strategies: {len(stable_rows)}",
        *(stable_rows if stable_rows else ["NONE"]),
        f"decayed_strategies_count: {decayed_count}",
        f"recent_only_strategies_count: {recent_only_count}",
        f"rejected_due_to_recent_period_failure: {rejected_recent_failure_count}",
        "",
        "WALK-FORWARD VALIDATION",
        f"walk_forward_pass_count: {walk_forward_pass_count}",
        f"walk_forward_mixed_count: {walk_forward_mixed_count}",
        f"walk_forward_fail_count: {walk_forward_fail_count}",
        f"walk_forward_insufficient_count: {walk_forward_insufficient_count}",
        f"walk_forward_recent_insufficient_count: {walk_forward_recent_insufficient_count}",
        f"strategies_blocked_due_to_walk_forward_failure: {blocked_walk_forward_count}",
        "BEST WALK-FORWARD STRATEGIES",
        *(best_walk_forward_rows if best_walk_forward_rows else ["NONE"]),
        "",
        "BEST ORIGINAL BY SYMBOL",
        *(_format_best_rows(best_original) if best_original else ["NONE"]),
        "",
        "BEST INVERSE BY SYMBOL",
        *(_format_best_rows(best_inverse) if best_inverse else ["NONE"]),
        "",
        "ORIGINAL VS INVERSE",
        *(_format_comparison_summary(comparison) if not comparison.empty else ["No paired original/inverse rows available."]),
        "Inverse mode is still BACKTEST_ONLY / RESEARCH_ONLY / NOT_REAL_MONEY_READY.",
        "",
        "PORTFOLIO ANALYZER",
    ]
    if portfolio:
        lines.extend(f"{key}: {value}" for key, value in portfolio.items())
    else:
        lines.append("No portfolio candidates available.")
    lines.extend(
        [
            "",
            "FINAL STATUS",
            RESEARCH_ONLY,
            BACKTEST_ONLY,
            NOT_REAL_MONEY_READY,
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_best_report(path: Path, symbol: str, row: dict[str, Any]) -> None:
    lines = [
        f"STRATEGY LAB V3 BEST REPORT - {symbol}",
        *safety_lines(),
        "",
    ]
    lines.extend(f"{key}: {value}" for key, value in sorted(row.items()))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def _decision_frame(candidates: pd.DataFrame, decision: str) -> pd.DataFrame:
    if candidates.empty or "decision" not in candidates:
        return candidates
    return candidates.loc[candidates["decision"] == decision].copy()


def _orientation_frame(candidates: pd.DataFrame, orientation: str) -> pd.DataFrame:
    if candidates.empty or "orientation" not in candidates:
        return candidates.iloc[0:0].copy() if not candidates.empty else candidates
    return candidates.loc[candidates["orientation"] == orientation].copy()


def _comparison_frame(candidates: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "symbol",
        "original_strategy_id",
        "inverse_strategy_id",
        "family",
        "original_net_points",
        "inverse_net_points",
        "original_pf",
        "inverse_pf",
        "original_win_rate",
        "inverse_win_rate",
        "original_trades",
        "inverse_trades",
        "original_decision",
        "inverse_decision",
        "better_orientation",
        "notes",
    ]
    if candidates.empty or not {"orientation", "strategy_id"}.issubset(candidates.columns):
        return pd.DataFrame(columns=columns)
    originals = candidates.loc[candidates["orientation"] == "ORIGINAL"].copy()
    inverses = candidates.loc[candidates["orientation"] == "INVERSE"].copy()
    rows = []
    for _, inverse in inverses.iterrows():
        original_id = str(inverse.get("inverse_of") or "").strip()
        original_match = originals.loc[originals["strategy_id"] == original_id]
        if original_match.empty:
            continue
        original = original_match.iloc[0]
        original_net = float(original.get("net_points", 0.0) or 0.0)
        inverse_net = float(inverse.get("net_points", 0.0) or 0.0)
        rows.append({
            "symbol": inverse.get("symbol", original.get("symbol", "")),
            "original_strategy_id": original_id,
            "inverse_strategy_id": inverse.get("strategy_id", ""),
            "family": inverse.get("family", original.get("family", "")),
            "original_net_points": original_net,
            "inverse_net_points": inverse_net,
            "original_pf": float(original.get("profit_factor", 0.0) or 0.0),
            "inverse_pf": float(inverse.get("profit_factor", 0.0) or 0.0),
            "original_win_rate": float(original.get("win_rate", 0.0) or 0.0),
            "inverse_win_rate": float(inverse.get("win_rate", 0.0) or 0.0),
            "original_trades": int(original.get("trades", 0) or 0),
            "inverse_trades": int(inverse.get("trades", 0) or 0),
            "original_decision": original.get("decision", ""),
            "inverse_decision": inverse.get("decision", ""),
            "better_orientation": _better_orientation(original, inverse, original_net, inverse_net),
            "notes": _comparison_notes(original_net, inverse_net),
        })
    return pd.DataFrame(rows, columns=columns)


def _best_rows(candidates: pd.DataFrame) -> dict[str, dict[str, Any]]:
    if candidates.empty or "symbol" not in candidates or "net_points" not in candidates:
        return {}
    rows = {}
    for symbol, group in candidates.sort_values("net_points", ascending=False).groupby("symbol", sort=True):
        rows[str(symbol)] = group.iloc[0].to_dict()
    return rows


def _orientation_count(candidates: pd.DataFrame, orientation: str) -> int:
    if candidates.empty or "orientation" not in candidates:
        return 0
    return int((candidates["orientation"] == orientation).sum())


def _best_by_orientation(candidates: pd.DataFrame, orientation: str) -> dict[str, dict[str, Any]]:
    return _best_rows(_orientation_frame(candidates, orientation))


def _format_best_rows(rows: dict[str, dict[str, Any]]) -> list[str]:
    return [
        (
            f"- {symbol}: {row.get('strategy_id')} net_points={row.get('net_points')} "
            f"decision={row.get('decision')}"
        )
        for symbol, row in sorted(rows.items())
    ]


def _format_comparison_summary(comparison: pd.DataFrame) -> list[str]:
    counts = comparison["better_orientation"].value_counts().to_dict()
    return [f"{key}: {value}" for key, value in sorted(counts.items())]


def _format_applied_costs(candidates: pd.DataFrame) -> list[str]:
    if candidates.empty or "symbol" not in candidates or "applied_cost_points" not in candidates:
        return []
    rows = []
    columns = ["symbol", "applied_cost_points"]
    if "cost_profile_source" in candidates:
        columns.append("cost_profile_source")
    for _, row in candidates[columns].drop_duplicates().sort_values("symbol").iterrows():
        source = row.get("cost_profile_source", "")
        source_text = f" cost_profile_source={source}" if source else ""
        rows.append(f"- {row.get('symbol')}: applied_cost_points={row.get('applied_cost_points')}{source_text}")
    return rows


def _format_top_stable_rows(candidates: pd.DataFrame, limit: int = 10) -> list[str]:
    if candidates.empty or "stability_label" not in candidates or "net_points" not in candidates:
        return []
    stable = candidates.loc[candidates["stability_label"] == STABLE_ACROSS_YEARS].copy()
    if stable.empty:
        return []
    stable["net_points"] = pd.to_numeric(stable["net_points"], errors="coerce").fillna(0.0)
    rows = []
    for _, row in stable.sort_values("net_points", ascending=False).head(limit).iterrows():
        rows.append(
            f"- {row.get('symbol')}: {row.get('strategy_id')} net_points={row.get('net_points')} "
            f"recent_net_points={row.get('recent_net_points')} decision={row.get('decision')}"
        )
    return rows


def _label_count(candidates: pd.DataFrame, column: str, labels: set[str]) -> int:
    if candidates.empty or column not in candidates:
        return 0
    return int(candidates[column].isin(labels).sum())


def _rejected_due_to_recent_period_failure(candidates: pd.DataFrame) -> int:
    if candidates.empty or "decision" not in candidates:
        return 0
    rejected = candidates["decision"] == REJECTED
    if "recent_net_points" in candidates:
        recent = pd.to_numeric(candidates["recent_net_points"], errors="coerce").fillna(0.0) < 0
        return int((rejected & recent).sum())
    if "gate_reasons" in candidates:
        return int((rejected & candidates["gate_reasons"].astype(str).str.contains("2025_2026_net_points negative")).sum())
    return 0


def _format_top_walk_forward_rows(candidates: pd.DataFrame, limit: int = 10) -> list[str]:
    if candidates.empty or "walk_forward_label" not in candidates or "walk_forward_test_net_points_total" not in candidates:
        return []
    accepted = candidates.loc[candidates["walk_forward_label"].isin({WALK_FORWARD_PASS, WALK_FORWARD_MIXED})].copy()
    if accepted.empty:
        return []
    accepted["walk_forward_test_net_points_total"] = pd.to_numeric(
        accepted["walk_forward_test_net_points_total"],
        errors="coerce",
    ).fillna(0.0)
    rows = []
    for _, row in accepted.sort_values("walk_forward_test_net_points_total", ascending=False).head(limit).iterrows():
        rows.append(
            f"- {row.get('symbol')}: {row.get('strategy_id')} label={row.get('walk_forward_label')} "
            f"test_net={row.get('walk_forward_test_net_points_total')} "
            f"pass_rate={row.get('walk_forward_pass_rate')} decision={row.get('decision')}"
        )
    return rows


def _blocked_due_to_walk_forward(candidates: pd.DataFrame) -> int:
    if candidates.empty or "gate_reasons" not in candidates:
        return 0
    rejected = candidates["decision"].eq(REJECTED) if "decision" in candidates else pd.Series(True, index=candidates.index)
    blocked = candidates["gate_reasons"].astype(str).str.contains("walk-forward", case=False, regex=False)
    return int((rejected & blocked).sum())


def _better_orientation(original: pd.Series, inverse: pd.Series, original_net: float, inverse_net: float) -> str:
    original_decision = str(original.get("decision", ""))
    inverse_decision = str(inverse.get("decision", ""))
    strong = PHASE6A_BACKTEST_CANDIDATE
    if original_decision == strong and inverse_decision == strong:
        return "BOTH_STRONG"
    if original_net <= 0 and inverse_net <= 0:
        return "BOTH_WEAK"
    if original_decision == strong and inverse_decision != strong:
        return "ORIGINAL"
    if inverse_decision == strong and original_decision != strong:
        return "INVERSE"
    if original_net > 0 and inverse_net > 0:
        return "MIXED_NEEDS_REVIEW"
    return "ORIGINAL" if original_net > inverse_net else "INVERSE"


def _comparison_notes(original_net: float, inverse_net: float) -> str:
    if original_net > inverse_net:
        return "inverse worsened results"
    if inverse_net > original_net:
        return "inverse improved results"
    return "original and inverse tied"


def _safe_symbol(symbol: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in symbol)
