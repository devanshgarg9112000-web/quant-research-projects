from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd


NORMALIZED_COLUMNS = [
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "open_interest",
    "symbol",
    "contract",
    "expiry",
]

ALIASES = {
    "timestamp": ("timestamp", "datetime", "date_time", "date time", "time"),
    "date": ("date", "trading_date"),
    "open": ("open", "o"),
    "high": ("high", "h"),
    "low": ("low", "l"),
    "close": ("close", "c", "ltp", "last_price"),
    "volume": ("volume", "vol", "volume_traded"),
    "open_interest": ("open_interest", "oi", "open interest"),
    "symbol": ("symbol", "ticker", "instrument", "name"),
    "contract": ("contract", "tradingsymbol", "kite_tradingsymbol"),
    "expiry": ("expiry", "expiry_date"),
}


DATA_FILE_FOUND = "DATA_FILE_FOUND"
DATA_FILE_NOT_FOUND = "DATA_FILE_NOT_FOUND"
AMBIGUOUS_DATA_FILE = "AMBIGUOUS_DATA_FILE"


@dataclass(frozen=True)
class FileMappingResult:
    requested_symbol: str
    matched_file: Path | None
    parsed_file_symbol: str
    status: str
    notes: str = ""

    def to_dict(self) -> dict[str, str]:
        return {
            "requested_symbol": self.requested_symbol,
            "matched_file": str(self.matched_file or ""),
            "parsed_file_symbol": self.parsed_file_symbol,
            "status": self.status,
            "notes": self.notes,
        }


class DataFileMappingError(FileNotFoundError):
    def __init__(self, mapping: FileMappingResult) -> None:
        super().__init__(mapping.notes)
        self.mapping = mapping


def parse_file_symbol(path: Path | str) -> str:
    stem = Path(path).stem.upper()
    marker = "_FUT_"
    if marker not in stem:
        return ""
    return stem.split(marker, 1)[0].strip().upper()


def resolve_symbol_file(data_dir: Path | str, symbol: str) -> FileMappingResult:
    base = Path(data_dir)
    requested = str(symbol or "").strip().upper()
    if not requested:
        return FileMappingResult(
            requested_symbol=requested,
            matched_file=None,
            parsed_file_symbol="",
            status=DATA_FILE_NOT_FOUND,
            notes="requested symbol is empty",
        )
    if not base.exists():
        return FileMappingResult(
            requested_symbol=requested,
            matched_file=None,
            parsed_file_symbol="",
            status=DATA_FILE_NOT_FOUND,
            notes=f"data directory not found: {base}",
        )
    matches: list[tuple[Path, str]] = []
    for path in base.rglob("*.csv"):
        parsed = parse_file_symbol(path)
        if parsed == requested:
            matches.append((path, parsed))
    if not matches:
        return FileMappingResult(
            requested_symbol=requested,
            matched_file=None,
            parsed_file_symbol="",
            status=DATA_FILE_NOT_FOUND,
            notes="no exact filename symbol match before _FUT_",
        )
    if len(matches) > 1:
        matched = ";".join(str(path) for path, _parsed in sorted(matches))
        return FileMappingResult(
            requested_symbol=requested,
            matched_file=None,
            parsed_file_symbol=requested,
            status=AMBIGUOUS_DATA_FILE,
            notes=f"multiple exact filename symbol matches: {matched}",
        )
    path, parsed = matches[0]
    return FileMappingResult(
        requested_symbol=requested,
        matched_file=path,
        parsed_file_symbol=parsed,
        status=DATA_FILE_FOUND,
        notes="exact filename symbol match before _FUT_",
    )


def write_file_mapping_report(path: Path | str, mappings: list[FileMappingResult]) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    columns = ["requested_symbol", "matched_file", "parsed_file_symbol", "status", "notes"]
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for mapping in mappings:
            writer.writerow(mapping.to_dict())
    return output


def find_symbol_csv(data_dir: Path | str, symbol: str) -> Path | None:
    mapping = resolve_symbol_file(data_dir, symbol)
    return mapping.matched_file if mapping.status == DATA_FILE_FOUND else None


def load_symbol_csv(data_dir: Path | str, symbol: str) -> pd.DataFrame:
    mapping = resolve_symbol_file(data_dir, symbol)
    if mapping.status != DATA_FILE_FOUND or mapping.matched_file is None:
        raise DataFileMappingError(mapping)
    return load_csv(mapping.matched_file, default_symbol=symbol)


def load_csv(path: Path | str, *, default_symbol: str = "") -> pd.DataFrame:
    source = pd.read_csv(path)
    return normalize_columns(source, default_symbol=default_symbol)


def normalize_columns(df: pd.DataFrame, *, default_symbol: str = "") -> pd.DataFrame:
    source = df.copy()
    lowered = {str(column).strip().lower(): column for column in source.columns}
    output = pd.DataFrame()
    timestamp_col = _find_column(lowered, ALIASES["timestamp"])
    date_col = _find_column(lowered, ALIASES["date"])
    if timestamp_col:
        output["timestamp"] = pd.to_datetime(source[timestamp_col], errors="coerce")
    elif date_col and _find_column(lowered, ("time",)):
        time_col = _find_column(lowered, ("time",))
        output["timestamp"] = pd.to_datetime(
            source[date_col].astype(str) + " " + source[time_col].astype(str),
            errors="coerce",
        )
    for normalized in ("open", "high", "low", "close", "volume", "open_interest"):
        column = _find_column(lowered, ALIASES[normalized])
        if column:
            output[normalized] = pd.to_numeric(source[column], errors="coerce")
    if "open_interest" not in output:
        output["open_interest"] = pd.NA
    if "volume" not in output:
        output["volume"] = pd.NA
    for normalized in ("symbol", "contract", "expiry"):
        column = _find_column(lowered, ALIASES[normalized])
        if column:
            output[normalized] = source[column].astype(str)
    if "symbol" not in output:
        output["symbol"] = default_symbol
    if "contract" not in output:
        output["contract"] = ""
    if "expiry" not in output:
        output["expiry"] = ""
    if "timestamp" in output:
        output = output.sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    return output


def _find_column(columns: dict[str, str], aliases: Iterable[str]) -> str | None:
    for alias in aliases:
        key = alias.lower()
        if key in columns:
            return columns[key]
    return None
