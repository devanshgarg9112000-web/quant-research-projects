from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from src.strategy_lab.metrics import calculate_metrics


@dataclass
class WalkForwardResult:
    split_metrics: pd.DataFrame
    train_net_points: float
    validation_net_points: float
    oos_net_points: float
    holdout_net_points: float


def walk_forward_summary(trades: pd.DataFrame) -> WalkForwardResult:
    bundle = calculate_metrics(trades)
    split = bundle.split
    values = {row["split"]: float(row["net_points"]) for _, row in split.iterrows()} if not split.empty else {}
    return WalkForwardResult(
        split_metrics=split,
        train_net_points=values.get("train", 0.0),
        validation_net_points=values.get("validation", 0.0),
        oos_net_points=values.get("oos", 0.0),
        holdout_net_points=values.get("holdout", 0.0),
    )

