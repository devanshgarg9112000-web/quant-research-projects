from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

import pandas as pd

from src.strategy_lab.config import NEEDS_SESSION_PROFILE
from src.strategy_lab.session_filters import apply_valid_market_session_filter, invalid_candle_mask


DATA_REJECTED = "DATA_REJECTED"
DATA_USABLE = "DATA_USABLE"
REQUIRED_PRICE_COLUMNS = ("open", "high", "low", "close")


@dataclass
class DataValidationSummary:
    symbol: str
    rows_raw: int = 0
    rows_after_valid_session_filter: int = 0
    date_range_raw: str = ""
    date_range_used: str = ""
    unique_trading_days: int = 0
    duplicate_timestamps: int = 0
    bad_ohlc_rows: int = 0
    nan_rows: int = 0
    negative_volume_rows: int = 0
    zero_volume_rows: int = 0
    nonpositive_price_rows: int = 0
    large_gap_or_jump_warnings: int = 0
    missing_days_estimate: int = 0
    contract_count: int = 0
    expiry_count: int = 0
    rejected_out_of_session_rows: int = 0
    rejected_invalid_rows: int = 0
    session_profile_used: str = ""
    decision: str = DATA_REJECTED
    missing_required_columns: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    session_start_end_by_day: dict[date, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = dict(self.__dict__)
        data["missing_required_columns"] = ",".join(self.missing_required_columns)
        data["warnings"] = "; ".join(self.warnings)
        data["session_start_end_by_day"] = "; ".join(
            f"{day}:{text}" for day, text in sorted(self.session_start_end_by_day.items())
        )
        return data


def validate_raw_data(df: pd.DataFrame, symbol: str) -> DataValidationSummary:
    summary = DataValidationSummary(symbol=symbol, rows_raw=len(df))
    summary.missing_required_columns = [
        column for column in ("timestamp", *REQUIRED_PRICE_COLUMNS) if column not in df.columns
    ]
    if "timestamp" in df.columns:
        timestamp = pd.to_datetime(df["timestamp"], errors="coerce")
        valid_timestamp = timestamp.dropna()
        if not valid_timestamp.empty:
            summary.date_range_raw = f"{valid_timestamp.min().isoformat()} -> {valid_timestamp.max().isoformat()}"
            summary.unique_trading_days = int(valid_timestamp.dt.date.nunique())
            summary.missing_days_estimate = _estimate_missing_days(valid_timestamp)
        summary.duplicate_timestamps = int(timestamp.duplicated(keep="first").sum())
    price_columns = [column for column in REQUIRED_PRICE_COLUMNS if column in df.columns]
    if price_columns:
        prices = df[price_columns].apply(pd.to_numeric, errors="coerce")
        summary.nan_rows = int(prices.isna().any(axis=1).sum())
        if all(column in prices.columns for column in REQUIRED_PRICE_COLUMNS):
            summary.nonpositive_price_rows = int((prices[list(REQUIRED_PRICE_COLUMNS)] <= 0).any(axis=1).sum())
            summary.bad_ohlc_rows = int(_bad_ohlc_mask(prices).sum())
            returns = prices["close"].pct_change().abs()
            summary.large_gap_or_jump_warnings = int((returns > 0.2).sum())
    if "volume" in df.columns:
        volume = pd.to_numeric(df["volume"], errors="coerce")
        summary.negative_volume_rows = int((volume < 0).sum())
        summary.zero_volume_rows = int((volume == 0).sum())
    if "contract" in df.columns:
        summary.contract_count = int(df["contract"].replace("", pd.NA).dropna().nunique())
    if "expiry" in df.columns:
        summary.expiry_count = int(df["expiry"].replace("", pd.NA).dropna().nunique())
    summary.decision = DATA_REJECTED if summary.missing_required_columns else DATA_USABLE
    return summary


def validate_and_filter_data(
    df: pd.DataFrame,
    symbol: str,
    **session_kwargs: Any,
) -> tuple[pd.DataFrame, DataValidationSummary]:
    summary = validate_raw_data(df, symbol)
    if summary.missing_required_columns:
        summary.warnings.append("Missing required columns: " + ", ".join(summary.missing_required_columns))
        return df.iloc[0:0].copy(), summary
    prepared = df.copy()
    prepared["timestamp"] = pd.to_datetime(prepared["timestamp"], errors="coerce")
    prepared = prepared.drop_duplicates(subset=["timestamp"], keep="first")
    prepared = prepared.sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    session_result = apply_valid_market_session_filter(prepared, symbol, **session_kwargs)
    filtered = session_result.filtered
    summary.rows_after_valid_session_filter = len(filtered)
    summary.rejected_out_of_session_rows = session_result.rejected_out_of_session_rows
    summary.rejected_invalid_rows = session_result.rejected_invalid_rows
    summary.session_profile_used = session_result.profile_name
    summary.warnings.extend(session_result.warnings)
    summary.session_start_end_by_day = {
        day: f"{bounds.session_start.strftime('%H:%M')}->{bounds.session_end.strftime('%H:%M')} ({bounds.source})"
        for day, bounds in session_result.session_by_day.items()
    }
    if not filtered.empty:
        used_timestamp = filtered["timestamp"]
        summary.date_range_used = f"{used_timestamp.min().isoformat()} -> {used_timestamp.max().isoformat()}"
        summary.unique_trading_days = int(used_timestamp.dt.date.nunique())
        summary.decision = DATA_USABLE
    elif session_result.decision == NEEDS_SESSION_PROFILE:
        summary.decision = NEEDS_SESSION_PROFILE
    else:
        summary.decision = DATA_REJECTED
    return filtered, summary


def count_invalid_candles(df: pd.DataFrame) -> int:
    return int(invalid_candle_mask(df).sum())


def _bad_ohlc_mask(prices: pd.DataFrame) -> pd.Series:
    return (
        (prices["high"] < prices[["open", "close", "low"]].max(axis=1))
        | (prices["low"] > prices[["open", "close", "high"]].min(axis=1))
    )


def _estimate_missing_days(timestamp: pd.Series) -> int:
    days = pd.Series(timestamp.dt.date.unique())
    if days.empty:
        return 0
    expected = pd.bdate_range(days.min(), days.max()).date
    return max(0, len(set(expected)) - len(set(days)))

