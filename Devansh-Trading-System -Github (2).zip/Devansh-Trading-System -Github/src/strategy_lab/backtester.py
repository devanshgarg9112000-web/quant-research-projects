from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Any

import pandas as pd

from src.strategy_lab.indicators import add_indicators
from src.strategy_lab.session_filters import invalid_candle_mask
from src.strategy_lab.strategy_primitives import LONG, StrategyVariant, build_signals


@dataclass
class TradeRecord:
    symbol: str
    strategy_id: str
    family: str
    side: str
    signal_time: datetime
    entry_time: datetime
    entry_price: float
    sl: float
    target: float
    exit_time: datetime
    exit_price: float
    exit_reason: str
    gross_points: float
    net_points: float
    hold_minutes: int
    params_json: str
    orientation: str = "ORIGINAL"
    inverse_of: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "strategy_id": self.strategy_id,
            "family": self.family,
            "side": self.side,
            "signal_time": self.signal_time.isoformat(),
            "entry_time": self.entry_time.isoformat(),
            "entry_price": self.entry_price,
            "sl": self.sl,
            "target": self.target,
            "exit_time": self.exit_time.isoformat(),
            "exit_price": self.exit_price,
            "exit_reason": self.exit_reason,
            "gross_points": self.gross_points,
            "net_points": self.net_points,
            "hold_minutes": self.hold_minutes,
            "params_json": self.params_json,
            "orientation": self.orientation,
            "inverse_of": self.inverse_of,
        }


@dataclass
class BacktestResult:
    symbol: str
    strategy: StrategyVariant
    trades: list[TradeRecord]
    lookahead_flags: list[str]

    def trades_frame(self) -> pd.DataFrame:
        return pd.DataFrame([trade.to_dict() for trade in self.trades])


def backtest_strategy(
    df: pd.DataFrame,
    variant: StrategyVariant,
    *,
    symbol: str,
    cost_points: float = 0.0,
    forced_exit_buffer_minutes: int = 5,
    session_close_by_day: dict[date, time] | None = None,
    signal_series: pd.Series | None = None,
    max_trades_per_day: int = 1,
) -> BacktestResult:
    if df.empty:
        return BacktestResult(symbol, variant, [], [])
    data = df.copy().sort_values("timestamp", kind="mergesort").reset_index(drop=True)
    data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce")
    if "atr_14" not in data.columns:
        data = add_indicators(data)
    invalid = invalid_candle_mask(data)
    signals = signal_series.reset_index(drop=True).astype(bool) if signal_series is not None else build_signals(data, variant)
    session_close_by_day = session_close_by_day or _detected_session_close(data)
    trades: list[TradeRecord] = []
    trades_by_day: dict[date, int] = {}
    for signal_index in range(0, len(data) - 1):
        if not bool(signals.iloc[signal_index]):
            continue
        signal_time = data.at[signal_index, "timestamp"].to_pydatetime()
        entry_index = signal_index + 1
        entry_time = data.at[entry_index, "timestamp"].to_pydatetime()
        trading_day = entry_time.date()
        if entry_time <= signal_time:
            continue
        if trades_by_day.get(trading_day, 0) >= max_trades_per_day:
            continue
        if bool(invalid.iloc[entry_index]):
            continue
        if float(data.at[entry_index, "volume"] or 0) <= 0:
            continue
        forced_exit_dt = _forced_exit_datetime(
            trading_day,
            session_close_by_day.get(trading_day, entry_time.time()),
            forced_exit_buffer_minutes,
        )
        if entry_time >= forced_exit_dt:
            continue
        entry_price = float(data.at[entry_index, "open"])
        sl_distance, target_distance = _risk_distances(data, signal_index, variant)
        if variant.side == LONG:
            sl = entry_price - sl_distance
            target = entry_price + target_distance
        else:
            sl = entry_price + sl_distance
            target = entry_price - target_distance
        trade = _resolve_trade(
            data,
            variant,
            symbol,
            entry_index,
            signal_time,
            entry_price,
            sl,
            target,
            forced_exit_dt,
            float(cost_points),
        )
        if trade:
            trades.append(trade)
            trades_by_day[trading_day] = trades_by_day.get(trading_day, 0) + 1
    return BacktestResult(symbol, variant, trades, list(variant.lookahead_flags))


def _resolve_trade(
    data: pd.DataFrame,
    variant: StrategyVariant,
    symbol: str,
    entry_index: int,
    signal_time: datetime,
    entry_price: float,
    sl: float,
    target: float,
    forced_exit_dt: datetime,
    cost_points: float,
) -> TradeRecord | None:
    entry_time = data.at[entry_index, "timestamp"].to_pydatetime()
    max_hold = int(variant.params.get("max_hold_minutes", 60))
    latest_exit = entry_time + timedelta(minutes=max_hold)
    exit_price = float(data.at[entry_index, "close"])
    exit_time = entry_time
    exit_reason = "END_EXIT"
    for row_index in range(entry_index, len(data)):
        row_time = data.at[row_index, "timestamp"].to_pydatetime()
        if row_time.date() != entry_time.date():
            break
        high = float(data.at[row_index, "high"])
        low = float(data.at[row_index, "low"])
        close = float(data.at[row_index, "close"])
        if variant.side == LONG:
            stop_hit = low <= sl
            target_hit = high >= target
            if stop_hit:
                exit_price, exit_reason, exit_time = sl, "STOP_LOSS", row_time
                break
            if target_hit:
                exit_price, exit_reason, exit_time = target, "TARGET", row_time
                break
        else:
            stop_hit = high >= sl
            target_hit = low <= target
            if stop_hit:
                exit_price, exit_reason, exit_time = sl, "STOP_LOSS", row_time
                break
            if target_hit:
                exit_price, exit_reason, exit_time = target, "TARGET", row_time
                break
        exit_price, exit_time = close, row_time
        if row_time >= forced_exit_dt:
            exit_reason = "FORCED_EXIT"
            break
        if row_time >= latest_exit:
            exit_reason = "MAX_HOLD_EXIT"
            break
    gross = exit_price - entry_price if variant.side == LONG else entry_price - exit_price
    net = gross - cost_points
    hold_minutes = int(max(0, (exit_time - entry_time).total_seconds() // 60))
    return TradeRecord(
        symbol=symbol,
        strategy_id=variant.strategy_id,
        family=variant.family,
        side=variant.side,
        signal_time=signal_time,
        entry_time=entry_time,
        entry_price=round(entry_price, 6),
        sl=round(sl, 6),
        target=round(target, 6),
        exit_time=exit_time,
        exit_price=round(exit_price, 6),
        exit_reason=exit_reason,
        gross_points=round(gross, 6),
        net_points=round(net, 6),
        hold_minutes=hold_minutes,
        params_json=variant.params_json,
        orientation=variant.orientation,
        inverse_of=variant.inverse_of,
    )


def _risk_distances(data: pd.DataFrame, signal_index: int, variant: StrategyVariant) -> tuple[float, float]:
    atr_value = float(data.at[signal_index, "atr_14"] or 0)
    sl_atr = float(variant.params.get("sl_atr_multiple", 0) or 0)
    target_atr = float(variant.params.get("target_atr_multiple", 0) or 0)
    sl = atr_value * sl_atr if sl_atr > 0 and atr_value > 0 else float(variant.params.get("sl_points", 50.0))
    target = atr_value * target_atr if target_atr > 0 and atr_value > 0 else float(variant.params.get("target_points", 100.0))
    return max(sl, 0.01), max(target, 0.01)


def _detected_session_close(data: pd.DataFrame) -> dict[date, time]:
    return {
        trading_day: rows["timestamp"].max().time()
        for trading_day, rows in data.groupby(data["timestamp"].dt.date, sort=True)
    }


def _forced_exit_datetime(trading_day: date, session_close: time, buffer_minutes: int) -> datetime:
    return datetime.combine(trading_day, session_close) - timedelta(minutes=max(0, int(buffer_minutes)))
