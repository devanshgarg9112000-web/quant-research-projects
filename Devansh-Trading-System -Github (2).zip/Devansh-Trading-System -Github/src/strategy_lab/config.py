from __future__ import annotations

from dataclasses import dataclass
from datetime import time
from pathlib import Path


RESEARCH_ONLY = "RESEARCH_ONLY"
BACKTEST_ONLY = "BACKTEST_ONLY"
NOT_REAL_MONEY_READY = "NOT_REAL_MONEY_READY"
EXECUTION_ALLOWED = False

REJECTED = "REJECTED"
WATCHLIST = "WATCHLIST"
PHASE6A_BACKTEST_CANDIDATE = "PHASE6A_BACKTEST_CANDIDATE"
NEEDS_MORE_DATA = "NEEDS_MORE_DATA"
NEEDS_SESSION_PROFILE = "NEEDS_SESSION_PROFILE"
ALLOWED_DECISIONS = {
    REJECTED,
    WATCHLIST,
    PHASE6A_BACKTEST_CANDIDATE,
    NEEDS_MORE_DATA,
    NEEDS_SESSION_PROFILE,
}


@dataclass(frozen=True)
class StrategyLabConfig:
    data_dir: Path
    symbols: tuple[str, ...]
    output_dir: Path = Path("reports") / "strategy_lab" / "v3"
    session_start: time | None = None
    session_end: time | None = None
    auto_session_profile: bool = True
    use_full_valid_session: bool = True
    max_variants: int = 1000
    include_inverse: bool = False
    strategy_orientation: str = "original"
    random_seed: int = 42
    top_n: int = 100
    families: tuple[str, ...] = ()
    min_trades: int = 80
    cost_points: float = 0.0
    cost_profile: Path | None = None
    save_every: int = 0
    progress_every: int = 100
    validate_only: bool = False
    benchmark: bool = False
    max_bars: int | None = None
    forced_exit_buffer_minutes: int = 5
    max_loss_streak: int = 8
    max_drawdown_points: float = 10_000.0


def parse_bool(value: str | bool | None, *, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    return default


def parse_time(value: str | None) -> time | None:
    if not value:
        return None
    hour_text, minute_text = str(value).strip().split(":", 1)
    return time(int(hour_text), int(minute_text))


def parse_symbols(values: list[str] | tuple[str, ...] | None) -> tuple[str, ...]:
    output: list[str] = []
    for value in values or []:
        for raw in str(value).replace(",", " ").split():
            symbol = raw.strip().upper()
            if symbol and symbol not in output:
                output.append(symbol)
    return tuple(output)


def families_tuple(values: list[str] | tuple[str, ...] | None) -> tuple[str, ...]:
    if not values:
        return ()
    output: list[str] = []
    for value in values:
        for raw in str(value).replace(",", " ").split():
            family = raw.strip()
            if family and family not in output:
                output.append(family)
    return tuple(output)


def safety_lines() -> list[str]:
    return [
        RESEARCH_ONLY,
        BACKTEST_ONLY,
        NOT_REAL_MONEY_READY,
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Production WhatsApp Alerts: BLOCKED",
        "execution_allowed=false",
    ]
