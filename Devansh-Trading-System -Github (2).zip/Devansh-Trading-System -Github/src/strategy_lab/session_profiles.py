from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Iterable


NSE_FNO_PREFIXES = (
    "BANKNIFTY",
    "MIDCPNIFTY",
    "FINNIFTY",
    "NIFTY",
    "BHARTIARTL",
    "HDFCBANK",
    "ICICIBANK",
    "KOTAKBANK",
    "RELIANCE",
    "AXISBANK",
    "SBIN",
    "INFY",
    "TCS",
    "LT",
)
MCX_NON_AGRI_PREFIXES = (
    "CRUDEOIL",
    "CRUDEMI",
    "SILVERMI",
    "SILVERM",
    "SILVER",
    "CRUDEM",
    "CRUDMI",
    "CRUDE",
    "SILMIN",
    "NATGAS",
    "GOLDMI",
    "GOLDM",
    "GOLD",
    "ALUMINIUM",
    "ALUMIN",
    "COPPER",
    "NICKEL",
    "ZINC",
    "LEAD",
)


@dataclass(frozen=True)
class SessionProfile:
    name: str
    prefixes: tuple[str, ...]
    default_start: time
    default_end: time | None
    dynamic_end: bool = False


@dataclass(frozen=True)
class SessionBounds:
    profile_name: str
    session_start: time
    session_end: time
    detected_close: bool = False
    source: str = "PROFILE"


NSE_FNO = SessionProfile("NSE_FNO", NSE_FNO_PREFIXES, time(9, 16), time(15, 29), False)
MCX_NON_AGRI = SessionProfile("MCX_NON_AGRI", MCX_NON_AGRI_PREFIXES, time(9, 0), None, True)


def normalize_symbol(symbol: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(symbol or "").upper())


def resolve_session_profile(symbol: str) -> SessionProfile | None:
    normalized = normalize_symbol(symbol)
    for profile in (NSE_FNO, MCX_NON_AGRI):
        for prefix in profile.prefixes:
            if normalized.startswith(prefix):
                return profile
    return None


def manual_session_bounds(start: time, end: time) -> SessionBounds:
    return SessionBounds("MANUAL", start, end, detected_close=False, source="MANUAL")


def session_bounds_for_day(
    symbol: str,
    trading_day: date,
    *,
    timestamps: Iterable[datetime] | None = None,
    profile: SessionProfile | None = None,
    manual_start: time | None = None,
    manual_end: time | None = None,
    use_full_valid_session: bool = True,
) -> SessionBounds | None:
    if manual_start and manual_end:
        return manual_session_bounds(manual_start, manual_end)
    profile = profile or resolve_session_profile(symbol)
    if profile is None:
        return None
    if profile.name == "NSE_FNO":
        return SessionBounds(profile.name, profile.default_start, profile.default_end or time(15, 29))
    if profile.name == "MCX_NON_AGRI":
        session_end = None
        detected = False
        if use_full_valid_session:
            session_end = _latest_valid_time(timestamps or (), profile.default_start)
            detected = session_end is not None
        if session_end is None:
            session_end = mcx_calendar_close(trading_day)
        return SessionBounds(
            profile.name,
            profile.default_start,
            session_end,
            detected_close=detected,
            source="DETECTED_FROM_DATA" if detected else "CALENDAR_FALLBACK",
        )
    return SessionBounds(profile.name, profile.default_start, profile.default_end or time(23, 59))


def forced_exit_time(session_end: time, buffer_minutes: int = 5) -> time:
    base = datetime.combine(date(2000, 1, 1), session_end)
    return (base - timedelta(minutes=max(0, int(buffer_minutes)))).time()


def mcx_calendar_close(trading_day: date) -> time:
    return time(23, 30) if _is_us_dst_period(trading_day) else time(23, 55)


def _latest_valid_time(timestamps: Iterable[datetime], session_start: time) -> time | None:
    values = [item.time() for item in timestamps if isinstance(item, datetime) and item.time() >= session_start]
    return max(values) if values else None


def _is_us_dst_period(day: date) -> bool:
    start = _nth_weekday(day.year, 3, 6, 2)
    end = _nth_weekday(day.year, 11, 6, 1)
    return start <= day < end


def _nth_weekday(year: int, month: int, weekday: int, nth: int) -> date:
    current = date(year, month, 1)
    while current.weekday() != weekday:
        current += timedelta(days=1)
    return current + timedelta(days=7 * (nth - 1))
