from __future__ import annotations

from src.models.signal import Signal


def passes_score(signal: Signal, min_score: float) -> bool:
    return signal.score >= min_score
