from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from math import inf
from pathlib import Path
from typing import Any, Iterable


REPORT_COLUMNS = [
    "strategy",
    "symbol",
    "status",
    "confidence",
    "trades",
    "win_rate",
    "net_pnl",
    "profit_factor",
    "expectancy",
    "warnings",
    "final_recommendation",
]


@dataclass(frozen=True)
class StrategyVerification:
    strategy: str
    symbol: str
    status: str
    confidence: str
    trades: int
    win_rate: float
    net_pnl: float
    profit_factor: float
    expectancy: float
    warnings: tuple[str, ...]
    final_recommendation: str

    def as_row(self) -> dict[str, Any]:
        return {
            "strategy": self.strategy,
            "symbol": self.symbol,
            "status": self.status,
            "confidence": self.confidence,
            "trades": self.trades,
            "win_rate": self.win_rate,
            "net_pnl": self.net_pnl,
            "profit_factor": "inf" if self.profit_factor == inf else self.profit_factor,
            "expectancy": self.expectancy,
            "warnings": ";".join(self.warnings) if self.warnings else "NONE",
            "final_recommendation": self.final_recommendation,
        }


@dataclass(frozen=True)
class StrategyGateDecision:
    allowed: bool
    status: str
    reason: str
    canonical_strategy: str


def evaluate_strategy_result(row: dict[str, Any]) -> StrategyVerification:
    strategy = str(row.get("strategy") or "unknown")
    symbol = str(row.get("symbol") or "UNKNOWN")
    trades = _as_int(row.get("accepted", row.get("trades", 0)))
    wins = _as_int(row.get("wins", 0))
    losses = _as_int(row.get("losses", 0))
    win_rate = _as_float(row.get("win_rate", 0.0))
    net_pnl = _as_float(row.get("net_pnl", 0.0))
    gross_pnl = _as_float(row.get("gross_pnl", 0.0))
    profit_factor = _as_float(row.get("profit_factor", 0.0))
    expectancy = _as_float(row.get("expectancy", 0.0))
    max_drawdown = _as_float(row.get("max_drawdown", 0.0))
    raw_signals = _as_int(row.get("raw_signals", row.get("signals", 0)))
    risk_rejected = _as_int(row.get("risk_rejected", 0))
    quality_accepted = _as_int(row.get("quality_accepted_signals", raw_signals))
    sample_status = str(row.get("sample_status") or "")
    max_consecutive_losses = _as_int(row.get("max_consecutive_losses", 0))

    warnings: list[str] = []
    severe: list[str] = []
    if trades == 0:
        severe.append("NO_USABLE_SIGNALS")
    if trades < 20:
        warnings.append("LOW_TRADE_COUNT")
    if "HIGH_SIGNAL_FREQUENCY_WARNING" in sample_status:
        warnings.append("HIGH_SIGNAL_FREQUENCY")
        severe.append("HIGH_SIGNAL_FREQUENCY")
    if raw_signals > max(100, trades * 20):
        severe.append("OVERFITTING_WARNING")
    if profit_factor > 3.0 and trades < 50:
        warnings.append("UNSTABLE_HIGH_PF_LOW_SAMPLE")
    if max_consecutive_losses >= 3:
        warnings.append("CONSECUTIVE_LOSS_WARNING")
    if max_drawdown < 0 and abs(max_drawdown) > max(abs(net_pnl) * 2, 1000):
        warnings.append("HIGH_DRAWDOWN")
    if quality_accepted > 0 and risk_rejected / quality_accepted >= 0.5:
        warnings.append("HIGH_RISK_REJECTION_RATE")
    if gross_pnl > 0 and net_pnl <= 0:
        warnings.append("COST_SENSITIVITY")
    for warning in severe:
        if warning not in warnings:
            warnings.append(warning)

    if trades == 0:
        status = "REJECTED"
        recommendation = "NEEDS_DIAGNOSIS: no usable signals or trades were produced."
    elif net_pnl <= 0:
        status = "REJECTED"
        recommendation = "REJECTED: net PnL after costs is not positive."
    elif profit_factor < 1.1:
        status = "REJECTED"
        recommendation = "REJECTED: profit factor is below 1.10."
    elif severe:
        status = "REJECTED"
        recommendation = "REJECTED: severe frequency/overfitting warning requires redesign or more evidence."
    elif net_pnl > 0 and profit_factor >= 1.3 and trades >= 20:
        status = "APPROVED"
        recommendation = "APPROVED for Launch 1 PAPER/manual alerts only; continue monitoring."
    else:
        status = "WATCHLIST"
        recommendation = "WATCHLIST: positive result, but PF or sample size is not approval-grade."

    confidence = "HIGH" if trades >= 100 else "MEDIUM" if trades >= 30 else "LOW"
    if severe or trades < 20:
        confidence = "LOW"
    return StrategyVerification(
        strategy=strategy,
        symbol=symbol,
        status=status,
        confidence=confidence,
        trades=trades,
        win_rate=round(win_rate, 2),
        net_pnl=round(net_pnl, 2),
        profit_factor=profit_factor,
        expectancy=round(expectancy, 2),
        warnings=tuple(warnings),
        final_recommendation=recommendation,
    )


def generate_strategy_approval_report(
    summary_paths: Iterable[Path | str],
    base_dir: Path | str = ".",
) -> list[StrategyVerification]:
    rows: list[dict[str, Any]] = []
    for source in summary_paths:
        path = Path(source)
        if not path.is_absolute():
            path = Path(base_dir) / path
        if not path.exists():
            raise FileNotFoundError(f"Strategy summary CSV missing: {path}")
        with path.open(newline="", encoding="utf-8") as f:
            rows.extend(csv.DictReader(f))
    results = _consolidate_results([evaluate_strategy_result(row) for row in rows])
    output_dir = Path(base_dir) / "reports" / "strategy_verification"
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "latest_strategy_approval_report.csv"
    txt_path = output_dir / "latest_strategy_approval_report.txt"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=REPORT_COLUMNS)
        writer.writeheader()
        writer.writerows(result.as_row() for result in results)
    txt_path.write_text(_format_report(results) + "\n", encoding="utf-8")
    print(_format_report(results))
    print(f"Strategy Approval CSV: {csv_path}")
    print(f"Strategy Approval Report: {txt_path}")
    return results


class StrategyApprovalGate:
    def __init__(self, base_dir: Path | str, config: dict[str, Any] | None = None):
        self.base = Path(base_dir)
        self.config = config or {}
        self.records = self._load_records()

    def evaluate(self, row: dict[str, Any]) -> StrategyGateDecision:
        if not bool(self.config.get("enabled", True)):
            return StrategyGateDecision(True, "DISABLED", "Strategy verification gate disabled by config.", "")
        canonical = canonical_strategy_name(str(row.get("strategy") or ""))
        symbol = str(row.get("symbol") or "")
        record = self.records.get((canonical, symbol)) or self.records.get((canonical, "*"))
        if record is None:
            return StrategyGateDecision(
                False,
                "NEEDS_DIAGNOSIS",
                "blocked_by_strategy_verification: no approval record for strategy/symbol",
                canonical,
            )
        status = str(record.get("status") or "NEEDS_DIAGNOSIS").upper()
        if status == "APPROVED" and bool(self.config.get("allow_approved", True)):
            return StrategyGateDecision(True, status, "strategy verification APPROVED", canonical)
        if status == "WATCHLIST" and bool(self.config.get("allow_watchlist", False)):
            return StrategyGateDecision(True, status, "strategy verification WATCHLIST allowed by config", canonical)
        return StrategyGateDecision(
            False,
            status,
            f"blocked_by_strategy_verification: status={status}",
            canonical,
        )

    def _load_records(self) -> dict[tuple[str, str], dict[str, str]]:
        report_path = Path(
            self.config.get(
                "approval_report_path",
                "reports/strategy_verification/latest_strategy_approval_report.csv",
            )
        )
        if not report_path.is_absolute():
            report_path = self.base / report_path
        if not report_path.exists():
            return {}
        with report_path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        return {
            (canonical_strategy_name(row.get("strategy", "")), str(row.get("symbol") or "*")): row
            for row in rows
        }


def canonical_strategy_name(name: str) -> str:
    value = str(name or "").strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "cluster_imbalance_trap": ("cluster_imbalance", "buyer_trap", "seller_trap", "mcx_estimated"),
        "trend_day_vwap_pullback": ("trend_day_vwap_pullback",),
        "breakout_acceptance": ("breakout_acceptance",),
        "breakdown_acceptance": ("breakdown_acceptance",),
        "failed_breakout": ("failed_breakout",),
        "failed_breakdown": ("failed_breakdown",),
        "vwap_reclaim": ("vwap_reclaim",),
        "vwap_rejection": ("vwap_rejection", "vwap_pullback"),
        "value_area_rejection": ("value_area_rejection",),
        "poc_magnet": ("poc_magnet",),
        "trend_following": ("trend_following",),
        "abnormal_flow": ("abnormal_flow",),
    }
    if value in aliases:
        return value
    for canonical, markers in aliases.items():
        if any(marker in value for marker in markers):
            return canonical
    return value


def _consolidate_results(results: list[StrategyVerification]) -> list[StrategyVerification]:
    grouped: dict[tuple[str, str], list[StrategyVerification]] = {}
    order: list[tuple[str, str]] = []
    for result in results:
        key = (canonical_strategy_name(result.strategy), result.symbol)
        if key not in grouped:
            order.append(key)
        grouped.setdefault(key, []).append(result)
    status_rank = {"REJECTED": 0, "WATCHLIST": 1, "APPROVED": 2}
    consolidated: list[StrategyVerification] = []
    for key in order:
        items = grouped[key]
        worst_rank = min(status_rank.get(item.status, 0) for item in items)
        worst_items = [item for item in items if status_rank.get(item.status, 0) == worst_rank]
        selected = max(worst_items, key=lambda item: item.trades)
        warnings = tuple(dict.fromkeys(warning for item in items for warning in item.warnings))
        if len(items) > 1:
            warnings = tuple(dict.fromkeys((*warnings, "MULTIPLE_DATA_SOURCE_RESULTS")))
        consolidated.append(StrategyVerification(
            strategy=key[0],
            symbol=selected.symbol,
            status=selected.status,
            confidence="LOW" if any(item.confidence == "LOW" for item in items) else selected.confidence,
            trades=selected.trades,
            win_rate=selected.win_rate,
            net_pnl=selected.net_pnl,
            profit_factor=selected.profit_factor,
            expectancy=selected.expectancy,
            warnings=warnings,
            final_recommendation=selected.final_recommendation,
        ))
    return consolidated


def discover_latest_summary_paths(base_dir: Path | str = ".") -> list[Path]:
    task_root = Path(base_dir) / "reports" / "today_truedata_tasks"
    run_dirs = sorted((path for path in task_root.glob("*") if path.is_dir()), key=lambda path: path.stat().st_mtime, reverse=True)
    for run_dir in run_dirs:
        paths = [
            run_dir / "tick_cluster_backtest_summary.csv",
            run_dir / "bar_strategy_backtest_summary.csv",
        ]
        existing = [path for path in paths if path.exists()]
        if existing:
            return existing
    fallback = Path(base_dir) / "reports" / "backtests" / "latest_strategy_backtest_summary.csv"
    return [fallback] if fallback.exists() else []


def _format_report(results: list[StrategyVerification]) -> str:
    lines = [
        "STRATEGY VERIFICATION / APPROVAL REPORT",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
    ]
    for result in results:
        row = result.as_row()
        lines.append(
            f"- {result.symbol} {result.strategy}: status={result.status} confidence={result.confidence} "
            f"trades={result.trades} win_rate={result.win_rate}% net_pnl={result.net_pnl} "
            f"pf={row['profit_factor']} expectancy={result.expectancy}"
        )
        lines.append(f"  Warnings: {row['warnings']}")
        lines.append(f"  Recommendation: {result.final_recommendation}")
    approved = [result for result in results if result.status == "APPROVED"]
    lines.extend([
        "",
        f"Monday Launch 1 Approved Strategies: {len(approved)}",
        "Manual execution only. Approval never enables broker orders.",
    ])
    return "\n".join(lines)


def _as_float(value: Any) -> float:
    text = str(value or "0").strip().lower()
    if text in {"inf", "infinity"}:
        return inf
    try:
        return float(text)
    except (TypeError, ValueError):
        return 0.0


def _as_int(value: Any) -> int:
    try:
        return int(float(str(value or "0")))
    except (TypeError, ValueError):
        return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="PAPER-only strategy verification and approval report.")
    parser.add_argument("--summary-csv", action="append", default=[], help="Backtest summary CSV; may be repeated.")
    args = parser.parse_args()
    paths = [Path(path) for path in args.summary_csv] or discover_latest_summary_paths(".")
    if not paths:
        print("Strategy verification failed safely: no backtest summary CSV found.")
        return 1
    try:
        generate_strategy_approval_report(paths)
    except Exception as exc:
        print(f"Strategy verification failed safely: {type(exc).__name__}: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
