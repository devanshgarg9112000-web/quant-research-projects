from __future__ import annotations

from src.models.signal import Signal


def resolve_conflicts(signals: list[Signal]) -> tuple[Signal | None, list[str]]:
    if not signals:
        return None, ["No strategy produced a passing signal."]
    best = sorted(signals, key=lambda s: (s.score, s.reward_risk), reverse=True)[0]
    sides = {s.side for s in signals}
    notes = []
    if len(sides) > 1:
        notes.append("Opposite-side signals existed; highest score selected.")
    notes.append(f"Selected {best.strategy_name} with score {best.score}.")
    return best, notes
