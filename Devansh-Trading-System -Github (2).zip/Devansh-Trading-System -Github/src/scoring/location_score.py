from __future__ import annotations


def score_location(distance_to_key_level: float) -> float:
    if distance_to_key_level <= 10:
        return 2.0
    if distance_to_key_level <= 40:
        return 1.0
    return 0.0
