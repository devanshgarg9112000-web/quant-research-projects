from __future__ import annotations


def guard_order(mode: str, risk_approved: bool) -> bool:
    return mode == "PAPER" and risk_approved
