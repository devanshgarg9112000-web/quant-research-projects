from __future__ import annotations


class TradeManager:
    def has_duplicate_open_trade(self, symbol: str, strategy_name: str) -> bool:
        return False
