from __future__ import annotations


class OrderManager:
    def confirm(self, order) -> str:
        return f"Order {order.order_id} confirmed as {order.status}."
