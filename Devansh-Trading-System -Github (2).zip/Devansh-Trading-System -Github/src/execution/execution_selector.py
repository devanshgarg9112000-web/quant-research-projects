from __future__ import annotations

from src.brokers.paper_broker import PaperBroker


def select_broker(mode: str) -> PaperBroker:
    return PaperBroker()
