from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from typing import Any

from src.brokers.kite_broker import evaluate_live_order_guard


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT"}
DEFAULT_PRODUCT = "MIS"
DEFAULT_VARIETY = "regular"
DEFAULT_VALIDITY = "DAY"


class KiteOrderPreviewError(ValueError):
    """Raised when a Kite order preview request is unsafe or invalid."""


@dataclass(slots=True)
class KiteLiveOrderSafetyResult:
    approved: bool
    reasons: list[str]


def build_kite_order_payload(
    symbol: str,
    side: str,
    quantity: int,
    order_type: str,
    price: float | None = None,
    product: str = DEFAULT_PRODUCT,
    variety: str = DEFAULT_VARIETY,
    validity: str = DEFAULT_VALIDITY,
) -> dict[str, Any]:
    symbol = _validate_symbol(symbol)
    transaction_type = _validate_side(side)
    quantity = _validate_quantity(quantity)
    order_type = _validate_order_type(order_type)
    price = _validate_price(order_type, price)
    exchange, tradingsymbol = _split_kite_symbol(symbol)
    payload: dict[str, Any] = {
        "symbol": symbol,
        "exchange": exchange,
        "tradingsymbol": tradingsymbol,
        "transaction_type": transaction_type,
        "quantity": quantity,
        "order_type": order_type,
        "product": product,
        "variety": variety,
        "validity": validity,
    }
    if order_type == "LIMIT":
        payload["price"] = price
    return payload


def evaluate_kite_live_order_safety(
    payload: dict[str, Any],
    settings: dict,
    risk_config: dict,
    confirm_live_order: bool,
    risk_approved: bool,
    allowed_symbols: set[str] | list[str] | tuple[str, ...] | None,
    env: dict | None = None,
) -> KiteLiveOrderSafetyResult:
    """Future live-order gate; preview CLI does not place orders."""

    env = env or os.environ
    reasons: list[str] = []
    live_guard = evaluate_live_order_guard("LIVE", settings, risk_config, broker_name="kite", env=env)
    reasons.extend(live_guard.reasons)
    if not confirm_live_order:
        reasons.append("explicit command flag --confirm-live-order was not passed")
    if not risk_approved:
        reasons.append("risk engine did not approve the order")
    try:
        _validate_quantity(payload.get("quantity"))
    except KiteOrderPreviewError as exc:
        reasons.append(str(exc))
    symbol = str(payload.get("symbol") or "").strip()
    allowed = {item.strip() for item in allowed_symbols or [] if item and item.strip()}
    if not allowed or symbol not in allowed:
        reasons.append("symbol is not in allowed list")
    return KiteLiveOrderSafetyResult(not reasons, reasons)


def format_order_preview(payload: dict[str, Any], live_trading: bool = False) -> str:
    lines = [
        "KITE ORDER PREVIEW",
        f"Symbol: {payload['symbol']}",
        f"Transaction Type: {payload['transaction_type']}",
        f"Quantity: {payload['quantity']}",
        f"Order Type: {payload['order_type']}",
    ]
    if payload["order_type"] == "LIMIT":
        lines.append(f"Price: {payload['price']}")
    lines.extend([
        f"Product: {payload['product']}",
        f"Variety: {payload['variety']}",
        f"Validity: {payload['validity']}",
        f"Live Trading: {str(bool(live_trading)).lower()}",
        "DRY RUN ONLY. No Kite order was placed.",
    ])
    return "\n".join(lines)


def run_preview_cli(args: argparse.Namespace) -> int:
    try:
        payload = build_kite_order_payload(
            symbol=args.symbol,
            side=args.side,
            quantity=args.quantity,
            order_type=args.order_type,
            price=args.price,
            product=args.product,
            variety=args.variety,
            validity=args.validity,
        )
    except KiteOrderPreviewError as exc:
        print(f"Kite order preview rejected: {exc}")
        print("DRY RUN ONLY. No Kite order was placed.")
        return 1
    print(format_order_preview(payload, live_trading=False))
    return 0


def _validate_symbol(symbol: str) -> str:
    clean = str(symbol or "").strip()
    if not clean:
        raise KiteOrderPreviewError("symbol must not be empty")
    return clean


def _validate_side(side: str) -> str:
    clean = str(side or "").strip().upper()
    if clean not in VALID_SIDES:
        raise KiteOrderPreviewError("side must be BUY or SELL")
    return clean


def _validate_quantity(quantity: Any) -> int:
    try:
        value = int(quantity)
    except (TypeError, ValueError) as exc:
        raise KiteOrderPreviewError("quantity must be positive") from exc
    if value <= 0:
        raise KiteOrderPreviewError("quantity must be positive")
    return value


def _validate_order_type(order_type: str) -> str:
    clean = str(order_type or "").strip().upper()
    if clean not in VALID_ORDER_TYPES:
        raise KiteOrderPreviewError("order_type must be MARKET or LIMIT")
    return clean


def _validate_price(order_type: str, price: float | None) -> float | None:
    if order_type == "MARKET":
        return None
    if price is None:
        raise KiteOrderPreviewError("LIMIT order requires a positive price")
    try:
        value = float(price)
    except (TypeError, ValueError) as exc:
        raise KiteOrderPreviewError("LIMIT order requires a positive price") from exc
    if value <= 0:
        raise KiteOrderPreviewError("LIMIT order requires a positive price")
    return value


def _split_kite_symbol(symbol: str) -> tuple[str | None, str]:
    if ":" not in symbol:
        return None, symbol
    exchange, tradingsymbol = symbol.split(":", 1)
    return exchange.strip() or None, tradingsymbol.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description="Dry-run Kite order preview. No orders are placed.")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--side", required=True)
    parser.add_argument("--quantity", type=int, required=True)
    parser.add_argument("--order-type", required=True)
    parser.add_argument("--price", type=float, default=None)
    parser.add_argument("--product", default=DEFAULT_PRODUCT)
    parser.add_argument("--variety", default=DEFAULT_VARIETY)
    parser.add_argument("--validity", default=DEFAULT_VALIDITY)
    args = parser.parse_args()
    return run_preview_cli(args)


if __name__ == "__main__":
    raise SystemExit(main())
