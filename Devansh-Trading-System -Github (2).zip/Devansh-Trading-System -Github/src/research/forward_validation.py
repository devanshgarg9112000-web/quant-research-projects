﻿from __future__ import annotations

import argparse
import csv
import hashlib
from collections import defaultdict
from dataclasses import dataclass, replace
from datetime import date, datetime, timedelta
from math import inf
from pathlib import Path
from typing import Any

from src.backtesting.strategy_backtest_runner import (
    StrategyBacktestError,
    _load_backtest_bars,
    _parse_optional_date,
    filter_bars_by_symbols,
    group_bars_by_symbol,
)
from src.config_loader import load_configs, load_yaml
from src.data_collection.market_data_schema import kite_tick_path, load_csv_rows, parse_timestamp, to_float
from src.research.strategy_research_lab import _prepare_symbol_bars
from src.research.vwap_rejection_deep_dive import (
    BASELINE_PARAMS,
    COST_PER_TRADE,
    SLIPPAGE_POINTS,
    _attach_session_ends,
    _generate_vwap_rejection_candidates,
)
from src.risk.position_sizing import calculate_position_size


FORWARD_STRATEGY = "gold_vwap_rejection_short"
STRATEGY_DISPLAY = "GOLD-I VWAP Rejection Short"
SYMBOL = "GOLD-I"
CANONICAL_FAMILY = "gold_vwap_rejection_reclaim_family"
CANONICAL_SETUP = "gold_vwap_rejection_short"
LEGACY_SCHEMA_VERSION = "1_legacy"
POST_LOCK_SCHEMA_VERSION = "2_post_lock"
LEGACY_LOCK_VERSION = "PRE_LOCK_LEGACY"
DEFAULT_MIN_FORWARD_TRADES = 30
DEFAULT_MIN_FORWARD_SESSIONS = 5
DEFAULT_REAL_PROVIDERS = ("KITE", "TRUEDATA")
LEDGER_COLUMNS = [
    "ledger_schema_version",
    "signal_id",
    "lock_version",
    "post_lock",
    "session_id",
    "date",
    "provider",
    "symbol",
    "canonical_family",
    "canonical_setup",
    "strategy",
    "signal_time",
    "entry_time",
    "side",
    "entry",
    "stop",
    "stop_loss",
    "target",
    "data_role",
    "used_for_parameter_tuning",
    "risk_per_unit",
    "reward_per_unit",
    "expected_R",
    "vwap_distance",
    "atr",
    "volume_multiplier",
    "market_regime",
    "signal_score",
    "approval_status_at_signal",
    "execution_allowed",
    "alert_mode",
    "status",
    "result",
    "exit_time",
    "exit_price",
    "gross_pnl",
    "net_pnl_after_costs",
    "R_multiple",
    "mfe",
    "mae",
    "notes",
]
FINAL_STATUSES = {"WIN", "LOSS", "END_EXIT", "EXPIRED"}
INDEPENDENT_FINAL_STATUSES = {"WIN", "LOSS", "END_EXIT"}
ACTIVE_STATUSES = {"PENDING"}
MIN_TOTAL_TRADES = 20
MIN_FORWARD_PF = 1.30
MIN_COMBINED_PF = 1.30


@dataclass(frozen=True)
class ForwardMetrics:
    trades: int = 0
    pending: int = 0
    wins: int = 0
    losses: int = 0
    end_exits: int = 0
    expired: int = 0
    net_pnl: float = 0.0
    profit_factor: float = 0.0
    expectancy: float = 0.0
    max_consecutive_losses: int = 0
    max_drawdown: float = 0.0
    largest_winner: float = 0.0
    total_winning_pnl: float = 0.0
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True)
class ForwardApprovalDecision:
    status: str
    reason: str
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True)
class ForwardEvidenceSummary:
    total_ledger_rows: int
    legacy_pre_lock_rows: int
    pending_post_lock_rows: int
    completed_independent_post_lock_trades: int
    distinct_post_lock_sessions: int
    required_forward_trades: int
    required_forward_sessions: int
    provider_breakdown: str
    independent_provider_breakdown: str
    ineligible_reasons: tuple[tuple[str, int], ...]
    independent_rows: tuple[dict[str, Any], ...]


@dataclass(frozen=True)
class PendingOutcomeUpdateStats:
    checked: int = 0
    resolved: int = 0
    still_pending: int = 0
    no_tick_data: int = 0
    no_later_tick: int = 0


@dataclass(frozen=True)
class ForwardValidationResult:
    ledger_path: Path
    summary_path: Path
    rows_recorded: int
    total_ledger_rows: int
    historical: ForwardMetrics
    forward: ForwardMetrics
    combined: ForwardMetrics
    decision: ForwardApprovalDecision
    evidence: ForwardEvidenceSummary
    pending_update: PendingOutcomeUpdateStats | None = None


def ledger_path(base_dir: Path | str = ".", strategy: str = FORWARD_STRATEGY) -> Path:
    if strategy != FORWARD_STRATEGY:
        raise StrategyBacktestError(f"Forward validation supports {FORWARD_STRATEGY} only.")
    return Path(base_dir) / "reports" / "forward_validation" / "gold_vwap_rejection_short_ledger.csv"


def summary_path(base_dir: Path | str = ".") -> Path:
    return Path(base_dir) / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"


def run_replay_forward_validation(
    base_dir: Path | str = ".",
    *,
    strategy: str = FORWARD_STRATEGY,
    symbol: str = SYMBOL,
    bar_dir: str = "data/historical/truedata/bars",
    from_date: str | date | None = None,
    to_date: str | date | None = None,
    configs: dict[str, Any] | None = None,
) -> ForwardValidationResult:
    """Replay historical bars through the WATCHLIST setup and append new ledger rows."""

    base = Path(base_dir)
    _validate_scope(strategy, symbol)
    from_day = _parse_optional_date(from_date, "--from-date")
    to_day = _parse_optional_date(to_date, "--to-date")
    if from_day and to_day and from_day > to_day:
        raise StrategyBacktestError("--from-date cannot be later than --to-date.")

    print("FORWARD VALIDATION REPLAY", flush=True)
    print("Mode: PAPER | Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false", flush=True)
    bars, bar_files, loader_notes = _load_backtest_bars(base, bar_dir, from_day, to_day)
    bars = filter_bars_by_symbols(bars, [symbol])
    if not bars:
        raise StrategyBacktestError(f"No bars found for {symbol}.")
    grouped = group_bars_by_symbol(bars)
    prepared = _prepare_symbol_bars(grouped[symbol])
    _attach_session_ends(prepared)
    configs = configs or load_configs(base)
    rows = _build_replay_ledger_rows(
        prepared,
        configs.get("risk", {}),
        (configs.get("instruments", {}) or {}).get(symbol, {}),
        approval_status="WATCHLIST",
    )
    recorded = append_ledger_rows(base, rows, strategy=strategy)
    print(f"Bar files loaded: {len(bar_files)}", flush=True)
    print(f"Bars loaded for {symbol}: {len(prepared)}", flush=True)
    print(f"Replay signals recorded: {recorded}", flush=True)
    if loader_notes:
        print("Loader notes: " + "; ".join(loader_notes), flush=True)
    return summarize_forward_validation(base, strategy=strategy, symbol=symbol, rows_recorded=recorded)


def summarize_forward_validation(
    base_dir: Path | str = ".",
    *,
    strategy: str = FORWARD_STRATEGY,
    symbol: str = SYMBOL,
    rows_recorded: int = 0,
) -> ForwardValidationResult:
    _validate_scope(strategy, symbol)
    base = Path(base_dir)
    ledger_rows = _filtered_ledger_rows(load_ledger(base, strategy), symbol, strategy)
    evidence = analyze_independent_evidence(base, ledger_rows)
    historical = _load_historical_baseline_metrics(base)
    forward = calculate_forward_metrics(list(evidence.independent_rows))
    combined = combine_metrics(historical, forward)
    decision = assess_forward_approval(
        historical,
        forward,
        combined,
        minimum_forward_trades=evidence.required_forward_trades,
        distinct_sessions=evidence.distinct_post_lock_sessions,
        minimum_distinct_sessions=evidence.required_forward_sessions,
    )
    path = summary_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    report = format_forward_summary(
        ledger_path(base, strategy),
        historical,
        forward,
        combined,
        decision,
        ledger_rows,
        evidence,
    )
    path.write_text(report + "\n", encoding="utf-8")
    print(report, flush=True)
    print(f"Forward ledger: {ledger_path(base, strategy)}", flush=True)
    print(f"Forward summary: {path}", flush=True)
    return ForwardValidationResult(
        ledger_path=ledger_path(base, strategy),
        summary_path=path,
        rows_recorded=rows_recorded,
        total_ledger_rows=len(ledger_rows),
        historical=historical,
        forward=forward,
        combined=combined,
        decision=decision,
        evidence=evidence,
    )


def update_pending_outcomes(
    base_dir: Path | str = ".",
    *,
    strategy: str = FORWARD_STRATEGY,
    symbol: str = SYMBOL,
    bar_dir: str = "data/historical/truedata/bars",
    from_date: str | date | None = None,
    to_date: str | date | None = None,
) -> ForwardValidationResult:
    """Resolve pending ledger rows without live data or broker execution."""

    _validate_scope(strategy, symbol)
    base = Path(base_dir)
    path = ledger_path(base, strategy)
    rows = load_ledger(base, strategy)
    if not rows:
        print("Forward validation update skipped: ledger is empty.", flush=True)
        return summarize_forward_validation(base, strategy=strategy, symbol=symbol)

    from_day = _parse_optional_date(from_date, "--from-date")
    to_day = _parse_optional_date(to_date, "--to-date")
    symbol_bars: list[dict[str, Any]] | None = None
    checked = resolved_count = still_pending = no_tick_data = no_later_tick = 0
    output: list[dict[str, Any]] = []

    for row in rows:
        is_pending_scope = row.get("symbol") == symbol and row.get("strategy") == strategy and row.get("status") == "PENDING"
        if not is_pending_scope:
            output.append(row)
            continue

        if _is_kite_post_lock_forward_row(row, symbol=symbol, strategy=strategy):
            checked += 1
            resolved, reason = resolve_kite_tick_pending_row(base, row)
            if resolved.get("status") != "PENDING":
                resolved_count += 1
            else:
                still_pending += 1
                if reason == "no_tick_data":
                    no_tick_data += 1
                elif reason == "no_later_tick":
                    no_later_tick += 1
            output.append(resolved)
            continue

        if symbol_bars is None:
            bars, _, _ = _load_backtest_bars(base, bar_dir, from_day, to_day)
            bars = filter_bars_by_symbols(bars, [symbol])
            symbol_bars = group_bars_by_symbol(bars).get(symbol, [])
        fallback_resolved = resolve_pending_row(row, symbol_bars)
        if fallback_resolved.get("status") != row.get("status"):
            resolved_count += 1
        output.append(fallback_resolved)

    _write_ledger(path, output)
    stats = PendingOutcomeUpdateStats(
        checked=checked,
        resolved=resolved_count,
        still_pending=still_pending,
        no_tick_data=no_tick_data,
        no_later_tick=no_later_tick,
    )
    print(
        "Pending outcomes checked: "
        f"{stats.checked} | resolved: {stats.resolved} | still_pending: {stats.still_pending} | "
        f"no_tick_data: {stats.no_tick_data} | no_later_tick: {stats.no_later_tick}",
        flush=True,
    )
    summary = summarize_forward_validation(base, strategy=strategy, symbol=symbol, rows_recorded=0)
    return replace(summary, pending_update=stats)

def record_watchlist_signal_from_row(
    base_dir: Path | str,
    row: dict[str, Any],
    *,
    scan_time: datetime,
    alert_mode: str,
    config: dict[str, Any] | None = None,
) -> bool:
    """Append one live/replay monitor WATCHLIST signal as a pending research row."""

    config = config or {}
    if not bool(config.get("enabled", True)):
        return False
    if not bool(config.get("record_watchlist_signals", True)):
        return False
    if bool(config.get("production_alerts_allowed", False)):
        return False
    symbols = _config_symbols(config)
    if row.get("symbol") not in symbols:
        return False
    if not _is_gold_vwap_rejection_short(row):
        return False
    if row.get("status") != "ACCEPTED_PAPER_SIGNAL":
        return False
    if not _execution_is_false(row.get("execution_allowed")):
        return False

    signal_time = _coerce_datetime(row.get("signal_time") or row.get("timestamp") or scan_time)
    entry = _to_float(row.get("entry"))
    stop = _to_float(row.get("stop"))
    target = _to_float(row.get("target"))
    side = str(row.get("direction") or "SELL").upper()
    if not entry or not stop or not target:
        return False
    risk_per_unit = abs(stop - entry)
    provider = str(row.get("provider") or row.get("data_feed") or "UNKNOWN").upper()
    data_role = str(row.get("data_role") or "FORWARD_VALIDATION").upper()
    reward_per_unit = abs(entry - target)
    ledger_row = _empty_ledger_row()
    ledger_row.update(
        {
            "ledger_schema_version": POST_LOCK_SCHEMA_VERSION,
            "lock_version": str(config.get("active_lock_version") or ""),
            "post_lock": _post_lock_value(signal_time, config, data_role),
            "session_id": _session_id(row["symbol"], signal_time, provider),
            "signal_id": make_signal_id(row["symbol"], FORWARD_STRATEGY, signal_time, side, entry, stop, target),
            "date": signal_time.date().isoformat(),
            "symbol": row["symbol"],
            "provider": provider,
            "strategy": FORWARD_STRATEGY,
            "canonical_family": str(row.get("canonical_family") or CANONICAL_FAMILY),
            "canonical_setup": str(row.get("canonical_setup") or CANONICAL_SETUP),
            "signal_time": signal_time.isoformat(),
            "entry_time": row.get("entry_time") or "",
            "side": side,
            "entry": _round(entry),
            "stop": _round(stop),
            "target": _round(target),
            "risk_per_unit": _round(risk_per_unit),
            "reward_per_unit": _round(reward_per_unit),
            "stop_loss": _round(stop),
            "expected_R": _round(reward_per_unit / risk_per_unit if risk_per_unit else 0.0, 3),
            "data_role": data_role,
            "used_for_parameter_tuning": "false",
            "vwap_distance": "",
            "atr": "",
            "volume_multiplier": "",
            "market_regime": row.get("market_mode") or "NOT_EVALUATED",
            "signal_score": row.get("score") or "",
            "approval_status_at_signal": row.get("approval_status_at_signal") or row.get("strategy_verification_status") or "RESEARCH_ONLY",
            "execution_allowed": "false",
            "alert_mode": alert_mode,
            "status": "PENDING",
            "result": "PENDING",
            "notes": row.get("key_reason") or "Recorded from Launch 1 PAPER monitor as research-only WATCHLIST evidence.",
        }
    )
    return append_ledger_rows(base_dir, [ledger_row]) == 1



def resolve_kite_tick_pending_row(base_dir: Path | str, row: dict[str, Any]) -> tuple[dict[str, Any], str]:
    """Resolve one locked KITE pending row from recorded ticks strictly after entry_time."""

    if not _is_kite_post_lock_forward_row(row):
        return row, "not_kite_post_lock"
    entry_time_value = row.get("entry_time") or row.get("signal_time")
    try:
        entry_time = _coerce_datetime(entry_time_value)
    except (TypeError, ValueError):
        return row, "missing_entry_time"
    day = _coerce_date(row.get("date") or entry_time.date())
    symbol = str(row.get("symbol") or SYMBOL)
    ticks = _load_recorded_kite_ticks(base_dir, day, symbol)
    if not ticks:
        return row, "no_tick_data"

    later_ticks = [tick for tick in ticks if tick["timestamp"] > entry_time]
    if not later_ticks:
        return row, "no_later_tick"

    entry = _to_float(row.get("entry"))
    stop = _to_float(row.get("stop_loss") or row.get("stop"))
    target = _to_float(row.get("target"))
    if entry <= 0 or stop <= 0 or target <= 0:
        resolved = dict(row)
        resolved["status"] = "EXPIRED"
        resolved["result"] = "EXPIRED"
        resolved["notes"] = _append_note(row.get("notes"), "Missing entry/stop/target prevented KITE tick outcome update.")
        return _normalize_ledger_row(resolved), "missing_price_fields"

    side = str(row.get("side") or "SELL").upper()
    mfe, mae = _mfe_mae_from_ticks(side, entry, later_ticks)
    for tick in later_ticks:
        price = tick["price"]
        if side == "BUY":
            if price <= stop:
                return _apply_exit_to_row(
                    row,
                    tick["timestamp"],
                    "LOSS",
                    stop,
                    "KITE tick stop reached strictly after entry_time.",
                    mfe=mfe,
                    mae=mae,
                ), "resolved"
            if price >= target:
                return _apply_exit_to_row(
                    row,
                    tick["timestamp"],
                    "WIN",
                    target,
                    "KITE tick target reached strictly after entry_time.",
                    mfe=mfe,
                    mae=mae,
                ), "resolved"
        else:
            if price >= stop:
                return _apply_exit_to_row(
                    row,
                    tick["timestamp"],
                    "LOSS",
                    stop,
                    "KITE tick stop reached strictly after entry_time.",
                    mfe=mfe,
                    mae=mae,
                ), "resolved"
            if price <= target:
                return _apply_exit_to_row(
                    row,
                    tick["timestamp"],
                    "WIN",
                    target,
                    "KITE tick target reached strictly after entry_time.",
                    mfe=mfe,
                    mae=mae,
                ), "resolved"

    resolved = dict(row)
    resolved["status"] = "PENDING"
    resolved["result"] = "PENDING"
    resolved["mfe"] = _round(mfe)
    resolved["mae"] = _round(mae)
    resolved["execution_allowed"] = "false"
    return _normalize_ledger_row(resolved), "still_pending"


def _is_kite_post_lock_forward_row(
    row: dict[str, Any],
    *,
    symbol: str = SYMBOL,
    strategy: str = FORWARD_STRATEGY,
) -> bool:
    return (
        str(row.get("provider") or "").upper() == "KITE"
        and _is_true(row.get("post_lock"))
        and str(row.get("data_role") or "").upper() == "FORWARD_VALIDATION"
        and str(row.get("status") or row.get("result") or "").upper() == "PENDING"
        and row.get("symbol") == symbol
        and row.get("strategy") == strategy
        and row.get("canonical_setup") == CANONICAL_SETUP
    )


def _load_recorded_kite_ticks(base_dir: Path | str, day: date, symbol: str) -> list[dict[str, Any]]:
    rows = load_csv_rows(kite_tick_path(base_dir, day, symbol))
    ticks: list[dict[str, Any]] = []
    for row in rows:
        if str(row.get("symbol") or row.get("internal_symbol") or symbol) != symbol:
            continue
        price = to_float(row.get("ltp") or row.get("last_price"))
        if price <= 0:
            continue
        try:
            timestamp = parse_timestamp(row.get("timestamp"))
        except (TypeError, ValueError):
            continue
        ticks.append({"timestamp": timestamp, "price": price})
    return sorted(ticks, key=lambda tick: tick["timestamp"])


def _mfe_mae_from_ticks(side: str, entry: float, ticks: list[dict[str, Any]]) -> tuple[float, float]:
    prices = [float(tick["price"]) for tick in ticks]
    if not prices:
        return 0.0, 0.0
    if side.upper() == "BUY":
        return max(0.0, max(prices) - entry), max(0.0, entry - min(prices))
    return max(0.0, entry - min(prices)), max(0.0, max(prices) - entry)
def resolve_pending_row(row: dict[str, Any], bars: list[dict[str, Any]]) -> dict[str, Any]:
    signal_time = _coerce_datetime(row["signal_time"])
    day = _coerce_date(row.get("date") or signal_time.date())
    side = str(row.get("side") or "SELL").upper()
    stop = _to_float(row["stop"])
    target = _to_float(row["target"])
    entry = _to_float(row["entry"])
    if stop <= 0 or target <= 0 or entry <= 0:
        resolved = dict(row)
        resolved["status"] = "EXPIRED"
        resolved["notes"] = _append_note(row.get("notes"), "Missing entry/stop/target prevented outcome update.")
        return resolved
    day_bars = [
        bar
        for bar in sorted(bars, key=lambda item: item["timestamp"])
        if _coerce_datetime(bar["timestamp"]).date() == day
        and _coerce_datetime(bar["timestamp"]) > signal_time
    ]
    if not day_bars:
        resolved = dict(row)
        resolved["status"] = "EXPIRED"
        resolved["notes"] = _append_note(row.get("notes"), "No future bars were available after signal time.")
        return resolved
    exit_bar, status, exit_price, reason = _first_exit_after_signal(day_bars, side, stop, target)
    if exit_bar is None:
        exit_bar = day_bars[-1]
        status = "END_EXIT"
        exit_price = float(exit_bar["close"])
        reason = "Neither target nor stop hit; closed at session end."
    return _apply_exit_to_row(row, exit_bar["timestamp"], status, exit_price, reason)


def calculate_forward_metrics(rows: list[dict[str, Any]]) -> ForwardMetrics:
    pnls: list[float] = []
    wins = losses = end_exits = expired = pending = 0
    for row in rows:
        status = str(row.get("status") or "").upper()
        if status == "PENDING":
            pending += 1
            continue
        if status == "WIN":
            wins += 1
        elif status == "LOSS":
            losses += 1
        elif status == "END_EXIT":
            end_exits += 1
        elif status == "EXPIRED":
            expired += 1
        if status in FINAL_STATUSES:
            pnls.append(_to_float(row.get("net_pnl_after_costs")))
    return _metrics_from_pnls(
        pnls,
        pending=pending,
        wins=wins,
        losses=losses,
        end_exits=end_exits,
        expired=expired,
    )


def combine_metrics(historical: ForwardMetrics, forward: ForwardMetrics) -> ForwardMetrics:
    warnings = tuple(dict.fromkeys([*historical.warnings, *forward.warnings]))
    net = historical.net_pnl + forward.net_pnl
    trades = historical.trades + forward.trades
    gross_profit = historical.total_winning_pnl + forward.total_winning_pnl
    gross_loss = _gross_loss_from_metrics(historical) + _gross_loss_from_metrics(forward)
    return ForwardMetrics(
        trades=trades,
        pending=forward.pending,
        wins=historical.wins + forward.wins,
        losses=historical.losses + forward.losses,
        end_exits=historical.end_exits + forward.end_exits,
        expired=historical.expired + forward.expired,
        net_pnl=net,
        profit_factor=inf if gross_profit > 0 and gross_loss == 0 else gross_profit / gross_loss if gross_loss else 0.0,
        expectancy=net / trades if trades else 0.0,
        max_consecutive_losses=max(historical.max_consecutive_losses, forward.max_consecutive_losses),
        max_drawdown=min(historical.max_drawdown, forward.max_drawdown),
        largest_winner=max(historical.largest_winner, forward.largest_winner),
        total_winning_pnl=gross_profit,
        warnings=warnings,
    )


def assess_forward_approval(
    historical: ForwardMetrics,
    forward: ForwardMetrics,
    combined: ForwardMetrics | None = None,
    *,
    minimum_forward_trades: int = DEFAULT_MIN_FORWARD_TRADES,
    distinct_sessions: int | None = None,
    minimum_distinct_sessions: int = DEFAULT_MIN_FORWARD_SESSIONS,
) -> ForwardApprovalDecision:
    combined = combined or combine_metrics(historical, forward)
    warnings = _approval_warnings(forward, combined)
    if forward.trades < minimum_forward_trades:
        return ForwardApprovalDecision(
            "RESEARCH_ONLY",
            f"Independent post-lock forward trades are {forward.trades}; at least {minimum_forward_trades} are required before approval review.",
            warnings,
        )
    if forward.net_pnl <= 0:
        return ForwardApprovalDecision("WATCHLIST", "Forward validation net PnL is not positive.", warnings)
    if distinct_sessions is not None and distinct_sessions < minimum_distinct_sessions:
        return ForwardApprovalDecision(
            "RESEARCH_ONLY",
            f"Independent post-lock sessions are {distinct_sessions}; at least {minimum_distinct_sessions} are required before approval review.",
            warnings,
        )
    if combined.trades < MIN_TOTAL_TRADES:
        return ForwardApprovalDecision(
            "WATCHLIST",
            f"Forward PnL is positive, but total trades are {combined.trades}; at least {MIN_TOTAL_TRADES} are required.",
            warnings,
        )
    if forward.profit_factor < MIN_FORWARD_PF:
        return ForwardApprovalDecision("WATCHLIST", f"Forward PF {forward.profit_factor:.2f} is below 1.30.", warnings)
    if combined.profit_factor < MIN_COMBINED_PF:
        return ForwardApprovalDecision("WATCHLIST", f"Combined PF {combined.profit_factor:.2f} is below 1.30.", warnings)
    if "SEVERE_DRAWDOWN_WARNING" in warnings:
        return ForwardApprovalDecision("WATCHLIST", "Severe drawdown warning blocks approval candidacy.", warnings)
    if "SINGLE_TRADE_DEPENDENCY_WARNING" in warnings:
        return ForwardApprovalDecision("WATCHLIST", "One large winner creates single-trade dependency.", warnings)
    return ForwardApprovalDecision(
        "APPROVAL_CANDIDATE",
        "Forward and combined evidence passed the research gate. APPROVED still requires manual review.",
        warnings,
    )


def append_ledger_rows(
    base_dir: Path | str,
    rows: list[dict[str, Any]],
    *,
    strategy: str = FORWARD_STRATEGY,
) -> int:
    path = ledger_path(base_dir, strategy)
    existing = load_ledger(base_dir, strategy)
    existing_ids = {str(row.get("signal_id")) for row in existing}
    active = [
        row for row in existing
        if row.get("strategy") == strategy and row.get("symbol") == SYMBOL and row.get("status") in ACTIVE_STATUSES
    ]
    appended = 0
    for row in rows:
        signal_id = str(row.get("signal_id") or "")
        if not signal_id or signal_id in existing_ids:
            continue
        if row.get("status") == "PENDING" and active:
            continue
        clean = _normalize_ledger_row(
            _prepare_new_ledger_row(base_dir, row),
            legacy=False,
        )
        existing.append(clean)
        existing_ids.add(signal_id)
        if clean.get("status") == "PENDING":
            active.append(clean)
        appended += 1
    _write_ledger(path, existing)
    return appended


def load_ledger(base_dir: Path | str = ".", strategy: str = FORWARD_STRATEGY) -> list[dict[str, Any]]:
    path = ledger_path(base_dir, strategy)
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        legacy_file = "ledger_schema_version" not in (reader.fieldnames or [])
        return [_normalize_ledger_row(row, legacy=legacy_file) for row in reader]


def make_signal_id(
    symbol: str,
    strategy: str,
    signal_time: datetime,
    side: str,
    entry: float,
    stop: float,
    target: float,
) -> str:
    raw = "|".join(
        [
            symbol,
            strategy,
            signal_time.replace(microsecond=0).isoformat(),
            side.upper(),
            f"{entry:.2f}",
            f"{stop:.2f}",
            f"{target:.2f}",
        ]
    )
    return "fvsig_" + hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def format_forward_summary(
    path: Path,
    historical: ForwardMetrics,
    forward: ForwardMetrics,
    combined: ForwardMetrics,
    decision: ForwardApprovalDecision,
    rows: list[dict[str, Any]],
    evidence: ForwardEvidenceSummary,
) -> str:
    lines = [
        "GOLD-I VWAP REJECTION SHORT FORWARD VALIDATION SUMMARY",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "",
        f"Ledger Path: {path}",
        f"Ledger Rows: {len(rows)}",
        f"Legacy/Pre-lock Rows: {evidence.legacy_pre_lock_rows}",
        f"Pending Post-lock Rows: {evidence.pending_post_lock_rows}",
        f"Completed Independent Post-lock Trades: {evidence.completed_independent_post_lock_trades}",
        f"Distinct Post-lock Sessions: {evidence.distinct_post_lock_sessions}",
        f"Required Forward Trades: {evidence.required_forward_trades}",
        f"Required Forward Sessions: {evidence.required_forward_sessions}",
        f"Provider Breakdown: {evidence.provider_breakdown}",
        f"Independent Provider Breakdown: {evidence.independent_provider_breakdown}",
        f"Ineligible Row Reasons: {_format_reason_counts(evidence.ineligible_reasons)}",
        _metric_line("Historical trades", historical),
        _metric_line("Forward/replay-recorded trades", forward),
        f"Pending independent post-lock trades: {evidence.pending_post_lock_rows}",
        _metric_line("Combined evidence", combined),
        f"Approval Decision: {decision.status}",
        f"Decision Reason: {decision.reason}",
        f"Warnings: {';'.join(decision.warnings) if decision.warnings else 'NONE'}",
        "",
        "APPROVAL RULES",
        f"- RESEARCH_ONLY until at least {evidence.required_forward_trades} completed independent post-lock forward trades exist.",
        f"- Independent evidence must span at least {evidence.required_forward_sessions} distinct sessions.",
        "- Legacy, replay, unknown-provider, tuning-used, pending, or wrong-lock rows do not count toward approval.",
        "- APPROVAL_CANDIDATE additionally requires forward PF >=1.30, combined PF >=1.30, and no severe drawdown or one-big-trade warning.",
        "- APPROVED is never automatic; manual review is required.",
        "",
        "PAPER MODE ONLY. No broker orders were placed.",
    ]
    return "\n".join(lines)


def _build_replay_ledger_rows(
    rows: list[dict[str, Any]],
    risk_config: dict[str, Any],
    instrument: dict[str, Any],
    *,
    approval_status: str,
) -> list[dict[str, Any]]:
    candidates = _generate_vwap_rejection_candidates(rows, BASELINE_PARAMS)
    capital = float(risk_config.get("capital", 100000))
    risk_percent = float(risk_config.get("risk_per_trade_percent", 0.5))
    point_value = float(instrument.get("point_value", 1) or 1)
    cooldown = timedelta(seconds=int(BASELINE_PARAMS["cooldown_seconds"]))
    active_exit_index = -1
    cooldown_until: datetime | None = None
    daily_trades: dict[date, int] = defaultdict(int)
    output: list[dict[str, Any]] = []

    for candidate in candidates:
        signal_index = int(candidate["index"])
        day = candidate["day"]
        signal_time = candidate["timestamp"]
        if active_exit_index >= signal_index:
            continue
        if cooldown_until and signal_time < cooldown_until:
            continue
        if daily_trades[day] >= int(BASELINE_PARAMS["max_trades_per_day"]):
            continue
        entry_index = signal_index + 1
        if entry_index >= len(rows) or rows[entry_index]["day"] != day:
            continue
        entry_row = rows[entry_index]
        raw_entry = float(entry_row["open"])
        adjusted_entry = raw_entry - SLIPPAGE_POINTS
        stop = max(
            float(candidate["signal_high"]),
            adjusted_entry + float(candidate["atr"]) * float(BASELINE_PARAMS["atr_stop_multiplier"]),
        )
        risk_distance = stop - adjusted_entry
        if risk_distance <= 0:
            continue
        target = adjusted_entry - risk_distance * float(BASELINE_PARAMS["reward_risk"])
        sizing = calculate_position_size(capital, risk_percent, adjusted_entry, stop, instrument)
        if sizing.quantity <= 0:
            continue
        future_bars = [
            row for row in rows[entry_index + 1:]
            if row["day"] == day
        ]
        exit_bar, status, raw_exit, reason = _first_exit_after_signal(future_bars, "SELL", stop, target)
        if exit_bar is None:
            exit_bar = entry_row if not future_bars else future_bars[-1]
            status = "END_EXIT"
            raw_exit = float(exit_bar["close"])
            reason = "Neither target nor stop hit; closed at session end."
        adjusted_exit = raw_exit + SLIPPAGE_POINTS
        gross_pnl = (raw_entry - raw_exit) * sizing.quantity * point_value
        net_pnl = (adjusted_entry - adjusted_exit) * sizing.quantity * point_value - COST_PER_TRADE
        estimated_risk = sizing.estimated_risk_amount or risk_distance * sizing.quantity * point_value
        output.append(
            _normalize_ledger_row(
                {
                    "ledger_schema_version": POST_LOCK_SCHEMA_VERSION,
                    "signal_id": make_signal_id(SYMBOL, FORWARD_STRATEGY, signal_time, "SELL", raw_entry, stop, target),
                    "lock_version": LEGACY_LOCK_VERSION,
                    "post_lock": "false",
                    "session_id": _session_id(SYMBOL, signal_time, "TRUEDATA_REPLAY"),
                    "date": day.isoformat(),
                    "provider": "TRUEDATA_REPLAY",
                    "symbol": SYMBOL,
                    "canonical_family": CANONICAL_FAMILY,
                    "canonical_setup": CANONICAL_SETUP,
                    "strategy": FORWARD_STRATEGY,
                    "signal_time": signal_time.isoformat(),
                    "side": "SELL",
                    "entry": _round(raw_entry),
                    "stop": _round(stop),
                    "stop_loss": _round(stop),
                    "target": _round(target),
                    "data_role": "REPLAY_RESEARCH",
                    "used_for_parameter_tuning": "UNKNOWN",
                    "risk_per_unit": _round(risk_distance * point_value),
                    "reward_per_unit": _round((adjusted_entry - target) * point_value),
                    "expected_R": _round(BASELINE_PARAMS["reward_risk"], 3),
                    "vwap_distance": _round(candidate["vwap_distance"]),
                    "atr": _round(candidate["atr"]),
                    "volume_multiplier": _round(candidate["volume_multiplier"], 3),
                    "market_regime": candidate["market_regime"],
                    "signal_score": 7.7,
                    "approval_status_at_signal": approval_status,
                    "execution_allowed": "false",
                    "alert_mode": "REPLAY_FORWARD_VALIDATION",
                    "status": status,
                    "result": status,
                    "exit_time": _coerce_datetime(exit_bar["timestamp"]).isoformat(),
                    "exit_price": _round(raw_exit),
                    "gross_pnl": _round(gross_pnl),
                    "net_pnl_after_costs": _round(net_pnl),
                    "R_multiple": _round(net_pnl / estimated_risk if estimated_risk else 0.0, 3),
                    "mfe": "",
                    "mae": "",
                    "notes": reason,
                },
                legacy=False,
            )
        )
        active_exit_index = int(exit_bar.get("index", rows.index(exit_bar) if exit_bar in rows else signal_index))
        cooldown_until = signal_time + cooldown
        daily_trades[day] += 1
    return output


def _first_exit_after_signal(
    bars: list[dict[str, Any]],
    side: str,
    stop: float,
    target: float,
) -> tuple[dict[str, Any] | None, str, float, str]:
    for bar in bars:
        high = float(bar["high"])
        low = float(bar["low"])
        if side.upper() == "BUY":
            if low <= stop:
                return bar, "LOSS", stop, "Stop reached after the signal bar."
            if high >= target:
                return bar, "WIN", target, "Target reached after the signal bar."
        else:
            if high >= stop:
                return bar, "LOSS", stop, "Stop reached after the signal bar."
            if low <= target:
                return bar, "WIN", target, "Target reached after the signal bar."
    return None, "END_EXIT", 0.0, "Neither target nor stop was reached."


def _apply_exit_to_row(
    row: dict[str, Any],
    exit_time: datetime,
    status: str,
    exit_price: float,
    reason: str,
    *,
    mfe: float | None = None,
    mae: float | None = None,
) -> dict[str, Any]:
    side = str(row.get("side") or "SELL").upper()
    entry = _to_float(row["entry"])
    risk_per_unit = _to_float(row.get("risk_per_unit")) or abs(_to_float(row["stop"]) - entry)
    if side == "BUY":
        adjusted_entry = entry + SLIPPAGE_POINTS
        adjusted_exit = exit_price - SLIPPAGE_POINTS
        gross_pnl = exit_price - entry
        net_pnl = adjusted_exit - adjusted_entry - COST_PER_TRADE
    else:
        adjusted_entry = entry - SLIPPAGE_POINTS
        adjusted_exit = exit_price + SLIPPAGE_POINTS
        gross_pnl = entry - exit_price
        net_pnl = adjusted_entry - adjusted_exit - COST_PER_TRADE
    resolved = dict(row)
    resolved.update(
        {
            "status": status,
            "result": status,
            "exit_time": _coerce_datetime(exit_time).isoformat(),
            "exit_price": _round(exit_price),
            "gross_pnl": _round(gross_pnl),
            "net_pnl_after_costs": _round(net_pnl),
            "R_multiple": _round(net_pnl / risk_per_unit if risk_per_unit else 0.0, 3),
            "mfe": _round(mfe) if mfe is not None else row.get("mfe", ""),
            "mae": _round(mae) if mae is not None else row.get("mae", ""),
            "notes": _append_note(row.get("notes"), reason),
            "execution_allowed": "false",
        }
    )
    return _normalize_ledger_row(resolved)


def _load_historical_baseline_metrics(base: Path) -> ForwardMetrics:
    csv_path = base / "reports" / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.csv"
    if not csv_path.exists():
        return ForwardMetrics()
    pnls: list[float] = []
    wins = losses = end_exits = 0
    with csv_path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("record_type") != "TRADE" or str(row.get("is_baseline")).lower() != "true":
                continue
            pnl = _to_float(row.get("trade_net_pnl"))
            result = str(row.get("result") or "").upper()
            pnls.append(pnl)
            wins += int(result == "WIN")
            losses += int(result == "LOSS")
            end_exits += int(result == "END_EXIT")
    return _metrics_from_pnls(pnls, wins=wins, losses=losses, end_exits=end_exits)


def _metrics_from_pnls(
    pnls: list[float],
    *,
    pending: int = 0,
    wins: int | None = None,
    losses: int | None = None,
    end_exits: int = 0,
    expired: int = 0,
) -> ForwardMetrics:
    wins = sum(1 for pnl in pnls if pnl > 0) if wins is None else wins
    losses = sum(1 for pnl in pnls if pnl < 0) if losses is None else losses
    gross_profit = sum(pnl for pnl in pnls if pnl > 0)
    gross_loss = abs(sum(pnl for pnl in pnls if pnl < 0))
    trades = len(pnls)
    warnings = _metric_warnings(pnls)
    return ForwardMetrics(
        trades=trades,
        pending=pending,
        wins=wins,
        losses=losses,
        end_exits=end_exits,
        expired=expired,
        net_pnl=sum(pnls),
        profit_factor=inf if gross_profit > 0 and gross_loss == 0 else gross_profit / gross_loss if gross_loss else 0.0,
        expectancy=sum(pnls) / trades if trades else 0.0,
        max_consecutive_losses=_max_consecutive_losses(pnls),
        max_drawdown=_max_drawdown(pnls),
        largest_winner=max((pnl for pnl in pnls if pnl > 0), default=0.0),
        total_winning_pnl=gross_profit,
        warnings=warnings,
    )


def _metric_warnings(pnls: list[float]) -> tuple[str, ...]:
    warnings: list[str] = []
    if not pnls:
        return ()
    total_net = sum(pnls)
    drawdown = _max_drawdown(pnls)
    gross_profit = sum(pnl for pnl in pnls if pnl > 0)
    largest_winner = max((pnl for pnl in pnls if pnl > 0), default=0.0)
    if drawdown < 0 and abs(drawdown) >= max(1000.0, abs(total_net) * 0.75):
        warnings.append("SEVERE_DRAWDOWN_WARNING")
    if gross_profit > 0 and largest_winner / gross_profit >= 0.60:
        warnings.append("SINGLE_TRADE_DEPENDENCY_WARNING")
    return tuple(warnings)


def _approval_warnings(forward: ForwardMetrics, combined: ForwardMetrics) -> tuple[str, ...]:
    warnings = list(dict.fromkeys([*forward.warnings, *combined.warnings]))
    return tuple(warnings)


def _max_drawdown(pnls: list[float]) -> float:
    equity = peak = drawdown = 0.0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        drawdown = min(drawdown, equity - peak)
    return drawdown


def _max_consecutive_losses(pnls: list[float]) -> int:
    maximum = current = 0
    for pnl in pnls:
        if pnl < 0:
            current += 1
            maximum = max(maximum, current)
        else:
            current = 0
    return maximum


def _gross_loss_from_metrics(metrics: ForwardMetrics) -> float:
    return max(0.0, metrics.total_winning_pnl - metrics.net_pnl)


def analyze_independent_evidence(
    base_dir: Path | str = ".",
    rows: list[dict[str, Any]] | None = None,
) -> ForwardEvidenceSummary:
    """Classify ledger rows and count only approval-grade post-lock evidence."""

    base = Path(base_dir)
    ledger_rows = [_normalize_ledger_row(row) for row in (rows if rows is not None else load_ledger(base))]
    config = _load_forward_validation_config(base)
    required_trades, required_sessions = _load_forward_validation_requirements(base)
    active_lock = _active_lock_version(config)
    recognized_providers = set(_recognized_real_providers(config))
    independent_rows: list[dict[str, Any]] = []
    ineligible_reasons: dict[str, int] = defaultdict(int)
    seen_signal_ids: set[str] = set()

    legacy_rows = 0
    pending_post_lock_rows = 0
    for row in ledger_rows:
        schema = str(row.get("ledger_schema_version") or "")
        is_legacy = schema == LEGACY_SCHEMA_VERSION or row.get("lock_version") == LEGACY_LOCK_VERSION
        if is_legacy:
            legacy_rows += 1
        if _is_true(row.get("post_lock")) and _derive_result(row) == "PENDING":
            pending_post_lock_rows += 1
        reason = _independent_ineligible_reason(row, active_lock, recognized_providers, seen_signal_ids)
        if reason:
            ineligible_reasons[reason] += 1
            continue
        independent_rows.append(row)
        seen_signal_ids.add(str(row.get("signal_id")))

    sessions = {str(row.get("session_id")) for row in independent_rows if str(row.get("session_id") or "").strip()}
    return ForwardEvidenceSummary(
        total_ledger_rows=len(ledger_rows),
        legacy_pre_lock_rows=legacy_rows,
        pending_post_lock_rows=pending_post_lock_rows,
        completed_independent_post_lock_trades=len(independent_rows),
        distinct_post_lock_sessions=len(sessions),
        required_forward_trades=required_trades,
        required_forward_sessions=required_sessions,
        provider_breakdown=_provider_breakdown(ledger_rows),
        independent_provider_breakdown=_provider_breakdown(independent_rows),
        ineligible_reasons=tuple(sorted(ineligible_reasons.items())),
        independent_rows=tuple(independent_rows),
    )


def _independent_ineligible_reason(
    row: dict[str, Any],
    active_lock: str,
    recognized_providers: set[str],
    seen_signal_ids: set[str],
) -> str | None:
    signal_id = str(row.get("signal_id") or "").strip()
    if not signal_id:
        return "missing_signal_id"
    if signal_id in seen_signal_ids:
        return "duplicate_signal_id"
    if str(row.get("ledger_schema_version") or "") == LEGACY_SCHEMA_VERSION or row.get("lock_version") == LEGACY_LOCK_VERSION:
        return "legacy_pre_lock"
    if not _is_true(row.get("post_lock")):
        return "post_lock_false"
    if active_lock and str(row.get("lock_version") or "") != active_lock:
        return "wrong_lock_version"
    if row.get("canonical_family") != CANONICAL_FAMILY or row.get("canonical_setup") != CANONICAL_SETUP:
        return "canonical_mismatch"
    if str(row.get("data_role") or "").upper() != "FORWARD_VALIDATION":
        return "data_role_not_forward_validation"
    if str(row.get("provider") or "").upper() not in recognized_providers:
        return "provider_not_recognized"
    if not str(row.get("session_id") or "").strip():
        return "missing_session_id"
    if _derive_result(row) not in INDEPENDENT_FINAL_STATUSES:
        return "not_completed"
    for field in ("entry", "stop_loss", "target"):
        if _to_float(row.get(field)) <= 0:
            return "missing_price_fields"
    if not _execution_is_false(row.get("execution_allowed")):
        return "execution_allowed_not_false"
    if not _is_false(row.get("used_for_parameter_tuning")):
        return "used_for_parameter_tuning_not_false"
    return None


def _filtered_ledger_rows(rows: list[dict[str, Any]], symbol: str, strategy: str) -> list[dict[str, Any]]:
    return [
        row for row in rows
        if row.get("symbol") == symbol and row.get("strategy") == strategy
    ]


def _write_ledger(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = sorted(
        (_normalize_ledger_row(row, legacy=False) for row in rows),
        key=lambda row: (row.get("signal_time") or "", row.get("signal_id") or ""),
    )
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=LEDGER_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _prepare_new_ledger_row(base_dir: Path | str, row: dict[str, Any]) -> dict[str, Any]:
    base = Path(base_dir)
    config = _load_forward_validation_config(base)
    prepared = dict(row)
    signal_time_value = prepared.get("signal_time") or prepared.get("timestamp")
    signal_time = _coerce_datetime(signal_time_value) if signal_time_value else datetime.now()
    provider = str(prepared.get("provider") or prepared.get("data_feed") or "UNKNOWN").upper()
    data_role = str(prepared.get("data_role") or "FORWARD_VALIDATION").upper()
    if provider.endswith("REPLAY") or "REPLAY" in provider:
        data_role = "REPLAY_RESEARCH"
    prepared.setdefault("ledger_schema_version", POST_LOCK_SCHEMA_VERSION)
    prepared.setdefault("lock_version", _active_lock_version(config))
    prepared.setdefault("post_lock", _post_lock_value(signal_time, config, data_role))
    prepared.setdefault("session_id", _session_id(str(prepared.get("symbol") or SYMBOL), signal_time, provider))
    prepared.setdefault("date", signal_time.date().isoformat())
    prepared.setdefault("provider", provider)
    prepared.setdefault("canonical_family", CANONICAL_FAMILY)
    prepared.setdefault("canonical_setup", CANONICAL_SETUP)
    prepared.setdefault("strategy", FORWARD_STRATEGY)
    prepared.setdefault("symbol", SYMBOL)
    prepared.setdefault("signal_time", signal_time.isoformat())
    prepared.setdefault("data_role", data_role)
    prepared.setdefault("used_for_parameter_tuning", "UNKNOWN" if data_role == "REPLAY_RESEARCH" else "false")
    if prepared.get("stop_loss") in {None, ""}:
        prepared["stop_loss"] = prepared.get("stop", "")
    if prepared.get("stop") in {None, ""}:
        prepared["stop"] = prepared.get("stop_loss", "")
    prepared.setdefault("result", _derive_result(prepared))
    prepared.setdefault("execution_allowed", "false")
    return prepared


def _normalize_ledger_row(row: dict[str, Any], *, legacy: bool | None = None) -> dict[str, Any]:
    output = _empty_ledger_row()
    output.update({key: row.get(key, "") for key in LEDGER_COLUMNS})
    if legacy is None:
        legacy = not bool(output.get("ledger_schema_version"))
    signal_time_value = output.get("signal_time")
    signal_time: datetime | None = None
    if signal_time_value:
        try:
            signal_time = _coerce_datetime(signal_time_value)
        except ValueError:
            signal_time = None
    provider = str(output.get("provider") or "UNKNOWN").upper()
    output["provider"] = provider
    output["strategy"] = output.get("strategy") or FORWARD_STRATEGY
    output["symbol"] = output.get("symbol") or SYMBOL
    output["canonical_family"] = output.get("canonical_family") or CANONICAL_FAMILY
    output["canonical_setup"] = output.get("canonical_setup") or CANONICAL_SETUP
    if output.get("stop_loss") in {None, ""}:
        output["stop_loss"] = output.get("stop", "")
    if output.get("stop") in {None, ""}:
        output["stop"] = output.get("stop_loss", "")
    if legacy:
        output["ledger_schema_version"] = LEGACY_SCHEMA_VERSION
        output["lock_version"] = LEGACY_LOCK_VERSION
        output["post_lock"] = "false"
        output["provider"] = provider or "UNKNOWN"
        output["data_role"] = output.get("data_role") or "REPLAY_RESEARCH"
        output["used_for_parameter_tuning"] = output.get("used_for_parameter_tuning") or "UNKNOWN"
    else:
        output["ledger_schema_version"] = output.get("ledger_schema_version") or POST_LOCK_SCHEMA_VERSION
        output["post_lock"] = "true" if _is_true(output.get("post_lock")) else "false"
        output["data_role"] = str(output.get("data_role") or "FORWARD_VALIDATION").upper()
        output["used_for_parameter_tuning"] = str(output.get("used_for_parameter_tuning") or "false").lower()
    if signal_time and not output.get("date"):
        output["date"] = signal_time.date().isoformat()
    if signal_time and not output.get("session_id") and not legacy:
        output["session_id"] = _session_id(str(output.get("symbol") or SYMBOL), signal_time, str(output.get("provider") or "UNKNOWN"))
    output["result"] = output.get("result") or _derive_result(output)
    output["status"] = str(output.get("status") or output.get("result") or "PENDING").upper()
    output["execution_allowed"] = "false"
    return output


def _empty_ledger_row() -> dict[str, Any]:
    return {column: "" for column in LEDGER_COLUMNS}


def _load_forward_validation_config(base: Path) -> dict[str, Any]:
    path = base / "config" / "forward_validation.yaml"
    if not path.exists():
        return {}
    try:
        return load_yaml(path)
    except Exception:
        return {}


def _load_forward_validation_requirements(base: Path) -> tuple[int, int]:
    path = base / "config" / "strategy_identity.yaml"
    return (
        _extract_yaml_int(path, "minimum_forward_trades", DEFAULT_MIN_FORWARD_TRADES),
        _extract_yaml_int(path, "minimum_distinct_sessions", DEFAULT_MIN_FORWARD_SESSIONS),
    )


def _extract_yaml_int(path: Path, key: str, default: int) -> int:
    if not path.exists():
        return default
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{key}:"):
            value = stripped.split(":", 1)[1].strip()
            try:
                return int(float(value))
            except ValueError:
                return default
    return default


def _active_lock_version(config: dict[str, Any]) -> str:
    return str(config.get("active_lock_version") or "").strip()


def _recognized_real_providers(config: dict[str, Any]) -> tuple[str, ...]:
    raw = config.get("recognized_real_providers") or DEFAULT_REAL_PROVIDERS
    if isinstance(raw, str):
        raw = raw.strip()
        if raw.startswith("[") and raw.endswith("]"):
            raw = raw[1:-1]
        values = [item.strip().strip("\"'") for item in raw.split(",") if item.strip()]
    elif isinstance(raw, (list, tuple, set)):
        values = [str(item) for item in raw]
    else:
        values = list(DEFAULT_REAL_PROVIDERS)
    return tuple(sorted({value.upper() for value in values if value}))


def _post_lock_value(signal_time: datetime, config: dict[str, Any], data_role: str) -> str:
    if str(data_role or "").upper() != "FORWARD_VALIDATION":
        return "false"
    active_lock = _active_lock_version(config)
    if not active_lock:
        return "false"
    raw_timestamp = config.get("active_lock_timestamp")
    if not raw_timestamp:
        return "true"
    try:
        lock_time = _coerce_datetime(raw_timestamp)
        compare_time = signal_time
        if lock_time.tzinfo and compare_time.tzinfo is None:
            compare_time = compare_time.replace(tzinfo=lock_time.tzinfo)
        return "true" if compare_time >= lock_time else "false"
    except Exception:
        return "false"


def _session_id(symbol: str, signal_time: datetime, provider: str) -> str:
    provider_text = str(provider or "UNKNOWN").upper().replace(" ", "_")
    return f"{symbol}_{signal_time.date().isoformat()}_{provider_text}"


def _derive_result(row: dict[str, Any]) -> str:
    for key in ("result", "status", "outcome"):
        value = str(row.get(key) or "").upper()
        if value in {*INDEPENDENT_FINAL_STATUSES, "EXPIRED", "PENDING", "RISK_REJECTED"}:
            return value
    pnl = _to_float(row.get("net_pnl_after_costs") or row.get("net_pnl"))
    if pnl > 0:
        return "WIN"
    if pnl < 0:
        return "LOSS"
    return "PENDING"


def _is_true(value: Any) -> bool:
    return value is True or str(value).strip().lower() == "true"


def _is_false(value: Any) -> bool:
    return value is False or str(value).strip().lower() == "false"


def _format_reason_counts(reasons: tuple[tuple[str, int], ...]) -> str:
    if not reasons:
        return "NONE"
    return ", ".join(f"{reason}={count}" for reason, count in reasons)
def _metric_line(label: str, metrics: ForwardMetrics) -> str:
    return (
        f"{label}: trades={metrics.trades} wins={metrics.wins} losses={metrics.losses} "
        f"end_exit={metrics.end_exits} expired={metrics.expired} pending={metrics.pending} "
        f"net_pnl={metrics.net_pnl:.2f} PF={_display_pf(metrics.profit_factor)} "
        f"expectancy={metrics.expectancy:.2f} max_consecutive_losses={metrics.max_consecutive_losses} "
        f"max_drawdown={metrics.max_drawdown:.2f}"
    )


def _provider_breakdown(rows: list[dict[str, Any]]) -> str:
    counts: dict[str, int] = defaultdict(int)
    for row in rows:
        provider = str(row.get("provider") or "UNKNOWN").upper()
        counts[provider] += 1
    if not counts:
        return "NONE"
    return ", ".join(f"{provider}={count}" for provider, count in sorted(counts.items()))


def _display_pf(value: float) -> str:
    return "inf" if value == inf else f"{value:.2f}"


def _round(value: Any, digits: int = 2) -> float:
    return round(float(value or 0.0), digits)


def _to_float(value: Any) -> float:
    if value in {None, ""}:
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _coerce_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    return datetime.fromisoformat(text)


def _coerce_date(value: Any) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def _append_note(existing: Any, note: str) -> str:
    text = str(existing or "").strip()
    return f"{text} | {note}" if text else note


def _config_symbols(config: dict[str, Any]) -> list[str]:
    raw = config.get("symbols", [SYMBOL])
    if isinstance(raw, str):
        raw = raw.strip()
        if raw.startswith("[") and raw.endswith("]"):
            raw = raw[1:-1]
        return [item.strip().strip("\"'") for item in raw.split(",") if item.strip()]
    if isinstance(raw, (list, tuple)):
        return [str(item) for item in raw]
    return [SYMBOL]


def _is_gold_vwap_rejection_short(row: dict[str, Any]) -> bool:
    symbol = row.get("symbol") == SYMBOL
    strategy = str(row.get("strategy") or "").strip().lower().replace("-", "_")
    strategy = strategy.replace(" ", "_")
    return symbol and strategy in {
        "vwap_rejection_short",
        "gold_i_vwap_rejection_short",
        "gold_vwap_rejection_short",
    }


def _execution_is_false(value: Any) -> bool:
    return value is False or str(value).strip().lower() == "false"


def _validate_scope(strategy: str, symbol: str) -> None:
    if strategy != FORWARD_STRATEGY:
        raise StrategyBacktestError(f"Unsupported forward strategy: {strategy}. Only {FORWARD_STRATEGY} is supported.")
    if symbol != SYMBOL:
        raise StrategyBacktestError(f"Unsupported forward symbol: {symbol}. Only {SYMBOL} is supported.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PAPER-only forward validation for GOLD-I VWAP Rejection Short.")
    parser.add_argument("--mode", choices=["replay", "summarize", "update"], required=True)
    parser.add_argument("--strategy", default=FORWARD_STRATEGY)
    parser.add_argument("--symbol", default=SYMBOL)
    parser.add_argument("--bar-dir", default="data/historical/truedata/bars")
    parser.add_argument("--from-date")
    parser.add_argument("--to-date")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.mode == "replay":
            result = run_replay_forward_validation(
                strategy=args.strategy,
                symbol=args.symbol,
                bar_dir=args.bar_dir,
                from_date=args.from_date,
                to_date=args.to_date,
            )
        elif args.mode == "update":
            result = update_pending_outcomes(
                strategy=args.strategy,
                symbol=args.symbol,
                bar_dir=args.bar_dir,
                from_date=args.from_date,
                to_date=args.to_date,
            )
        else:
            result = summarize_forward_validation(strategy=args.strategy, symbol=args.symbol)
    except (StrategyBacktestError, FileNotFoundError, ValueError) as exc:
        print(f"Forward validation failed safely: {exc}")
        print("Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false")
        return 1
    print(f"Replay/forward trades recorded this run: {result.rows_recorded}")
    print(f"Total forward ledger rows: {result.total_ledger_rows}")
    print(f"Approval decision: {result.decision.status}")
    print(f"Decision reason: {result.decision.reason}")
    print("Production WhatsApp Alerts: BLOCKED")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())







