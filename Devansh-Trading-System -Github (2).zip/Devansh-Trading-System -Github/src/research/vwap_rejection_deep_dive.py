from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from math import inf
from pathlib import Path
from typing import Any

from src.backtesting.strategy_backtest_runner import (
    StrategyBacktestError,
    _load_backtest_bars,
    _parse_optional_date,
    filter_bars_by_symbols,
    group_bars_by_symbol,
)
from src.config_loader import load_configs
from src.research.strategy_research_lab import _prepare_symbol_bars, split_train_validation_dates
from src.risk.position_sizing import calculate_position_size


STRATEGY_NAME = "vwap_rejection_short"
SLIPPAGE_POINTS = 5.0
COST_PER_TRADE = 50.0
MIN_COMBINED_TRADES = 20
MIN_TRAIN_TRADES = 10
MIN_VALIDATION_TRADES = 5
MIN_APPROVAL_PF = 1.30

BASELINE_PARAMS = {
    "atr_stop_multiplier": 2.0,
    "reward_risk": 2.0,
    "volume_multiplier": 1.2,
    "cooldown_seconds": 300,
    "max_trades_per_day": 3,
    "time_filter": "full_session",
    "trend_ema": 20,
}

CSV_COLUMNS = [
    "record_type",
    "variation_id",
    "is_baseline",
    "changed_dimension",
    "params",
    "split",
    "trades",
    "win_rate",
    "net_pnl",
    "profit_factor",
    "expectancy",
    "max_drawdown",
    "max_consecutive_losses",
    "raw_signals",
    "warning_flags",
    "robustness",
    "approval_status",
    "date",
    "entry_time",
    "exit_time",
    "entry_price",
    "adjusted_entry",
    "stop",
    "target",
    "exit_price",
    "adjusted_exit",
    "result",
    "gross_pnl",
    "trade_net_pnl",
    "r_multiple",
    "vwap_distance_at_entry",
    "volume_multiplier",
    "required_volume_multiplier",
    "atr_value",
    "market_regime",
    "reason_for_entry",
    "reason_for_exit",
    "qty",
    "execution_allowed",
]


@dataclass(frozen=True)
class DeepDiveTrade:
    variation_id: str
    day: date
    entry_time: datetime
    exit_time: datetime
    entry_price: float
    adjusted_entry: float
    stop: float
    target: float
    exit_price: float
    adjusted_exit: float
    result: str
    gross_pnl: float
    net_pnl: float
    r_multiple: float
    vwap_distance_at_entry: float
    volume_multiplier: float
    required_volume_multiplier: float
    atr_value: float
    market_regime: str
    reason_for_entry: str
    reason_for_exit: str
    qty: int


@dataclass(frozen=True)
class DeepDiveMetrics:
    trades: int = 0
    wins: int = 0
    losses: int = 0
    end_exits: int = 0
    win_rate: float = 0.0
    net_pnl: float = 0.0
    profit_factor: float = 0.0
    expectancy: float = 0.0
    max_drawdown: float = 0.0
    max_consecutive_losses: int = 0
    raw_signals: int = 0
    max_raw_signals_per_day: int = 0
    largest_winner: float = 0.0
    total_winning_pnl: float = 0.0


@dataclass(frozen=True)
class VariationResult:
    variation_id: str
    changed_dimension: str
    params: dict[str, Any]
    trades: tuple[DeepDiveTrade, ...]
    train: DeepDiveMetrics
    validation: DeepDiveMetrics
    combined: DeepDiveMetrics
    warnings: tuple[str, ...]


@dataclass(frozen=True)
class ApprovalDecision:
    status: str
    reason: str


@dataclass(frozen=True)
class DeepDiveRunResult:
    variations: tuple[VariationResult, ...]
    baseline: VariationResult
    robustness: str
    approval: ApprovalDecision
    report_path: Path
    csv_path: Path
    playbook_path: Path
    train_dates: tuple[date, ...]
    validation_dates: tuple[date, ...]


def build_controlled_variations() -> list[dict[str, Any]]:
    """One-factor-at-a-time sensitivity set covering every requested value."""

    variations = [
        {"variation_id": "baseline", "changed_dimension": "baseline", **BASELINE_PARAMS},
    ]
    requested = {
        "atr_stop_multiplier": [1.0, 1.25, 1.5, 2.0],
        "reward_risk": [1.2, 1.5, 2.0],
        "volume_multiplier": [1.0, 1.2, 1.5, 2.0],
        "cooldown_seconds": [300, 600, 900],
        "max_trades_per_day": [1, 2, 3],
        "time_filter": ["full_session", "avoid_first_15", "avoid_first_30", "avoid_last_30"],
    }
    for field, values in requested.items():
        for value in values:
            if value == BASELINE_PARAMS[field]:
                continue
            row = dict(BASELINE_PARAMS)
            row[field] = value
            row["variation_id"] = f"{field}={value}"
            row["changed_dimension"] = field
            variations.append(row)
    return variations


def classify_robustness(results: list[VariationResult], baseline_id: str = "baseline") -> str:
    baseline = next(result for result in results if result.variation_id == baseline_id)
    profitable = [
        result
        for result in results
        if result.combined.net_pnl > 0
        and result.combined.profit_factor >= 1.10
        and result.train.net_pnl > 0
        and result.validation.net_pnl > 0
    ]
    profitable_dimensions = {
        result.changed_dimension for result in profitable if result.changed_dimension != "baseline"
    }
    low_sample = baseline.combined.trades < MIN_COMBINED_TRADES
    if (
        baseline.combined.net_pnl > 0
        and baseline.validation.net_pnl > 0
        and len(profitable) >= 5
        and len(profitable_dimensions) >= 3
    ):
        return "ROBUST;LOW_SAMPLE" if low_sample else "ROBUST"
    if baseline.combined.net_pnl > 0:
        return "FRAGILE;LOW_SAMPLE" if low_sample else "FRAGILE"
    return "NO_EDGE;LOW_SAMPLE" if low_sample else "NO_EDGE"


def assess_deep_dive_approval(
    baseline: VariationResult,
    robustness: str,
) -> ApprovalDecision:
    metrics = baseline.combined
    if metrics.net_pnl <= 0 or metrics.profit_factor < MIN_APPROVAL_PF:
        return ApprovalDecision("REJECTED", "Combined net PnL or profit factor is below the approval threshold.")
    if baseline.train.net_pnl <= 0 or baseline.train.profit_factor < MIN_APPROVAL_PF:
        return ApprovalDecision("WATCHLIST", "Training performance does not independently meet the approval threshold.")
    if baseline.validation.net_pnl <= 0 or baseline.validation.profit_factor < MIN_APPROVAL_PF:
        return ApprovalDecision("WATCHLIST", "Out-of-sample validation does not independently meet the approval threshold.")
    if (
        metrics.trades < MIN_COMBINED_TRADES
        or baseline.train.trades < MIN_TRAIN_TRADES
        or baseline.validation.trades < MIN_VALIDATION_TRADES
    ):
        return ApprovalDecision("WATCHLIST", "Sample size is too small for approval.")
    if robustness != "ROBUST":
        return ApprovalDecision("WATCHLIST", f"Nearby parameter evidence is {robustness}, not ROBUST.")
    if "OVERFIT_RISK" in baseline.warnings or "ONE_BIG_TRADE" in baseline.warnings:
        return ApprovalDecision("WATCHLIST", "Profit concentration creates overfitting risk.")
    return ApprovalDecision("APPROVED_CANDIDATE", "Train, validation, sample size, and nearby settings all passed.")


def run_deep_dive(
    base_dir: Path | str = ".",
    *,
    symbol: str = "GOLD-I",
    bar_dir: str = "data/historical/truedata/bars",
    from_date: str | date | None = None,
    to_date: str | date | None = None,
    configs: dict[str, Any] | None = None,
) -> DeepDiveRunResult:
    base = Path(base_dir)
    if symbol != "GOLD-I":
        raise StrategyBacktestError("This focused deep dive supports GOLD-I only.")
    from_day = _parse_optional_date(from_date, "--from-date")
    to_day = _parse_optional_date(to_date, "--to-date")
    if from_day and to_day and from_day > to_day:
        raise StrategyBacktestError("--from-date cannot be later than --to-date.")

    print("GOLD-I VWAP REJECTION SHORT DEEP DIVE", flush=True)
    print("Mode: PAPER | Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false", flush=True)
    bars, bar_files, notes = _load_backtest_bars(base, bar_dir, from_day, to_day)
    bars = filter_bars_by_symbols(bars, [symbol])
    bar_files = [path for path in bar_files if path.name.startswith(f"{symbol}_")]
    grouped = group_bars_by_symbol(bars)
    if symbol not in grouped:
        raise StrategyBacktestError(f"No bar data found for {symbol}.")
    prepared = _prepare_symbol_bars(grouped[symbol])
    _attach_session_ends(prepared)
    available_dates = sorted({row["day"] for row in prepared})
    train_dates, validation_dates = split_train_validation_dates(available_dates)
    configs = configs or load_configs(base)
    risk_config = configs.get("risk", {})
    instrument = configs.get("instruments", {}).get(symbol, {})

    sparse_dates = _sparse_session_dates(prepared)
    results: list[VariationResult] = []
    for variation in build_controlled_variations():
        params = {
            key: value
            for key, value in variation.items()
            if key not in {"variation_id", "changed_dimension"}
        }
        candidates = _generate_vwap_rejection_candidates(prepared, params)
        trades = _simulate_intraday_trades(
            prepared,
            candidates,
            params,
            risk_config,
            instrument,
            str(variation["variation_id"]),
        )
        train = _metrics_for_dates(trades, candidates, set(train_dates))
        validation = _metrics_for_dates(trades, candidates, set(validation_dates))
        combined = _metrics_for_dates(trades, candidates, set(available_dates))
        warnings = _variation_warnings(train, validation, combined)
        results.append(
            VariationResult(
                variation_id=str(variation["variation_id"]),
                changed_dimension=str(variation["changed_dimension"]),
                params=params,
                trades=tuple(trades),
                train=train,
                validation=validation,
                combined=combined,
                warnings=warnings,
            )
        )

    baseline = next(result for result in results if result.variation_id == "baseline")
    robustness = classify_robustness(results)
    approval = assess_deep_dive_approval(baseline, robustness)
    output_dir = base / "reports" / "strategy_research"
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "latest_gold_vwap_rejection_deep_dive.txt"
    csv_path = output_dir / "latest_gold_vwap_rejection_deep_dive.csv"
    playbook_path = output_dir / "gold_vwap_rejection_short_playbook.txt"
    _write_deep_dive_csv(csv_path, results, baseline, robustness, approval)
    report = _format_report(
        symbol,
        prepared,
        bar_files,
        notes,
        sparse_dates,
        train_dates,
        validation_dates,
        results,
        baseline,
        robustness,
        approval,
    )
    report_path.write_text(report + "\n", encoding="utf-8")
    playbook_path.write_text(
        _format_playbook(baseline, robustness, approval, sparse_dates) + "\n",
        encoding="utf-8",
    )
    print(report, flush=True)
    print(f"Deep-dive CSV: {csv_path}", flush=True)
    print(f"Deep-dive report: {report_path}", flush=True)
    print(f"Playbook draft: {playbook_path}", flush=True)
    return DeepDiveRunResult(
        variations=tuple(results),
        baseline=baseline,
        robustness=robustness,
        approval=approval,
        report_path=report_path,
        csv_path=csv_path,
        playbook_path=playbook_path,
        train_dates=tuple(train_dates),
        validation_dates=tuple(validation_dates),
    )


def _generate_vwap_rejection_candidates(
    rows: list[dict[str, Any]],
    params: dict[str, Any],
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    required_volume = float(params["volume_multiplier"])
    ema_key = f"ema{int(params.get('trend_ema', 20))}"
    for index in range(1, len(rows)):
        row = rows[index]
        previous = rows[index - 1]
        if row["day"] != previous["day"] or index < 20 or not _time_filter_allows(row, str(params["time_filter"])):
            continue
        average_volume = max(float(row["average_volume"]), 1.0)
        actual_volume_multiplier = float(row["volume"]) / average_volume
        if (
            previous["close"] < previous["vwap"]
            and row["high"] >= row["vwap"]
            and row["close"] < row["vwap"]
            and row["close"] < row["open"]
            and row["close"] < row[ema_key]
            and actual_volume_multiplier >= required_volume
        ):
            candidates.append(
                {
                    "index": index,
                    "timestamp": row["timestamp"],
                    "day": row["day"],
                    "signal_high": float(row["high"]),
                    "atr": float(row["atr"]),
                    "vwap_distance": float(row["vwap"]) - float(row["close"]),
                    "volume_multiplier": actual_volume_multiplier,
                    "market_regime": _market_regime(row),
                    "reason": (
                        "Prior close below session VWAP; current bar retested VWAP, "
                        "closed bearish below VWAP and EMA20 with volume expansion."
                    ),
                }
            )
    return candidates


def _simulate_intraday_trades(
    rows: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    params: dict[str, Any],
    risk_config: dict[str, Any],
    instrument: dict[str, Any],
    variation_id: str,
) -> list[DeepDiveTrade]:
    capital = float(risk_config.get("capital", 100000))
    risk_percent = float(risk_config.get("risk_per_trade_percent", 0.5))
    point_value = float(instrument.get("point_value", 1) or 1)
    cooldown = timedelta(seconds=int(params["cooldown_seconds"]))
    active_exit_index = -1
    cooldown_until: datetime | None = None
    daily_trades: dict[date, int] = defaultdict(int)
    trades: list[DeepDiveTrade] = []

    for candidate in candidates:
        signal_index = int(candidate["index"])
        day = candidate["day"]
        if active_exit_index >= signal_index:
            continue
        if cooldown_until and candidate["timestamp"] < cooldown_until:
            continue
        if daily_trades[day] >= int(params["max_trades_per_day"]):
            continue
        entry_index = signal_index + 1
        if entry_index >= len(rows) or rows[entry_index]["day"] != day:
            continue

        entry_row = rows[entry_index]
        raw_entry = float(entry_row["open"])
        adjusted_entry = raw_entry - SLIPPAGE_POINTS
        stop = max(
            float(candidate["signal_high"]),
            adjusted_entry + float(candidate["atr"]) * float(params["atr_stop_multiplier"]),
        )
        risk_distance = stop - adjusted_entry
        target = adjusted_entry - risk_distance * float(params["reward_risk"])
        sizing = calculate_position_size(capital, risk_percent, adjusted_entry, stop, instrument)
        if sizing.quantity <= 0:
            continue

        exit_index, raw_exit, result, exit_reason = _find_intraday_exit(
            rows,
            entry_index + 1,
            entry_index,
            day,
            stop,
            target,
        )
        adjusted_exit = raw_exit + SLIPPAGE_POINTS
        gross_pnl = (raw_entry - raw_exit) * sizing.quantity * point_value
        net_pnl = (adjusted_entry - adjusted_exit) * sizing.quantity * point_value - COST_PER_TRADE
        estimated_risk = sizing.estimated_risk_amount or risk_distance * sizing.quantity * point_value
        trades.append(
            DeepDiveTrade(
                variation_id=variation_id,
                day=day,
                entry_time=entry_row["timestamp"],
                exit_time=rows[exit_index]["timestamp"],
                entry_price=raw_entry,
                adjusted_entry=adjusted_entry,
                stop=stop,
                target=target,
                exit_price=raw_exit,
                adjusted_exit=adjusted_exit,
                result=result,
                gross_pnl=gross_pnl,
                net_pnl=net_pnl,
                r_multiple=net_pnl / estimated_risk if estimated_risk else 0.0,
                vwap_distance_at_entry=float(candidate["vwap_distance"]),
                volume_multiplier=float(candidate["volume_multiplier"]),
                required_volume_multiplier=float(params["volume_multiplier"]),
                atr_value=float(candidate["atr"]),
                market_regime=str(candidate["market_regime"]),
                reason_for_entry=str(candidate["reason"]),
                reason_for_exit=exit_reason,
                qty=sizing.quantity,
            )
        )
        active_exit_index = exit_index
        cooldown_until = candidate["timestamp"] + cooldown
        daily_trades[day] += 1
    return trades


def _find_intraday_exit(
    rows: list[dict[str, Any]],
    start_index: int,
    entry_index: int,
    day: date,
    stop: float,
    target: float,
) -> tuple[int, float, str, str]:
    last_index = entry_index
    for index in range(start_index, len(rows)):
        row = rows[index]
        if row["day"] != day:
            break
        last_index = index
        # Conservative ordering when both are inside one minute bar.
        if float(row["high"]) >= stop:
            return index, stop, "LOSS", "Stop reached; stop is assumed first on an ambiguous bar."
        if float(row["low"]) <= target:
            return index, target, "WIN", "Target reached after the delayed entry bar."
    return last_index, float(rows[last_index]["close"]), "END_EXIT", "Closed at the final available bar of the session."


def _metrics_for_dates(
    trades: list[DeepDiveTrade],
    candidates: list[dict[str, Any]],
    allowed_dates: set[date],
) -> DeepDiveMetrics:
    selected = [trade for trade in trades if trade.day in allowed_dates]
    pnls = [trade.net_pnl for trade in selected]
    gross_profit = sum(pnl for pnl in pnls if pnl > 0)
    gross_loss = abs(sum(pnl for pnl in pnls if pnl < 0))
    raw_by_day: dict[date, int] = defaultdict(int)
    for candidate in candidates:
        if candidate["day"] in allowed_dates:
            raw_by_day[candidate["day"]] += 1
    wins = sum(trade.net_pnl > 0 for trade in selected)
    losses = sum(trade.net_pnl < 0 for trade in selected)
    return DeepDiveMetrics(
        trades=len(selected),
        wins=wins,
        losses=losses,
        end_exits=sum(trade.result == "END_EXIT" for trade in selected),
        win_rate=(wins / len(selected) * 100) if selected else 0.0,
        net_pnl=sum(pnls),
        profit_factor=inf if gross_profit > 0 and gross_loss == 0 else gross_profit / gross_loss if gross_loss else 0.0,
        expectancy=(sum(pnls) / len(selected)) if selected else 0.0,
        max_drawdown=_max_drawdown(pnls),
        max_consecutive_losses=_max_consecutive_losses(pnls),
        raw_signals=sum(raw_by_day.values()),
        max_raw_signals_per_day=max(raw_by_day.values(), default=0),
        largest_winner=max((pnl for pnl in pnls if pnl > 0), default=0.0),
        total_winning_pnl=gross_profit,
    )


def _variation_warnings(
    train: DeepDiveMetrics,
    validation: DeepDiveMetrics,
    combined: DeepDiveMetrics,
) -> tuple[str, ...]:
    warnings: list[str] = []
    if combined.trades < MIN_COMBINED_TRADES:
        warnings.append("LOW_SAMPLE")
    if validation.trades < MIN_VALIDATION_TRADES:
        warnings.append("LOW_VALIDATION_SAMPLE")
    if combined.max_raw_signals_per_day > 100 or combined.raw_signals > max(100, combined.trades * 20):
        warnings.append("HIGH_SIGNAL_FREQUENCY")
    if combined.net_pnl > 0 and combined.trades < 10:
        warnings.append("OVERFIT_RISK")
    if train.net_pnl > 0 and validation.net_pnl <= 0:
        warnings.append("OVERFIT_RISK")
    if (
        combined.total_winning_pnl > 0
        and combined.largest_winner / combined.total_winning_pnl >= 0.65
    ):
        warnings.append("ONE_BIG_TRADE")
        warnings.append("OVERFIT_RISK")
    return tuple(dict.fromkeys(warnings))


def _write_deep_dive_csv(
    path: Path,
    results: list[VariationResult],
    baseline: VariationResult,
    robustness: str,
    approval: ApprovalDecision,
) -> None:
    rows: list[dict[str, Any]] = []
    for result in results:
        params_json = json.dumps(result.params, sort_keys=True, separators=(",", ":"))
        for split, metrics in (
            ("TRAIN", result.train),
            ("VALIDATION", result.validation),
            ("COMBINED", result.combined),
        ):
            rows.append(
                {
                    "record_type": "VARIATION_SUMMARY",
                    "variation_id": result.variation_id,
                    "is_baseline": str(result.variation_id == baseline.variation_id).lower(),
                    "changed_dimension": result.changed_dimension,
                    "params": params_json,
                    "split": split,
                    "trades": metrics.trades,
                    "win_rate": round(metrics.win_rate, 2),
                    "net_pnl": round(metrics.net_pnl, 2),
                    "profit_factor": _display_pf(metrics.profit_factor),
                    "expectancy": round(metrics.expectancy, 2),
                    "max_drawdown": round(metrics.max_drawdown, 2),
                    "max_consecutive_losses": metrics.max_consecutive_losses,
                    "raw_signals": metrics.raw_signals,
                    "warning_flags": ";".join(result.warnings) if result.warnings else "NONE",
                    "robustness": robustness,
                    "approval_status": approval.status,
                    "execution_allowed": "false",
                }
            )
        for trade in result.trades:
            rows.append(
                {
                    "record_type": "TRADE",
                    "variation_id": result.variation_id,
                    "is_baseline": str(result.variation_id == baseline.variation_id).lower(),
                    "changed_dimension": result.changed_dimension,
                    "params": params_json,
                    "warning_flags": ";".join(result.warnings) if result.warnings else "NONE",
                    "robustness": robustness,
                    "approval_status": approval.status,
                    "date": trade.day.isoformat(),
                    "entry_time": trade.entry_time.isoformat(),
                    "exit_time": trade.exit_time.isoformat(),
                    "entry_price": round(trade.entry_price, 2),
                    "adjusted_entry": round(trade.adjusted_entry, 2),
                    "stop": round(trade.stop, 2),
                    "target": round(trade.target, 2),
                    "exit_price": round(trade.exit_price, 2),
                    "adjusted_exit": round(trade.adjusted_exit, 2),
                    "result": trade.result,
                    "gross_pnl": round(trade.gross_pnl, 2),
                    "trade_net_pnl": round(trade.net_pnl, 2),
                    "r_multiple": round(trade.r_multiple, 3),
                    "vwap_distance_at_entry": round(trade.vwap_distance_at_entry, 2),
                    "volume_multiplier": round(trade.volume_multiplier, 3),
                    "required_volume_multiplier": trade.required_volume_multiplier,
                    "atr_value": round(trade.atr_value, 2),
                    "market_regime": trade.market_regime,
                    "reason_for_entry": trade.reason_for_entry,
                    "reason_for_exit": trade.reason_for_exit,
                    "qty": trade.qty,
                    "execution_allowed": "false",
                }
            )
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _format_report(
    symbol: str,
    bars: list[dict[str, Any]],
    bar_files: list[Path],
    loader_notes: list[str],
    sparse_dates: list[date],
    train_dates: list[date],
    validation_dates: list[date],
    results: list[VariationResult],
    baseline: VariationResult,
    robustness: str,
    approval: ApprovalDecision,
) -> str:
    profitable = sum(
        result.combined.net_pnl > 0 and result.combined.profit_factor >= 1.10
        for result in results
    )
    lines = [
        "GOLD-I VWAP REJECTION SHORT DEEP DIVE",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
        f"Symbol: {symbol}",
        f"Bar files: {len(bar_files)} | Bars: {len(bars)}",
        f"Available dates: {train_dates[0]} to {validation_dates[-1]}",
        f"Train dates: {train_dates[0]} to {train_dates[-1]} ({len(train_dates)})",
        f"Validation dates: {validation_dates[0]} to {validation_dates[-1]} ({len(validation_dates)})",
        f"Controlled variations: {len(results)} (one factor at a time; no full Cartesian grid)",
        f"Profitable variations with PF >= 1.10: {profitable}/{len(results)}",
        f"Robustness: {robustness}",
        f"Current approval status: {approval.status}",
        f"Approval reason: {approval.reason}",
        "",
        "BASELINE",
        f"Parameters: {json.dumps(baseline.params, sort_keys=True)}",
        _metric_line("Train", baseline.train),
        _metric_line("Validation", baseline.validation),
        _metric_line("Combined", baseline.combined),
        f"Warnings: {';'.join(baseline.warnings) if baseline.warnings else 'NONE'}",
        "",
        "BASELINE TRADE-BY-TRADE",
    ]
    if baseline.trades:
        for trade in baseline.trades:
            lines.append(
                f"- {trade.day} {trade.entry_time.time()}->{trade.exit_time.time()} {trade.result} "
                f"entry={trade.entry_price:.2f} stop={trade.stop:.2f} target={trade.target:.2f} "
                f"exit={trade.exit_price:.2f} gross={trade.gross_pnl:.2f} net={trade.net_pnl:.2f} "
                f"R={trade.r_multiple:.2f} regime={trade.market_regime}"
            )
            lines.append(
                f"  VWAP distance={trade.vwap_distance_at_entry:.2f} "
                f"volume={trade.volume_multiplier:.2f}x ATR={trade.atr_value:.2f}; {trade.reason_for_exit}"
            )
    else:
        lines.append("- No baseline trades.")

    lines.extend(["", "SENSITIVITY SUMMARY"])
    for result in results:
        lines.append(
            f"- {result.variation_id}: trades={result.combined.trades} "
            f"net={result.combined.net_pnl:.2f} PF={_display_pf(result.combined.profit_factor)} "
            f"validation={result.validation.net_pnl:.2f}/{_display_pf(result.validation.profit_factor)} "
            f"warnings={';'.join(result.warnings) if result.warnings else 'NONE'}"
        )
    if sparse_dates:
        lines.extend(
            [
                "",
                "DATA QUALITY WARNING",
                "Sparse session dates (<100 bars): " + ", ".join(day.isoformat() for day in sparse_dates),
                "These dates reduce confidence and must not be treated as complete sessions.",
            ]
        )
    if loader_notes:
        lines.extend(["Loader notes: " + "; ".join(loader_notes)])
    lines.extend(
        [
            "",
            "CONCLUSION",
            (
                "Evidence is not approval-grade. Continue PAPER watchlist research and collect more complete, "
                "out-of-sample sessions."
                if approval.status != "APPROVED_CANDIDATE"
                else "Evidence passed the research gate only; production alerts remain separately gated."
            ),
            "PAPER MODE ONLY. No broker orders were placed.",
        ]
    )
    return "\n".join(lines)


def _format_playbook(
    baseline: VariationResult,
    robustness: str,
    approval: ApprovalDecision,
    sparse_dates: list[date],
) -> str:
    return "\n".join(
        [
            "GOLD-I VWAP REJECTION SHORT - RESEARCH PLAYBOOK DRAFT",
            "RESEARCH ONLY - DO NOT TRADE",
            "Mode: PAPER | execution_allowed=false | Broker Orders: DISABLED",
            "",
            "SETUP DEFINITION",
            "Intraday short after price is already below session VWAP, pulls back to touch/retest VWAP, "
            "then closes as a bearish candle below VWAP and EMA20 on expanded volume.",
            "",
            "ENTRY CONDITIONS",
            "1. Previous one-minute close is below its session VWAP.",
            "2. Rejection bar high reaches session VWAP.",
            "3. Rejection bar closes below VWAP, below its open, and below EMA20.",
            f"4. Volume is at least {baseline.params['volume_multiplier']}x the trailing 20-bar average.",
            "5. Enter short at the next bar open with five points adverse entry slippage.",
            "",
            "WHEN TO AVOID",
            "Avoid incomplete/sparse sessions, missing volume, a close above VWAP/EMA20, no bearish rejection candle, "
            "and any setup that exceeds the daily cap or occurs inside cooldown. Do not infer an edge from one large winner.",
            "",
            "STOP / TARGET",
            f"Stop is the higher of the rejection-bar high or {baseline.params['atr_stop_multiplier']} ATR above adjusted entry.",
            f"Target is {baseline.params['reward_risk']}R. Stop is assumed first when stop and target occur in the same bar.",
            "Any unfinished position exits at the final available bar of the same session.",
            "",
            "RISK LOGIC",
            "Use the existing lot-aware PAPER position sizing with 0.5% configured account risk, point value, "
            "minimum quantity, and lot size. Apply five points exit slippage and 50 cost units per trade.",
            "",
            "EXPECTED FREQUENCY",
            f"Observed baseline: {baseline.combined.trades} trades across the available dates; maximum three per day.",
            "",
            "KNOWN WEAKNESSES",
            f"Robustness classification: {robustness}.",
            f"Baseline warnings: {';'.join(baseline.warnings) if baseline.warnings else 'NONE'}.",
            "The current sample is small, early dates include sparse sessions, VWAP depends on reliable intraday volume, "
            "and one-minute bars cannot reveal true intrabar stop/target ordering.",
            (
                "Sparse dates: " + ", ".join(day.isoformat() for day in sparse_dates)
                if sparse_dates
                else "No sparse dates detected."
            ),
            "",
            "CURRENT APPROVAL STATUS",
            f"{approval.status}: {approval.reason}",
            "Production WhatsApp alerts remain blocked. Research watchlist previews are disabled by default.",
            "",
            "MORE DATA REQUIRED",
            "At least 20 combined trades, at least 10 training and 5 validation trades, multiple complete unseen weeks, "
            "positive validation and combined PF >=1.30, profitable nearby settings across several dimensions, "
            "and no one-big-trade or overfitting warning.",
        ]
    )


def _attach_session_ends(rows: list[dict[str, Any]]) -> None:
    by_day: dict[date, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_day[row["day"]].append(row)
    for day_rows in by_day.values():
        end = max(row["timestamp"] for row in day_rows)
        for row in day_rows:
            row["session_end"] = end
            row["minutes_to_session_end"] = int((end - row["timestamp"]).total_seconds() // 60)


def _time_filter_allows(row: dict[str, Any], time_filter: str) -> bool:
    if time_filter == "avoid_first_15":
        return int(row["elapsed_minutes"]) >= 15
    if time_filter == "avoid_first_30":
        return int(row["elapsed_minutes"]) >= 30
    if time_filter == "avoid_last_30":
        return int(row["minutes_to_session_end"]) >= 30
    return True


def _market_regime(row: dict[str, Any]) -> str:
    if (
        row["close"] < row["ema20"] < row["ema50"]
        and row["ema20_slope"] < 0
        and row["ema50_slope"] < 0
    ):
        return "TREND_DOWN"
    if row["close"] < row["ema20"] and row["ema20_slope"] < 0:
        return "BEARISH"
    if abs(float(row["ema20"]) - float(row["ema50"])) <= float(row["atr"]) * 0.5:
        return "RANGE"
    return "MIXED"


def _sparse_session_dates(rows: list[dict[str, Any]]) -> list[date]:
    counts: dict[date, int] = defaultdict(int)
    for row in rows:
        counts[row["day"]] += 1
    return sorted(day for day, count in counts.items() if count < 100)


def _metric_line(label: str, metrics: DeepDiveMetrics) -> str:
    return (
        f"{label}: trades={metrics.trades} wins={metrics.wins} losses={metrics.losses} "
        f"end_exit={metrics.end_exits} win_rate={metrics.win_rate:.2f}% "
        f"net_pnl={metrics.net_pnl:.2f} PF={_display_pf(metrics.profit_factor)} "
        f"expectancy={metrics.expectancy:.2f} drawdown={metrics.max_drawdown:.2f}"
    )


def _max_drawdown(pnls: list[float]) -> float:
    equity = peak = drawdown = 0.0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        drawdown = min(drawdown, equity - peak)
    return drawdown


def _max_consecutive_losses(pnls: list[float]) -> int:
    maximum = current = 0
    for pnl in pnls:
        if pnl < 0:
            current += 1
            maximum = max(maximum, current)
        else:
            current = 0
    return maximum


def _display_pf(value: float) -> str | float:
    return "inf" if value == inf else round(value, 2)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PAPER-only GOLD-I VWAP rejection short deep dive.")
    parser.add_argument("--symbol", default="GOLD-I")
    parser.add_argument("--bar-dir", default="data/historical/truedata/bars")
    parser.add_argument("--from-date")
    parser.add_argument("--to-date")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = run_deep_dive(
            symbol=args.symbol,
            bar_dir=args.bar_dir,
            from_date=args.from_date,
            to_date=args.to_date,
        )
    except (StrategyBacktestError, FileNotFoundError, ValueError) as exc:
        print(f"Deep dive failed safely: {exc}")
        print("Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false")
        return 1
    print(f"Trades found: {result.baseline.combined.trades}")
    print(f"Robustness: {result.robustness}")
    print(
        f"Train: {result.baseline.train.trades} trades, net={result.baseline.train.net_pnl:.2f}, "
        f"PF={_display_pf(result.baseline.train.profit_factor)}"
    )
    print(
        f"Validation: {result.baseline.validation.trades} trades, net={result.baseline.validation.net_pnl:.2f}, "
        f"PF={_display_pf(result.baseline.validation.profit_factor)}"
    )
    print(f"Current approval status: {result.approval.status}")
    print(f"Reason: {result.approval.reason}")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
