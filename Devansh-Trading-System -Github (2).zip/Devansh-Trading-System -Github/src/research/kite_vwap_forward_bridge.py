from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs
from src.data_collection.market_data_schema import (
    kite_tick_path,
    load_csv_rows,
    parse_timestamp,
    to_float,
)
from src.market_context.market_mode import classify_market_mode
from src.research.forward_validation import (
    CANONICAL_FAMILY,
    CANONICAL_SETUP,
    FORWARD_STRATEGY,
    load_ledger,
    make_signal_id,
    record_watchlist_signal_from_row,
)
from src.strategies import vwap_reclaim, vwap_rejection


ACTIVE_LOCKED_SETUP = CANONICAL_SETUP
RECLAIM_SETUP = "gold_vwap_reclaim_long"


@dataclass
class KiteVwapForwardBridgeResult:
    symbol: str
    day: date
    tick_rows_loaded: int = 0
    usable_tick_rows: int = 0
    candles_built: int = 0
    candidates_found: int = 0
    rejection_candidates_found: int = 0
    reclaim_candidates_found: int = 0
    ledger_rows_added: int = 0
    duplicate_signals_skipped: int = 0
    active_pending_skipped: int = 0
    unsupported_lock_candidates_skipped: int = 0
    status: str = "NO_INPUT"
    reason: str = ""
    tick_path: Path | None = None
    warnings: list[str] = field(default_factory=list)


def run_kite_vwap_forward_bridge(
    base_dir: Path | str = ".",
    *,
    symbol: str = "GOLD-I",
    day: str | date,
    configs: dict[str, Any] | None = None,
    as_of: datetime | None = None,
    record_func: Callable[..., bool] = record_watchlist_signal_from_row,
) -> KiteVwapForwardBridgeResult:
    """Scan recorded Kite ticks for locked VWAP-family PAPER signals.

    Candle OHLCV is derived only from recorded ticks. The final/incomplete
    minute is excluded. Under the current research lock, reclaim candidates
    are diagnostic only; only GOLD-I VWAP Rejection Short can enter the
    forward-validation ledger.
    """

    base = Path(base_dir)
    feature_day = _parse_date(day)
    result = KiteVwapForwardBridgeResult(symbol=symbol, day=feature_day)
    result.tick_path = kite_tick_path(base, feature_day, symbol)
    raw_rows = load_csv_rows(result.tick_path)
    result.tick_rows_loaded = len(raw_rows)
    ticks = _prepare_real_ticks(raw_rows, symbol)
    result.usable_tick_rows = len(ticks)
    if not ticks:
        result.status = "NO_INPUT"
        result.reason = "No usable real Kite tick rows were available."
        return result

    candles = build_closed_one_minute_candles(ticks, as_of=as_of)
    result.candles_built = len(candles)
    if len(candles) < 4:
        result.status = "INSUFFICIENT_CLOSED_CANDLES"
        result.reason = (
            f"Only {len(candles)} closed one-minute candle(s) were available; "
            "at least 4 are required by the existing VWAP strategies."
        )
        return result
    if not any(float(candle.get("volume") or 0) > 0 for candle in candles):
        result.status = "VOLUME_UNAVAILABLE"
        result.reason = "Recorded ticks did not provide LTQ or cumulative-volume changes needed for VWAP."
        return result

    configs = configs or load_configs(base)
    forward_config = dict(configs.get("forward_validation", {}) or {})
    existing = load_ledger(base)
    existing_ids = {str(row.get("signal_id") or "") for row in existing}
    active_pending = any(
        row.get("symbol") == symbol
        and row.get("strategy") == FORWARD_STRATEGY
        and str(row.get("status") or "").upper() == "PENDING"
        for row in existing
    )

    for index in range(3, len(candles)):
        history = candles[: index + 1]
        market_mode = classify_market_mode(history, configs.get("settings", {}))
        context = {"market_mode": market_mode}
        for setup, generator in (
            (ACTIVE_LOCKED_SETUP, vwap_rejection.generate_signal),
            (RECLAIM_SETUP, vwap_reclaim.generate_signal),
        ):
            signal = generator(history, context)
            if signal is None:
                continue
            if setup == ACTIVE_LOCKED_SETUP and signal.side != "SELL":
                continue
            if setup == RECLAIM_SETUP and signal.side != "BUY":
                continue
            result.candidates_found += 1
            if setup == ACTIVE_LOCKED_SETUP:
                result.rejection_candidates_found += 1
            else:
                result.reclaim_candidates_found += 1

            signal_time = _candle_close_time(history[-1])
            entry_tick = _first_tick_after(ticks, signal_time)
            if entry_tick is None:
                result.warnings.append(
                    f"{setup}: no strictly later tick existed after signal confirmation at "
                    f"{signal_time.isoformat()}."
                )
                continue
            if entry_tick["timestamp"] <= signal_time:
                continue
            if setup != ACTIVE_LOCKED_SETUP:
                result.unsupported_lock_candidates_skipped += 1
                continue

            entry = float(entry_tick["ltp"])
            stop = float(signal.stop_loss)
            target = float(signal.target_price)
            if not (target < entry < stop):
                result.warnings.append(
                    f"{setup}: next-tick entry {entry:.2f} invalidated the locked SELL stop/target geometry."
                )
                continue
            signal_id = make_signal_id(symbol, FORWARD_STRATEGY, signal_time, "SELL", entry, stop, target)
            if signal_id in existing_ids:
                result.duplicate_signals_skipped += 1
                continue
            if active_pending:
                result.active_pending_skipped += 1
                continue

            row = {
                "symbol": symbol,
                "status": "ACCEPTED_PAPER_SIGNAL",
                "signal_time": signal_time.isoformat(),
                "entry_time": entry_tick["timestamp"].isoformat(),
                "direction": "SELL",
                "strategy": "VWAP Rejection Short",
                "entry": entry,
                "stop": stop,
                "target": target,
                "score": signal.score,
                "market_mode": market_mode,
                "key_reason": signal.reason,
                "provider": "KITE",
                "data_role": "FORWARD_VALIDATION",
                "used_for_parameter_tuning": "false",
                "canonical_family": CANONICAL_FAMILY,
                "canonical_setup": ACTIVE_LOCKED_SETUP,
                "approval_status_at_signal": "RESEARCH_ONLY",
                "execution_allowed": False,
            }
            recorded = record_func(
                base,
                row,
                scan_time=signal_time,
                alert_mode="blocked",
                config=forward_config,
            )
            if recorded:
                result.ledger_rows_added += 1
                existing_ids.add(signal_id)
                active_pending = True

    if result.ledger_rows_added:
        result.status = "PENDING_POST_LOCK_RECORDED"
        result.reason = f"Recorded {result.ledger_rows_added} locked RESEARCH_ONLY candidate(s)."
    elif result.candidates_found == 0:
        result.status = "NO_SETUP"
        result.reason = "No existing VWAP rejection/reclaim strategy setup was confirmed on closed candles."
    elif result.active_pending_skipped:
        result.status = "ACTIVE_PENDING_EXISTS"
        result.reason = "A pending locked forward trade already exists; overlapping candidates were not recorded."
    elif result.duplicate_signals_skipped:
        result.status = "DUPLICATE_SKIPPED"
        result.reason = "All recordable locked candidates already existed in the ledger."
    elif result.reclaim_candidates_found and not result.rejection_candidates_found:
        result.status = "RECLAIM_OUTSIDE_ACTIVE_LOCK"
        result.reason = "VWAP reclaim candidates were diagnostic only because the active lock is rejection-short."
    else:
        result.status = "NO_LEDGER_ROW"
        result.reason = "Candidates were found but none passed next-tick and active-lock recording rules."
    return result


def build_closed_one_minute_candles(
    ticks: list[dict[str, Any]],
    *,
    as_of: datetime | None = None,
) -> list[dict[str, Any]]:
    clean = sorted(
        (tick for tick in ticks if tick.get("timestamp") and to_float(tick.get("ltp")) > 0),
        key=lambda tick: tick["timestamp"],
    )
    if not clean:
        return []
    cutoff = _minute_start(as_of or clean[-1]["timestamp"])
    buckets: dict[datetime, list[dict[str, Any]]] = {}
    for tick in clean:
        minute = _minute_start(tick["timestamp"])
        if minute >= cutoff:
            continue
        buckets.setdefault(minute, []).append(tick)

    candles: list[dict[str, Any]] = []
    previous_cumulative_volume: float | None = None
    for minute in sorted(buckets):
        bucket = buckets[minute]
        prices = [float(tick["ltp"]) for tick in bucket]
        ltq_volume = sum(max(0.0, to_float(tick.get("ltq"))) for tick in bucket)
        cumulative_values = [to_float(tick.get("volume")) for tick in bucket if to_float(tick.get("volume")) > 0]
        cumulative_delta = 0.0
        if cumulative_values:
            first = cumulative_values[0]
            last = cumulative_values[-1]
            baseline = previous_cumulative_volume if previous_cumulative_volume is not None else first
            cumulative_delta = max(0.0, last - baseline)
            previous_cumulative_volume = last
        volume = ltq_volume if ltq_volume > 0 else cumulative_delta
        candles.append(
            {
                "timestamp": minute,
                "open": prices[0],
                "high": max(prices),
                "low": min(prices),
                "close": prices[-1],
                "volume": volume,
                "symbol": bucket[0].get("symbol") or bucket[0].get("internal_symbol") or "GOLD-I",
                "interval": "1minute",
                "source": "KITE_RECORDED_TICKS",
            }
        )
    return candles


def _prepare_real_ticks(rows: list[dict[str, Any]], symbol: str) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for row in rows:
        if str(row.get("internal_symbol") or row.get("symbol") or "").upper() != symbol.upper():
            continue
        if str(row.get("is_synthetic") or "false").strip().lower() in {"true", "1", "yes"}:
            continue
        if str(row.get("data_mode") or "").strip().upper() == "DRY_RUN":
            continue
        try:
            timestamp = parse_timestamp(row.get("timestamp"))
        except (TypeError, ValueError):
            continue
        ltp = to_float(row.get("ltp") or row.get("last_price"))
        if ltp <= 0:
            continue
        output.append(
            {
                "timestamp": timestamp,
                "symbol": symbol,
                "ltp": ltp,
                "ltq": to_float(row.get("ltq")),
                "volume": to_float(row.get("volume")),
            }
        )
    return sorted(output, key=lambda tick: tick["timestamp"])


def _first_tick_after(
    ticks: list[dict[str, Any]],
    timestamp: datetime,
) -> dict[str, Any] | None:
    return next((tick for tick in ticks if tick["timestamp"] > timestamp), None)


def _candle_close_time(candle: dict[str, Any]) -> datetime:
    return candle["timestamp"] + timedelta(minutes=1)


def _minute_start(value: datetime) -> datetime:
    return value.replace(second=0, microsecond=0)


def _parse_date(value: str | date) -> date:
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))
