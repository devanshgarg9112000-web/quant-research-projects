from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from math import inf
from pathlib import Path
from typing import Any, Iterable

from src.backtesting.strategy_backtest_runner import (
    StrategyBacktestError,
    _load_backtest_bars,
    _load_backtest_ticks,
    _parse_optional_date,
    filter_bars_by_symbols,
    group_bars_by_symbol,
)
from src.config_loader import load_configs
from src.replay.replay_engine import parse_replay_symbols
from src.risk.position_sizing import calculate_position_size
from src.scoring.strategy_verification import REPORT_COLUMNS


RESEARCH_COLUMNS = [
    "strategy",
    "symbol",
    "variant_params",
    "train_trades",
    "train_net_pnl",
    "train_pf",
    "validation_trades",
    "validation_net_pnl",
    "validation_pf",
    "combined_trades",
    "combined_win_rate",
    "combined_net_pnl",
    "combined_pf",
    "expectancy",
    "max_drawdown",
    "max_consecutive_losses",
    "warnings",
    "approval_candidate",
    "recommendation",
]

RESEARCH_STRATEGIES = [
    "vwap_reclaim_long",
    "vwap_rejection_short",
    "failed_breakout_trap",
    "opening_range_breakout",
    "trend_pullback",
    "range_reversal_poc_retest",
]

VARIANT_PROFILES = [
    {"atr_stop_multiplier": 1.0, "reward_risk": 1.5, "volume_multiplier": 1.2, "opening_range_minutes": 15, "trend_ema": 20},
    {"atr_stop_multiplier": 1.5, "reward_risk": 1.5, "volume_multiplier": 1.5, "opening_range_minutes": 30, "trend_ema": 20},
    {"atr_stop_multiplier": 2.0, "reward_risk": 1.5, "volume_multiplier": 2.0, "opening_range_minutes": 60, "trend_ema": 50},
    {"atr_stop_multiplier": 1.0, "reward_risk": 2.0, "volume_multiplier": 1.5, "opening_range_minutes": 60, "trend_ema": 50},
    {"atr_stop_multiplier": 1.5, "reward_risk": 2.0, "volume_multiplier": 2.0, "opening_range_minutes": 15, "trend_ema": 50},
    {"atr_stop_multiplier": 2.0, "reward_risk": 2.0, "volume_multiplier": 1.2, "opening_range_minutes": 30, "trend_ema": 20},
]

MIN_COMBINED_TRADES = 20
MIN_TRAIN_TRADES = 10
MIN_VALIDATION_TRADES = 5
MIN_APPROVAL_PF = 1.3
MAX_RAW_SIGNALS_PER_DAY = 100
SIGNAL_COOLDOWN_SECONDS = 300
SLIPPAGE_POINTS = 5.0
COST_PER_TRADE = 50.0


@dataclass(frozen=True)
class ResearchMetrics:
    trades: int = 0
    wins: int = 0
    losses: int = 0
    win_rate: float = 0.0
    net_pnl: float = 0.0
    profit_factor: float = 0.0
    expectancy: float = 0.0
    max_drawdown: float = 0.0
    max_consecutive_losses: int = 0
    raw_signals: int = 0
    max_raw_signals_per_day: int = 0
    risk_rejected: int = 0
    overlap_skipped: int = 0
    cooldown_skipped: int = 0
    daily_limit_skipped: int = 0


@dataclass(frozen=True)
class ResearchAssessment:
    warnings: tuple[str, ...]
    approval_candidate: bool
    recommendation: str


@dataclass(frozen=True)
class ResearchRunResult:
    rows: list[dict[str, Any]]
    report_path: Path
    csv_path: Path
    train_dates: tuple[date, ...]
    validation_dates: tuple[date, ...]
    bar_files: tuple[Path, ...]
    tick_files: tuple[Path, ...]
    bar_count: int
    tick_count: int
    production_approved_count: int


def split_train_validation_dates(
    available_dates: Iterable[date | str],
    train_fraction: float = 0.70,
) -> tuple[list[date], list[date]]:
    """Return an ordered chronological 70/30 split with no date leakage."""

    dates = sorted({_coerce_date(value) for value in available_dates})
    if len(dates) < 2:
        raise StrategyBacktestError("Strategy research requires at least two available trading dates.")
    train_count = int(len(dates) * train_fraction)
    train_count = min(max(train_count, 1), len(dates) - 1)
    return dates[:train_count], dates[train_count:]


def assess_research_result(
    train: ResearchMetrics,
    validation: ResearchMetrics,
    combined: ResearchMetrics,
    *,
    strategy: str = "",
) -> ResearchAssessment:
    """Apply conservative, out-of-sample-first approval rules."""

    warnings: list[str] = []
    if combined.trades < MIN_COMBINED_TRADES:
        warnings.append("LOW_TRADE_COUNT")
    if train.trades < MIN_TRAIN_TRADES:
        warnings.append("LOW_TRAIN_SAMPLE")
    if validation.trades < MIN_VALIDATION_TRADES:
        warnings.append("LOW_VALIDATION_SAMPLE")

    high_frequency = (
        combined.max_raw_signals_per_day > MAX_RAW_SIGNALS_PER_DAY
        or combined.raw_signals > max(MAX_RAW_SIGNALS_PER_DAY, combined.trades * 20)
    )
    if high_frequency:
        warnings.append("HIGH_SIGNAL_FREQUENCY_WARNING")

    overfit = _has_overfitting_warning(train, validation, combined)
    if overfit:
        warnings.append("OVERFITTING_WARNING")

    poc_unverified = strategy == "range_reversal_poc_retest"
    if poc_unverified:
        warnings.append("BAR_DERIVED_POC_APPROXIMATION")

    train_pass = train.net_pnl > 0 and train.profit_factor >= MIN_APPROVAL_PF
    validation_pass = validation.net_pnl > 0 and validation.profit_factor >= MIN_APPROVAL_PF
    combined_pass = combined.net_pnl > 0 and combined.profit_factor >= MIN_APPROVAL_PF
    enough_trades = (
        combined.trades >= MIN_COMBINED_TRADES
        and train.trades >= MIN_TRAIN_TRADES
        and validation.trades >= MIN_VALIDATION_TRADES
    )

    if high_frequency or overfit:
        recommendation = "REJECTED"
    elif not train_pass:
        recommendation = "REJECTED"
    elif not validation_pass:
        recommendation = "REJECTED"
    elif not combined_pass:
        recommendation = "REJECTED"
    elif not enough_trades or poc_unverified:
        recommendation = "WATCHLIST"
    else:
        recommendation = "APPROVED_CANDIDATE"

    return ResearchAssessment(
        warnings=tuple(warnings),
        approval_candidate=recommendation == "APPROVED_CANDIDATE",
        recommendation=recommendation,
    )


def run_strategy_research(
    base_dir: Path | str = ".",
    *,
    symbols_text: str = "GOLD-I,SILVER-I",
    bar_dir: str = "data/historical/truedata/bars",
    tick_dir: str = "data/historical/truedata/ticks",
    from_date: str | date | None = None,
    to_date: str | date | None = None,
    configs: dict[str, Any] | None = None,
) -> ResearchRunResult:
    """Run controlled PAPER-only bar research and inventory tick coverage."""

    base = Path(base_dir)
    symbols = parse_replay_symbols(symbols_text)
    if not symbols:
        raise StrategyBacktestError("At least one symbol is required for strategy research.")
    from_day = _parse_optional_date(from_date, "--from-date")
    to_day = _parse_optional_date(to_date, "--to-date")
    if from_day and to_day and from_day > to_day:
        raise StrategyBacktestError("--from-date cannot be later than --to-date.")

    print("STRATEGY RESEARCH LAB", flush=True)
    print("Mode: PAPER | Broker Orders: DISABLED | execution_allowed=false", flush=True)
    bars, bar_files, _ = _load_backtest_bars(base, bar_dir, from_day, to_day)
    bars = filter_bars_by_symbols(bars, symbols)
    if not bars:
        raise StrategyBacktestError("No matching TrueData bars were available for the requested research.")
    grouped = group_bars_by_symbol(bars)
    missing_symbols = [symbol for symbol in symbols if symbol not in grouped]
    if missing_symbols:
        raise StrategyBacktestError(f"No bar data found for symbols: {', '.join(missing_symbols)}")

    tick_rows: list[dict[str, Any]] = []
    tick_files: list[Path] = []
    try:
        tick_rows, tick_files, _ = _load_backtest_ticks(
            base,
            None,
            tick_dir,
            from_day=from_day,
            to_day=to_day,
            symbols=symbols,
        )
    except StrategyBacktestError as exc:
        print(f"[RESEARCH] Tick coverage warning: {exc}", flush=True)

    available_dates = sorted({_coerce_datetime(row["timestamp"]).date() for row in bars})
    train_dates, validation_dates = split_train_validation_dates(available_dates)
    print(
        f"[RESEARCH] Bars={len(bars)} files={len(bar_files)} | "
        f"Ticks={len(tick_rows)} files={len(tick_files)}",
        flush=True,
    )
    print(
        f"[RESEARCH] Train dates {train_dates[0]}..{train_dates[-1]} ({len(train_dates)}) | "
        f"Validation dates {validation_dates[0]}..{validation_dates[-1]} ({len(validation_dates)})",
        flush=True,
    )

    configs = configs or load_configs(base)
    risk_config = configs.get("risk", {})
    instruments = configs.get("instruments", {})
    rows: list[dict[str, Any]] = []
    for symbol in symbols:
        prepared = _prepare_symbol_bars(grouped[symbol])
        print(f"[RESEARCH] Starting {symbol}: {len(prepared)} bars", flush=True)
        for strategy in RESEARCH_STRATEGIES:
            for profile_number, params in enumerate(VARIANT_PROFILES, start=1):
                candidates = _generate_candidates(strategy, prepared, params)
                max_trades = 5 if strategy == "range_reversal_poc_retest" else 10
                train = _simulate_candidates(
                    prepared,
                    candidates,
                    set(train_dates),
                    params,
                    risk_config,
                    instruments.get(symbol, {}),
                    max_trades,
                )
                validation = _simulate_candidates(
                    prepared,
                    candidates,
                    set(validation_dates),
                    params,
                    risk_config,
                    instruments.get(symbol, {}),
                    max_trades,
                )
                combined = _simulate_candidates(
                    prepared,
                    candidates,
                    set(available_dates),
                    params,
                    risk_config,
                    instruments.get(symbol, {}),
                    max_trades,
                )
                assessment = assess_research_result(train, validation, combined, strategy=strategy)
                variant_params = dict(params)
                variant_params["profile"] = profile_number
                rows.append(
                    _build_result_row(
                        strategy,
                        symbol,
                        variant_params,
                        train,
                        validation,
                        combined,
                        assessment,
                    )
                )
        print(f"[RESEARCH] Completed {symbol}: {len(RESEARCH_STRATEGIES) * len(VARIANT_PROFILES)} variants", flush=True)

    rows.sort(key=_ranking_key, reverse=True)
    output_dir = base / "reports" / "strategy_research"
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "latest_strategy_research_report.csv"
    report_path = output_dir / "latest_strategy_research_report.txt"
    _write_csv(csv_path, RESEARCH_COLUMNS, rows)
    report_text = _format_research_report(
        rows,
        symbols,
        train_dates,
        validation_dates,
        bar_files,
        tick_files,
        len(bars),
        len(tick_rows),
    )
    report_path.write_text(report_text + "\n", encoding="utf-8")
    _update_strategy_approval_report(base, rows)
    production_approved_count = _count_production_approvals(base)

    print(report_text, flush=True)
    print(f"Research CSV: {csv_path}", flush=True)
    print(f"Research Report: {report_path}", flush=True)
    return ResearchRunResult(
        rows=rows,
        report_path=report_path,
        csv_path=csv_path,
        train_dates=tuple(train_dates),
        validation_dates=tuple(validation_dates),
        bar_files=tuple(bar_files),
        tick_files=tuple(tick_files),
        bar_count=len(bars),
        tick_count=len(tick_rows),
        production_approved_count=production_approved_count,
    )


def _prepare_symbol_bars(bars: list[dict[str, Any]]) -> list[dict[str, Any]]:
    prepared: list[dict[str, Any]] = []
    atr_values: deque[float] = deque(maxlen=14)
    volume_values: deque[float] = deque(maxlen=20)
    recent_highs: deque[float] = deque(maxlen=20)
    recent_lows: deque[float] = deque(maxlen=20)
    ema20: float | None = None
    ema50: float | None = None
    previous_close: float | None = None
    current_day: date | None = None
    session_start: datetime | None = None
    cumulative_volume = 0.0
    cumulative_price_volume = 0.0
    volume_profile: dict[float, float] = {}

    for index, original in enumerate(sorted(bars, key=lambda row: row["timestamp"])):
        row = dict(original)
        timestamp = _coerce_datetime(row["timestamp"])
        day = timestamp.date()
        if day != current_day:
            current_day = day
            session_start = timestamp
            cumulative_volume = 0.0
            cumulative_price_volume = 0.0
            volume_profile = {}

        close = float(row["close"])
        high = float(row["high"])
        low = float(row["low"])
        volume = float(row.get("volume") or 0.0)
        previous_ema20 = ema20
        previous_ema50 = ema50
        ema20 = close if ema20 is None else _ema(close, ema20, 20)
        ema50 = close if ema50 is None else _ema(close, ema50, 50)
        true_range = high - low
        if previous_close is not None:
            true_range = max(true_range, abs(high - previous_close), abs(low - previous_close))
        atr_values.append(true_range)
        atr = sum(atr_values) / len(atr_values)
        average_volume = sum(volume_values) / len(volume_values) if volume_values else volume
        prior_high = max(recent_highs) if recent_highs else None
        prior_low = min(recent_lows) if recent_lows else None
        prior_poc = max(volume_profile, key=volume_profile.get) if volume_profile else None

        typical_price = (high + low + close) / 3.0
        cumulative_volume += max(volume, 0.0)
        cumulative_price_volume += typical_price * max(volume, 0.0)
        vwap = cumulative_price_volume / cumulative_volume if cumulative_volume else close
        poc_bucket = round(close / 10.0) * 10.0
        volume_profile[poc_bucket] = volume_profile.get(poc_bucket, 0.0) + max(volume, 0.0)

        row.update(
            {
                "timestamp": timestamp,
                "index": index,
                "day": day,
                "session_start": session_start,
                "elapsed_minutes": int((timestamp - session_start).total_seconds() // 60) if session_start else 0,
                "atr": atr,
                "average_volume": average_volume,
                "ema20": ema20,
                "ema50": ema50,
                "ema20_slope": 0.0 if previous_ema20 is None else ema20 - previous_ema20,
                "ema50_slope": 0.0 if previous_ema50 is None else ema50 - previous_ema50,
                "vwap": vwap,
                "prior_high20": prior_high,
                "prior_low20": prior_low,
                "poc": prior_poc,
            }
        )
        prepared.append(row)
        previous_close = close
        volume_values.append(volume)
        recent_highs.append(high)
        recent_lows.append(low)

    _attach_opening_ranges(prepared)
    return prepared


def _attach_opening_ranges(rows: list[dict[str, Any]]) -> None:
    by_day: dict[date, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_day[row["day"]].append(row)
    for day_rows in by_day.values():
        for minutes in (15, 30, 60):
            opening = [row for row in day_rows if row["elapsed_minutes"] < minutes]
            high = max((float(row["high"]) for row in opening), default=None)
            low = min((float(row["low"]) for row in opening), default=None)
            for row in day_rows:
                row[f"or{minutes}_high"] = high
                row[f"or{minutes}_low"] = low


def _generate_candidates(
    strategy: str,
    rows: list[dict[str, Any]],
    params: dict[str, Any],
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    volume_multiplier = float(params["volume_multiplier"])
    ema_key = f"ema{int(params['trend_ema'])}"
    slope_key = f"{ema_key}_slope"

    for index in range(1, len(rows)):
        row = rows[index]
        previous = rows[index - 1]
        if row["day"] != previous["day"] or index < 20:
            continue
        atr = float(row["atr"])
        if atr <= 0:
            continue
        volume_ok = float(row["volume"]) >= max(float(row["average_volume"]) * volume_multiplier, 1.0)
        direction: str | None = None

        if strategy == "vwap_reclaim_long":
            if (
                previous["close"] < previous["vwap"]
                and row["close"] > row["vwap"]
                and row["close"] > row["open"]
                and row["close"] > row[ema_key]
                and volume_ok
            ):
                direction = "BUY"
        elif strategy == "vwap_rejection_short":
            if (
                previous["close"] < previous["vwap"]
                and row["high"] >= row["vwap"]
                and row["close"] < row["vwap"]
                and row["close"] < row["open"]
                and row["close"] < row[ema_key]
                and volume_ok
            ):
                direction = "SELL"
        elif strategy == "failed_breakout_trap":
            prior_high = row["prior_high20"]
            prior_low = row["prior_low20"]
            if prior_high is not None and row["high"] > prior_high and row["close"] < prior_high and row["close"] < row["open"] and volume_ok:
                direction = "SELL"
            elif prior_low is not None and row["low"] < prior_low and row["close"] > prior_low and row["close"] > row["open"] and volume_ok:
                direction = "BUY"
        elif strategy == "opening_range_breakout":
            minutes = int(params["opening_range_minutes"])
            opening_high = row[f"or{minutes}_high"]
            opening_low = row[f"or{minutes}_low"]
            if row["elapsed_minutes"] < minutes or opening_high is None or opening_low is None:
                continue
            if previous["close"] <= opening_high < row["close"] and row["close"] > row[ema_key] and row[slope_key] > 0 and volume_ok:
                direction = "BUY"
            elif previous["close"] >= opening_low > row["close"] and row["close"] < row[ema_key] and row[slope_key] < 0 and volume_ok:
                direction = "SELL"
        elif strategy == "trend_pullback":
            tolerance = atr * 0.20
            support = max(float(row["vwap"]), float(row[ema_key]))
            resistance = min(float(row["vwap"]), float(row[ema_key]))
            if (
                row["close"] > row[ema_key]
                and row[slope_key] > 0
                and row["low"] <= support + tolerance
                and row["close"] > support
                and row["close"] > row["open"]
                and volume_ok
            ):
                direction = "BUY"
            elif (
                row["close"] < row[ema_key]
                and row[slope_key] < 0
                and row["high"] >= resistance - tolerance
                and row["close"] < resistance
                and row["close"] < row["open"]
                and volume_ok
            ):
                direction = "SELL"
        elif strategy == "range_reversal_poc_retest":
            poc = row["poc"]
            range_mode = abs(float(row["ema20"]) - float(row["ema50"])) <= atr * 0.50
            if poc is None or not range_mode:
                continue
            if row["low"] <= poc < row["close"] and row["close"] > row["open"] and volume_ok:
                direction = "BUY"
            elif row["high"] >= poc > row["close"] and row["close"] < row["open"] and volume_ok:
                direction = "SELL"

        if direction:
            candidates.append(
                {
                    "index": index,
                    "timestamp": row["timestamp"],
                    "day": row["day"],
                    "direction": direction,
                    "signal_close": float(row["close"]),
                    "signal_low": float(row["low"]),
                    "signal_high": float(row["high"]),
                    "atr": atr,
                }
            )
    return candidates


def _simulate_candidates(
    rows: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    allowed_dates: set[date],
    params: dict[str, Any],
    risk_config: dict[str, Any],
    instrument: dict[str, Any],
    max_trades_per_day: int,
) -> ResearchMetrics:
    selected = [candidate for candidate in candidates if candidate["day"] in allowed_dates]
    raw_by_day: dict[date, int] = defaultdict(int)
    for candidate in selected:
        raw_by_day[candidate["day"]] += 1

    capital = float(risk_config.get("capital", 100000))
    risk_percent = float(risk_config.get("risk_per_trade_percent", 0.5))
    point_value = float(instrument.get("point_value", 1) or 1)
    active_exit_index = -1
    cooldown_until: datetime | None = None
    daily_trades: dict[date, int] = defaultdict(int)
    pnls: list[float] = []
    risk_rejected = overlap_skipped = cooldown_skipped = daily_limit_skipped = 0

    for candidate in selected:
        signal_index = int(candidate["index"])
        signal_time = candidate["timestamp"]
        day = candidate["day"]
        if active_exit_index >= signal_index:
            overlap_skipped += 1
            continue
        if cooldown_until is not None and signal_time < cooldown_until:
            cooldown_skipped += 1
            continue
        if daily_trades[day] >= max_trades_per_day:
            daily_limit_skipped += 1
            continue

        entry_index = signal_index + 1
        if entry_index >= len(rows) or rows[entry_index]["day"] not in allowed_dates:
            continue
        direction = candidate["direction"]
        raw_entry = float(rows[entry_index]["open"])
        adjusted_entry = raw_entry + SLIPPAGE_POINTS if direction == "BUY" else raw_entry - SLIPPAGE_POINTS
        atr_stop = float(candidate["atr"]) * float(params["atr_stop_multiplier"])
        if direction == "BUY":
            stop = min(float(candidate["signal_low"]), adjusted_entry - atr_stop)
            risk_distance = adjusted_entry - stop
            target = adjusted_entry + risk_distance * float(params["reward_risk"])
        else:
            stop = max(float(candidate["signal_high"]), adjusted_entry + atr_stop)
            risk_distance = stop - adjusted_entry
            target = adjusted_entry - risk_distance * float(params["reward_risk"])
        sizing = calculate_position_size(capital, risk_percent, adjusted_entry, stop, instrument)
        if sizing.quantity <= 0:
            risk_rejected += 1
            continue

        exit_index, raw_exit = _find_exit(
            rows,
            entry_index + 1,
            allowed_dates,
            direction,
            stop,
            target,
        )
        if exit_index is None:
            exit_index = max(index for index, row in enumerate(rows) if row["day"] in allowed_dates)
            raw_exit = float(rows[exit_index]["close"])
        adjusted_exit = raw_exit - SLIPPAGE_POINTS if direction == "BUY" else raw_exit + SLIPPAGE_POINTS
        move = adjusted_exit - adjusted_entry if direction == "BUY" else adjusted_entry - adjusted_exit
        net_pnl = move * sizing.quantity * point_value - COST_PER_TRADE
        pnls.append(net_pnl)
        active_exit_index = exit_index
        cooldown_until = signal_time + timedelta(seconds=SIGNAL_COOLDOWN_SECONDS)
        daily_trades[day] += 1

    wins = sum(1 for pnl in pnls if pnl > 0)
    losses = sum(1 for pnl in pnls if pnl < 0)
    gross_profit = sum(pnl for pnl in pnls if pnl > 0)
    gross_loss = abs(sum(pnl for pnl in pnls if pnl < 0))
    profit_factor = inf if gross_profit > 0 and gross_loss == 0 else gross_profit / gross_loss if gross_loss else 0.0
    net_pnl = sum(pnls)
    trades = len(pnls)
    return ResearchMetrics(
        trades=trades,
        wins=wins,
        losses=losses,
        win_rate=(wins / trades * 100) if trades else 0.0,
        net_pnl=net_pnl,
        profit_factor=profit_factor,
        expectancy=(net_pnl / trades) if trades else 0.0,
        max_drawdown=_max_drawdown(pnls),
        max_consecutive_losses=_max_consecutive_losses(pnls),
        raw_signals=len(selected),
        max_raw_signals_per_day=max(raw_by_day.values(), default=0),
        risk_rejected=risk_rejected,
        overlap_skipped=overlap_skipped,
        cooldown_skipped=cooldown_skipped,
        daily_limit_skipped=daily_limit_skipped,
    )


def _find_exit(
    rows: list[dict[str, Any]],
    start_index: int,
    allowed_dates: set[date],
    direction: str,
    stop: float,
    target: float,
) -> tuple[int | None, float]:
    """Use only bars after the delayed entry bar; stop wins ambiguous bars."""

    for index in range(start_index, len(rows)):
        row = rows[index]
        if row["day"] not in allowed_dates:
            if row["day"] > max(allowed_dates):
                break
            continue
        high = float(row["high"])
        low = float(row["low"])
        if direction == "BUY":
            if low <= stop:
                return index, stop
            if high >= target:
                return index, target
        else:
            if high >= stop:
                return index, stop
            if low <= target:
                return index, target
    return None, 0.0


def _has_overfitting_warning(
    train: ResearchMetrics,
    validation: ResearchMetrics,
    combined: ResearchMetrics,
) -> bool:
    if train.net_pnl > 0 and validation.net_pnl <= 0:
        return True
    if train.profit_factor >= MIN_APPROVAL_PF and validation.profit_factor < 1.0:
        return True
    if (
        train.profit_factor not in {0.0, inf}
        and validation.profit_factor not in {0.0, inf}
        and train.profit_factor >= 2.5
        and train.profit_factor > validation.profit_factor * 2.5
    ):
        return True
    return combined.trades < MIN_COMBINED_TRADES and combined.profit_factor > 3.0


def _build_result_row(
    strategy: str,
    symbol: str,
    params: dict[str, Any],
    train: ResearchMetrics,
    validation: ResearchMetrics,
    combined: ResearchMetrics,
    assessment: ResearchAssessment,
) -> dict[str, Any]:
    return {
        "strategy": strategy,
        "symbol": symbol,
        "variant_params": json.dumps(params, sort_keys=True, separators=(",", ":")),
        "train_trades": train.trades,
        "train_net_pnl": round(train.net_pnl, 2),
        "train_pf": _display_pf(train.profit_factor),
        "validation_trades": validation.trades,
        "validation_net_pnl": round(validation.net_pnl, 2),
        "validation_pf": _display_pf(validation.profit_factor),
        "combined_trades": combined.trades,
        "combined_win_rate": round(combined.win_rate, 2),
        "combined_net_pnl": round(combined.net_pnl, 2),
        "combined_pf": _display_pf(combined.profit_factor),
        "expectancy": round(combined.expectancy, 2),
        "max_drawdown": round(combined.max_drawdown, 2),
        "max_consecutive_losses": combined.max_consecutive_losses,
        "warnings": ";".join(assessment.warnings) if assessment.warnings else "NONE",
        "approval_candidate": assessment.approval_candidate,
        "recommendation": assessment.recommendation,
    }


def _ranking_key(row: dict[str, Any]) -> tuple[float, ...]:
    recommendation_rank = {"REJECTED": 0.0, "WATCHLIST": 1.0, "APPROVED_CANDIDATE": 2.0}
    return (
        recommendation_rank.get(str(row["recommendation"]), 0.0),
        _pf_number(row["validation_pf"]),
        float(row["validation_net_pnl"]),
        _pf_number(row["combined_pf"]),
        float(row["combined_net_pnl"]),
        float(row["combined_trades"]),
    )


def _format_research_report(
    rows: list[dict[str, Any]],
    symbols: list[str],
    train_dates: list[date],
    validation_dates: list[date],
    bar_files: list[Path],
    tick_files: list[Path],
    bar_count: int,
    tick_count: int,
) -> str:
    approved = [row for row in rows if _as_bool(row["approval_candidate"])]
    lines = [
        "STRATEGY RESEARCH LAB REPORT",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Manual execution only.",
        "",
        f"Symbols: {', '.join(symbols)}",
        f"Bar files: {len(bar_files)} | Bars: {bar_count}",
        f"Tick files inventoried: {len(tick_files)} | Ticks: {tick_count}",
        f"Train: {train_dates[0]} to {train_dates[-1]} ({len(train_dates)} trading dates)",
        f"Validation: {validation_dates[0]} to {validation_dates[-1]} ({len(validation_dates)} trading dates)",
        f"Total strategy variants tested: {len(rows)}",
        f"APPROVED candidates: {len(approved)}",
        "",
        "BEST RESULT PER SYMBOL",
    ]
    for symbol in symbols:
        best = next((row for row in rows if row["symbol"] == symbol), None)
        if best is None:
            continue
        lines.append(
            f"- {symbol}: {best['strategy']} {best['recommendation']} "
            f"train={best['train_net_pnl']}/{best['train_pf']} "
            f"validation={best['validation_net_pnl']}/{best['validation_pf']} "
            f"combined={best['combined_net_pnl']}/{best['combined_pf']} "
            f"trades={best['combined_trades']}"
        )
        lines.append(f"  Params: {best['variant_params']}")
        lines.append(f"  Warnings: {best['warnings']}")
    lines.extend(
        [
            "",
            "APPROVAL / ALERT STATUS",
            (
                "Research candidates passed the strict statistical gate, but isolated research IDs do not "
                "automatically authorize runtime WhatsApp alerts."
                if approved
                else "No research strategy passed strict approval. Monday WhatsApp strategy alerts remain blocked/research-only."
            ),
            "PAPER MODE ONLY. No broker orders were placed.",
        ]
    )
    return "\n".join(lines)


def _update_strategy_approval_report(base: Path, research_rows: list[dict[str, Any]]) -> None:
    output_dir = base / "reports" / "strategy_verification"
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "latest_strategy_approval_report.csv"
    txt_path = output_dir / "latest_strategy_approval_report.txt"
    existing: list[dict[str, Any]] = []
    if csv_path.exists():
        with csv_path.open(newline="", encoding="utf-8") as f:
            existing = [row for row in csv.DictReader(f) if not str(row.get("strategy", "")).startswith("research_lab__")]

    best_by_pair: dict[tuple[str, str], dict[str, Any]] = {}
    for row in research_rows:
        key = (str(row["symbol"]), str(row["strategy"]))
        if key not in best_by_pair:
            best_by_pair[key] = row
    strategy_codes = {
        "vwap_reclaim_long": "vrl",
        "vwap_rejection_short": "vrs",
        "failed_breakout_trap": "fbt",
        "opening_range_breakout": "orb",
        "trend_pullback": "tpb",
        "range_reversal_poc_retest": "rrp",
    }
    research_approval_rows: list[dict[str, Any]] = []
    for (symbol, strategy), row in best_by_pair.items():
        recommendation = str(row["recommendation"])
        status = "APPROVED" if recommendation == "APPROVED_CANDIDATE" else recommendation
        trades = int(row["combined_trades"])
        confidence = "HIGH" if trades >= 100 else "MEDIUM" if trades >= 30 else "LOW"
        research_approval_rows.append(
            {
                "strategy": f"research_lab__{symbol.lower().replace('-', '_')}__{strategy_codes[strategy]}",
                "symbol": symbol,
                "status": status,
                "confidence": confidence,
                "trades": trades,
                "win_rate": row["combined_win_rate"],
                "net_pnl": row["combined_net_pnl"],
                "profit_factor": row["combined_pf"],
                "expectancy": row["expectancy"],
                "warnings": row["warnings"],
                "final_recommendation": (
                    f"{strategy}: {recommendation}; isolated research ID does not authorize production alerts. "
                    f"Params={row['variant_params']}"
                ),
            }
        )
    _write_csv(csv_path, REPORT_COLUMNS, [*existing, *research_approval_rows])

    marker = "STRATEGY RESEARCH LAB UPDATE"
    prior_text = txt_path.read_text(encoding="utf-8") if txt_path.exists() else ""
    prior_text = prior_text.split(marker, 1)[0].rstrip()
    update_lines = [
        marker,
        "Research rows use isolated IDs and cannot unlock production strategy alerts.",
    ]
    for row in research_approval_rows:
        update_lines.append(
            f"- {row['symbol']} {row['final_recommendation']} status={row['status']} "
            f"trades={row['trades']} net_pnl={row['net_pnl']} pf={row['profit_factor']}"
        )
    txt_path.write_text(prior_text + "\n\n" + "\n".join(update_lines) + "\n", encoding="utf-8")


def _count_production_approvals(base: Path) -> int:
    path = base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv"
    if not path.exists():
        return 0
    with path.open(newline="", encoding="utf-8") as f:
        return sum(
            1
            for row in csv.DictReader(f)
            if row.get("status") == "APPROVED" and not str(row.get("strategy", "")).startswith("research_lab__")
        )


def _max_drawdown(pnls: list[float]) -> float:
    equity = peak = drawdown = 0.0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        drawdown = min(drawdown, equity - peak)
    return drawdown


def _max_consecutive_losses(pnls: list[float]) -> int:
    maximum = current = 0
    for pnl in pnls:
        if pnl < 0:
            current += 1
            maximum = max(maximum, current)
        else:
            current = 0
    return maximum


def _ema(value: float, previous: float, period: int) -> float:
    alpha = 2.0 / (period + 1.0)
    return value * alpha + previous * (1.0 - alpha)


def _display_pf(value: float) -> float | str:
    return "inf" if value == inf else round(value, 2)


def _pf_number(value: Any) -> float:
    return inf if str(value).lower() == "inf" else float(value or 0.0)


def _coerce_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    return datetime.fromisoformat(text)


def _coerce_date(value: date | str) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def _as_bool(value: Any) -> bool:
    return value is True or str(value).strip().lower() == "true"


def _write_csv(path: Path, columns: list[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PAPER-only controlled strategy research lab.")
    parser.add_argument("--symbols", default="GOLD-I,SILVER-I")
    parser.add_argument("--bar-dir", default="data/historical/truedata/bars")
    parser.add_argument("--tick-dir", default="data/historical/truedata/ticks")
    parser.add_argument("--from-date")
    parser.add_argument("--to-date")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = run_strategy_research(
            symbols_text=args.symbols,
            bar_dir=args.bar_dir,
            tick_dir=args.tick_dir,
            from_date=args.from_date,
            to_date=args.to_date,
        )
    except (StrategyBacktestError, FileNotFoundError, ValueError) as exc:
        print(f"Strategy research failed safely: {exc}")
        print("Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false")
        return 1
    approved = sum(1 for row in result.rows if _as_bool(row["approval_candidate"]))
    print(f"Research approval candidates: {approved}")
    print(f"Production-approved strategies: {result.production_approved_count}")
    print("PAPER MODE ONLY. No broker orders were placed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
