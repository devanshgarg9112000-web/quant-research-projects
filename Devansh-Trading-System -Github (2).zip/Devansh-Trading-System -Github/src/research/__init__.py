"""PAPER-only strategy research tools."""
