from __future__ import annotations


def calculate_vwap(candles: list[dict]) -> list[dict]:
    """Calculate VWAP, the intraday fair value used by many institutions."""

    output: list[dict] = []
    cumulative_tp_volume = 0.0
    cumulative_volume = 0.0
    previous_vwap = None
    for candle in candles:
        typical_price = (candle["high"] + candle["low"] + candle["close"]) / 3
        tp_volume = typical_price * candle["volume"]
        cumulative_tp_volume += tp_volume
        cumulative_volume += candle["volume"]
        vwap = cumulative_tp_volume / cumulative_volume if cumulative_volume else typical_price
        enriched = dict(candle)
        enriched.update({
            "typical_price": typical_price,
            "tp_volume": tp_volume,
            "cumulative_tp_volume": cumulative_tp_volume,
            "cumulative_volume": cumulative_volume,
            "vwap": vwap,
            "vwap_slope": 0.0 if previous_vwap is None else vwap - previous_vwap,
            "distance_from_vwap": candle["close"] - vwap,
            "distance_from_vwap_percent": ((candle["close"] - vwap) / vwap * 100) if vwap else 0.0,
        })
        output.append(enriched)
        previous_vwap = vwap
    return output
