from __future__ import annotations


def calculate_cvd(delta_rows: list[dict]) -> list[dict]:
    cumulative = 0.0
    output: list[dict] = []
    for row in delta_rows:
        cumulative += row.get("delta", 0.0)
        enriched = dict(row)
        enriched["cvd"] = cumulative
        output.append(enriched)
    return output
