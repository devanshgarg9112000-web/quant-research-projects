from __future__ import annotations


def calculate_opening_range(candles: list[dict], minutes: int = 15, candle_minutes: int = 5) -> dict:
    count = max(1, minutes // candle_minutes)
    first = candles[:count]
    one = candles[:1]
    six = candles[:max(1, 30 // candle_minutes)]
    return {
        "first_5_high": max(c["high"] for c in one),
        "first_5_low": min(c["low"] for c in one),
        "first_15_high": max(c["high"] for c in candles[:3]),
        "first_15_low": min(c["low"] for c in candles[:3]),
        "first_30_high": max(c["high"] for c in six),
        "first_30_low": min(c["low"] for c in six),
        "opening_range_high": max(c["high"] for c in first),
        "opening_range_low": min(c["low"] for c in first),
    }
