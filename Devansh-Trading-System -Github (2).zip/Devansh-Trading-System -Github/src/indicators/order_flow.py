from __future__ import annotations

from .cluster import build_cluster_table
from .cvd import calculate_cvd
from .delta import calculate_delta_ticks


def analyze_order_flow(ticks: list[dict]) -> dict:
    delta_rows = calculate_delta_ticks(ticks)
    cvd_rows = calculate_cvd(delta_rows)
    clusters = build_cluster_table(ticks)
    total_volume = sum(t["ltq"] for t in ticks)
    total_delta = sum(r["delta"] for r in delta_rows)
    stacked_buy = any(r["stacked_buy_imbalance"] for r in clusters)
    stacked_sell = any(r["stacked_sell_imbalance"] for r in clusters)
    event = "UNCLEAR"
    if stacked_buy and total_delta > 0:
        event = "BUYER_TRAP"
    elif stacked_sell and total_delta < 0:
        event = "SELLER_TRAP"
    elif abs(total_delta) > total_volume * 0.60:
        event = "AGGRESSIVE_CONTINUATION"
    return {"delta_rows": delta_rows, "cvd_rows": cvd_rows, "clusters": clusters, "total_delta": total_delta, "event": event}
