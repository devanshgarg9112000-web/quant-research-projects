from __future__ import annotations


def detect_absorption(candles: list[dict], cluster_rows: list[dict], key_levels: dict) -> dict:
    last = candles[-1]
    support = key_levels.get("day_low_so_far", last["low"])
    resistance = key_levels.get("day_high_so_far", last["high"])
    sell_imbalance = any(r.get("sell_imbalance") for r in cluster_rows)
    buy_imbalance = any(r.get("buy_imbalance") for r in cluster_rows)
    bullish = sell_imbalance and last["low"] <= support + 80 and last["close"] > last["low"]
    bearish = buy_imbalance and last["high"] >= resistance - 80 and last["close"] < last["high"]
    return {"bullish_absorption": bullish, "bearish_absorption": bearish}
