from __future__ import annotations


def calculate_key_levels(candles: list[dict], previous: dict | None = None) -> dict:
    previous = previous or {}
    highs = [c["high"] for c in candles]
    lows = [c["low"] for c in candles]
    closes = [c["close"] for c in candles]
    day_open = candles[0]["open"]
    close = closes[-1]
    round_base = round(close / 100) * 100
    return {
        "day_open": day_open,
        "day_high_so_far": max(highs),
        "day_low_so_far": min(lows),
        "session_high": max(highs),
        "session_low": min(lows),
        "previous_day_high": previous.get("high", max(highs) + 100),
        "previous_day_low": previous.get("low", min(lows) - 100),
        "previous_day_close": previous.get("close", candles[0]["close"]),
        "round_numbers": [round_base - 100, round_base, round_base + 100],
        "recent_swing_high": max(highs[-5:]),
        "recent_swing_low": min(lows[-5:]),
    }
