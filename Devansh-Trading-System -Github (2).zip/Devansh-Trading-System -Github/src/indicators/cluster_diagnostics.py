from __future__ import annotations

import argparse
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from src.config_loader import load_configs
from src.data_feeds.tick_storage import append_daily_ticks, default_tick_file, save_normalized_ticks
from src.data_feeds.truedata_feed import TrueDataFeed


IMBALANCE_RATIO = 3.0
MIN_RELIABLE_TICKS = 50
MIN_BID_ASK_COVERAGE = 0.70
MCX_CLUSTER_SYMBOLS = {"GOLD-I", "SILVER-I"}


def classify_tick_aggression(tick: dict[str, Any]) -> str:
    """Classify aggressor side from LTP versus bid/ask.

    This is an estimate. A true footprint needs exchange-quality tick data with
    trade direction and depth updates at each price level.
    """

    bid = tick.get("bid")
    ask = tick.get("ask")
    ltp = tick.get("ltp")
    if ltp is None:
        return "UNKNOWN"
    if ask is not None and ltp >= ask:
        return "BUY"
    if bid is not None and ltp <= bid:
        return "SELL"
    return "UNKNOWN"


def bucket_ticks(ticks: list[dict[str, Any]], bucket_seconds: int) -> list[dict[str, Any]]:
    if not ticks:
        return []
    clean = sorted(ticks, key=lambda tick: tick["timestamp"])
    buckets: list[dict[str, Any]] = []
    bucket_start = clean[0]["timestamp"]
    bucket: list[dict[str, Any]] = []
    for tick in clean:
        if tick["timestamp"] >= bucket_start + timedelta(seconds=bucket_seconds):
            buckets.append({"start": bucket_start, "end": bucket_start + timedelta(seconds=bucket_seconds), "ticks": bucket})
            bucket_start = tick["timestamp"]
            bucket = []
        bucket.append(tick)
    if bucket:
        buckets.append({"start": bucket_start, "end": bucket_start + timedelta(seconds=bucket_seconds), "ticks": bucket})
    return buckets


def calculate_delta_cvd_by_candle(ticks: list[dict[str, Any]], bucket_seconds: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    cvd = 0.0
    for bucket in bucket_ticks(ticks, bucket_seconds):
        buy_volume = 0.0
        sell_volume = 0.0
        unknown_volume = 0.0
        for tick in bucket["ticks"]:
            volume = float(tick.get("ltq") or 0)
            side = classify_tick_aggression(tick)
            if side == "BUY":
                buy_volume += volume
            elif side == "SELL":
                sell_volume += volume
            else:
                unknown_volume += volume
        delta = buy_volume - sell_volume
        cvd += delta
        rows.append({
            "bucket_start": bucket["start"],
            "bucket_end": bucket["end"],
            "tick_count": len(bucket["ticks"]),
            "buy_volume": buy_volume,
            "sell_volume": sell_volume,
            "unknown_volume": unknown_volume,
            "delta": delta,
            "cvd": cvd,
        })
    return rows


def build_volume_at_price(ticks: list[dict[str, Any]], imbalance_ratio: float = IMBALANCE_RATIO) -> list[dict[str, Any]]:
    levels: dict[float, dict[str, Any]] = {}
    for tick in ticks:
        price = float(tick["ltp"])
        volume = float(tick.get("ltq") or 0)
        row = levels.setdefault(price, {
            "price": price,
            "total_volume": 0.0,
            "bid_volume_at_price": 0.0,
            "ask_volume_at_price": 0.0,
            "unknown_volume": 0.0,
        })
        row["total_volume"] += volume
        side = classify_tick_aggression(tick)
        if side == "BUY":
            row["ask_volume_at_price"] += volume
        elif side == "SELL":
            row["bid_volume_at_price"] += volume
        else:
            row["unknown_volume"] += volume
    output = []
    for row in sorted(levels.values(), key=lambda item: item["price"]):
        ask_volume = row["ask_volume_at_price"]
        bid_volume = row["bid_volume_at_price"]
        larger = max(ask_volume, bid_volume)
        smaller = min(ask_volume, bid_volume)
        ratio = larger / max(smaller, 1.0) if larger else 0.0
        row["imbalance_ratio"] = ratio
        row["buy_imbalance"] = ask_volume >= imbalance_ratio * max(bid_volume, 1.0)
        row["sell_imbalance"] = bid_volume >= imbalance_ratio * max(ask_volume, 1.0)
        row["classification"] = "ESTIMATED_FROM_LTP_VS_BID_ASK"
        output.append(row)
    return output


def find_stacked_imbalance_zones(volume_rows: list[dict[str, Any]], side: str, min_levels: int = 3) -> list[dict[str, Any]]:
    key = "buy_imbalance" if side == "BUY" else "sell_imbalance"
    zones: list[dict[str, Any]] = []
    current: list[dict[str, Any]] = []
    for row in volume_rows:
        if row.get(key):
            current.append(row)
            continue
        if len(current) >= min_levels:
            zones.append(_zone_from_rows(current, side))
        current = []
    if len(current) >= min_levels:
        zones.append(_zone_from_rows(current, side))
    return zones


def detect_absorption_zones(volume_rows: list[dict[str, Any]], ticks: list[dict[str, Any]]) -> list[str]:
    if not ticks or not volume_rows:
        return []
    last_price = float(ticks[-1]["ltp"])
    zones: list[str] = []
    buy_imbalances = [row for row in volume_rows if row["buy_imbalance"]]
    sell_imbalances = [row for row in volume_rows if row["sell_imbalance"]]
    if buy_imbalances:
        high_buy = max(row["price"] for row in buy_imbalances)
        if last_price < high_buy:
            zones.append(f"ESTIMATED bearish absorption: buy imbalance near {high_buy} did not hold; latest LTP {last_price}")
    if sell_imbalances:
        low_sell = min(row["price"] for row in sell_imbalances)
        if last_price > low_sell:
            zones.append(f"ESTIMATED bullish absorption: sell imbalance near {low_sell} did not continue; latest LTP {last_price}")
    return zones


def detect_exhaustion_signs(delta_rows: list[dict[str, Any]], ticks: list[dict[str, Any]]) -> list[str]:
    if len(delta_rows) < 2 or not ticks:
        return []
    signs: list[str] = []
    last = delta_rows[-1]
    previous = delta_rows[-2]
    latest_price = float(ticks[-1]["ltp"])
    previous_price = float(ticks[-2]["ltp"]) if len(ticks) >= 2 else latest_price
    if abs(last["delta"]) > 0 and abs(last["delta"]) >= abs(previous["delta"]) * 2 and latest_price == previous_price:
        signs.append("ESTIMATED exhaustion: strong latest delta with no LTP progress.")
    if last["unknown_volume"] > (last["buy_volume"] + last["sell_volume"]):
        signs.append("Data warning: latest candle has more unknown volume than classified bid/ask volume.")
    return signs


def classify_cluster_trap(volume_rows: list[dict[str, Any]], ticks: list[dict[str, Any]]) -> str:
    if not ticks or not volume_rows:
        return "INSUFFICIENT_DATA"
    last_price = float(ticks[-1]["ltp"])
    buy_levels = [row["price"] for row in volume_rows if row["buy_imbalance"]]
    sell_levels = [row["price"] for row in volume_rows if row["sell_imbalance"]]
    if buy_levels and last_price < max(buy_levels):
        return "ESTIMATED_BUYER_TRAP_POSSIBLE"
    if sell_levels and last_price > min(sell_levels):
        return "ESTIMATED_SELLER_TRAP_POSSIBLE"
    if buy_levels or sell_levels:
        return "IMBALANCE_PRESENT_NO_CONFIRMED_TRAP"
    return "NO_CLUSTER_TRAP_EVIDENCE"


def calculate_trap_strength(status: str, volume_rows: list[dict[str, Any]]) -> float:
    """Normalize estimated imbalance strength to 0..1 for PAPER signal filtering."""

    if status == "ESTIMATED_BUYER_TRAP_POSSIBLE":
        relevant = [float(row.get("imbalance_ratio") or 0.0) for row in volume_rows if row.get("buy_imbalance")]
    elif status == "ESTIMATED_SELLER_TRAP_POSSIBLE":
        relevant = [float(row.get("imbalance_ratio") or 0.0) for row in volume_rows if row.get("sell_imbalance")]
    else:
        relevant = []
    if not relevant:
        return 0.0
    return round(min(1.0, max(relevant) / (IMBALANCE_RATIO * 1.5)), 4)


def assess_data_sufficiency(ticks: list[dict[str, Any]]) -> tuple[bool, list[str]]:
    notes: list[str] = []
    if len(ticks) < MIN_RELIABLE_TICKS:
        notes.append(f"Only {len(ticks)} ticks; cluster analysis is weak below {MIN_RELIABLE_TICKS} ticks.")
    if ticks:
        bid_ask_ticks = sum(1 for tick in ticks if tick.get("bid") is not None and tick.get("ask") is not None)
        coverage = bid_ask_ticks / len(ticks)
        if coverage < MIN_BID_ASK_COVERAGE:
            notes.append(f"Bid/ask coverage {coverage:.2%}; reliable footprint needs cleaner bid/ask context.")
    else:
        notes.append("No ticks received.")
    notes.append("Volume-at-price and imbalance are ESTIMATED from LTP, LTQ, bid, and ask; not full exchange footprint depth.")
    return not any(note.startswith("Only") or note.startswith("Bid/ask") or note.startswith("No ticks") for note in notes), notes


def build_symbol_diagnostics(symbol: str, ticks: list[dict[str, Any]], bucket_seconds: int) -> dict[str, Any]:
    symbol_ticks = sorted([tick for tick in ticks if tick["symbol"] == symbol], key=lambda tick: tick["timestamp"])
    delta_rows = calculate_delta_cvd_by_candle(symbol_ticks, bucket_seconds)
    volume_rows = build_volume_at_price(symbol_ticks)
    reliable, sufficiency_notes = assess_data_sufficiency(symbol_ticks)
    bid_count = sum(1 for tick in symbol_ticks if tick.get("bid") is not None)
    ask_count = sum(1 for tick in symbol_ticks if tick.get("ask") is not None)
    trap_status = classify_cluster_trap(volume_rows, symbol_ticks)
    return {
        "symbol": symbol,
        "total_ticks": len(symbol_ticks),
        "first_tick_time": symbol_ticks[0]["timestamp"] if symbol_ticks else None,
        "last_tick_time": symbol_ticks[-1]["timestamp"] if symbol_ticks else None,
        "latest_ltp": symbol_ticks[-1]["ltp"] if symbol_ticks else None,
        "latest_ltq": symbol_ticks[-1].get("ltq") if symbol_ticks else None,
        "bid_ask_availability": f"{bid_count}/{ask_count} of {len(symbol_ticks)} ticks",
        "bucket_seconds": bucket_seconds,
        "candles_built": len(delta_rows),
        "delta_per_candle": delta_rows,
        "cvd_progression": [row["cvd"] for row in delta_rows],
        "volume_at_price": volume_rows,
        "buy_imbalance_levels": [row["price"] for row in volume_rows if row["buy_imbalance"]],
        "sell_imbalance_levels": [row["price"] for row in volume_rows if row["sell_imbalance"]],
        "stacked_imbalance_zones": find_stacked_imbalance_zones(volume_rows, "BUY") + find_stacked_imbalance_zones(volume_rows, "SELL"),
        "absorption_zones": detect_absorption_zones(volume_rows, symbol_ticks),
        "exhaustion_signs": detect_exhaustion_signs(delta_rows, symbol_ticks),
        "cluster_imbalance_trap_status": trap_status,
        "trap_strength": calculate_trap_strength(trap_status, volume_rows),
        "data_sufficient": reliable,
        "data_quality_notes": sufficiency_notes,
    }


def build_mcx_cluster_gate(diagnostics: dict[str, Any]) -> dict[str, Any]:
    """Translate estimated MCX cluster diagnostics into a paper-signal gate."""

    symbol = str(diagnostics.get("symbol") or "")
    status = str(diagnostics.get("cluster_imbalance_trap_status") or "INSUFFICIENT_DATA")
    data_sufficient = bool(diagnostics.get("data_sufficient"))
    base = {
        "applicable": symbol in MCX_CLUSTER_SYMBOLS,
        "symbol": symbol,
        "diagnostic_status": status,
        "data_sufficient": data_sufficient,
        "preferred_side": None,
        "gate_status": "NOT_APPLICABLE",
        "reason": f"{symbol or 'Symbol'} is not configured for the MCX cluster gate.",
        "execution_allowed": False,
    }
    if not base["applicable"]:
        return base
    if not data_sufficient:
        base.update({
            "gate_status": "BLOCKED_DATA_INSUFFICIENT",
            "reason": "MCX cluster gate blocked: diagnostic tick count or bid/ask coverage is insufficient.",
        })
        return base
    if status == "ESTIMATED_BUYER_TRAP_POSSIBLE":
        base.update({
            "preferred_side": "SELL",
            "gate_status": "READY_SELL_CONFIRMATION",
            "reason": "Reliable estimated buyer-trap diagnostic permits SELL candidates only; a strategy setup is still required.",
        })
        return base
    if status == "ESTIMATED_SELLER_TRAP_POSSIBLE":
        base.update({
            "preferred_side": "BUY",
            "gate_status": "READY_BUY_CONFIRMATION",
            "reason": "Reliable estimated seller-trap diagnostic permits BUY candidates only; a strategy setup is still required.",
        })
        return base
    base.update({
        "gate_status": "WAIT_NO_DIRECTIONAL_TRAP",
        "reason": f"MCX cluster gate is waiting: {status} does not provide a directional trap confirmation.",
    })
    return base


def evaluate_mcx_cluster_gate_for_side(gate: dict[str, Any], side: str) -> tuple[bool, str, str]:
    """Return whether a candidate side passes the PAPER-only MCX cluster gate."""

    if not gate.get("applicable"):
        return True, "MCX cluster gate not applicable.", "NOT_APPLICABLE"
    gate_status = str(gate.get("gate_status") or "BLOCKED")
    preferred_side = gate.get("preferred_side")
    if gate_status.startswith("READY_") and preferred_side == side:
        return True, f"MCX cluster gate PASS: {gate['diagnostic_status']} confirms {side}.", "PASS"
    if gate_status.startswith("READY_"):
        return False, (
            f"MCX cluster gate REJECT: {gate['diagnostic_status']} prefers "
            f"{preferred_side}, not candidate side {side}."
        ), "REJECT_SIDE_CONFLICT"
    return False, f"MCX cluster gate REJECT: {gate.get('reason', gate_status)}", gate_status


def format_diagnostics_report(diagnostics: list[dict[str, Any]]) -> str:
    lines = [
        "CLUSTER / FOOTPRINT / IMBALANCE DIAGNOSTICS",
        "Mode: PAPER diagnostics only",
        "Broker Orders: DISABLED",
        "Classification Note: ESTIMATED values are inferred from LTP vs bid/ask, not full exchange footprint depth.",
        "",
    ]
    for item in diagnostics:
        lines.extend([
            f"Symbol: {item['symbol']}",
            f"  Total Ticks: {item['total_ticks']}",
            f"  First Tick Time: {_fmt(item['first_tick_time'])}",
            f"  Last Tick Time: {_fmt(item['last_tick_time'])}",
            f"  Latest LTP: {_fmt(item['latest_ltp'])}",
            f"  Bid/Ask Availability: {item['bid_ask_availability']}",
            f"  Candle Bucket Seconds: {item['bucket_seconds']}",
            f"  Candles Built: {item['candles_built']}",
            f"  Data Sufficient For Reliable Cluster Analysis: {'YES' if item['data_sufficient'] else 'NO'}",
            "  Data Quality Notes:",
        ])
        lines.extend(f"    - {note}" for note in item["data_quality_notes"])
        lines.append("  Delta Per Candle / CVD Progression:")
        if item["delta_per_candle"]:
            for row in item["delta_per_candle"]:
                lines.append(
                    f"    - {row['bucket_start']} ticks={row['tick_count']} "
                    f"delta={row['delta']} cvd={row['cvd']} "
                    f"buy={row['buy_volume']} sell={row['sell_volume']} unknown={row['unknown_volume']}"
                )
        else:
            lines.append("    - NONE")
        lines.append("  Volume At Price (ESTIMATED):")
        if item["volume_at_price"]:
            for row in item["volume_at_price"]:
                lines.append(
                    f"    - price={row['price']} total={row['total_volume']} "
                    f"bid_volume={row['bid_volume_at_price']} ask_volume={row['ask_volume_at_price']} "
                    f"unknown={row['unknown_volume']} imbalance_ratio={row['imbalance_ratio']:.2f} "
                    f"buy_imbalance={row['buy_imbalance']} sell_imbalance={row['sell_imbalance']}"
                )
        else:
            lines.append("    - NONE")
        lines.extend([
            f"  Buy Imbalance Levels: {_fmt_list(item['buy_imbalance_levels'])}",
            f"  Sell Imbalance Levels: {_fmt_list(item['sell_imbalance_levels'])}",
            f"  Stacked Imbalance Zones: {_fmt_zones(item['stacked_imbalance_zones'])}",
            f"  Absorption Zones: {_fmt_list(item['absorption_zones'])}",
            f"  Exhaustion Signs: {_fmt_list(item['exhaustion_signs'])}",
            f"  Cluster Imbalance Trap Status: {item['cluster_imbalance_trap_status']}",
            "",
        ])
    lines.append("PAPER MODE ONLY. No broker orders were placed.")
    return "\n".join(lines)


def run_live_diagnostics(symbols_text: str, seconds: int, bucket_seconds: int, base_dir: Path | str = ".") -> int:
    base = Path(base_dir)
    configs = load_configs(base)
    settings = dict(configs["settings"])
    settings["enable_true_data"] = True
    settings["mode"] = "PAPER"
    settings["enable_live_trading"] = False
    symbols = [symbol.strip() for symbol in symbols_text.split(",") if symbol.strip()]
    if not symbols:
        print("Cluster diagnostics skipped: no symbols supplied.")
        return 1
    print("Cluster diagnostics PAPER mode. Broker orders disabled.")
    print("Collecting TrueData ticks for diagnostics only. Secrets are not printed.")
    feed = TrueDataFeed(settings, base, allow_network=True)
    ticks = feed.collect_live_ticks(symbols, seconds, echo=False)
    tick_path = save_normalized_ticks(ticks, default_tick_file(base))
    print(f"Normalized ticks saved: {tick_path}")
    daily_result = append_daily_ticks(ticks, base, source="TRUEDATA_CLUSTER_DIAGNOSTICS")
    print(
        "Daily tick recorder: "
        f"{daily_result['rows_written']} new rows across {daily_result['files_touched']} files"
    )
    diagnostics = [build_symbol_diagnostics(symbol, ticks, bucket_seconds) for symbol in symbols]
    report = format_diagnostics_report(diagnostics)
    report_dir = base / "reports" / "daily_trade_reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    path = report_dir / "latest_cluster_diagnostics.txt"
    path.write_text(report + "\n", encoding="utf-8")
    print(report)
    print(f"Cluster diagnostics saved: {path}")
    return 0


def _zone_from_rows(rows: list[dict[str, Any]], side: str) -> dict[str, Any]:
    return {
        "side": side,
        "from_price": rows[0]["price"],
        "to_price": rows[-1]["price"],
        "levels": [row["price"] for row in rows],
    }


def _fmt(value: Any) -> str:
    return "N/A" if value is None else str(value)


def _fmt_list(values: list[Any]) -> str:
    return "NONE" if not values else ", ".join(str(value) for value in values)


def _fmt_zones(zones: list[dict[str, Any]]) -> str:
    if not zones:
        return "NONE"
    return "; ".join(f"{zone['side']} {zone['from_price']}->{zone['to_price']} levels={zone['levels']}" for zone in zones)


def main() -> int:
    parser = argparse.ArgumentParser(description="TrueData cluster/footprint/imbalance diagnostics.")
    parser.add_argument("--symbols", required=True, help="Comma-separated TrueData symbols, e.g. GOLD-I,SILVER-I.")
    parser.add_argument("--seconds", type=int, default=300)
    parser.add_argument("--bucket-seconds", type=int, default=15)
    args = parser.parse_args()
    return run_live_diagnostics(args.symbols, args.seconds, args.bucket_seconds)


if __name__ == "__main__":
    raise SystemExit(main())
