from __future__ import annotations


def calculate_volume_profile(candles: list[dict], bin_size: float = 20.0) -> dict:
    """Approximate candle-based volume profile.

    Accurate Volume Profile requires tick-level data. This MVP distributes
    candle volume across the candle range only for safe demonstration.
    """

    profile: dict[float, float] = {}
    for candle in candles:
        low = int(candle["low"] // bin_size) * bin_size
        high = int(candle["high"] // bin_size) * bin_size
        levels = []
        price = low
        while price <= high:
            levels.append(float(price))
            price += bin_size
        share = candle["volume"] / max(len(levels), 1)
        for level in levels:
            profile[level] = profile.get(level, 0.0) + share
    if not profile:
        return {"poc": 0.0, "vah": 0.0, "val": 0.0, "hvn_zones": [], "lvn_zones": [], "value_area_range": 0.0, "profile": {}}
    poc = max(profile, key=profile.get)
    total = sum(profile.values())
    running = 0.0
    value_levels: list[float] = []
    for level, volume in sorted(profile.items(), key=lambda item: item[1], reverse=True):
        value_levels.append(level)
        running += volume
        if running >= total * 0.70:
            break
    vah = max(value_levels)
    val = min(value_levels)
    avg_volume = total / len(profile)
    return {
        "poc": poc,
        "vah": vah,
        "val": val,
        "hvn_zones": [level for level, volume in profile.items() if volume >= avg_volume * 1.2],
        "lvn_zones": [level for level, volume in profile.items() if volume <= avg_volume * 0.8],
        "value_area_range": vah - val,
        "profile": profile,
    }
