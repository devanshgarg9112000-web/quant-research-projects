from __future__ import annotations

from .delta import calculate_delta_ticks


def build_cluster_table(ticks: list[dict], price_step: float = 5.0, imbalance_ratio: float = 3.0) -> list[dict]:
    """Build a simple footprint-like cluster table from sample tick data."""

    grouped: dict[float, dict] = {}
    for tick in calculate_delta_ticks(ticks):
        price = round(tick["ltp"] / price_step) * price_step
        row = grouped.setdefault(price, {"price": price, "buy_volume_at_price": 0.0, "sell_volume_at_price": 0.0})
        row["buy_volume_at_price"] += tick["buy_volume"]
        row["sell_volume_at_price"] += tick["sell_volume"]
    rows = []
    for row in sorted(grouped.values(), key=lambda item: item["price"]):
        buy = row["buy_volume_at_price"]
        sell = row["sell_volume_at_price"]
        row["delta_at_price"] = buy - sell
        row["total_volume_at_price"] = buy + sell
        row["buy_imbalance"] = buy >= imbalance_ratio * max(sell, 1)
        row["sell_imbalance"] = sell >= imbalance_ratio * max(buy, 1)
        row["stacked_buy_imbalance"] = False
        row["stacked_sell_imbalance"] = False
        rows.append(row)
    for i in range(len(rows) - 2):
        block = rows[i:i + 3]
        if all(r["buy_imbalance"] for r in block):
            for r in block:
                r["stacked_buy_imbalance"] = True
        if all(r["sell_imbalance"] for r in block):
            for r in block:
                r["stacked_sell_imbalance"] = True
    return rows
