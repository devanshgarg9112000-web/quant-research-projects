from __future__ import annotations


def find_support_resistance(candles: list[dict], lookback: int = 2) -> dict:
    swing_highs: list[float] = []
    swing_lows: list[float] = []
    for i in range(lookback, len(candles) - lookback):
        window = candles[i - lookback:i + lookback + 1]
        if candles[i]["high"] == max(c["high"] for c in window):
            swing_highs.append(candles[i]["high"])
        if candles[i]["low"] == min(c["low"] for c in window):
            swing_lows.append(candles[i]["low"])
    return {"resistance_zones": swing_highs[-5:], "support_zones": swing_lows[-5:]}
