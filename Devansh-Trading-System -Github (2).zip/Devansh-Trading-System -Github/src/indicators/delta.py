from __future__ import annotations


def calculate_delta_ticks(ticks: list[dict]) -> list[dict]:
    """Classify aggressive buy/sell volume from sample bid/ask ticks."""

    rows: list[dict] = []
    cumulative_delta = 0.0
    for tick in ticks:
        buy_volume = 0.0
        sell_volume = 0.0
        bid = tick.get("bid")
        ask = tick.get("ask")
        if ask is not None and tick["ltp"] >= ask:
            buy_volume = tick["ltq"]
        elif bid is not None and tick["ltp"] <= bid:
            sell_volume = tick["ltq"]
        delta = buy_volume - sell_volume
        cumulative_delta += delta
        row = dict(tick)
        row.update({"buy_volume": buy_volume, "sell_volume": sell_volume, "delta": delta, "cumulative_delta": cumulative_delta})
        rows.append(row)
    return rows
