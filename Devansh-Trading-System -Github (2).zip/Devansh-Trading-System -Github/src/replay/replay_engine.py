from __future__ import annotations

from collections import defaultdict
from typing import Any


class ReplayEngine:
    """Small helpers for deterministic saved-tick PAPER replay."""

    def step(self, candles: list[dict], index: int) -> dict:
        return candles[index]


def parse_replay_symbols(symbols_text: str | None) -> list[str]:
    """Parse a comma-separated symbol filter while preserving user order."""

    symbols: list[str] = []
    for value in (symbols_text or "").split(","):
        symbol = value.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def filter_replay_ticks(ticks: list[dict[str, Any]], symbols: list[str]) -> list[dict[str, Any]]:
    """Return only requested symbols; an empty filter keeps the whole session."""

    if not symbols:
        return list(ticks)
    allowed = set(symbols)
    return [tick for tick in ticks if tick.get("symbol") in allowed]


def group_replay_ticks(ticks: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Group ticks by symbol and keep timestamp order inside each group."""

    grouped: defaultdict[str, list[dict[str, Any]]] = defaultdict(list)
    for tick in ticks:
        symbol = str(tick.get("symbol") or "")
        if symbol:
            grouped[symbol].append(tick)
    return {
        symbol: sorted(symbol_ticks, key=lambda tick: tick["timestamp"])
        for symbol, symbol_ticks in grouped.items()
    }
