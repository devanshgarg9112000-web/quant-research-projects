from __future__ import annotations

import csv
from pathlib import Path

from src.models.signal import Signal
from src.models.trade import Trade


class TradeJournal:
    def __init__(self, base_dir: Path | str = "."):
        self.base = Path(base_dir)
        (self.base / "logs").mkdir(exist_ok=True)
        self.signals_path = self.base / "logs" / "signals.csv"
        self.trades_path = self.base / "logs" / "trades.csv"
        self._ensure_headers()

    def _ensure_headers(self) -> None:
        if not self.signals_path.exists():
            with self.signals_path.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["timestamp", "symbol", "strategy", "side", "entry", "stop", "target", "rr", "score", "market_mode", "reason"])
        if not self.trades_path.exists():
            with self.trades_path.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["trade_id", "symbol", "strategy", "side", "entry_time", "entry", "stop", "target", "exit_time", "exit", "qty", "pnl", "r", "status", "reason"])

    def log_signal(self, signal: Signal) -> None:
        with self.signals_path.open("a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([signal.timestamp, signal.symbol, signal.strategy_name, signal.side, signal.entry_price, signal.stop_loss, signal.target_price, signal.reward_risk, signal.score, signal.market_mode, signal.reason])

    def log_trade(self, trade: Trade) -> None:
        with self.trades_path.open("a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([trade.trade_id, trade.symbol, trade.strategy_name, trade.side, trade.entry_time, trade.entry_price, trade.stop_loss, trade.target_price, trade.exit_time, trade.exit_price, trade.quantity, trade.pnl, trade.r_multiple, trade.status, trade.reason])
