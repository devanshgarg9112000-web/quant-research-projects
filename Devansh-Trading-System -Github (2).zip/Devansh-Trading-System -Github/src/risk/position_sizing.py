from __future__ import annotations

from dataclasses import dataclass
from math import floor


@dataclass(frozen=True)
class PositionSizingResult:
    quantity: int
    raw_quantity: int
    allowed_risk_amount: float
    stop_distance: float
    point_value: float
    risk_per_unit: float
    min_qty: int
    lot_size: int
    estimated_risk_amount: float
    rejection_reason: str | None = None


def calculate_position_size(
    capital: float,
    risk_percent: float,
    entry: float,
    stop: float,
    instrument: dict | None = None,
) -> PositionSizingResult:
    """Calculate risk-capped quantity with point-value and lot constraints."""

    instrument = instrument or {}
    point_value = _positive_float(instrument.get("point_value"), 1.0)
    min_qty = _positive_int(instrument.get("min_qty"), 1)
    lot_size = _positive_int(instrument.get("lot_size"), 1)
    allowed_risk = max(float(capital), 0.0) * max(float(risk_percent), 0.0) / 100
    stop_distance = abs(float(entry) - float(stop))
    risk_per_unit = stop_distance * point_value
    minimum_trade_qty = ((min_qty + lot_size - 1) // lot_size) * lot_size

    if risk_per_unit <= 0:
        return PositionSizingResult(
            0, 0, allowed_risk, stop_distance, point_value, risk_per_unit,
            min_qty, lot_size, 0.0, "risk per unit must be positive",
        )

    raw_quantity = floor(allowed_risk / risk_per_unit)
    quantity = (raw_quantity // lot_size) * lot_size
    minimum_quantity_risk = minimum_trade_qty * risk_per_unit
    if raw_quantity < minimum_trade_qty or minimum_quantity_risk > allowed_risk:
        exchange = str(instrument.get("exchange") or "").upper()
        market_label = "MCX " if exchange == "MCX" else ""
        reason = (
            f"risk amount too small for minimum {market_label}quantity: "
            f"minimum quantity {minimum_trade_qty} risks {minimum_quantity_risk:.2f}, "
            f"above allowed risk {allowed_risk:.2f}"
        )
        return PositionSizingResult(
            0, raw_quantity, allowed_risk, stop_distance, point_value, risk_per_unit,
            min_qty, lot_size, 0.0, reason,
        )

    estimated_risk = quantity * risk_per_unit
    return PositionSizingResult(
        quantity, raw_quantity, allowed_risk, stop_distance, point_value, risk_per_unit,
        min_qty, lot_size, estimated_risk,
    )


def calculate_quantity(
    capital: float,
    risk_percent: float,
    entry: float,
    stop: float,
    instrument: dict | None = None,
) -> int:
    """Backward-compatible quantity-only wrapper."""

    return calculate_position_size(capital, risk_percent, entry, stop, instrument).quantity


def _positive_float(value, default: float) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def _positive_int(value, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default
