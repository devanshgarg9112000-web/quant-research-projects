from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DailyLimitState:
    trades_today: int = 0
    realized_pnl: float = 0.0
    consecutive_losses: int = 0
