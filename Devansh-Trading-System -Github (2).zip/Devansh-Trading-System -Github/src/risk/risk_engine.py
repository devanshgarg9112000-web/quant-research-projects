from __future__ import annotations

import os
from dataclasses import dataclass

from src.models.signal import Signal
from .daily_limits import DailyLimitState
from .kill_switch import KillSwitch
from .position_sizing import calculate_position_size


@dataclass
class RiskDecision:
    approved: bool
    quantity: int
    risk_amount: float
    reasons: list[str]
    sizing: dict


class RiskEngine:
    """Safety-first risk validation before any paper or live execution."""

    def __init__(
        self,
        risk_config: dict,
        settings: dict,
        state: DailyLimitState | None = None,
        kill_switch: KillSwitch | None = None,
        instruments: dict | None = None,
    ):
        self.risk_config = risk_config
        self.settings = settings
        self.state = state or DailyLimitState()
        self.kill_switch = kill_switch or KillSwitch()
        self.instruments = instruments or {}

    def validate_signal(self, signal: Signal, mode: str | None = None, data_quality_ok: bool = True, spread_percent: float = 0.0) -> RiskDecision:
        reasons: list[str] = []
        mode = mode or self.settings.get("mode", "PAPER")
        if self.kill_switch.active:
            reasons.append("Kill switch is active.")
        if not data_quality_ok:
            reasons.append("Data quality guard failed.")
        if signal.side == "BUY" and not self.risk_config.get("allow_long_trades", True):
            reasons.append("Long trades are disabled.")
        if signal.side == "SELL" and not self.risk_config.get("allow_short_trades", True):
            reasons.append("Short trades are disabled.")
        if signal.reward_risk < float(self.risk_config.get("min_reward_risk", 2.0)):
            reasons.append("Reward-risk below minimum.")
        if signal.side == "BUY" and signal.stop_loss >= signal.entry_price:
            reasons.append("BUY stop loss must be below entry.")
        if signal.side == "SELL" and signal.stop_loss <= signal.entry_price:
            reasons.append("SELL stop loss must be above entry.")
        if self.state.trades_today >= int(self.risk_config.get("max_trades_per_day", 3)):
            reasons.append("Max trades per day breached.")
        capital = float(self.risk_config.get("capital", 100000))
        max_loss = capital * float(self.risk_config.get("max_daily_loss_percent", 1.5)) / 100
        if self.state.realized_pnl <= -max_loss:
            reasons.append("Daily loss limit breached.")
        if self.state.consecutive_losses >= int(self.risk_config.get("max_consecutive_losses", 2)):
            reasons.append("Max consecutive losses breached.")
        if spread_percent > float(self.risk_config.get("max_spread_percent", 0.25)):
            reasons.append("Spread too wide.")
        live_env = os.getenv("ENABLE_LIVE_TRADING", "false").lower() == "true"
        live_allowed = bool(self.risk_config.get("allow_live_trading")) and bool(self.settings.get("enable_live_trading")) and live_env
        if mode == "LIVE" and not live_allowed:
            reasons.append("Live trading blocked by default safety gates.")
        risk_percent = float(self.risk_config.get("risk_per_trade_percent", 0.5))
        instrument = self.instruments.get(signal.symbol, {})
        sizing_result = calculate_position_size(
            capital,
            risk_percent,
            signal.entry_price,
            signal.stop_loss,
            instrument,
        )
        if sizing_result.quantity <= 0:
            reasons.append(sizing_result.rejection_reason or "position sizing rejected without a positive quantity")
        sizing = {
            "symbol": signal.symbol,
            "account_capital": capital,
            "risk_per_trade_pct": risk_percent,
            "allowed_risk_amount": round(sizing_result.allowed_risk_amount, 2),
            "entry": signal.entry_price,
            "stop_loss": signal.stop_loss,
            "stop_distance": round(sizing_result.stop_distance, 2),
            "point_value": sizing_result.point_value,
            "risk_per_unit": round(sizing_result.risk_per_unit, 2),
            "min_qty": sizing_result.min_qty,
            "lot_size": sizing_result.lot_size,
            "raw_quantity": sizing_result.raw_quantity,
            "calculated_qty": sizing_result.quantity,
            "estimated_risk_amount": round(sizing_result.estimated_risk_amount, 2),
            "rejection_reason": sizing_result.rejection_reason,
            "exchange": instrument.get("exchange", "UNSPECIFIED"),
            "instrument_type": instrument.get("instrument_type", "UNSPECIFIED"),
            "execution_allowed": False,
        }
        return RiskDecision(
            not reasons,
            sizing_result.quantity,
            round(sizing_result.estimated_risk_amount, 2),
            reasons,
            sizing,
        )
