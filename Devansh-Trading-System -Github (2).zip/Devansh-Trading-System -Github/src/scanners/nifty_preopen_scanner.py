from __future__ import annotations

import argparse
import csv
from datetime import date, datetime, timedelta
from typing import Any
from pathlib import Path

from src.brokers.kite_broker import KiteBroker
from src.config_loader import load_yaml
from src.options.black_scholes import black_scholes_price
from src.options.implied_volatility import implied_volatility
from src.options.option_chain import (
    filter_nifty_option_symbols,
    get_available_expiries,
    get_instrument_expiry,
    get_instrument_strike,
    normalize_expiry,
    select_strikes_around_atm,
)
from src.strategies.opening_option_mispricing import (
    MODEL_WARNING_MESSAGE,
    build_option_mispricing_diagnostics,
    calculate_time_to_expiry_years,
    detect_model_reference_warning_details,
    scan_opening_option_mispricing,
)


DEFAULT_CONFIG = {
    "enabled": False,
    "underlying": "NIFTY",
    "strikes_around_atm": 10,
    "min_mispricing_pct": 15,
    "min_depth_quantity": 50,
    "min_bid_qty": 50,
    "min_ask_qty": 50,
    "max_spread_pct": 20,
    "default_iv": 0.18,
    "risk_free_rate": 0.065,
    "max_signals": 10,
    "dry_run_only": True,
    "tick_size": 0.05,
    "suggested_limit_offset_ticks": 1,
    "opening_spike_planner": True,
}
QUOTE_SOURCE_SAMPLE = "SAMPLE MOCK"
QUOTE_SOURCE_KITE = "KITE READ-ONLY"
KITE_UNAVAILABLE_MESSAGE = "Kite read-only quotes unavailable. Run Kite login/read-only setup first, or rerun without --use-kite-quotes for sample mode."
SCANNER_REPORT_DIR = Path("reports") / "scanner_reports"
SCANNER_REPORT_TXT = "latest_nifty_preopen_scanner_report.txt"
SCANNER_REPORT_CSV = "latest_nifty_preopen_scanner_report.csv"
SCANNER_CSV_COLUMNS = [
    "symbol",
    "option_type",
    "strike",
    "expiry",
    "fair_price",
    "best_bid",
    "best_ask",
    "spread_pct",
    "mispricing_pct",
    "suggested_action",
    "confidence",
    "visible_match_price",
    "visible_match_side",
    "suggested_limit_price",
    "suggested_limit_rule",
    "fair_exit_price",
    "expected_gross_edge_points",
    "expected_gross_edge_pct",
    "tick_size",
    "max_adverse_price_note",
    "exit_plan",
    "planner_note",
    "execution_allowed",
    "hedge_required",
    "risk_note",
    "reason",
    "dry_run",
]


class KiteQuoteUnavailable(RuntimeError):
    """Raised when read-only Kite quotes cannot be loaded safely."""


def run_scanner(
    underlying: str,
    spot: float,
    previous_close: float,
    expiry: str,
    default_iv: float,
    use_kite_quotes: bool = False,
    strikes_around_atm: int | None = None,
    exchange: str = "NFO",
    base_dir: Path | str = ".",
) -> list[dict]:
    result = run_scanner_full(
        underlying=underlying,
        spot=spot,
        previous_close=previous_close,
        expiry=expiry,
        default_iv=default_iv,
        use_kite_quotes=use_kite_quotes,
        strikes_around_atm=strikes_around_atm,
        exchange=exchange,
        base_dir=base_dir,
    )
    return result["rows"]


def run_scanner_with_metadata(
    underlying: str,
    spot: float,
    previous_close: float,
    expiry: str | None,
    default_iv: float,
    use_kite_quotes: bool = False,
    strikes_around_atm: int | None = None,
    exchange: str = "NFO",
    base_dir: Path | str = ".",
) -> tuple[list[dict], str]:
    result = run_scanner_full(
        underlying=underlying,
        spot=spot,
        previous_close=previous_close,
        expiry=expiry,
        default_iv=default_iv,
        use_kite_quotes=use_kite_quotes,
        strikes_around_atm=strikes_around_atm,
        exchange=exchange,
        base_dir=base_dir,
    )
    return result["rows"], result["resolved_expiry"]


def run_scanner_full(
    underlying: str,
    spot: float,
    previous_close: float,
    expiry: str | None,
    default_iv: float,
    use_kite_quotes: bool = False,
    strikes_around_atm: int | None = None,
    exchange: str = "NFO",
    base_dir: Path | str = ".",
    auto_spot: bool = False,
    spot_symbol: str = "NSE:NIFTY 50",
    future_reference: str = "auto",
    max_model_warning_ratio: float = 0.35,
    suppress_signals_on_model_warning: bool = True,
) -> dict:
    config = _load_config(base_dir)
    resolved_expiry = expiry or ""
    spot_used = float(spot)
    spot_source = "MANUAL"
    spot_warning = None
    if use_kite_quotes and auto_spot:
        auto_value, spot_warning = fetch_kite_spot_reference(spot_symbol, base_dir=base_dir)
        if auto_value is not None:
            spot_used = auto_value
            spot_source = "KITE READ-ONLY"
    if use_kite_quotes:
        snapshots, resolved_expiry = resolve_kite_option_quote_snapshots(
            underlying=underlying,
            spot=spot_used,
            expiry=expiry,
            strikes_around_atm=int(strikes_around_atm if strikes_around_atm is not None else config.get("strikes_around_atm", DEFAULT_CONFIG["strikes_around_atm"])),
            exchange=exchange,
            base_dir=base_dir,
        )
    else:
        if not resolved_expiry or str(resolved_expiry).strip().lower() == "auto":
            resolved_expiry = (date.today() + timedelta(days=7)).isoformat()
        snapshots = build_sample_option_quote_snapshots(
            underlying=underlying,
            spot=spot_used,
            expiry=resolved_expiry,
            default_iv=default_iv,
            risk_free_rate=float(config.get("risk_free_rate", DEFAULT_CONFIG["risk_free_rate"])),
        )
    risk_free_rate = float(config.get("risk_free_rate", DEFAULT_CONFIG["risk_free_rate"]))
    min_mispricing_pct = float(config.get("min_mispricing_pct", DEFAULT_CONFIG["min_mispricing_pct"]))
    min_depth_quantity = int(config.get("min_depth_quantity", DEFAULT_CONFIG["min_depth_quantity"]))
    min_bid_qty = int(config.get("min_bid_qty", min_depth_quantity))
    min_ask_qty = int(config.get("min_ask_qty", min_depth_quantity))
    max_spread_pct = float(config.get("max_spread_pct", DEFAULT_CONFIG["max_spread_pct"]))
    tick_size = float(config.get("tick_size", DEFAULT_CONFIG["tick_size"]))
    suggested_limit_offset_ticks = int(config.get("suggested_limit_offset_ticks", DEFAULT_CONFIG["suggested_limit_offset_ticks"]))
    initial_diagnostics = build_option_mispricing_diagnostics(
        underlying_symbol=underlying,
        spot_reference=spot_used,
        previous_close=previous_close,
        option_quote_snapshots=snapshots,
        expiry=resolved_expiry,
        risk_free_rate=risk_free_rate,
        default_iv=default_iv,
        max_spread_pct=max_spread_pct,
    )
    atm_iv = calculate_atm_implied_ivs(initial_diagnostics, spot_used, resolved_expiry, risk_free_rate)
    iv_selection = select_effective_iv(
        ce_iv=atm_iv["ce_iv"],
        pe_iv=atm_iv["pe_iv"],
        default_iv=default_iv,
        prefer_market_iv=use_kite_quotes,
    )
    effective_iv = iv_selection["effective_iv"]
    diagnostics = build_option_mispricing_diagnostics(
        underlying_symbol=underlying,
        spot_reference=spot_used,
        previous_close=previous_close,
        option_quote_snapshots=snapshots,
        expiry=resolved_expiry,
        risk_free_rate=risk_free_rate,
        default_iv=effective_iv,
        max_spread_pct=max_spread_pct,
    )
    rows = scan_opening_option_mispricing(
        underlying_symbol=underlying,
        spot_reference=spot_used,
        previous_close=previous_close,
        option_quote_snapshots=snapshots,
        expiry=resolved_expiry,
        risk_free_rate=risk_free_rate,
        default_iv=effective_iv,
        min_mispricing_pct=min_mispricing_pct,
        min_depth_quantity=min_depth_quantity,
        min_bid_qty=min_bid_qty,
        min_ask_qty=min_ask_qty,
        max_spread_pct=max_spread_pct,
        max_signals=int(config.get("max_signals", DEFAULT_CONFIG["max_signals"])),
        tick_size=tick_size,
        suggested_limit_offset_ticks=suggested_limit_offset_ticks,
    )
    warning_details = detect_model_reference_warning_details(
        diagnostics,
        max_model_warning_ratio=max_model_warning_ratio,
        min_mispricing_pct=min_mispricing_pct,
        market_iv_available=iv_selection["source"] == "MARKET IMPLIED",
    )
    warning_reasons = list(warning_details["reasons"])
    if use_kite_quotes and iv_selection["source"] != "MARKET IMPLIED":
        warning_reasons.append("missing IV")
    if calculate_time_to_expiry_years(resolved_expiry) <= 0:
        warning_reasons.append("expiry/time issue")
    warning_reasons = list(dict.fromkeys(warning_reasons))
    warning = MODEL_WARNING_MESSAGE if warning_reasons else None
    suppressed = bool(warning and suppress_signals_on_model_warning)
    return {
        "rows": [] if suppressed else rows,
        "raw_rows": rows,
        "diagnostics": diagnostics,
        "resolved_expiry": resolved_expiry,
        "spot_used": spot_used,
        "spot_source": spot_source,
        "spot_symbol": spot_symbol if spot_source == "KITE READ-ONLY" else None,
        "spot_warning": spot_warning,
        "model_status": "WARNING" if warning else "OK",
        "model_warning": warning,
        "suppressed": suppressed,
        "suppressed_count": len(rows) if suppressed else 0,
        "approx_atm_ce_iv": atm_iv["ce_iv"],
        "approx_atm_pe_iv": atm_iv["pe_iv"],
        "effective_iv_used": effective_iv,
        "default_iv_input": float(default_iv),
        "iv_source": iv_selection["source"],
        "warning_reason": ", ".join(warning_reasons),
        "active_filters": {
            "min_bid_qty": min_bid_qty,
            "min_ask_qty": min_ask_qty,
            "max_spread_pct": max_spread_pct,
            "min_mispricing_pct": min_mispricing_pct,
            "tick_size": tick_size,
            "suggested_limit_offset_ticks": suggested_limit_offset_ticks,
            "opening_spike_planner": bool(config.get("opening_spike_planner", DEFAULT_CONFIG["opening_spike_planner"])),
        },
        "future_reference": future_reference,
    }


def build_sample_option_quote_snapshots(underlying: str, spot: float, expiry: str, default_iv: float, risk_free_rate: float) -> list[dict]:
    atm = round(float(spot) / 50.0) * 50.0
    expiry_label = _expiry_label(expiry)
    call_symbol = f"{underlying}{expiry_label}{int(atm)}CE"
    put_symbol = f"{underlying}{expiry_label}{int(atm)}PE"
    time_to_expiry = max(_sample_time_to_expiry(expiry), 1 / 365.0)
    fair_call = max(black_scholes_price(spot, atm, time_to_expiry, risk_free_rate, default_iv, "CALL"), 1.0)
    fair_put = max(black_scholes_price(spot, atm, time_to_expiry, risk_free_rate, default_iv, "PUT"), 1.0)
    return [
        {
            "symbol": call_symbol,
            "best_bid": round(fair_call * 1.25, 2),
            "best_ask": round(fair_call * 1.34, 2),
            "bid_qty": 150,
            "ask_qty": 200,
        },
        {
            "symbol": put_symbol,
            "best_bid": round(fair_put * 0.70, 2),
            "best_ask": round(fair_put * 0.78, 2),
            "bid_qty": 180,
            "ask_qty": 160,
        },
    ]


def build_kite_option_quote_snapshots(
    underlying: str,
    spot: float,
    expiry: str,
    strikes_around_atm: int,
    exchange: str = "NFO",
    base_dir: Path | str = ".",
) -> list[dict]:
    snapshots, _resolved_expiry = resolve_kite_option_quote_snapshots(underlying, spot, expiry, strikes_around_atm, exchange, base_dir)
    return snapshots


def resolve_kite_option_quote_snapshots(
    underlying: str,
    spot: float,
    expiry: str | None,
    strikes_around_atm: int,
    exchange: str = "NFO",
    base_dir: Path | str = ".",
) -> tuple[list[dict], str]:
    broker = KiteBroker(base_dir=base_dir)
    instruments = _load_kite_nifty_instruments(broker, exchange)
    available_expiries = get_available_expiries(instruments)
    resolved_expiry = _resolve_requested_expiry(expiry, available_expiries)
    selected = filter_nifty_option_symbols(instruments, expiry=resolved_expiry, spot=spot, strikes_around_atm=strikes_around_atm)
    if not selected:
        nearest = _nearest_strikes_for_message(instruments, resolved_expiry, spot)
        raise KiteQuoteUnavailable(
            "Kite read-only quotes unavailable. No matching NIFTY option instruments found for expiry/ATM filter. "
            f"Expiry: {resolved_expiry}. Available expiries: {_fmt_values(available_expiries)}. "
            f"Nearest strikes around spot: {_fmt_values(nearest)}."
        )
    quote_symbols, instrument_map = _kite_quote_symbols(selected, exchange)
    quotes = broker.get_quote(quote_symbols)
    if _is_error_payload(quotes):
        raise KiteQuoteUnavailable(KITE_UNAVAILABLE_MESSAGE)
    if not isinstance(quotes, dict):
        raise KiteQuoteUnavailable(KITE_UNAVAILABLE_MESSAGE)
    return kite_quotes_to_option_snapshots(quotes, instrument_map), resolved_expiry


def list_kite_nifty_options(spot: float | None = None, exchange: str = "NFO", base_dir: Path | str = ".") -> str:
    broker = KiteBroker(base_dir=base_dir)
    instruments = _load_kite_nifty_instruments(broker, exchange)
    expiries = get_available_expiries(instruments)
    counts = {expiry: 0 for expiry in expiries}
    for instrument in instruments:
        expiry = get_instrument_expiry(instrument)
        if expiry in counts:
            counts[expiry] += 1
    lines = [
        "KITE NIFTY OPTION INSTRUMENTS",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Quote Source: KITE READ-ONLY",
        "DRY RUN ONLY. No orders were placed.",
        "",
        "Available Expiries:",
    ]
    if expiries:
        for expiry in expiries:
            lines.append(f"- {expiry}: {counts.get(expiry, 0)} instruments")
    else:
        lines.append("- NONE")
    lines.extend(["", "Sample Option Instruments Around ATM:", "tradingsymbol | exchange | expiry | strike | instrument_type | instrument_token"])
    sample = _sample_instruments_around_atm(instruments, spot)
    if sample:
        for item in sample[:10]:
            lines.append(
                f"{item.get('tradingsymbol')} | {item.get('exchange')} | {get_instrument_expiry(item)} | "
                f"{get_instrument_strike(item)} | {item.get('instrument_type')} | {item.get('instrument_token')}"
            )
    else:
        lines.append("NONE")
    return "\n".join(lines)


def fetch_kite_spot_reference(spot_symbol: str, base_dir: Path | str = ".") -> tuple[float | None, str | None]:
    broker = KiteBroker(base_dir=base_dir)
    try:
        quote = broker.get_quote([spot_symbol])
    except Exception:
        return None, f"Auto spot warning: could not fetch {spot_symbol}; using manual --spot if supplied."
    if _is_error_payload(quote) or not isinstance(quote, dict):
        return None, f"Auto spot warning: could not fetch {spot_symbol}; using manual --spot if supplied."
    payload = quote.get(spot_symbol) or next(iter(quote.values()), {})
    if not isinstance(payload, dict):
        return None, f"Auto spot warning: invalid quote payload for {spot_symbol}; using manual --spot if supplied."
    spot = _optional_float(payload.get("last_price"))
    if spot is None:
        return None, f"Auto spot warning: last_price missing for {spot_symbol}; using manual --spot if supplied."
    return spot, None


def calculate_atm_implied_ivs(diagnostics: list[dict], spot: float, expiry: str, risk_free_rate: float) -> dict:
    time_to_expiry = calculate_time_to_expiry_years(expiry)
    if not diagnostics or time_to_expiry <= 0:
        return {"ce_iv": None, "pe_iv": None, "iv_source": "DEFAULT"}
    calls = [row for row in diagnostics if row.get("option_type") == "CALL"]
    puts = [row for row in diagnostics if row.get("option_type") == "PUT"]
    call = min(calls, key=lambda row: abs(row["strike"] - spot), default=None)
    put = min(puts, key=lambda row: abs(row["strike"] - spot), default=None)
    ce_iv = _row_implied_iv(call, spot, time_to_expiry, risk_free_rate, "CALL")
    pe_iv = _row_implied_iv(put, spot, time_to_expiry, risk_free_rate, "PUT")
    return {"ce_iv": ce_iv, "pe_iv": pe_iv, "iv_source": "MARKET IMPLIED" if ce_iv or pe_iv else "DEFAULT"}


def select_effective_iv(ce_iv: float | None, pe_iv: float | None, default_iv: float, prefer_market_iv: bool = True) -> dict:
    values = [float(value) for value in (ce_iv, pe_iv) if _optional_float(value) is not None]
    if prefer_market_iv and values:
        return {
            "effective_iv": round(sum(values) / len(values), 4),
            "source": "MARKET IMPLIED",
        }
    return {
        "effective_iv": float(default_iv),
        "source": "DEFAULT FALLBACK",
    }


def _load_kite_nifty_instruments(broker: KiteBroker, exchange: str) -> list[dict]:
    instruments = broker.get_instruments(exchange)
    if _is_error_payload(instruments):
        raise KiteQuoteUnavailable(KITE_UNAVAILABLE_MESSAGE)
    if not isinstance(instruments, list):
        raise KiteQuoteUnavailable(KITE_UNAVAILABLE_MESSAGE)
    return filter_nifty_option_symbols([item for item in instruments if _instrument_exchange(item) == exchange], expiry=None, spot=None)


def kite_quotes_to_option_snapshots(quotes: dict, instruments_by_quote_symbol: dict | None = None) -> list[dict]:
    instruments_by_quote_symbol = instruments_by_quote_symbol or {}
    snapshots: list[dict] = []
    for quote_symbol, quote in (quotes or {}).items():
        if not isinstance(quote, dict):
            continue
        instrument = instruments_by_quote_symbol.get(quote_symbol, {})
        depth = quote.get("depth") if isinstance(quote.get("depth"), dict) else {}
        best_bid, bid_qty = _top_depth(depth, "buy")
        best_ask, ask_qty = _top_depth(depth, "sell")
        snapshots.append({
            "symbol": quote_symbol,
            "strike": _optional_float(instrument.get("strike")),
            "option_type": instrument.get("instrument_type"),
            "best_bid": best_bid,
            "best_ask": best_ask,
            "bid_qty": bid_qty,
            "ask_qty": ask_qty,
            "depth": depth,
            "last_price": quote.get("last_price"),
            "oi": quote.get("oi"),
        })
    return snapshots


def format_scanner_output(
    rows: list[dict],
    underlying: str,
    spot: float,
    previous_close: float,
    expiry: str,
    default_iv: float,
    quote_source: str = QUOTE_SOURCE_SAMPLE,
    spot_source: str = "MANUAL",
    spot_symbol: str | None = None,
    spot_warning: str | None = None,
    model_status: str = "OK",
    model_warning: str | None = None,
    suppressed_count: int = 0,
    approx_atm_ce_iv: float | None = None,
    approx_atm_pe_iv: float | None = None,
    effective_iv_used: float | None = None,
    default_iv_input: float | None = None,
    iv_source: str = "DEFAULT FALLBACK",
    warning_reason: str | None = None,
    active_filters: dict | None = None,
) -> str:
    effective_iv_display = float(default_iv) if effective_iv_used is None else effective_iv_used
    default_iv_display = float(default_iv) if default_iv_input is None else default_iv_input
    active_filters = active_filters or _default_active_filters()
    lines = [
        "NIFTY PRE-OPEN OPTION MISPRICING SCANNER",
        "SCANNER ONLY - NOT EXECUTION READY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Option SELL rows: HEDGE REQUIRED. No naked option selling.",
        f"Quote Source: {quote_source}",
        f"Spot Source: {spot_source}",
        f"Spot Symbol: {spot_symbol or 'MANUAL'}",
        f"Spot Used: {spot}",
        f"Approx ATM CE IV: {_fmt_optional_float(approx_atm_ce_iv)}",
        f"Approx ATM PE IV: {_fmt_optional_float(approx_atm_pe_iv)}",
        f"Default IV Input: {_fmt_optional_float(default_iv_display)}",
        f"Effective IV Used: {_fmt_optional_float(effective_iv_display)}",
        f"IV Source: {iv_source}",
        f"Model Status: {model_status}",
        "DRY RUN ONLY. No orders were placed.",
        "",
        f"underlying: {underlying}",
        f"spot: {spot}",
        f"previous_close: {previous_close}",
        f"expiry: {expiry}",
        f"default_iv: {default_iv_display}",
        "",
        "Active Filters:",
        f"- min_bid_qty: {active_filters['min_bid_qty']}",
        f"- min_ask_qty: {active_filters['min_ask_qty']}",
        f"- max_spread_pct: {active_filters['max_spread_pct']}",
        f"- min_mispricing_pct: {active_filters['min_mispricing_pct']}",
        f"- tick_size: {active_filters['tick_size']}",
        f"- suggested_limit_offset_ticks: {active_filters['suggested_limit_offset_ticks']}",
        f"- opening_spike_planner: {_fmt_bool(active_filters['opening_spike_planner'])}",
        "",
        f"number of opportunities found: {len(rows)}",
        "",
    ]
    if spot_warning:
        lines.extend(["SPOT WARNING:", f"- {spot_warning}", ""])
    if model_warning:
        lines.extend([
            "MODEL WARNING: fair value reference appears miscalibrated.",
            f"Warning Reason: {warning_reason or 'model reference mismatch'}",
            "Do not treat these rows as trade signals.",
            "Possible causes: wrong spot, wrong IV, wrong expiry, futures/forward mismatch, pre-open illiquidity.",
            "",
        ])
    if suppressed_count:
        lines.append(f"opportunities suppressed due to model warning: {suppressed_count}")
        return "\n".join(lines)
    lines.extend([
        "OPENING SPIKE LIMIT ORDER PLANNER",
        "This is dry-run guidance only.",
        "Visible orders can disappear, be cancelled, or not fill.",
        "",
        "Symbol | Type | Strike | Fair | Bid | Ask | Spread% | Mispricing% | Action | Confidence | Visible Match Side | Visible Match Price | Suggested Limit Price | Suggested Limit Rule | Fair Exit Price | Expected Gross Edge | Expected Gross Edge % | Exit Plan | Planner Note | Execution Allowed | Hedge Required | Risk Note | Reason",
    ])
    if not rows:
        lines.append("NONE")
        return "\n".join(lines)
    for row in rows:
        lines.append(
            f"{row['symbol']} | {row['option_type']} | {row['strike']:.0f} | "
            f"{row['fair_price']:.2f} | {row['best_bid']:.2f} | {row['best_ask']:.2f} | "
            f"{row['spread_pct']:.2f} | {row['mispricing_pct']:.2f} | "
            f"{row['suggested_action']} | {row['confidence']} | "
            f"{row.get('visible_match_side', 'N/A')} | {_fmt_report_number(row.get('visible_match_price'))} | "
            f"{_fmt_report_number(row.get('suggested_limit_price'))} | {row.get('suggested_limit_rule', 'N/A')} | "
            f"{_fmt_report_number(row.get('fair_exit_price'))} | {_fmt_report_number(row.get('expected_gross_edge_points'))} | "
            f"{_fmt_report_number(row.get('expected_gross_edge_pct'))} | {row.get('exit_plan', 'N/A')} | "
            f"{row.get('planner_note', 'Opening spike planner only. Visible orders can disappear or not fill.')} | "
            f"{_fmt_bool(row.get('execution_allowed', False))} | {_fmt_bool(row.get('hedge_required', False))} | "
            f"{row.get('risk_note', 'Scanner-only. Manual review required. Dry-run only.')} | {row['reason']}"
        )
    return "\n".join(lines)


def save_scanner_report(report_text: str, rows: list[dict], base_dir: Path | str = ".") -> dict[str, Path]:
    report_dir = Path(base_dir) / SCANNER_REPORT_DIR
    report_dir.mkdir(parents=True, exist_ok=True)
    text_path = report_dir / SCANNER_REPORT_TXT
    csv_path = report_dir / SCANNER_REPORT_CSV
    text_path.write_text(report_text, encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=SCANNER_CSV_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: _csv_value(row, column) for column in SCANNER_CSV_COLUMNS})
    return {"text": text_path, "csv": csv_path}


def _default_active_filters() -> dict:
    return {
        "min_bid_qty": DEFAULT_CONFIG["min_bid_qty"],
        "min_ask_qty": DEFAULT_CONFIG["min_ask_qty"],
        "max_spread_pct": DEFAULT_CONFIG["max_spread_pct"],
        "min_mispricing_pct": DEFAULT_CONFIG["min_mispricing_pct"],
        "tick_size": DEFAULT_CONFIG["tick_size"],
        "suggested_limit_offset_ticks": DEFAULT_CONFIG["suggested_limit_offset_ticks"],
        "opening_spike_planner": DEFAULT_CONFIG["opening_spike_planner"],
    }


def _fmt_bool(value: Any) -> str:
    return "true" if bool(value) else "false"


def _fmt_report_number(value: Any) -> str:
    try:
        return f"{float(value):.2f}"
    except (TypeError, ValueError):
        return "N/A"


def _csv_value(row: dict, column: str) -> Any:
    if column == "execution_allowed":
        return bool(row.get(column, False))
    if column == "hedge_required":
        return bool(row.get(column, False))
    if column == "dry_run":
        return bool(row.get(column, True))
    if column == "risk_note":
        return row.get(column, "Scanner-only. Manual review required. Dry-run only.")
    return row.get(column, "")


def _load_config(base_dir: Path | str) -> dict:
    path = Path(base_dir) / "config" / "preopen_options.yaml"
    if not path.exists():
        return dict(DEFAULT_CONFIG)
    config = dict(DEFAULT_CONFIG)
    config.update(load_yaml(path))
    return config


def _resolve_requested_expiry(expiry: str | None, available_expiries: list[str]) -> str:
    if not available_expiries:
        raise KiteQuoteUnavailable("Kite read-only quotes unavailable. No NIFTY option expiries found in Kite instruments.")
    requested = normalize_expiry(expiry) if expiry else "auto"
    if requested == "auto":
        today = date.today().isoformat()
        future = [item for item in available_expiries if item >= today]
        return future[0] if future else available_expiries[0]
    if requested not in available_expiries:
        raise KiteQuoteUnavailable(
            f"Kite read-only quotes unavailable. Requested expiry {requested} was not found. "
            f"Available expiries: {_fmt_values(available_expiries)}."
        )
    return requested


def _nearest_strikes_for_message(instruments: list[dict], expiry: str, spot: float) -> list[float]:
    expiry_items = filter_nifty_option_symbols(instruments, expiry=expiry, spot=None)
    strikes = [strike for item in expiry_items for strike in [get_instrument_strike(item)] if strike is not None]
    return select_strikes_around_atm(strikes, spot, 5)


def _sample_instruments_around_atm(instruments: list[dict], spot: float | None) -> list[dict]:
    if spot is None:
        return sorted(instruments, key=_instrument_sort_key)[:10]
    strikes = [strike for item in instruments for strike in [get_instrument_strike(item)] if strike is not None]
    selected_strikes = set(select_strikes_around_atm(strikes, spot, 5))
    sample = [item for item in instruments if get_instrument_strike(item) in selected_strikes]
    sample.sort(key=lambda item: (abs((get_instrument_strike(item) or 0.0) - float(spot)), str(item.get("instrument_type") or ""), str(item.get("tradingsymbol") or "")))
    return sample[:10]


def _instrument_exchange(item: Any) -> str:
    if isinstance(item, dict):
        return str(item.get("exchange") or "").strip().upper()
    return ""


def _instrument_sort_key(item: dict) -> tuple:
    return (get_instrument_expiry(item) or "", get_instrument_strike(item) or 0.0, str(item.get("instrument_type") or ""), str(item.get("tradingsymbol") or ""))


def _fmt_values(values: list | tuple | set) -> str:
    return "NONE" if not values else ", ".join(str(value) for value in values)


def _kite_quote_symbols(instruments: list[dict], exchange: str) -> tuple[list[str], dict]:
    quote_symbols: list[str] = []
    instrument_map: dict[str, dict] = {}
    for instrument in instruments:
        if not isinstance(instrument, dict):
            continue
        tradingsymbol = str(instrument.get("tradingsymbol") or instrument.get("symbol") or "").strip()
        if not tradingsymbol:
            continue
        symbol_exchange = str(instrument.get("exchange") or exchange or "NFO").strip() or "NFO"
        quote_symbol = f"{symbol_exchange}:{tradingsymbol}"
        quote_symbols.append(quote_symbol)
        instrument_map[quote_symbol] = instrument
    return quote_symbols, instrument_map


def _top_depth(depth: dict, side: str) -> tuple[float | None, int]:
    levels = depth.get(side) if isinstance(depth, dict) else None
    if not isinstance(levels, list) or not levels:
        return None, 0
    first = levels[0] or {}
    return _optional_float(first.get("price")), _optional_int(first.get("quantity"))


def _row_implied_iv(row: dict | None, spot: float, time_to_expiry: float, risk_free_rate: float, option_type: str) -> float | None:
    if not row:
        return None
    return implied_volatility(
        market_price=row.get("mid_price"),
        spot=spot,
        strike=row.get("strike"),
        time_to_expiry_years=time_to_expiry,
        risk_free_rate=risk_free_rate,
        option_type=option_type,
    )


def _fmt_optional_float(value: float | None) -> str:
    return "N/A" if value is None else str(round(float(value), 4))


def _optional_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _optional_int(value: Any) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def _is_error_payload(value: Any) -> bool:
    return isinstance(value, dict) and bool(value.get("status"))


def _parse_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _expiry_label(expiry: str) -> str:
    try:
        expiry_date = datetime.strptime(expiry, "%Y-%m-%d").date()
    except ValueError:
        return expiry.replace("-", "")
    return expiry_date.strftime("%d%b").upper()


def _sample_time_to_expiry(expiry: str) -> float:
    try:
        expiry_date = datetime.strptime(expiry, "%Y-%m-%d").date()
    except ValueError:
        return 0.0
    days = (expiry_date - date.today()).days
    return max(days, 0) / 365.0


def main() -> int:
    parser = argparse.ArgumentParser(description="Dry-run NIFTY pre-open option mispricing scanner.")
    parser.add_argument("--underlying", default=DEFAULT_CONFIG["underlying"])
    parser.add_argument("--spot", type=float, default=None)
    parser.add_argument("--previous-close", type=float, default=None)
    parser.add_argument("--expiry", default=None)
    parser.add_argument("--default-iv", type=float, default=DEFAULT_CONFIG["default_iv"])
    parser.add_argument("--use-kite-quotes", action="store_true", help="Use Kite read-only instruments and quotes. Never places orders.")
    parser.add_argument("--list-kite-nifty-options", action="store_true", help="List read-only Kite NIFTY option expiries and sample instruments.")
    parser.add_argument("--strikes-around-atm", type=int, default=DEFAULT_CONFIG["strikes_around_atm"])
    parser.add_argument("--exchange", default="NFO")
    parser.add_argument("--auto-spot", action="store_true", help="Fetch spot/index quote read-only from Kite when using --use-kite-quotes.")
    parser.add_argument("--spot-symbol", default="NSE:NIFTY 50")
    parser.add_argument("--future-reference", choices=["auto", "manual", "off"], default="auto")
    parser.add_argument("--max-model-warning-ratio", type=float, default=0.35)
    parser.add_argument("--suppress-signals-on-model-warning", default="true")
    parser.add_argument("--save-report", dest="save_report", action="store_true", default=True, help="Save latest scanner text and CSV reports. Enabled by default.")
    parser.add_argument("--no-save-report", dest="save_report", action="store_false", help="Skip writing scanner report files.")
    args = parser.parse_args()
    if args.list_kite_nifty_options:
        try:
            print(list_kite_nifty_options(spot=args.spot, exchange=args.exchange))
            return 0
        except KiteQuoteUnavailable as exc:
            print(str(exc))
            print("Live Trading: DISABLED")
            print("Broker Orders: DISABLED")
            print("DRY RUN ONLY. No orders were placed.")
            return 1
    if args.spot is None:
        print("Scanner skipped: --spot is required.")
        print("DRY RUN ONLY. No orders were placed.")
        return 1
    if args.previous_close is None:
        print("Scanner skipped: --previous-close is required.")
        print("DRY RUN ONLY. No orders were placed.")
        return 1
    expiry = args.expiry
    if not expiry and args.use_kite_quotes:
        expiry = "auto"
    if not expiry:
        print("Scanner skipped: --expiry is required unless --use-kite-quotes is used with auto expiry.")
        print("DRY RUN ONLY. No orders were placed.")
        return 1
    quote_source = QUOTE_SOURCE_KITE if args.use_kite_quotes else QUOTE_SOURCE_SAMPLE
    try:
        result = run_scanner_full(
            underlying=args.underlying,
            spot=args.spot,
            previous_close=args.previous_close,
            expiry=expiry,
            default_iv=args.default_iv,
            use_kite_quotes=args.use_kite_quotes,
            strikes_around_atm=args.strikes_around_atm,
            exchange=args.exchange,
            auto_spot=args.auto_spot,
            spot_symbol=args.spot_symbol,
            future_reference=args.future_reference,
            max_model_warning_ratio=args.max_model_warning_ratio,
            suppress_signals_on_model_warning=_parse_bool(args.suppress_signals_on_model_warning),
        )
    except KiteQuoteUnavailable as exc:
        print(str(exc))
        print("Live Trading: DISABLED")
        print("Broker Orders: DISABLED")
        print("DRY RUN ONLY. No orders were placed.")
        return 1
    report_text = format_scanner_output(
        result["rows"],
        args.underlying,
        result["spot_used"],
        args.previous_close,
        result["resolved_expiry"],
        args.default_iv,
        quote_source=quote_source,
        spot_source=result["spot_source"],
        spot_symbol=result["spot_symbol"],
        spot_warning=result["spot_warning"],
        model_status=result["model_status"],
        model_warning=result["model_warning"],
        suppressed_count=result["suppressed_count"],
        approx_atm_ce_iv=result["approx_atm_ce_iv"],
        approx_atm_pe_iv=result["approx_atm_pe_iv"],
        effective_iv_used=result["effective_iv_used"],
        default_iv_input=result["default_iv_input"],
        iv_source=result["iv_source"],
        warning_reason=result["warning_reason"],
        active_filters=result["active_filters"],
    )
    print(report_text)
    if args.save_report:
        paths = save_scanner_report(report_text, result["rows"])
        print("")
        print(f"Scanner text report saved: {paths['text']}")
        print(f"Scanner CSV report saved: {paths['csv']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
