"""Dry-run market scanners."""
