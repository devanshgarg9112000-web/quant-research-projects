from __future__ import annotations

import importlib
import sys
from pathlib import Path

from src.config_loader import load_configs


REQUIRED_FOLDERS = ["config", "data", "logs", "reports", "src"]
OPTIONAL_PACKAGES = ["pandas", "numpy", "yaml", "dotenv", "requests", "websocket", "kiteconnect", "pytest", "tabulate"]


def run_environment_check(base_dir: Path | str = ".") -> dict:
    base = Path(base_dir)
    results = {"ok": True, "warnings": [], "python": sys.version.split()[0]}
    if sys.version_info < (3, 11):
        results["ok"] = False
        results["warnings"].append("Python 3.11+ is recommended.")
    for folder in REQUIRED_FOLDERS:
        if not (base / folder).exists():
            results["ok"] = False
            results["warnings"].append(f"Missing folder: {folder}")
    if not (base / ".env.example").exists():
        results["ok"] = False
        results["warnings"].append(".env.example missing.")
    missing_packages = []
    for package in OPTIONAL_PACKAGES:
        try:
            importlib.import_module(package)
        except Exception:
            missing_packages.append(package)
    if missing_packages:
        results["warnings"].append("Install requirements for full stack: " + ", ".join(missing_packages))
    configs = load_configs(base)
    if configs["settings"].get("mode") != "PAPER":
        results["ok"] = False
        results["warnings"].append("Default mode must be PAPER.")
    if configs["settings"].get("enable_live_trading"):
        results["ok"] = False
        results["warnings"].append("Live trading must be disabled by default.")
    return results


if __name__ == "__main__":
    check = run_environment_check(Path.cwd())
    print(check)
