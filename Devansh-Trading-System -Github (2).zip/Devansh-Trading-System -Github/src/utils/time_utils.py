from __future__ import annotations


def format_time(timestamp) -> str:
    return timestamp.strftime("%I:%M %p")
