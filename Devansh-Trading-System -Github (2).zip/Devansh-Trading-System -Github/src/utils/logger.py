from __future__ import annotations

from datetime import datetime
from pathlib import Path


def setup_logs(base_dir: Path | str = ".") -> None:
    base = Path(base_dir)
    (base / "logs").mkdir(exist_ok=True)
    for name in ["system.log", "errors.log"]:
        path = base / "logs" / name
        if not path.exists():
            path.write_text("", encoding="utf-8")


def log_event(message: str, base_dir: Path | str = ".") -> None:
    setup_logs(base_dir)
    path = Path(base_dir) / "logs" / "system.log"
    path.write_text(path.read_text(encoding="utf-8") + f"{datetime.now().isoformat()} {message}\n", encoding="utf-8")


def log_error(message: str, base_dir: Path | str = ".") -> None:
    setup_logs(base_dir)
    path = Path(base_dir) / "logs" / "errors.log"
    path.write_text(path.read_text(encoding="utf-8") + f"{datetime.now().isoformat()} {message}\n", encoding="utf-8")
