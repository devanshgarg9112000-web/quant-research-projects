from __future__ import annotations


def split_walk_forward(candles: list[dict], ratio: float = 0.6) -> tuple[list[dict], list[dict]]:
    split = int(len(candles) * ratio)
    return candles[:split], candles[split:]
