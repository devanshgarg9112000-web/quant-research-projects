from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any

from src.backtesting.strategy_backtest_runner import (
    BACKTEST_STRATEGIES,
    BAR_COLUMNS,
    _load_backtest_bars,
    filter_bars_by_symbols,
    group_bars_by_symbol,
)
from src.config_loader import load_configs
from src.indicators.cluster_diagnostics import evaluate_mcx_cluster_gate_for_side
from src.indicators.vwap import calculate_vwap
from src.risk.risk_engine import RiskEngine
from src.strategies.strategy_engine import STRATEGY_MODULES, StrategyEngine


DIAGNOSTIC_COLUMNS = [
    "symbol",
    "strategy",
    "files_loaded",
    "bars_loaded",
    "bars_evaluated",
    "raw_setup_candidates",
    "rejected_by_trend_mode_filter",
    "rejected_by_score",
    "rejected_by_cluster_gate",
    "rejected_by_risk",
    "final_accepted_signals",
    "required_columns_ok",
    "datetime_parsing_ok",
    "ohlcv_valid",
    "vwap_calculated",
    "atr_calculated",
    "ema_calculated",
    "zero_signal_reason",
    "execution_allowed",
]


def diagnose_bar_strategies(
    base_dir: Path | str = ".",
    bar_dir: str = "data/historical/truedata/bars",
    symbols_text: str = "GOLD-I,SILVER-I",
    from_date: str | date | None = None,
    to_date: str | date | None = None,
    configs: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    base = Path(base_dir)
    configs = configs or load_configs(base)
    settings = dict(configs.get("settings", {}))
    settings["mode"] = "PAPER"
    settings["enable_live_trading"] = False
    settings["candle_only_backtest"] = True
    risk_engine = RiskEngine(configs.get("risk", {}), settings, instruments=configs.get("instruments", {}))
    symbols = [item.strip() for item in symbols_text.split(",") if item.strip()]
    from_day = date.fromisoformat(str(from_date)) if from_date else None
    to_day = date.fromisoformat(str(to_date)) if to_date else None
    bars, paths, notes = _load_backtest_bars(base, bar_dir, from_day=from_day, to_day=to_day)
    bars = filter_bars_by_symbols(bars, symbols)
    grouped = group_bars_by_symbol(bars)
    file_checks = _inspect_bar_files(paths)
    context_engine = StrategyEngine(settings, {})
    rows: list[dict[str, Any]] = []

    for symbol in symbols:
        symbol_bars = grouped.get(symbol, [])
        indicator_health = _indicator_health(symbol_bars)
        symbol_paths = [path for path in paths if path.name.startswith(f"{symbol}_")]
        day_groups: dict[Any, list[dict[str, Any]]] = defaultdict(list)
        for bar in symbol_bars:
            day_groups[bar["timestamp"].date()].append(bar)

        counters = {
            strategy: {
                "bars_evaluated": 0,
                "raw_setup_candidates": 0,
                "rejected_by_trend_mode_filter": 0,
                "rejected_by_score": 0,
                "rejected_by_cluster_gate": 0,
                "rejected_by_risk": 0,
                "final_accepted_signals": 0,
            }
            for strategy in BACKTEST_STRATEGIES
        }
        for day_bars in day_groups.values():
            clean = sorted(day_bars, key=lambda row: row["timestamp"])
            for index in range(3, len(clean)):
                window = clean[: index + 1]
                context = context_engine.build_context(window, [])
                for strategy in BACKTEST_STRATEGIES:
                    module = STRATEGY_MODULES.get(strategy)
                    if module is None:
                        continue
                    counters[strategy]["bars_evaluated"] += 1
                    signal = module.generate_signal(window, context)
                    if signal is None:
                        continue
                    counters[strategy]["raw_setup_candidates"] += 1
                    if _against_market_mode(signal.side, context["market_mode"]):
                        counters[strategy]["rejected_by_trend_mode_filter"] += 1
                    if signal.score < float(settings.get("min_signal_score", 7)):
                        counters[strategy]["rejected_by_score"] += 1
                        continue
                    if strategy == "cluster_imbalance_trap":
                        gate_allowed, _, _ = evaluate_mcx_cluster_gate_for_side(context["cluster_gate"], signal.side)
                        if not gate_allowed:
                            counters[strategy]["rejected_by_cluster_gate"] += 1
                            continue
                    decision = risk_engine.validate_signal(signal, mode="PAPER", data_quality_ok=True)
                    if not decision.approved:
                        counters[strategy]["rejected_by_risk"] += 1
                        continue
                    counters[strategy]["final_accepted_signals"] += 1

        for strategy in BACKTEST_STRATEGIES:
            values = counters[strategy]
            rows.append({
                "symbol": symbol,
                "strategy": strategy,
                "files_loaded": len(symbol_paths),
                "bars_loaded": len(symbol_bars),
                **values,
                "required_columns_ok": file_checks["required_columns_ok"],
                "datetime_parsing_ok": file_checks["datetime_parsing_ok"],
                "ohlcv_valid": indicator_health["ohlcv_valid"],
                "vwap_calculated": indicator_health["vwap_calculated"],
                "atr_calculated": indicator_health["atr_calculated"],
                "ema_calculated": indicator_health["ema_calculated"],
                "zero_signal_reason": _zero_signal_reason(strategy, values),
                "execution_allowed": False,
            })

    output_dir = base / "reports" / "strategy_diagnostics"
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "latest_bar_strategy_zero_signal_diagnosis.csv"
    txt_path = output_dir / "latest_bar_strategy_zero_signal_diagnosis.txt"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=DIAGNOSTIC_COLUMNS)
        writer.writeheader()
        for row in rows:
            output = dict(row)
            output["execution_allowed"] = "false"
            writer.writerow(output)
    txt_path.write_text(_format_diagnosis(rows, paths, notes) + "\n", encoding="utf-8")
    print(_format_diagnosis(rows, paths, notes))
    print(f"Bar Strategy Diagnosis CSV: {csv_path}")
    print(f"Bar Strategy Diagnosis Report: {txt_path}")
    return rows


def _inspect_bar_files(paths: list[Path]) -> dict[str, bool]:
    required_ok = True
    datetime_ok = True
    for path in paths:
        with path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            required_ok = required_ok and all(column in (reader.fieldnames or []) for column in BAR_COLUMNS)
            first = next(reader, None)
            if first:
                try:
                    from datetime import datetime

                    datetime.fromisoformat(str(first.get("timestamp") or ""))
                except ValueError:
                    datetime_ok = False
    return {"required_columns_ok": required_ok, "datetime_parsing_ok": datetime_ok}


def _indicator_health(bars: list[dict[str, Any]]) -> dict[str, bool]:
    valid = bool(bars) and all(
        float(row["high"]) >= max(float(row["open"]), float(row["close"]), float(row["low"]))
        and float(row["low"]) <= min(float(row["open"]), float(row["close"]), float(row["high"]))
        and float(row.get("volume") or 0) >= 0
        for row in bars
    )
    vwap_ok = bool(bars) and len(calculate_vwap(bars[: min(len(bars), 100)])) > 0
    closes = [float(row["close"]) for row in bars[: min(len(bars), 100)]]
    ema_ok = len(_ema(closes, 20)) == len(closes) and bool(closes)
    atr_ok = len(_atr(bars[: min(len(bars), 100)], 14)) > 0
    return {
        "ohlcv_valid": valid,
        "vwap_calculated": vwap_ok,
        "atr_calculated": atr_ok,
        "ema_calculated": ema_ok,
    }


def _ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2.0 / (period + 1)
    output = [values[0]]
    for value in values[1:]:
        output.append(alpha * value + (1 - alpha) * output[-1])
    return output


def _atr(bars: list[dict[str, Any]], period: int) -> list[float]:
    if len(bars) < 2:
        return []
    ranges: list[float] = []
    for previous, current in zip(bars, bars[1:]):
        ranges.append(max(
            float(current["high"]) - float(current["low"]),
            abs(float(current["high"]) - float(previous["close"])),
            abs(float(current["low"]) - float(previous["close"])),
        ))
    return [sum(ranges[max(0, index - period + 1):index + 1]) / min(index + 1, period) for index in range(len(ranges))]


def _against_market_mode(side: str, market_mode: str) -> bool:
    return (side == "BUY" and market_mode == "TREND_DOWN") or (side == "SELL" and market_mode == "TREND_UP")


def _zero_signal_reason(strategy: str, values: dict[str, int]) -> str:
    if strategy not in STRATEGY_MODULES:
        return "No standalone strategy module is registered."
    if strategy == "abnormal_flow":
        return "Confirmation-only module; it intentionally does not generate standalone signals."
    if values["raw_setup_candidates"] == 0:
        return "No raw setup matched the strategy's conservative candle conditions."
    if values["rejected_by_score"] >= values["raw_setup_candidates"]:
        return "All raw setups were below the configured minimum score."
    if values["rejected_by_cluster_gate"] >= values["raw_setup_candidates"]:
        return "All raw setups required unavailable tick/cluster confirmation."
    if values["rejected_by_risk"] and values["final_accepted_signals"] == 0:
        return "Raw setups formed, but all were rejected by the existing risk engine."
    if values["final_accepted_signals"] == 0:
        return "Setups were filtered before final acceptance; review score, mode, cluster, and risk counts."
    return "Signals are available after compatibility correction."


def _format_diagnosis(rows: list[dict[str, Any]], paths: list[Path], notes: list[str]) -> str:
    lines = [
        "BAR STRATEGY ZERO-SIGNAL DIAGNOSIS",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        f"Files Loaded: {len(paths)}",
        "",
        "FILES",
    ]
    lines.extend(f"- {path}" for path in paths)
    lines.extend(["", "PER STRATEGY / SYMBOL"])
    for row in rows:
        lines.append(
            f"- {row['symbol']} {row['strategy']}: bars={row['bars_evaluated']} "
            f"raw={row['raw_setup_candidates']} mode={row['rejected_by_trend_mode_filter']} "
            f"score={row['rejected_by_score']} cluster={row['rejected_by_cluster_gate']} "
            f"risk={row['rejected_by_risk']} accepted={row['final_accepted_signals']}"
        )
        lines.append(f"  Reason: {row['zero_signal_reason']}")
    if notes:
        lines.extend(["", "NOTES"])
        lines.extend(f"- {note}" for note in notes)
    lines.extend(["", "PAPER/manual-signal diagnostics only."])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Diagnose PAPER bar-strategy zero signals.")
    parser.add_argument("--bar-dir", default="data/historical/truedata/bars")
    parser.add_argument("--symbols", default="GOLD-I,SILVER-I")
    parser.add_argument("--from-date", default=None)
    parser.add_argument("--to-date", default=None)
    args = parser.parse_args()
    try:
        diagnose_bar_strategies(
            bar_dir=args.bar_dir,
            symbols_text=args.symbols,
            from_date=args.from_date,
            to_date=args.to_date,
        )
    except Exception as exc:
        print(f"Bar strategy diagnosis failed safely: {type(exc).__name__}: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
