from __future__ import annotations

import argparse
import csv
import time
from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from math import ceil, floor, inf
from pathlib import Path
from typing import Any

from src.config_loader import load_configs
from src.data_feeds.candle_builder import build_candles_from_ticks_seconds
from src.data_feeds.tick_storage import TickCsvError, load_tick_csv, resolve_tick_file
from src.filters.data_quality_guard import validate_candles
from src.indicators.cluster import build_cluster_table
from src.indicators.cluster_diagnostics import (
    IMBALANCE_RATIO,
    MIN_BID_ASK_COVERAGE,
    MIN_RELIABLE_TICKS,
    build_mcx_cluster_gate,
    calculate_trap_strength,
    classify_tick_aggression,
    evaluate_mcx_cluster_gate_for_side,
)
from src.market_context.regime_router import route_regime
from src.replay.replay_engine import filter_replay_ticks, group_replay_ticks, parse_replay_symbols
from src.risk.risk_engine import RiskEngine
from src.strategies import cluster_imbalance_trap
from src.strategies.cluster_signal_quality import (
    ClusterSignalQualityConfig,
    ClusterSignalQualityDecision,
    ClusterSignalQualityState,
)
from src.strategies.strategy_engine import STRATEGY_MODULES, StrategyEngine, StrategyEngineResult


_DEFAULT_STRATEGY_ENGINE_CLASS = StrategyEngine


BACKTEST_STRATEGIES = [
    "trend_following",
    "breakout_acceptance",
    "breakdown_acceptance",
    "failed_breakout",
    "failed_breakdown",
    "vwap_reclaim",
    "vwap_rejection",
    "value_area_rejection",
    "poc_magnet",
    "trend_day_vwap_pullback",
    "cluster_imbalance_trap",
    "abnormal_flow",
]
CANDLE_TIMEFRAME_SECONDS = 15
MIN_BACKTEST_CANDLES = 4
MIN_SAMPLE_SIZE = 5
MIN_SOURCE_TICKS_FOR_CONFIDENCE = 1000
BAR_COLUMNS = ["timestamp", "symbol", "open", "high", "low", "close", "volume", "oi", "source", "interval"]

SUMMARY_COLUMNS = [
    "strategy",
    "symbol",
    "signals",
    "raw_signals",
    "quality_accepted_signals",
    "quality_rejected",
    "weak_trap_rejected",
    "bad_stop_distance_rejected",
    "bad_target_distance_rejected",
    "direction_flip_rejected",
    "same_zone_rejected",
    "market_mode_rejected",
    "accepted",
    "wins",
    "losses",
    "open",
    "end_exit",
    "risk_rejected",
    "overlap_skipped",
    "cooldown_skipped",
    "daily_limit_skipped",
    "gross_pnl",
    "net_pnl",
    "costs",
    "win_rate",
    "profit_factor",
    "expectancy",
    "max_drawdown",
    "sample_status",
    "execution_allowed",
    "execution_model",
    "approval_grade_execution_ready",
    "entry_timing",
    "entry_delay_ticks",
    "cost_per_trade",
    "slippage_points",
    "spread_points",
    "tick_size",
    "same_bar_rule",
]

SUMMARY_ALIAS_COLUMNS = [
    "total_signals",
    "accepted_signals",
    "wins",
    "losses",
    "open_trades",
    "end_exit_trades",
    "risk_rejected_signals",
]

TRADE_COLUMNS = [
    "signal_time",
    "symbol",
    "strategy",
    "direction",
    "quality_status",
    "quality_rejection_reason",
    "signal_score",
    "trap_strength",
    "entry_time",
    "entry_price",
    "adjusted_entry",
    "stop",
    "target",
    "exit_time",
    "exit_price",
    "adjusted_exit",
    "qty",
    "status",
    "outcome",
    "gross_pnl",
    "cost",
    "net_pnl",
    "rr",
    "r_multiple",
    "mfe",
    "mae",
    "risk_status",
    "score",
    "market_mode",
    "reason",
    "rejection_reason",
    "risk_budget",
    "estimated_risk_amount",
    "cluster_status",
    "cluster_gate_status",
    "execution_allowed",
    "execution_model",
    "approval_grade_execution_ready",
    "entry_timing",
    "entry_delay_ticks",
    "cost_per_trade",
    "slippage_points",
    "spread_points",
    "tick_size",
    "same_bar_rule",
]


@dataclass
class StrategyBacktestResult:
    summary_rows: list[dict[str, Any]]
    trade_rows: list[dict[str, Any]]
    report_path: Path
    summary_csv_path: Path
    trades_csv_path: Path
    tick_file: Path | None
    tick_files: list[Path]
    bar_files: list[Path]
    date_range: str
    exit_at_end: bool
    source_kind: str
    total_source_ticks: int
    total_filtered_ticks: int
    total_source_bars: int = 0
    total_filtered_bars: int = 0
    timed_out: bool = False


@dataclass(frozen=True)
class BacktestControls:
    one_trade_at_a_time: bool = True
    signal_cooldown_seconds: int = 300
    max_trades_per_day: int = 20
    slippage_points: float = 0.0
    cost_per_trade: float = 0.0
    entry_delay_ticks: int = 1
    execution_model: str = "DEFAULT_TICK_PATH"
    spread_points: float = 0.0
    tick_size: float = 0.0
    same_bar_rule: str = "NOT_APPLICABLE_TICK_PATH"

    @property
    def approval_grade_execution_ready(self) -> bool:
        return _approval_grade_execution_ready(self)


CONSERVATIVE_VWAP_EXECUTION_MODEL = "CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK"
VWAP_APPROVAL_GRADE_STRATEGIES = {
    "gold_vwap_rejection_reclaim_family",
    "gold_vwap_rejection_short",
    "vwap_rejection",
    "vwap_reclaim",
    "trend_day_vwap_pullback",
}


def _is_vwap_approval_grade_strategy(strategy: str | None) -> bool:
    normalized = str(strategy or "").strip().lower().replace(" ", "_").replace("-", "_")
    return normalized in VWAP_APPROVAL_GRADE_STRATEGIES


def _approval_grade_execution_ready(controls: BacktestControls) -> bool:
    return (
        controls.execution_model == CONSERVATIVE_VWAP_EXECUTION_MODEL
        and int(controls.entry_delay_ticks) >= 1
        and float(controls.cost_per_trade) > 0.0
        and float(controls.slippage_points) > 0.0
        and float(controls.spread_points) > 0.0
        and float(controls.tick_size) > 0.0
        and str(controls.same_bar_rule).upper() in {"STOP_FIRST", "NOT_APPLICABLE_TICK_PATH"}
    )


def _execution_metadata_fields(controls: BacktestControls) -> dict[str, Any]:
    return {
        "execution_model": controls.execution_model,
        "approval_grade_execution_ready": controls.approval_grade_execution_ready,
        "entry_timing": (
            "NEXT_FUTURE_TICK_OR_NEXT_BAR"
            if controls.execution_model == CONSERVATIVE_VWAP_EXECUTION_MODEL
            else "FUTURE_TICK_PATH"
        ),
        "entry_delay_ticks": int(controls.entry_delay_ticks),
        "cost_per_trade": round(float(controls.cost_per_trade), 2),
        "slippage_points": round(float(controls.slippage_points), 4),
        "spread_points": round(float(controls.spread_points), 4),
        "tick_size": round(float(controls.tick_size), 4),
        "same_bar_rule": controls.same_bar_rule,
    }


def _round_to_tick(price: float, tick_size: float, mode: str) -> float:
    tick = float(tick_size or 0.0)
    value = float(price)
    if tick <= 0:
        return value
    units = value / tick
    mode = mode.upper()
    if mode == "UP":
        return round(ceil(units - 1e-12) * tick, 10)
    if mode == "DOWN":
        return round(floor(units + 1e-12) * tick, 10)
    return round(round(units) * tick, 10)


def _round_conservative_price(price: float, side: str, purpose: str, controls: BacktestControls) -> float:
    side = str(side).upper()
    purpose = str(purpose).lower()
    if side == "BUY":
        mode = "UP" if purpose in {"entry", "target"} else "DOWN"
    else:
        mode = "DOWN" if purpose in {"entry", "target"} else "UP"
    return _round_to_tick(float(price), controls.tick_size, mode)


def _apply_conservative_entry_price(raw_entry: float, side: str, controls: BacktestControls) -> float:
    side = str(side).upper()
    adverse = float(controls.slippage_points) + float(controls.spread_points)
    price = float(raw_entry) + adverse if side == "BUY" else float(raw_entry) - adverse
    return _round_conservative_price(price, side, "entry", controls)


def _apply_conservative_exit_price(raw_exit: float, side: str, controls: BacktestControls) -> float:
    side = str(side).upper()
    adverse = float(controls.slippage_points) + float(controls.spread_points)
    price = float(raw_exit) - adverse if side == "BUY" else float(raw_exit) + adverse
    return _round_conservative_price(price, side, "exit", controls)


def _approval_grade_same_bar_exit(side: str, high: float, low: float, stop: float, target: float) -> tuple[str, float] | None:
    """Conservative OHLC ambiguity helper: if stop and target both hit, stop wins."""
    side = str(side).upper()
    if side == "BUY":
        stop_hit = float(low) <= float(stop)
        target_hit = float(high) >= float(target)
        if stop_hit:
            return "LOSS", float(stop)
        if target_hit:
            return "WIN", float(target)
        return None
    stop_hit = float(high) >= float(stop)
    target_hit = float(low) <= float(target)
    if stop_hit:
        return "LOSS", float(stop)
    if target_hit:
        return "WIN", float(target)
    return None


@dataclass
class BacktestRunState:
    started_at: float
    deadline: float | None = None
    timed_out: bool = False

    def exceeded(self) -> bool:
        if self.deadline is None:
            return False
        if time.monotonic() <= self.deadline:
            return False
        self.timed_out = True
        return True


class IncrementalClusterDiagnostics:
    """Maintain the existing MCX trap/gate inputs without rescanning all prior ticks."""

    def __init__(self, symbol: str):
        self.symbol = symbol
        self.total_ticks = 0
        self.bid_ask_ticks = 0
        self.bid_count = 0
        self.ask_count = 0
        self.first_tick_time: datetime | None = None
        self.last_tick_time: datetime | None = None
        self.latest_ltp: float | None = None
        self.latest_ltq: float | None = None
        self.levels: dict[float, dict[str, float]] = {}
        self.buy_levels: set[float] = set()
        self.sell_levels: set[float] = set()

    def extend(self, ticks: list[dict[str, Any]]) -> None:
        for tick in ticks:
            if str(tick.get("symbol") or "") != self.symbol:
                continue
            timestamp = tick["timestamp"]
            price = float(tick["ltp"])
            volume = float(tick.get("ltq") or 0.0)
            if self.first_tick_time is None:
                self.first_tick_time = timestamp
            self.last_tick_time = timestamp
            self.latest_ltp = price
            self.latest_ltq = volume
            self.total_ticks += 1
            if tick.get("bid") is not None:
                self.bid_count += 1
            if tick.get("ask") is not None:
                self.ask_count += 1
            if tick.get("bid") is not None and tick.get("ask") is not None:
                self.bid_ask_ticks += 1

            row = self.levels.setdefault(
                price,
                {"total_volume": 0.0, "bid_volume_at_price": 0.0, "ask_volume_at_price": 0.0, "unknown_volume": 0.0},
            )
            row["total_volume"] += volume
            side = classify_tick_aggression(tick)
            if side == "BUY":
                row["ask_volume_at_price"] += volume
            elif side == "SELL":
                row["bid_volume_at_price"] += volume
            else:
                row["unknown_volume"] += volume
            self._refresh_level(price, row)

    def snapshot(self) -> dict[str, Any]:
        buy_levels = sorted(self.buy_levels)
        sell_levels = sorted(self.sell_levels)
        coverage = self.bid_ask_ticks / self.total_ticks if self.total_ticks else 0.0
        reliable = self.total_ticks >= MIN_RELIABLE_TICKS and coverage >= MIN_BID_ASK_COVERAGE
        status = "INSUFFICIENT_DATA"
        if self.total_ticks and self.levels:
            latest = float(self.latest_ltp or 0.0)
            if buy_levels and latest < buy_levels[-1]:
                status = "ESTIMATED_BUYER_TRAP_POSSIBLE"
            elif sell_levels and latest > sell_levels[0]:
                status = "ESTIMATED_SELLER_TRAP_POSSIBLE"
            elif buy_levels or sell_levels:
                status = "IMBALANCE_PRESENT_NO_CONFIRMED_TRAP"
            else:
                status = "NO_CLUSTER_TRAP_EVIDENCE"
        volume_rows = self._volume_rows()
        return {
            "symbol": self.symbol,
            "total_ticks": self.total_ticks,
            "first_tick_time": self.first_tick_time,
            "last_tick_time": self.last_tick_time,
            "latest_ltp": self.latest_ltp,
            "latest_ltq": self.latest_ltq,
            "bid_ask_availability": f"{self.bid_count}/{self.ask_count} of {self.total_ticks} ticks",
            "bucket_seconds": CANDLE_TIMEFRAME_SECONDS,
            "candles_built": 0,
            "delta_per_candle": [],
            "cvd_progression": [],
            "volume_at_price": volume_rows,
            "buy_imbalance_levels": buy_levels,
            "sell_imbalance_levels": sell_levels,
            "stacked_imbalance_zones": [],
            "absorption_zones": [],
            "exhaustion_signs": [],
            "cluster_imbalance_trap_status": status,
            "trap_strength": calculate_trap_strength(status, volume_rows),
            "data_sufficient": reliable,
            "data_quality_notes": [
                "Volume-at-price and imbalance are ESTIMATED from LTP, LTQ, bid, and ask; not full exchange footprint depth."
            ],
        }

    def _refresh_level(self, price: float, row: dict[str, float]) -> None:
        ask_volume = row["ask_volume_at_price"]
        bid_volume = row["bid_volume_at_price"]
        if ask_volume >= IMBALANCE_RATIO * max(bid_volume, 1.0):
            self.buy_levels.add(price)
        else:
            self.buy_levels.discard(price)
        if bid_volume >= IMBALANCE_RATIO * max(ask_volume, 1.0):
            self.sell_levels.add(price)
        else:
            self.sell_levels.discard(price)

    def _volume_rows(self) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        for price, values in self.levels.items():
            ask_volume = values["ask_volume_at_price"]
            bid_volume = values["bid_volume_at_price"]
            larger = max(ask_volume, bid_volume)
            smaller = min(ask_volume, bid_volume)
            ratio = larger / max(smaller, 1.0) if larger else 0.0
            output.append({
                "price": price,
                **values,
                "imbalance_ratio": ratio,
                "buy_imbalance": price in self.buy_levels,
                "sell_imbalance": price in self.sell_levels,
                "classification": "ESTIMATED_FROM_LTP_VS_BID_ASK",
            })
        return sorted(output, key=lambda row: row["price"])


class StrategyBacktestError(ValueError):
    """Clear CLI-facing error for safe PAPER backtest failures."""


def parse_strategy_selection(strategies_text: str | None) -> list[str]:
    """Parse --strategies while preserving order and rejecting unknown names."""

    text = (strategies_text or "all").strip()
    if not text or text.lower() == "all":
        return list(BACKTEST_STRATEGIES)

    selected: list[str] = []
    unknown: list[str] = []
    for raw in text.split(","):
        strategy = raw.strip()
        if not strategy:
            continue
        if strategy not in BACKTEST_STRATEGIES:
            unknown.append(strategy)
            continue
        if strategy not in selected:
            selected.append(strategy)
    if unknown:
        raise StrategyBacktestError(
            "Unsupported strategy selection: "
            + ", ".join(unknown)
            + ". Use all or one of: "
            + ", ".join(BACKTEST_STRATEGIES)
        )
    if not selected:
        raise StrategyBacktestError("No strategies selected for PAPER backtest.")
    return selected


def run_strategy_backtest(
    base_dir: Path | str = ".",
    tick_file: str | None = None,
    tick_dir: str | None = None,
    bar_dir: str | None = None,
    symbols_text: str | None = None,
    strategies_text: str | None = "all",
    exit_at_end: bool = False,
    one_trade_at_a_time: bool = True,
    signal_cooldown_seconds: int = 300,
    max_trades_per_day: int = 20,
    slippage_points: float = 0.0,
    cost_per_trade: float = 0.0,
    entry_delay_ticks: int = 1,
    execution_model: str = "DEFAULT_TICK_PATH",
    spread_points: float = 0.0,
    tick_size: float = 0.0,
    same_bar_rule: str = "NOT_APPLICABLE_TICK_PATH",
    from_date: str | date | None = None,
    to_date: str | date | None = None,
    max_backtest_seconds: float | None = None,
    min_score: float | None = None,
    min_trap_strength: float | None = None,
    same_zone_cooldown_seconds: int | None = None,
    direction_flip_cooldown_seconds: int | None = None,
    configs: dict[str, Any] | None = None,
) -> StrategyBacktestResult:
    """Run strategy-wise saved-tick PAPER backtests and persist reports."""

    started_at = time.monotonic()
    max_seconds = float(max_backtest_seconds) if max_backtest_seconds is not None else None
    runtime = BacktestRunState(
        started_at=started_at,
        deadline=started_at + max_seconds if max_seconds is not None and max_seconds > 0 else None,
    )
    base = Path(base_dir)
    configs = configs or load_configs(base)
    settings = dict(configs.get("settings", {}))
    settings["mode"] = "PAPER"
    settings["enable_live_trading"] = False
    risk_config = dict(configs.get("risk", {}))
    instruments = configs.get("instruments", {})
    quality_config = ClusterSignalQualityConfig.from_mapping(
        configs.get("strategy_quality", {}),
        min_score=min_score,
        min_trap_strength=min_trap_strength,
        same_zone_cooldown_seconds=same_zone_cooldown_seconds,
        direction_flip_cooldown_seconds=direction_flip_cooldown_seconds,
    )
    selected_strategies = parse_strategy_selection(strategies_text)
    controls = BacktestControls(
        one_trade_at_a_time=bool(one_trade_at_a_time),
        signal_cooldown_seconds=max(0, int(signal_cooldown_seconds)),
        max_trades_per_day=max(0, int(max_trades_per_day)),
        slippage_points=max(0.0, float(slippage_points)),
        cost_per_trade=max(0.0, float(cost_per_trade)),
        entry_delay_ticks=max(1, int(entry_delay_ticks)),
        execution_model=str(execution_model or "DEFAULT_TICK_PATH"),
        spread_points=max(0.0, float(spread_points)),
        tick_size=max(0.0, float(tick_size)),
        same_bar_rule=str(same_bar_rule or "NOT_APPLICABLE_TICK_PATH").upper(),
    )
    from_day = _parse_optional_date(from_date, "--from-date")
    to_day = _parse_optional_date(to_date, "--to-date")
    if from_day and to_day and from_day > to_day:
        raise StrategyBacktestError("--from-date cannot be later than --to-date.")
    requested_symbols = parse_replay_symbols(symbols_text)
    source = _load_backtest_source(
        base,
        tick_file,
        tick_dir,
        bar_dir,
        from_day=from_day,
        to_day=to_day,
        symbols=requested_symbols,
    )
    settings["candle_only_backtest"] = source["kind"] == "BARS"

    if source["kind"] == "TICKS" and not source["ticks"]:
        source_label = tick_dir or tick_file or "NO_TICK_SOURCE"
        raise StrategyBacktestError(f"Backtest tick source is empty: {source_label}")
    if source["kind"] == "BARS" and not source["bars"]:
        raise StrategyBacktestError(f"Backtest bar source is empty: {bar_dir}")

    symbols = requested_symbols
    if not symbols:
        symbols = _symbols_from_ticks(source["ticks"]) if source["kind"] == "TICKS" else _symbols_from_bars(source["bars"])
    filtered_ticks = filter_replay_ticks(source["ticks"], symbols) if source["kind"] == "TICKS" else []
    filtered_bars = filter_bars_by_symbols(source["bars"], symbols) if source["kind"] == "BARS" else []
    if source["kind"] == "TICKS" and not filtered_ticks:
        raise StrategyBacktestError(
            "Backtest tick file contains no ticks matching requested symbols: "
            + (", ".join(symbols) if symbols else "NONE")
        )
    if source["kind"] == "BARS" and not filtered_bars:
        raise StrategyBacktestError(
            "Backtest bar directory contains no bars matching requested symbols: "
            + (", ".join(symbols) if symbols else "NONE")
        )

    grouped_ticks = group_replay_ticks(filtered_ticks)
    grouped_bars = group_bars_by_symbol(filtered_bars)
    _progress(f"Files Loaded: {len(source['paths'])}")
    for symbol in symbols:
        if source["kind"] == "TICKS":
            _progress(f"Ticks Loaded [{symbol}]: {len(grouped_ticks.get(symbol, []))}")
        else:
            _progress(f"Bars Loaded [{symbol}]: {len(grouped_bars.get(symbol, []))}")
    summary_rows: list[dict[str, Any]] = []
    trade_rows: list[dict[str, Any]] = []
    notes: list[str] = list(source["notes"])
    if source["kind"] == "TICKS" and len(filtered_ticks) < MIN_SOURCE_TICKS_FOR_CONFIDENCE:
        notes.append(
            f"Filtered tick sample is only {len(filtered_ticks)} ticks; this is below the {MIN_SOURCE_TICKS_FOR_CONFIDENCE}-tick confidence warning threshold."
        )
    if source["kind"] == "BARS" and len(filtered_bars) < MIN_SAMPLE_SIZE:
        notes.append(f"Filtered bar sample is only {len(filtered_bars)} bars; this is too small for strategy accuracy.")
    date_range = _date_range(filtered_ticks) if source["kind"] == "TICKS" else _date_range(filtered_bars)

    for symbol in symbols:
        if runtime.exceeded():
            break
        symbol_ticks = grouped_ticks.get(symbol, [])
        candles = (
            build_candles_from_ticks_seconds(symbol_ticks, timeframe_seconds=CANDLE_TIMEFRAME_SECONDS)
            if source["kind"] == "TICKS"
            else grouped_bars.get(symbol, [])
        )
        simulation_ticks = symbol_ticks if source["kind"] == "TICKS" else _price_points_from_candles(candles)
        candle_timeframe_seconds = (
            CANDLE_TIMEFRAME_SECONDS
            if source["kind"] == "TICKS"
            else _infer_candle_timeframe_seconds(candles)
        )
        quality_ok, quality_errors = validate_candles(candles)
        bar_rows_by_strategy: dict[str, list[dict[str, Any]]] | None = None
        if source["kind"] == "TICKS" and not symbol_ticks:
            notes.append(f"{symbol}: no matching ticks.")
        elif source["kind"] == "BARS" and not candles:
            notes.append(f"{symbol}: no matching bars.")
        elif len(candles) < MIN_BACKTEST_CANDLES:
            notes.append(f"{symbol}: only {len(candles)} candles; strategy sample is too small.")
        elif not quality_ok:
            notes.append(f"{symbol}: candle quality failed: {'; '.join(quality_errors)}")
        elif source["kind"] == "BARS":
            bar_rows_by_strategy = _run_bar_symbol_strategies_backtest(
                symbol=symbol,
                strategies=selected_strategies,
                candles=candles,
                simulation_ticks=simulation_ticks,
                candle_timeframe_seconds=candle_timeframe_seconds,
                settings=settings,
                risk_config=risk_config,
                instruments=instruments,
                exit_at_end=exit_at_end,
                controls=controls,
                runtime=runtime,
                quality_config=quality_config,
            )

        for strategy in selected_strategies:
            if runtime.exceeded():
                break
            _progress(f"Starting Symbol/Strategy: {symbol} / {strategy}")
            strategy_rows: list[dict[str, Any]] = []
            if bar_rows_by_strategy is not None:
                strategy_rows = bar_rows_by_strategy.get(strategy, [])
                _progress(f"Raw Signals Count Before Simulation [{symbol} / {strategy}]: {len(strategy_rows)}")
                trade_rows.extend(strategy_rows)
            elif candles and len(candles) >= MIN_BACKTEST_CANDLES and quality_ok:
                strategy_rows = _run_symbol_strategy_backtest(
                    symbol=symbol,
                    strategy=strategy,
                    candles=candles,
                    ticks=symbol_ticks,
                    simulation_ticks=simulation_ticks,
                    candle_timeframe_seconds=candle_timeframe_seconds,
                    settings=settings,
                    risk_config=risk_config,
                    instruments=instruments,
                    exit_at_end=exit_at_end,
                    controls=controls,
                    runtime=runtime,
                    quality_config=quality_config,
                )
                trade_rows.extend(strategy_rows)
            else:
                _progress(f"Raw Signals Count Before Simulation [{symbol} / {strategy}]: 0")
            summary = _build_summary_row(
                strategy,
                symbol,
                strategy_rows,
                max_raw_signals_per_day_warning=quality_config.max_raw_signals_per_day_warning,
            )
            if runtime.timed_out:
                summary["sample_status"] = _append_status_flag(summary["sample_status"], "BACKTEST_TIMEOUT")
            summary_rows.append(summary)
            if runtime.timed_out:
                break

    if runtime.timed_out:
        warning = f"BACKTEST_TIMEOUT after {round(time.monotonic() - started_at, 2)} seconds; partial results were saved."
        notes.append(warning)
        _progress(f"Warning: {warning}")

    output_paths = save_strategy_backtest_outputs(
        base,
        summary_rows,
        trade_rows,
        source["paths"],
        selected_strategies,
        symbols,
        len(source["ticks"]),
        len(filtered_ticks),
        len(source["bars"]),
        len(filtered_bars),
        source["kind"],
        date_range,
        exit_at_end,
        controls,
        notes,
    )
    _print_strategy_backtest_summary(
        summary_rows,
        source["paths"],
        selected_strategies,
        symbols,
        len(source["ticks"]),
        len(filtered_ticks),
        len(source["bars"]),
        len(filtered_bars),
        source["kind"],
        date_range,
        exit_at_end,
        controls,
        output_paths,
        notes,
    )
    return StrategyBacktestResult(
        summary_rows=summary_rows,
        trade_rows=trade_rows,
        report_path=output_paths["report"],
        summary_csv_path=output_paths["summary_csv"],
        trades_csv_path=output_paths["trades_csv"],
        tick_file=source["paths"][0] if source["kind"] == "TICKS" and len(source["paths"]) == 1 else None,
        tick_files=source["paths"] if source["kind"] == "TICKS" else [],
        bar_files=source["paths"] if source["kind"] == "BARS" else [],
        date_range=date_range,
        exit_at_end=exit_at_end,
        source_kind=source["kind"],
        total_source_ticks=len(source["ticks"]),
        total_filtered_ticks=len(filtered_ticks),
        total_source_bars=len(source["bars"]),
        total_filtered_bars=len(filtered_bars),
        timed_out=runtime.timed_out,
    )


def _run_bar_symbol_strategies_backtest(
    symbol: str,
    strategies: list[str],
    candles: list[dict[str, Any]],
    simulation_ticks: list[dict[str, Any]],
    candle_timeframe_seconds: int,
    settings: dict[str, Any],
    risk_config: dict[str, Any],
    instruments: dict[str, Any],
    exit_at_end: bool,
    controls: BacktestControls,
    runtime: BacktestRunState,
    quality_config: ClusterSignalQualityConfig,
) -> dict[str, list[dict[str, Any]]]:
    enabled = {name: name in strategies for name in STRATEGY_MODULES}
    engine = StrategyEngine(settings, enabled)
    risk_engine = RiskEngine(risk_config, settings, instruments=instruments)
    quality_states = {name: ClusterSignalQualityState() for name in strategies}
    records: dict[str, list[tuple[Any, ClusterSignalQualityDecision, Any | None, datetime, dict[str, Any]]]] = {
        name: [] for name in strategies
    }
    day_start_index = 0
    current_day = candles[0]["timestamp"].date() if candles else None
    for index in range(MIN_BACKTEST_CANDLES - 1, len(candles)):
        if runtime.exceeded():
            break
        candle_day = candles[index]["timestamp"].date()
        if candle_day != current_day:
            current_day = candle_day
            day_start_index = index
        window = candles[day_start_index:index + 1]
        if len(window) < MIN_BACKTEST_CANDLES:
            continue
        signal_time = window[-1]["timestamp"] + timedelta(seconds=candle_timeframe_seconds)
        result = engine.run(window, [])
        cluster_gate = (getattr(result, "context", {}) or {}).get("cluster_gate") or {}
        for signal in result.candidates:
            strategy = signal.setup_type or _strategy_key_from_name(signal.strategy_name)
            if strategy not in records:
                continue
            quality_decision = quality_states[strategy].evaluate(signal, signal_time, quality_config)
            risk_decision = (
                risk_engine.validate_signal(signal, mode="PAPER", data_quality_ok=True)
                if quality_decision.accepted
                else None
            )
            records[strategy].append((signal, quality_decision, risk_decision, signal_time, cluster_gate))
    return {
        strategy: _process_candidate_records(
            candidate_records=records[strategy],
            simulation_ticks=simulation_ticks,
            controls=controls,
            exit_at_end=exit_at_end,
            runtime=runtime,
        )
        for strategy in strategies
    }


def _run_symbol_strategy_backtest(
    symbol: str,
    strategy: str,
    candles: list[dict[str, Any]],
    ticks: list[dict[str, Any]],
    settings: dict[str, Any],
    risk_config: dict[str, Any],
    instruments: dict[str, Any],
    simulation_ticks: list[dict[str, Any]] | None = None,
    candle_timeframe_seconds: int = CANDLE_TIMEFRAME_SECONDS,
    exit_at_end: bool = False,
    controls: BacktestControls | None = None,
    runtime: BacktestRunState | None = None,
    quality_config: ClusterSignalQualityConfig | None = None,
) -> list[dict[str, Any]]:
    if strategy not in STRATEGY_MODULES:
        return []

    controls = controls or BacktestControls()
    rows: list[dict[str, Any]] = []
    candidate_records: list[
        tuple[Any, ClusterSignalQualityDecision, Any | None, datetime, dict[str, Any]]
    ] = []
    strategy_flags = _single_strategy_flags(strategy)
    engine = StrategyEngine(settings, strategy_flags)
    risk_engine = RiskEngine(risk_config, settings, instruments=instruments)
    cluster_cache = (
        IncrementalClusterDiagnostics(symbol)
        if strategy == "cluster_imbalance_trap" and type(engine) is _DEFAULT_STRATEGY_ENGINE_CLASS
        else None
    )
    tick_times = [tick["timestamp"] for tick in ticks]
    simulation_ticks = ticks if simulation_ticks is None else simulation_ticks
    simulation_times = [tick["timestamp"] for tick in simulation_ticks]
    history_ticks: list[dict[str, Any]] = []
    history_end_index = 0
    quality_state = ClusterSignalQualityState()
    bar_day_start_index = 0
    current_bar_day = candles[0]["timestamp"].date() if candles and not ticks else None

    for index in range(MIN_BACKTEST_CANDLES - 1, len(candles)):
        if runtime is not None and runtime.exceeded():
            break
        if not ticks:
            candle_day = candles[index]["timestamp"].date()
            if current_bar_day != candle_day:
                current_bar_day = candle_day
                bar_day_start_index = index
            candle_window = candles[bar_day_start_index:index + 1]
            if len(candle_window) < MIN_BACKTEST_CANDLES:
                continue
        else:
            candle_window = candles[: index + 1]
        signal_candle = candle_window[-1]
        signal_complete_at = signal_candle["timestamp"] + timedelta(seconds=candle_timeframe_seconds)
        next_history_end = bisect_left(tick_times, signal_complete_at)
        if next_history_end > history_end_index:
            new_history_ticks = ticks[history_end_index:next_history_end]
            history_ticks.extend(new_history_ticks)
            if cluster_cache is not None:
                cluster_cache.extend(new_history_ticks)
            history_end_index = next_history_end
        result = (
            _run_incremental_cluster_strategy(candle_window, history_ticks, settings, cluster_cache)
            if cluster_cache is not None
            else engine.run(candle_window, history_ticks)
        )
        context = getattr(result, "context", {}) or {}
        cluster_gate = context.get("cluster_gate") or {}
        for signal in result.candidates:
            if runtime is not None and runtime.exceeded():
                break
            quality_decision = (
                quality_state.evaluate(signal, signal_complete_at, quality_config)
                if quality_config is not None
                else ClusterSignalQualityDecision(
                    True,
                    "QUALITY_ACCEPTED",
                    trap_strength=float(signal.metadata.get("trap_strength") or 0.0),
                )
            )
            risk_decision = (
                risk_engine.validate_signal(signal, mode="PAPER", data_quality_ok=True)
                if quality_decision.accepted
                else None
            )
            candidate_records.append((signal, quality_decision, risk_decision, signal_complete_at, cluster_gate))

    _progress(f"Raw Signals Count Before Simulation [{symbol} / {strategy}]: {len(candidate_records)}")
    return _process_candidate_records(
        candidate_records=candidate_records,
        simulation_ticks=simulation_ticks,
        controls=controls,
        exit_at_end=exit_at_end,
        runtime=runtime,
    )


def _process_candidate_records(
    candidate_records: list[tuple[Any, ClusterSignalQualityDecision, Any | None, datetime, dict[str, Any]]],
    simulation_ticks: list[dict[str, Any]],
    controls: BacktestControls,
    exit_at_end: bool,
    runtime: BacktestRunState | None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    simulation_times = [tick["timestamp"] for tick in simulation_ticks]
    active_until: datetime | None = None
    cooldown_until: datetime | None = None
    accepted_by_day: dict[Any, int] = {}

    for signal, quality_decision, decision, signal_complete_at, cluster_gate in candidate_records:
        if runtime is not None and runtime.exceeded():
            break
        if not quality_decision.accepted:
            rows.append(
                _build_quality_rejected_row(
                    signal,
                    quality_decision,
                    signal_complete_at,
                    cluster_gate,
                )
            )
            continue
        if decision is None:
            continue
        if not decision.approved:
            rows.append(
                _build_trade_row(
                    signal=signal,
                    decision=decision,
                    future_ticks=[],
                    signal_complete_at=signal_complete_at,
                    cluster_gate=cluster_gate,
                    exit_at_end=exit_at_end,
                    controls=controls,
                    quality_decision=quality_decision,
                )
            )
            continue

        day_key = signal_complete_at.date()
        if controls.one_trade_at_a_time and active_until is not None and signal_complete_at < active_until:
            rows.append(_build_skipped_signal_row(signal, decision, signal_complete_at, cluster_gate, "OVERLAP_SKIPPED", quality_decision))
            continue
        if cooldown_until is not None and signal_complete_at < cooldown_until:
            rows.append(_build_skipped_signal_row(signal, decision, signal_complete_at, cluster_gate, "COOLDOWN_SKIPPED", quality_decision))
            continue
        if controls.max_trades_per_day and accepted_by_day.get(day_key, 0) >= controls.max_trades_per_day:
            rows.append(_build_skipped_signal_row(signal, decision, signal_complete_at, cluster_gate, "DAILY_LIMIT_SKIPPED", quality_decision))
            continue

        future_start_index = bisect_right(simulation_times, signal_complete_at)
        trade_row = _build_trade_row(
                signal=signal,
                decision=decision,
                future_ticks=simulation_ticks,
                future_start_index=future_start_index,
                signal_complete_at=signal_complete_at,
                cluster_gate=cluster_gate,
                exit_at_end=exit_at_end,
                controls=controls,
                runtime=runtime,
                quality_decision=quality_decision,
            )
        rows.append(trade_row)
        accepted_by_day[day_key] = accepted_by_day.get(day_key, 0) + 1
        if trade_row["status"] == "OPEN":
            active_until = datetime.max
        elif trade_row.get("exit_time"):
            active_until = _coerce_datetime(trade_row["exit_time"])
        else:
            active_until = signal_complete_at
        cooldown_until = _coerce_datetime(trade_row.get("entry_time") or signal_complete_at) + timedelta(seconds=controls.signal_cooldown_seconds)
    return rows


def _run_incremental_cluster_strategy(
    candles: list[dict[str, Any]],
    history_ticks: list[dict[str, Any]],
    settings: dict[str, Any],
    diagnostics_cache: IncrementalClusterDiagnostics,
) -> StrategyEngineResult:
    route = route_regime(candles, settings)
    diagnostics = diagnostics_cache.snapshot()
    gate = build_mcx_cluster_gate(diagnostics)
    context = {
        "market_mode": route["market_mode"],
        "preferred_strategies": route["preferred_strategies"],
        "cluster_diagnostics": diagnostics,
        "cluster_gate": gate,
        "clusters": [],
    }
    if context["market_mode"] == "HIGH_VOLATILITY_NEWS":
        return StrategyEngineResult(None, [], ["High volatility news mode: no trade."], context["market_mode"], context)

    signal = cluster_imbalance_trap.generate_signal(candles, context)
    if signal is None:
        context["clusters"] = build_cluster_table(history_ticks) if history_ticks else []
        signal = cluster_imbalance_trap.generate_signal(candles, context)
    if signal is None:
        return StrategyEngineResult(
            None,
            [],
            ["cluster_imbalance_trap: no confirmed setup on latest candle"],
            context["market_mode"],
            context,
        )

    min_score = float(settings.get("min_signal_score", 7))
    if signal.score < min_score:
        return StrategyEngineResult(
            None,
            [],
            [f"cluster_imbalance_trap: score {signal.score} below minimum {min_score}"],
            context["market_mode"],
            context,
        )
    gate_allowed, gate_reason, gate_result = evaluate_mcx_cluster_gate_for_side(gate, signal.side)
    signal.metadata.update({
        "cluster_gate_result": gate_result,
        "cluster_gate_reason": gate_reason,
        "cluster_diagnostic_status": gate.get("diagnostic_status"),
        "cluster_data_sufficient": gate.get("data_sufficient"),
        "execution_allowed": False,
    })
    if not gate_allowed:
        return StrategyEngineResult(None, [], [f"cluster_imbalance_trap: {gate_reason}"], context["market_mode"], context)
    return StrategyEngineResult(signal, [signal], [], context["market_mode"], context)


def _build_trade_row(
    signal,
    decision,
    future_ticks: list[dict[str, Any]],
    signal_complete_at: datetime,
    cluster_gate: dict[str, Any],
    exit_at_end: bool = False,
    controls: BacktestControls | None = None,
    future_start_index: int = 0,
    runtime: BacktestRunState | None = None,
    quality_decision: ClusterSignalQualityDecision | None = None,
) -> dict[str, Any]:
    controls = controls or BacktestControls()
    sizing = getattr(decision, "sizing", {}) or {}
    risk_reasons = list(getattr(decision, "reasons", []) or [])
    if not decision.approved:
        return {
            "signal_time": signal_complete_at,
            "symbol": signal.symbol,
            "strategy": signal.setup_type or _strategy_key_from_name(signal.strategy_name),
            "direction": signal.side,
            **_quality_fields(signal, quality_decision),
            "entry_time": signal_complete_at,
            "entry_price": signal.entry_price,
            "adjusted_entry": "",
            "stop": signal.stop_loss,
            "target": signal.target_price,
            "exit_time": "",
            "exit_price": "",
            "adjusted_exit": "",
            "qty": 0,
            "status": "RISK_REJECTED",
            "outcome": "RISK_REJECTED",
            "risk_status": "REJECTED",
            "gross_pnl": 0.0,
            "cost": 0.0,
            "net_pnl": 0.0,
            "rr": signal.reward_risk,
            "r_multiple": 0.0,
            "mfe": 0.0,
            "mae": 0.0,
            "score": signal.score,
            "market_mode": signal.market_mode,
            "reason": signal.reason,
            "rejection_reason": "; ".join(str(reason) for reason in risk_reasons),
            "risk_budget": sizing.get("allowed_risk_amount"),
            "estimated_risk_amount": sizing.get("estimated_risk_amount", 0.0),
            "cluster_status": signal.metadata.get("cluster_diagnostic_status")
            or cluster_gate.get("diagnostic_status", "NOT_APPLICABLE"),
            "cluster_gate_status": signal.metadata.get("cluster_gate_result")
            or cluster_gate.get("gate_status", "NOT_APPLICABLE"),
            "execution_allowed": False,
            **_execution_metadata_fields(controls),
        }

    simulation = _simulate_paper_trade(
        signal,
        int(decision.quantity),
        future_ticks,
        signal_complete_at=signal_complete_at,
        exit_at_end=exit_at_end,
        controls=controls,
        future_start_index=future_start_index,
        runtime=runtime,
    )
    return {
        "signal_time": signal_complete_at,
        "symbol": signal.symbol,
        "strategy": signal.setup_type or _strategy_key_from_name(signal.strategy_name),
        "direction": signal.side,
        **_quality_fields(signal, quality_decision),
        "entry_time": simulation["entry_time"],
        "entry_price": simulation["entry_price"],
        "adjusted_entry": simulation["adjusted_entry"],
        "stop": signal.stop_loss,
        "target": signal.target_price,
        "exit_time": simulation["exit_time"],
        "exit_price": simulation["exit_price"],
        "adjusted_exit": simulation["adjusted_exit"],
        "qty": int(decision.quantity),
        "status": simulation["status"],
        "outcome": simulation["status"],
        "risk_status": "APPROVED",
        "gross_pnl": simulation["gross_pnl"],
        "cost": simulation["cost"],
        "net_pnl": simulation["net_pnl"],
        "rr": signal.reward_risk,
        "r_multiple": simulation["r_multiple"],
        "mfe": simulation["mfe"],
        "mae": simulation["mae"],
        "score": signal.score,
        "market_mode": signal.market_mode,
        "reason": signal.reason,
        "rejection_reason": "",
        "risk_budget": sizing.get("allowed_risk_amount"),
        "estimated_risk_amount": sizing.get("estimated_risk_amount", decision.risk_amount),
        "cluster_status": signal.metadata.get("cluster_diagnostic_status")
        or cluster_gate.get("diagnostic_status", "NOT_APPLICABLE"),
        "cluster_gate_status": signal.metadata.get("cluster_gate_result")
        or cluster_gate.get("gate_status", "NOT_APPLICABLE"),
        "execution_allowed": False,
        "execution_model": simulation["execution_model"],
        "approval_grade_execution_ready": simulation["approval_grade_execution_ready"],
        "entry_timing": simulation["entry_timing"],
        "entry_delay_ticks": simulation["entry_delay_ticks"],
        "cost_per_trade": simulation["cost_per_trade"],
        "slippage_points": simulation["slippage_points"],
        "spread_points": simulation["spread_points"],
        "tick_size": simulation["tick_size"],
        "same_bar_rule": simulation["same_bar_rule"],
    }


def _build_quality_rejected_row(
    signal,
    quality_decision: ClusterSignalQualityDecision,
    signal_complete_at: datetime,
    cluster_gate: dict[str, Any],
) -> dict[str, Any]:
    return {
        "signal_time": signal_complete_at,
        "symbol": signal.symbol,
        "strategy": signal.setup_type or _strategy_key_from_name(signal.strategy_name),
        "direction": signal.side,
        **_quality_fields(signal, quality_decision),
        "entry_time": signal_complete_at,
        "entry_price": signal.entry_price,
        "adjusted_entry": "",
        "stop": signal.stop_loss,
        "target": signal.target_price,
        "exit_time": "",
        "exit_price": "",
        "adjusted_exit": "",
        "qty": 0,
        "status": "QUALITY_REJECTED",
        "outcome": "QUALITY_REJECTED",
        "gross_pnl": 0.0,
        "cost": 0.0,
        "net_pnl": 0.0,
        "rr": signal.reward_risk,
        "r_multiple": 0.0,
        "mfe": 0.0,
        "mae": 0.0,
        "risk_status": "NOT_EVALUATED",
        "score": signal.score,
        "market_mode": signal.market_mode,
        "reason": signal.reason,
        "rejection_reason": quality_decision.reason_text,
        "risk_budget": "",
        "estimated_risk_amount": 0.0,
        "cluster_status": signal.metadata.get("cluster_diagnostic_status")
        or cluster_gate.get("diagnostic_status", "NOT_APPLICABLE"),
        "cluster_gate_status": signal.metadata.get("cluster_gate_result")
        or cluster_gate.get("gate_status", "NOT_APPLICABLE"),
        "quality_rejection_codes": quality_decision.reason_codes,
        "execution_allowed": False,
    }


def _build_skipped_signal_row(
    signal,
    decision,
    signal_complete_at: datetime,
    cluster_gate: dict[str, Any],
    status: str,
    quality_decision: ClusterSignalQualityDecision | None = None,
) -> dict[str, Any]:
    sizing = getattr(decision, "sizing", {}) or {}
    return {
        "signal_time": signal_complete_at,
        "symbol": signal.symbol,
        "strategy": signal.setup_type or _strategy_key_from_name(signal.strategy_name),
        "direction": signal.side,
        **_quality_fields(signal, quality_decision),
        "entry_time": signal_complete_at,
        "entry_price": signal.entry_price,
        "adjusted_entry": "",
        "stop": signal.stop_loss,
        "target": signal.target_price,
        "exit_time": "",
        "exit_price": "",
        "adjusted_exit": "",
        "qty": 0,
        "status": status,
        "outcome": status,
        "gross_pnl": 0.0,
        "cost": 0.0,
        "net_pnl": 0.0,
        "rr": signal.reward_risk,
        "r_multiple": 0.0,
        "mfe": 0.0,
        "mae": 0.0,
        "risk_status": "SKIPPED",
        "score": signal.score,
        "market_mode": signal.market_mode,
        "reason": signal.reason,
        "rejection_reason": status.lower().replace("_", " "),
        "risk_budget": sizing.get("allowed_risk_amount"),
        "estimated_risk_amount": sizing.get("estimated_risk_amount", decision.risk_amount),
        "cluster_status": signal.metadata.get("cluster_diagnostic_status")
        or cluster_gate.get("diagnostic_status", "NOT_APPLICABLE"),
        "cluster_gate_status": signal.metadata.get("cluster_gate_result")
        or cluster_gate.get("gate_status", "NOT_APPLICABLE"),
        "execution_allowed": False,
    }


def _quality_fields(signal, decision: ClusterSignalQualityDecision | None) -> dict[str, Any]:
    status = decision.status if decision is not None else "QUALITY_ACCEPTED"
    reason = decision.reason_text if decision is not None else ""
    strength = (
        decision.trap_strength
        if decision is not None
        else float(signal.metadata.get("trap_strength") or 0.0)
    )
    return {
        "quality_status": status,
        "quality_rejection_reason": reason,
        "signal_score": signal.score,
        "trap_strength": round(float(strength), 4),
    }


def _simulate_paper_trade(
    signal,
    quantity: int,
    future_ticks: list[dict[str, Any]],
    signal_complete_at: datetime,
    exit_at_end: bool = False,
    controls: BacktestControls | None = None,
    future_start_index: int = 0,
    runtime: BacktestRunState | None = None,
) -> dict[str, Any]:
    controls = controls or BacktestControls()
    entry_index = max(0, int(future_start_index)) + controls.entry_delay_ticks - 1
    if len(future_ticks) > entry_index:
        entry_tick = future_ticks[entry_index]
        entry_time = entry_tick["timestamp"]
        entry = float(entry_tick["ltp"])
        exit_start_index = entry_index + 1
    else:
        entry_time = signal_complete_at
        entry = float(signal.entry_price)
        exit_start_index = len(future_ticks)

    side = str(signal.side).upper()
    adjusted_entry = _apply_conservative_entry_price(entry, side, controls)
    stop = _round_conservative_price(float(signal.stop_loss), side, "stop", controls)
    target = _round_conservative_price(float(signal.target_price), side, "target", controls)
    risk_per_unit = abs(adjusted_entry - stop)
    exit_time = ""
    exit_price = ""
    adjusted_exit: float | str = ""
    status = "OPEN"
    interrupted = False
    mfe = 0.0
    mae = 0.0

    for tick_index in range(exit_start_index, len(future_ticks)):
        if runtime is not None and tick_index % 1024 == 0 and runtime.exceeded():
            interrupted = True
            break
        tick = future_ticks[tick_index]
        price = float(tick["ltp"])
        if side == "BUY":
            mfe = max(mfe, price - adjusted_entry)
            mae = max(mae, adjusted_entry - price)
            if price <= stop:
                exit_time = tick["timestamp"]
                exit_price = stop
                status = "LOSS"
                break
            if price >= target:
                exit_time = tick["timestamp"]
                exit_price = target
                status = "WIN"
                break
        else:
            mfe = max(mfe, adjusted_entry - price)
            mae = max(mae, price - adjusted_entry)
            if price >= stop:
                exit_time = tick["timestamp"]
                exit_price = stop
                status = "LOSS"
                break
            if price <= target:
                exit_time = tick["timestamp"]
                exit_price = target
                status = "WIN"
                break

    if status == "OPEN":
        if interrupted:
            return {
                "status": status,
                "entry_time": entry_time,
                "entry_price": round(entry, 2),
                "adjusted_entry": round(adjusted_entry, 2),
                "exit_time": "",
                "exit_price": "",
                "adjusted_exit": "",
                "gross_pnl": 0.0,
                "cost": 0.0,
                "net_pnl": 0.0,
                "r_multiple": 0.0,
                "mfe": round(mfe, 2),
                "mae": round(mae, 2),
                **_execution_metadata_fields(controls),
            }
        if exit_at_end:
            end_tick = future_ticks[-1] if entry_index < len(future_ticks) else {"timestamp": entry_time, "ltp": entry}
            exit_time = end_tick["timestamp"]
            exit_price = float(end_tick["ltp"])
            status = "END_EXIT"
        else:
            gross_pnl = 0.0
            net_pnl = 0.0
            return {
                "status": status,
                "entry_time": entry_time,
                "entry_price": round(entry, 2),
                "adjusted_entry": round(adjusted_entry, 2),
                "exit_time": "",
                "exit_price": "",
                "adjusted_exit": "",
                "gross_pnl": gross_pnl,
                "cost": 0.0,
                "net_pnl": net_pnl,
                "r_multiple": 0.0,
                "mfe": round(mfe, 2),
                "mae": round(mae, 2),
                **_execution_metadata_fields(controls),
            }

    adjusted_exit = _apply_conservative_exit_price(float(exit_price), side, controls)
    gross_pnl = (adjusted_exit - adjusted_entry) * quantity if side == "BUY" else (adjusted_entry - adjusted_exit) * quantity
    cost = controls.cost_per_trade
    net_pnl = gross_pnl - cost
    r_multiple = net_pnl / (risk_per_unit * quantity) if risk_per_unit and quantity else 0.0

    return {
        "status": status,
        "entry_time": entry_time,
        "entry_price": round(entry, 2),
        "adjusted_entry": round(adjusted_entry, 2),
        "exit_time": exit_time,
        "exit_price": round(exit_price, 2) if exit_price is not None else None,
        "adjusted_exit": round(adjusted_exit, 2),
        "gross_pnl": round(gross_pnl, 2),
        "cost": round(cost, 2),
        "net_pnl": round(net_pnl, 2),
        "r_multiple": round(r_multiple, 2),
        "mfe": round(mfe, 2),
        "mae": round(mae, 2),
        **_execution_metadata_fields(controls),
    }


def _build_summary_row(
    strategy: str,
    symbol: str,
    rows: list[dict[str, Any]],
    max_raw_signals_per_day_warning: int = 100,
) -> dict[str, Any]:
    quality_rejected_rows = [row for row in rows if row.get("quality_status") == "QUALITY_REJECTED"]
    quality_accepted_rows = [row for row in rows if row.get("quality_status", "QUALITY_ACCEPTED") == "QUALITY_ACCEPTED"]
    accepted = [row for row in rows if row["risk_status"] == "APPROVED"]
    rejected = [row for row in rows if row["status"] == "RISK_REJECTED"]
    overlap_skipped = [row for row in rows if row["status"] == "OVERLAP_SKIPPED"]
    cooldown_skipped = [row for row in rows if row["status"] == "COOLDOWN_SKIPPED"]
    daily_limit_skipped = [row for row in rows if row["status"] == "DAILY_LIMIT_SKIPPED"]
    wins = [row for row in accepted if row["status"] == "WIN"]
    losses = [row for row in accepted if row["status"] == "LOSS"]
    open_trades = [row for row in accepted if row["status"] == "OPEN"]
    end_exits = [row for row in accepted if row["status"] == "END_EXIT"]
    closed_for_win_rate = wins + losses
    closed_for_expectancy = wins + losses + end_exits
    net_pnls = [float(row.get("net_pnl") or 0.0) for row in closed_for_expectancy]
    gross_pnls = [float(row.get("gross_pnl") or 0.0) for row in closed_for_expectancy]
    costs = [float(row.get("cost") or 0.0) for row in closed_for_expectancy]
    profits = [pnl for pnl in net_pnls if pnl > 0]
    loss_values = [pnl for pnl in net_pnls if pnl < 0]
    signals = len(rows)
    sample_status = _sample_status(rows, accepted, max_raw_signals_per_day_warning)
    first_execution_row = next((row for row in rows if row.get("execution_model")), {})
    summary = {
        "strategy": strategy,
        "symbol": symbol,
        "signals": signals,
        "raw_signals": signals,
        "quality_accepted_signals": len(quality_accepted_rows),
        "quality_rejected": len(quality_rejected_rows),
        "weak_trap_rejected": _quality_code_count(quality_rejected_rows, "WEAK_TRAP"),
        "bad_stop_distance_rejected": _quality_code_count(quality_rejected_rows, "BAD_STOP_DISTANCE"),
        "bad_target_distance_rejected": _quality_code_count(quality_rejected_rows, "BAD_TARGET_DISTANCE"),
        "direction_flip_rejected": _quality_code_count(quality_rejected_rows, "DIRECTION_FLIP"),
        "same_zone_rejected": _quality_code_count(quality_rejected_rows, "SAME_ZONE"),
        "market_mode_rejected": _quality_code_count(quality_rejected_rows, "MARKET_MODE"),
        "accepted": len(accepted),
        "wins": len(wins),
        "losses": len(losses),
        "open": len(open_trades),
        "end_exit": len(end_exits),
        "risk_rejected": len(rejected),
        "overlap_skipped": len(overlap_skipped),
        "cooldown_skipped": len(cooldown_skipped),
        "daily_limit_skipped": len(daily_limit_skipped),
        "gross_pnl": round(sum(gross_pnls), 2),
        "net_pnl": round(sum(net_pnls), 2),
        "costs": round(sum(costs), 2),
        "win_rate": round((len(wins) / len(closed_for_win_rate) * 100) if closed_for_win_rate else 0.0, 2),
        "profit_factor": _round_profit_factor(sum(profits), sum(loss_values)),
        "expectancy": round(sum(net_pnls) / len(closed_for_expectancy), 2) if closed_for_expectancy else 0.0,
        "max_drawdown": round(_max_drawdown(net_pnls), 2),
        "sample_status": sample_status,
        "execution_allowed": False,
        "execution_model": first_execution_row.get("execution_model", ""),
        "approval_grade_execution_ready": first_execution_row.get("approval_grade_execution_ready", False),
        "entry_timing": first_execution_row.get("entry_timing", ""),
        "entry_delay_ticks": first_execution_row.get("entry_delay_ticks", ""),
        "cost_per_trade": first_execution_row.get("cost_per_trade", ""),
        "slippage_points": first_execution_row.get("slippage_points", ""),
        "spread_points": first_execution_row.get("spread_points", ""),
        "tick_size": first_execution_row.get("tick_size", ""),
        "same_bar_rule": first_execution_row.get("same_bar_rule", ""),
    }
    summary.update({
        "total_signals": signals,
        "accepted_signals": len(accepted),
        "risk_rejected_signals": len(rejected),
        "open_trades": len(open_trades),
        "end_exit_trades": len(end_exits),
    })
    return summary


def _quality_code_count(rows: list[dict[str, Any]], code: str) -> int:
    return sum(1 for row in rows if code in set(row.get("quality_rejection_codes") or ()))


def _sample_status(
    rows: list[dict[str, Any]],
    accepted: list[dict[str, Any]],
    max_raw_signals_per_day_warning: int = 100,
) -> str:
    flags: list[str] = []
    if len(rows) < MIN_SAMPLE_SIZE:
        flags.append("INSUFFICIENT_SAMPLE")
    raw_by_day: dict[Any, int] = {}
    for row in rows:
        timestamp = _coerce_datetime(row.get("signal_time"))
        raw_by_day[timestamp.date()] = raw_by_day.get(timestamp.date(), 0) + 1
    if any(count > max_raw_signals_per_day_warning for count in raw_by_day.values()) or (
        len(rows) >= max(len(accepted) * 3, len(accepted) + 10) and len(rows) > 0
    ):
        flags.append("HIGH_SIGNAL_FREQUENCY_WARNING")
    quality_rejected = sum(1 for row in rows if row.get("quality_status") == "QUALITY_REJECTED")
    if quality_rejected >= max(1, int(len(rows) * 0.05)):
        flags.append("SIGNAL_FILTERING_ACTIVE")
    return ";".join(flags) if flags else "OK"


def save_strategy_backtest_outputs(
    base: Path,
    summary_rows: list[dict[str, Any]],
    trade_rows: list[dict[str, Any]],
    source_paths: list[Path],
    selected_strategies: list[str],
    symbols: list[str],
    total_source_ticks: int,
    total_filtered_ticks: int,
    total_source_bars: int,
    total_filtered_bars: int,
    source_kind: str,
    date_range: str,
    exit_at_end: bool,
    controls: BacktestControls,
    notes: list[str],
) -> dict[str, Path]:
    report_dir = base / "reports" / "backtests"
    report_dir.mkdir(parents=True, exist_ok=True)
    summary_csv = report_dir / "latest_strategy_backtest_summary.csv"
    trades_csv = report_dir / "latest_strategy_backtest_trades.csv"
    report_txt = report_dir / "latest_strategy_backtest_report.txt"

    with summary_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for row in summary_rows:
            output = dict(row)
            output["execution_allowed"] = "false"
            writer.writerow(output)

    with trades_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TRADE_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for row in trade_rows:
            output = dict(row)
            output["execution_allowed"] = "false"
            writer.writerow(output)

    report_txt.write_text(
        _format_strategy_backtest_report(
            summary_rows,
            trade_rows,
            source_paths,
            selected_strategies,
            symbols,
            total_source_ticks,
            total_filtered_ticks,
            total_source_bars,
            total_filtered_bars,
            source_kind,
            date_range,
            exit_at_end,
            controls,
            notes,
        )
        + "\n",
        encoding="utf-8",
    )
    return {"summary_csv": summary_csv, "trades_csv": trades_csv, "report": report_txt}


def _format_strategy_backtest_report(
    summary_rows: list[dict[str, Any]],
    trade_rows: list[dict[str, Any]],
    source_paths: list[Path],
    selected_strategies: list[str],
    symbols: list[str],
    total_source_ticks: int,
    total_filtered_ticks: int,
    total_source_bars: int,
    total_filtered_bars: int,
    source_kind: str,
    date_range: str,
    exit_at_end: bool,
    controls: BacktestControls,
    notes: list[str],
) -> str:
    lines = [
        "STRATEGY BACKTEST SUMMARY",
        "Mode: PAPER",
        "Data Feed: REPLAY",
        f"Source Kind: {source_kind}",
        f"Files Loaded: {len(source_paths)}",
        f"Source Files: {_format_tick_sources(source_paths)}",
        f"Date Range: {date_range}",
        f"Exit At End: {'true' if exit_at_end else 'false'}",
        f"One Trade At A Time: {'true' if controls.one_trade_at_a_time else 'false'}",
        f"Signal Cooldown Seconds: {controls.signal_cooldown_seconds}",
        f"Max Trades Per Day: {controls.max_trades_per_day}",
        f"Slippage Points: {controls.slippage_points}",
        f"Cost Per Trade: {controls.cost_per_trade}",
        f"Entry Delay Ticks: {controls.entry_delay_ticks}",
        f"Execution Model: {controls.execution_model}",
        f"Approval Grade Execution Ready: {str(controls.approval_grade_execution_ready).lower()}",
        f"Entry Timing: {_execution_metadata_fields(controls)['entry_timing']}",
        f"Spread Points: {controls.spread_points}",
        f"Tick Size: {controls.tick_size}",
        f"Same Bar Rule: {controls.same_bar_rule}",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "PAPER MODE ONLY. No broker orders were placed.",
        f"Symbols: {', '.join(symbols)}",
        f"Strategies: {', '.join(selected_strategies)}",
        f"Source Ticks: {total_source_ticks}",
        f"Filtered Ticks: {total_filtered_ticks}",
        f"Source Bars: {total_source_bars}",
        f"Filtered Bars: {total_filtered_bars}",
        f"Trade Candidate Rows: {len(trade_rows)}",
        "",
        "PER STRATEGY / SYMBOL METRICS",
    ]
    for row in summary_rows:
        lines.append(
            "- "
            f"{row['symbol']} {row['strategy']}: "
            f"raw_signals={row['raw_signals']} quality_accepted_signals={row['quality_accepted_signals']} "
            f"quality_rejected={row['quality_rejected']} risk_rejected={row['risk_rejected']} "
            f"accepted_trades={row['accepted']} wins={row['wins']} "
            f"losses={row['losses']} open={row['open']} end_exit={row['end_exit']} "
            f"overlap_skipped={row['overlap_skipped']} "
            f"cooldown_skipped={row['cooldown_skipped']} daily_limit_skipped={row['daily_limit_skipped']} "
            f"gross_pnl={row['gross_pnl']} net_pnl={row['net_pnl']} costs={row['costs']} "
            f"win_rate={row['win_rate']}% pf={_fmt_pf(row['profit_factor'])} "
            f"expectancy={row['expectancy']} max_dd={row['max_drawdown']} sample={row['sample_status']}"
        )
        lines.append(
            "  Quality counters: "
            f"weak_trap={row['weak_trap_rejected']} bad_stop={row['bad_stop_distance_rejected']} "
            f"bad_target={row['bad_target_distance_rejected']} direction_flip={row['direction_flip_rejected']} "
            f"same_zone={row['same_zone_rejected']} market_mode={row['market_mode_rejected']}"
        )
        if "HIGH_SIGNAL_FREQUENCY_WARNING" in str(row.get("sample_status", "")):
            lines.append(f"  Warning: HIGH_SIGNAL_FREQUENCY_WARNING for {row['symbol']} {row['strategy']}")
        if "SIGNAL_FILTERING_ACTIVE" in str(row.get("sample_status", "")):
            lines.append(f"  Status: SIGNAL_FILTERING_ACTIVE for {row['symbol']} {row['strategy']}")
    if notes:
        lines.extend(["", "NOTES"])
        lines.extend(f"- {note}" for note in notes)
    missing_modules = [strategy for strategy in selected_strategies if strategy not in STRATEGY_MODULES]
    if missing_modules:
        lines.extend(["", "STRATEGY MODULE NOTES"])
        for strategy in missing_modules:
            lines.append(f"- {strategy}: no standalone strategy module is registered, so no candidate signals were generated.")
    lines.extend([
        "",
        "Safety: PAPER/manual review only. No broker order path is imported or called by this runner.",
        "execution_allowed=false",
    ])
    return "\n".join(lines)


def _print_strategy_backtest_summary(
    summary_rows: list[dict[str, Any]],
    source_paths: list[Path],
    selected_strategies: list[str],
    symbols: list[str],
    total_source_ticks: int,
    total_filtered_ticks: int,
    total_source_bars: int,
    total_filtered_bars: int,
    source_kind: str,
    date_range: str,
    exit_at_end: bool,
    controls: BacktestControls,
    output_paths: dict[str, Path],
    notes: list[str],
) -> None:
    print("STRATEGY BACKTEST SUMMARY")
    print("Mode: PAPER")
    print("Data Feed: REPLAY")
    print(f"Source Kind: {source_kind}")
    print(f"Files Loaded: {len(source_paths)}")
    print(f"Source Files: {_format_tick_sources(source_paths)}")
    print(f"Date Range: {date_range}")
    print(f"Exit At End: {'true' if exit_at_end else 'false'}")
    print(f"One Trade At A Time: {'true' if controls.one_trade_at_a_time else 'false'}")
    print(f"Signal Cooldown Seconds: {controls.signal_cooldown_seconds}")
    print(f"Max Trades Per Day: {controls.max_trades_per_day}")
    print(f"Slippage Points: {controls.slippage_points}")
    print(f"Cost Per Trade: {controls.cost_per_trade}")
    print(f"Entry Delay Ticks: {controls.entry_delay_ticks}")
    print(f"Execution Model: {controls.execution_model}")
    print(f"Approval Grade Execution Ready: {str(controls.approval_grade_execution_ready).lower()}")
    print(f"Entry Timing: {_execution_metadata_fields(controls)['entry_timing']}")
    print(f"Spread Points: {controls.spread_points}")
    print(f"Tick Size: {controls.tick_size}")
    print(f"Same Bar Rule: {controls.same_bar_rule}")
    print("Live Trading: DISABLED")
    print("Broker Orders: DISABLED")
    print("execution_allowed=false")
    print("PAPER MODE ONLY. No broker orders were placed.")
    print(f"Symbols: {', '.join(symbols)}")
    print(f"Strategies: {', '.join(selected_strategies)}")
    print(f"Source Ticks: {total_source_ticks}")
    print(f"Filtered Ticks: {total_filtered_ticks}")
    print(f"Source Bars: {total_source_bars}")
    print(f"Filtered Bars: {total_filtered_bars}")
    for row in summary_rows:
        print(
            f"- {row['symbol']} {row['strategy']}: "
            f"raw_signals={row['raw_signals']} quality_accepted_signals={row['quality_accepted_signals']} "
            f"quality_rejected={row['quality_rejected']} risk_rejected={row['risk_rejected']} "
            f"accepted_trades={row['accepted']} wins={row['wins']} "
            f"losses={row['losses']} open={row['open']} end_exit={row['end_exit']} "
            f"overlap_skipped={row['overlap_skipped']} "
            f"cooldown_skipped={row['cooldown_skipped']} daily_limit_skipped={row['daily_limit_skipped']} "
            f"gross_pnl={row['gross_pnl']} net_pnl={row['net_pnl']} costs={row['costs']} "
            f"win_rate={row['win_rate']}% pf={_fmt_pf(row['profit_factor'])} "
            f"expectancy={row['expectancy']} sample={row['sample_status']}"
        )
        print(
            "  Quality counters: "
            f"weak_trap={row['weak_trap_rejected']} bad_stop={row['bad_stop_distance_rejected']} "
            f"bad_target={row['bad_target_distance_rejected']} direction_flip={row['direction_flip_rejected']} "
            f"same_zone={row['same_zone_rejected']} market_mode={row['market_mode_rejected']}"
        )
        if "HIGH_SIGNAL_FREQUENCY_WARNING" in str(row.get("sample_status", "")):
            print(f"  Warning: HIGH_SIGNAL_FREQUENCY_WARNING for {row['symbol']} {row['strategy']}")
        if "SIGNAL_FILTERING_ACTIVE" in str(row.get("sample_status", "")):
            print(f"  Status: SIGNAL_FILTERING_ACTIVE for {row['symbol']} {row['strategy']}")
    if notes:
        print("Notes:")
        for note in notes:
            print(f"- {note}")
    print(f"Summary CSV: {output_paths['summary_csv']}")
    print(f"Trades CSV: {output_paths['trades_csv']}")
    print(f"Report: {output_paths['report']}")
    print("Safety: PAPER ONLY. Broker Orders: DISABLED. execution_allowed=false")


def _single_strategy_flags(strategy: str) -> dict[str, bool]:
    names = set(BACKTEST_STRATEGIES) | set(STRATEGY_MODULES)
    return {name: name == strategy for name in names}


def _load_backtest_source(
    base: Path,
    tick_file: str | None,
    tick_dir: str | None,
    bar_dir: str | None,
    from_day: date | None = None,
    to_day: date | None = None,
    symbols: list[str] | None = None,
) -> dict[str, Any]:
    if tick_file or tick_dir:
        ticks, paths, notes = _load_backtest_ticks(
            base,
            tick_file,
            tick_dir,
            from_day=from_day,
            to_day=to_day,
            symbols=symbols,
        )
        if bar_dir:
            notes.append("Both tick and bar sources were supplied; tick source was used because tick/order-flow strategies prefer ticks.")
        return {"kind": "TICKS", "ticks": ticks, "bars": [], "paths": paths, "notes": notes}
    if bar_dir:
        bars, paths, notes = _load_backtest_bars(base, bar_dir, from_day=from_day, to_day=to_day)
        return {"kind": "BARS", "ticks": [], "bars": bars, "paths": paths, "notes": notes}
    raise StrategyBacktestError("Provide --tick-file, --tick-dir, or --bar-dir for the PAPER backtest.")


def _load_backtest_ticks(
    base: Path,
    tick_file: str | None,
    tick_dir: str | None,
    from_day: date | None = None,
    to_day: date | None = None,
    symbols: list[str] | None = None,
) -> tuple[list[dict[str, Any]], list[Path], list[str]]:
    paths: list[Path] = []
    if tick_file:
        paths.append(resolve_tick_file(base, tick_file))
    if tick_dir:
        directory = Path(tick_dir)
        directory = directory if directory.is_absolute() else base / directory
        if not directory.exists():
            raise StrategyBacktestError(f"Backtest tick directory missing: {directory}")
        paths.extend(
            sorted(
                path
                for path in directory.rglob("*_ticks.csv")
                if path.is_file()
                and _path_matches_date_filter(path, from_day, to_day)
                and _path_matches_symbol_filter(path, symbols)
            )
        )
    if not paths:
        raise StrategyBacktestError("Provide --tick-file or --tick-dir for the PAPER backtest.")

    unique_paths: list[Path] = []
    seen_paths: set[Path] = set()
    for path in paths:
        resolved = path.resolve()
        if resolved in seen_paths:
            continue
        seen_paths.add(resolved)
        unique_paths.append(path)
    if not unique_paths:
        date_text = _format_date_filter(from_day, to_day)
        raise StrategyBacktestError(f"No tick files found for the PAPER backtest{date_text}.")

    _progress(f"Files Loaded: {len(unique_paths)} (selected; reading rows)")
    ticks: list[dict[str, Any]] = []
    notes: list[str] = []
    for path in unique_paths:
        try:
            loaded = load_tick_csv(path)
        except FileNotFoundError as exc:
            raise StrategyBacktestError(f"Backtest tick file missing: {path}") from exc
        except TickCsvError as exc:
            raise StrategyBacktestError(f"Backtest tick CSV invalid: {path}: {exc}") from exc
        loaded = _filter_rows_by_date(loaded, from_day, to_day)
        ticks.extend(loaded)
        _progress(f"Loaded {len(loaded)} ticks: {path}")
        if not loaded:
            notes.append(f"{path}: no ticks loaded.")

    deduped = _dedupe_ticks(ticks)
    if len(deduped) < len(ticks):
        notes.append(f"Deduped {len(ticks) - len(deduped)} duplicate ticks across loaded files.")
    deduped.sort(key=lambda tick: (tick["timestamp"], tick.get("symbol", "")))
    return deduped, unique_paths, notes


def _load_backtest_bars(
    base: Path,
    bar_dir: str,
    from_day: date | None = None,
    to_day: date | None = None,
) -> tuple[list[dict[str, Any]], list[Path], list[str]]:
    directory = Path(bar_dir)
    directory = directory if directory.is_absolute() else base / directory
    if not directory.exists():
        raise StrategyBacktestError(f"Backtest bar directory missing: {directory}")
    paths = sorted(
        path
        for pattern in ("*_bars.csv", "*_candles.csv")
        for path in directory.rglob(pattern)
        if path.is_file() and _path_matches_date_filter(path, from_day, to_day)
    )
    unique_paths: list[Path] = []
    seen_paths: set[Path] = set()
    for path in paths:
        resolved = path.resolve()
        if resolved in seen_paths:
            continue
        seen_paths.add(resolved)
        unique_paths.append(path)
    if not unique_paths:
        raise StrategyBacktestError(
            f"No historical bar/candle files found under: {directory}{_format_date_filter(from_day, to_day)}"
        )
    _progress(f"Files Loaded: {len(unique_paths)} (selected; reading rows)")
    bars: list[dict[str, Any]] = []
    notes: list[str] = []
    for path in unique_paths:
        loaded = _load_bar_csv(path)
        loaded = _filter_rows_by_date(loaded, from_day, to_day)
        bars.extend(loaded)
        _progress(f"Loaded {len(loaded)} bars: {path}")
        if not loaded:
            notes.append(f"{path}: no bars loaded.")
    deduped = _dedupe_bars(bars)
    if len(deduped) < len(bars):
        notes.append(f"Deduped {len(bars) - len(deduped)} duplicate bars across loaded files.")
    deduped.sort(key=lambda row: (row["timestamp"], row.get("symbol", "")))
    return deduped, unique_paths, notes


def _load_bar_csv(path: Path) -> list[dict[str, Any]]:
    with path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        missing = [column for column in BAR_COLUMNS if column not in fieldnames]
        if missing:
            raise StrategyBacktestError(f"Backtest bar CSV invalid: {path}: missing columns {', '.join(missing)}")
        return [_parse_bar_row(row, path, index + 2) for index, row in enumerate(reader)]


def _parse_bar_row(row: dict[str, str], path: Path, row_number: int) -> dict[str, Any]:
    try:
        return {
            "timestamp": _parse_timestamp(row["timestamp"]),
            "symbol": row["symbol"].strip(),
            "open": float(row["open"]),
            "high": float(row["high"]),
            "low": float(row["low"]),
            "close": float(row["close"]),
            "volume": float(row["volume"] or 0),
            "oi": float(row["oi"]) if row.get("oi") not in {None, ""} else None,
            "source": row.get("source", ""),
            "interval": row.get("interval", ""),
        }
    except Exception as exc:
        raise StrategyBacktestError(f"Backtest bar CSV row {row_number} invalid in {path}: {type(exc).__name__}") from exc


def _parse_timestamp(value: str) -> datetime:
    text = str(value or "").strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    return datetime.fromisoformat(text)


def _parse_optional_date(value: str | date | None, option_name: str) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value).strip())
    except ValueError as exc:
        raise StrategyBacktestError(f"{option_name} must use YYYY-MM-DD format.") from exc


def _path_matches_date_filter(path: Path, from_day: date | None, to_day: date | None) -> bool:
    if from_day is None and to_day is None:
        return True
    path_day: date | None = None
    for part in reversed(path.parts):
        try:
            path_day = date.fromisoformat(part)
            break
        except ValueError:
            continue
    if path_day is None:
        return True
    return (from_day is None or path_day >= from_day) and (to_day is None or path_day <= to_day)


def _path_matches_symbol_filter(path: Path, symbols: list[str] | None) -> bool:
    if not symbols:
        return True
    suffix = "_ticks.csv"
    filename = path.name
    if not filename.lower().endswith(suffix):
        return True
    file_symbol = filename[:-len(suffix)]
    return file_symbol in set(symbols)


def _filter_rows_by_date(
    rows: list[dict[str, Any]],
    from_day: date | None,
    to_day: date | None,
) -> list[dict[str, Any]]:
    if from_day is None and to_day is None:
        return rows
    return [
        row
        for row in rows
        if (from_day is None or _coerce_datetime(row.get("timestamp")).date() >= from_day)
        and (to_day is None or _coerce_datetime(row.get("timestamp")).date() <= to_day)
    ]


def _format_date_filter(from_day: date | None, to_day: date | None) -> str:
    if from_day is None and to_day is None:
        return ""
    return f" for date range {from_day or 'START'} to {to_day or 'END'}"


def _coerce_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    if value in {None, ""}:
        return datetime.min
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    return datetime.fromisoformat(text)


def _append_status_flag(status: str, flag: str) -> str:
    flags = [item for item in str(status or "").split(";") if item and item != "OK"]
    if flag not in flags:
        flags.append(flag)
    return ";".join(flags) if flags else "OK"


def _progress(message: str) -> None:
    print(f"[BACKTEST] {message}", flush=True)


def _dedupe_ticks(ticks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str, str, str]] = set()
    output: list[dict[str, Any]] = []
    for tick in ticks:
        key = (
            str(tick.get("timestamp")),
            str(tick.get("symbol") or ""),
            str(float(tick.get("ltp") or 0.0)),
            str(float(tick.get("ltq") or 0.0)),
        )
        if key in seen:
            continue
        seen.add(key)
        output.append(tick)
    return output


def _dedupe_bars(bars: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str, str]] = set()
    output: list[dict[str, Any]] = []
    for row in bars:
        key = (str(row.get("timestamp")), str(row.get("symbol") or ""), str(row.get("interval") or ""))
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def _ticks_before(ticks: list[dict[str, Any]], cutoff: datetime) -> list[dict[str, Any]]:
    return [tick for tick in ticks if tick["timestamp"] < cutoff]


def _ticks_at_or_after(ticks: list[dict[str, Any]], cutoff: datetime) -> list[dict[str, Any]]:
    return [tick for tick in ticks if tick["timestamp"] > cutoff]


def _symbols_from_ticks(ticks: list[dict[str, Any]]) -> list[str]:
    symbols: list[str] = []
    for tick in ticks:
        symbol = str(tick.get("symbol") or "")
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _symbols_from_bars(bars: list[dict[str, Any]]) -> list[str]:
    symbols: list[str] = []
    for row in bars:
        symbol = str(row.get("symbol") or "")
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def filter_bars_by_symbols(bars: list[dict[str, Any]], symbols: list[str]) -> list[dict[str, Any]]:
    if not symbols:
        return list(bars)
    allowed = set(symbols)
    return [row for row in bars if row.get("symbol") in allowed]


def group_bars_by_symbol(bars: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in bars:
        grouped.setdefault(str(row.get("symbol") or ""), []).append(row)
    return {symbol: sorted(rows, key=lambda item: item["timestamp"]) for symbol, rows in grouped.items() if symbol}


def _price_points_from_candles(candles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    points: list[dict[str, Any]] = []
    for candle in candles:
        timestamp = candle["timestamp"]
        for offset, price_key in enumerate(("open", "high", "low", "close"), start=1):
            points.append({
                "timestamp": timestamp + timedelta(microseconds=offset),
                "symbol": candle.get("symbol"),
                "ltp": candle[price_key],
                "ltq": 0,
            })
    return points


def _infer_candle_timeframe_seconds(candles: list[dict[str, Any]]) -> int:
    if len(candles) >= 2:
        differences = [
            int((later["timestamp"] - earlier["timestamp"]).total_seconds())
            for earlier, later in zip(candles, candles[1:])
            if later["timestamp"] > earlier["timestamp"]
        ]
        if differences:
            return max(1, min(differences))
    interval = str(candles[0].get("interval") or "1minute").lower() if candles else "1minute"
    if interval.endswith("minute"):
        prefix = interval.removesuffix("minute") or "1"
        return max(1, int(prefix)) * 60
    return 60


def _date_range(ticks: list[dict[str, Any]]) -> str:
    if not ticks:
        return "N/A"
    timestamps = sorted(tick["timestamp"] for tick in ticks)
    return f"{timestamps[0]} to {timestamps[-1]}"


def _format_tick_sources(tick_paths: list[Path]) -> str:
    if not tick_paths:
        return "NONE"
    if len(tick_paths) <= 3:
        return ", ".join(str(path) for path in tick_paths)
    return ", ".join(str(path) for path in tick_paths[:3]) + f", ... (+{len(tick_paths) - 3} more)"


def _round_profit_factor(gross_profit: float, gross_loss: float) -> float:
    if gross_loss:
        return round(gross_profit / abs(gross_loss), 2)
    if gross_profit > 0:
        return inf
    return 0.0


def _fmt_pf(value: float) -> str:
    return "inf" if value == inf else str(value)


def _max_drawdown(pnls: list[float]) -> float:
    equity = 0.0
    peak = 0.0
    max_dd = 0.0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        max_dd = min(max_dd, equity - peak)
    return max_dd


def _strategy_key_from_name(strategy_name: str) -> str:
    normalized = str(strategy_name or "").strip().lower().replace(" ", "_").replace("-", "_")
    for key in BACKTEST_STRATEGIES:
        if key in normalized:
            return key
    return normalized or "unknown"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Launch 1 strategy-wise saved-tick PAPER backtest runner. Never places broker orders."
    )
    parser.add_argument("--tick-file", default=None, help="Normalized saved tick CSV.")
    parser.add_argument("--tick-dir", default=None, help="Directory containing daily *_ticks.csv files.")
    parser.add_argument("--bar-dir", default=None, help="Directory containing historical *_bars.csv or *_candles.csv files.")
    parser.add_argument("--symbols", default=None, help="Comma-separated symbols. Defaults to all symbols in the file.")
    parser.add_argument("--strategies", default="all", help="all or comma-separated strategy keys.")
    parser.add_argument("--from-date", default=None, help="Inclusive YYYY-MM-DD source-date filter.")
    parser.add_argument("--to-date", default=None, help="Inclusive YYYY-MM-DD source-date filter.")
    parser.add_argument("--exit-at-end", default="false", choices=["true", "false"], help="Close unfinished trades at the final available tick.")
    parser.add_argument(
        "--one-trade-at-a-time",
        default="true",
        choices=["true", "false"],
        help="Prevent overlapping accepted trades per symbol/strategy.",
    )
    parser.add_argument("--signal-cooldown-seconds", type=int, default=300, help="Cooldown after a taken trade per symbol/strategy.")
    parser.add_argument("--max-trades-per-day", type=int, default=20, help="Maximum accepted trades per symbol/strategy/day. Use 0 for no limit.")
    parser.add_argument("--slippage-points", type=float, default=0.0, help="Points of slippage applied to entry and exit.")
    parser.add_argument("--cost-per-trade", type=float, default=0.0, help="Flat cost deducted from each closed simulated trade.")
    parser.add_argument("--entry-delay-ticks", type=int, default=1, help="Number of future ticks to wait before simulated entry.")
    parser.add_argument("--execution-model", default="DEFAULT_TICK_PATH", choices=["DEFAULT_TICK_PATH", CONSERVATIVE_VWAP_EXECUTION_MODEL], help="Execution model for PAPER backtest simulation.")
    parser.add_argument("--spread-points", type=float, default=0.0, help="Adverse spread points applied to entry and exit when using conservative execution.")
    parser.add_argument("--tick-size", type=float, default=0.0, help="Tick size used for conservative price rounding.")
    parser.add_argument("--same-bar-rule", default="NOT_APPLICABLE_TICK_PATH", choices=["NOT_APPLICABLE_TICK_PATH", "STOP_FIRST"], help="OHLC same-bar ambiguity rule for approval-grade reporting.")
    parser.add_argument("--min-score", type=float, default=None, help="Override cluster signal-quality minimum score.")
    parser.add_argument("--min-trap-strength", type=float, default=None, help="Override cluster signal-quality minimum trap strength.")
    parser.add_argument(
        "--same-zone-cooldown-seconds",
        type=int,
        default=None,
        help="Override repeated cluster-zone quality cooldown.",
    )
    parser.add_argument(
        "--direction-flip-cooldown-seconds",
        type=int,
        default=None,
        help="Override rapid BUY/SELL flip quality cooldown.",
    )
    parser.add_argument(
        "--max-backtest-seconds",
        type=float,
        default=None,
        help="Optional safe runtime limit. Partial PAPER reports are saved with BACKTEST_TIMEOUT.",
    )
    args = parser.parse_args()
    try:
        run_strategy_backtest(
            tick_file=args.tick_file,
            tick_dir=args.tick_dir,
            bar_dir=args.bar_dir,
            symbols_text=args.symbols,
            strategies_text=args.strategies,
            exit_at_end=args.exit_at_end == "true",
            one_trade_at_a_time=args.one_trade_at_a_time == "true",
            signal_cooldown_seconds=args.signal_cooldown_seconds,
            max_trades_per_day=args.max_trades_per_day,
            slippage_points=args.slippage_points,
            cost_per_trade=args.cost_per_trade,
            entry_delay_ticks=args.entry_delay_ticks,
            execution_model=args.execution_model,
            spread_points=args.spread_points,
            tick_size=args.tick_size,
            same_bar_rule=args.same_bar_rule,
            from_date=args.from_date,
            to_date=args.to_date,
            max_backtest_seconds=args.max_backtest_seconds,
            min_score=args.min_score,
            min_trap_strength=args.min_trap_strength,
            same_zone_cooldown_seconds=args.same_zone_cooldown_seconds,
            direction_flip_cooldown_seconds=args.direction_flip_cooldown_seconds,
        )
        return 0
    except StrategyBacktestError as exc:
        print(f"Strategy backtest failed safely: {exc}")
        print("Live Trading: DISABLED")
        print("Broker Orders: DISABLED")
        print("execution_allowed=false")
        print("PAPER MODE ONLY. No broker orders were placed.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
