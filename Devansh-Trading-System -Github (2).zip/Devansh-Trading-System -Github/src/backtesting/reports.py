from __future__ import annotations

import csv
from pathlib import Path

from src.backtesting.metrics import calculate_metrics, group_by_strategy
from src.models.trade import Trade


def review_flags(metrics: dict, min_sample_size: int = 5) -> list[str]:
    flags: list[str] = []
    if metrics["total_trades"] < min_sample_size:
        flags.append("WEAK_SAMPLE")
    if metrics["total_trades"] > 0 and metrics["expectancy"] <= 0:
        flags.append("POOR_EXPECTANCY")
    if metrics["total_trades"] > 0 and metrics["profit_factor"] < 1.2:
        flags.append("POOR_PROFIT_FACTOR")
    if abs(metrics["max_drawdown"]) > 1500:
        flags.append("HIGH_DRAWDOWN")
    return flags


def save_backtest_report(combined_trades: list[Trade], strategy_trades: list[Trade], enabled_strategies: dict, report_dir: Path | str = "reports/backtest_reports") -> Path:
    report_path = Path(report_dir)
    report_path.mkdir(parents=True, exist_ok=True)
    combined_metrics = calculate_metrics(combined_trades)
    strategy_metrics = group_by_strategy(strategy_trades, enabled_strategies)
    text_path = report_path / "latest_backtest_report.txt"
    csv_path = report_path / "latest_backtest_trades.csv"
    lines = []
    lines.append("DEVANSH TRADING SYSTEM BACKTEST REPORT")
    lines.append("")
    lines.append("FULL COMBINED SYSTEM PERFORMANCE")
    lines.extend(_format_metrics(combined_metrics))
    lines.append("Review Flags: " + (", ".join(review_flags(combined_metrics)) or "OK"))
    lines.append("")
    lines.append("INDIVIDUAL STRATEGY-WISE PERFORMANCE")
    for strategy, metrics in sorted(strategy_metrics.items()):
        flags = review_flags(metrics)
        lines.append(f"- {strategy}")
        lines.append(f"  Trades: {metrics['total_trades']} | Win Rate: {metrics['win_rate']:.2f}% | Profit Factor: {_fmt_pf(metrics['profit_factor'])} | Expectancy: {metrics['expectancy']:.2f} | Avg R: {metrics['average_r']:.2f} | Max DD: {metrics['max_drawdown']:.2f}")
        lines.append("  Review: " + (", ".join(flags) if flags else "OK"))
        if flags:
            lines.append("  Action: Review this strategy. It can be disabled from config/strategies.yaml if real-data validation stays weak.")
    lines.append("")
    lines.append("SETUP-WISE BREAKDOWN")
    setup_counts: dict[str, int] = {}
    for trade in strategy_trades:
        setup = trade.tags[0] if trade.tags else "unknown"
        setup_counts[setup] = setup_counts.get(setup, 0) + 1
    for setup, count in sorted(setup_counts.items()):
        lines.append(f"- {setup}: {count} trades")
    lines.append("")
    lines.append("Walk-forward placeholder: split real historical data into in-sample and out-of-sample periods before trusting any strategy.")
    lines.append("Tick-backtest placeholder: cluster/order-flow strategies need tick-level bid/ask history for accurate validation.")
    text_path.write_text("\n".join(lines), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["strategy", "side", "entry_time", "entry", "exit_time", "exit", "qty", "pnl", "r", "status"])
        for trade in combined_trades:
            writer.writerow([trade.strategy_name, trade.side, trade.entry_time, trade.entry_price, trade.exit_time, trade.exit_price, trade.quantity, trade.pnl, trade.r_multiple, trade.status])
    return text_path


def _format_metrics(metrics: dict) -> list[str]:
    return [
        f"Total Trades: {metrics['total_trades']}",
        f"Wins: {metrics['wins']}",
        f"Losses: {metrics['losses']}",
        f"Win Rate: {metrics['win_rate']:.2f}%",
        f"Gross Profit: {metrics['gross_profit']:.2f}",
        f"Gross Loss: {metrics['gross_loss']:.2f}",
        f"Net P&L: {metrics['net_pnl']:.2f}",
        f"Profit Factor: {_fmt_pf(metrics['profit_factor'])}",
        f"Expectancy: {metrics['expectancy']:.2f}",
        f"Average R: {metrics['average_r']:.2f}",
        f"Max Drawdown: {metrics['max_drawdown']:.2f}",
        f"Final Equity: {metrics['final_equity']:.2f}",
    ]


def _fmt_pf(value: float) -> str:
    return "inf" if value == float("inf") else f"{value:.2f}"
