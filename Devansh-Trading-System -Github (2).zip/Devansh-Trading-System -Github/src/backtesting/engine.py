from __future__ import annotations

from dataclasses import dataclass
from uuid import uuid4

from src.models.signal import Signal
from src.models.trade import Trade
from src.risk.daily_limits import DailyLimitState
from src.risk.risk_engine import RiskEngine
from src.strategies.strategy_engine import StrategyEngine


@dataclass
class BacktestResult:
    combined_trades: list[Trade]
    strategy_trades: list[Trade]
    equity_curve: list[float]


class BacktestEngine:
    """Candle-by-candle backtest that avoids future data for signal creation."""

    def __init__(self, settings: dict, risk_config: dict, strategies: dict, instruments: dict | None = None):
        self.settings = settings
        self.risk_config = risk_config
        self.strategies = strategies
        self.instruments = instruments or {}

    def run(self, candles: list[dict], ticks: list[dict] | None = None) -> BacktestResult:
        combined: list[Trade] = []
        strategy_trades: list[Trade] = []
        equity = float(self.risk_config.get("capital", 100000))
        equity_curve = [equity]
        for i in range(4, len(candles) - 1):
            window = candles[:i + 1]
            result = StrategyEngine(self.settings, self.strategies).run(window, ticks)
            if result.best_signal:
                decision = RiskEngine(
                    self.risk_config,
                    self.settings,
                    DailyLimitState(),
                    instruments=self.instruments,
                ).validate_signal(result.best_signal, mode="PAPER")
                if decision.approved:
                    trade = simulate_trade(result.best_signal, candles, i + 1, max(decision.quantity, 1))
                    combined.append(trade)
                    equity += trade.pnl
                    equity_curve.append(equity)
            for candidate in result.candidates:
                strategy_trades.append(simulate_trade(candidate, candles, i + 1, 1))
        return BacktestResult(combined, strategy_trades, equity_curve)


def simulate_trade(signal: Signal, candles: list[dict], entry_index: int, quantity: int) -> Trade:
    entry_candle = candles[entry_index]
    entry = entry_candle["open"]
    exit_price = entry_candle["close"]
    exit_time = entry_candle["timestamp"]
    status = "TIME_EXIT"
    for candle in candles[entry_index:min(len(candles), entry_index + 6)]:
        if signal.side == "BUY":
            if candle["low"] <= signal.stop_loss:
                exit_price = signal.stop_loss
                status = "STOP"
                exit_time = candle["timestamp"]
                break
            if candle["high"] >= signal.target_price:
                exit_price = signal.target_price
                status = "TARGET"
                exit_time = candle["timestamp"]
                break
        else:
            if candle["high"] >= signal.stop_loss:
                exit_price = signal.stop_loss
                status = "STOP"
                exit_time = candle["timestamp"]
                break
            if candle["low"] <= signal.target_price:
                exit_price = signal.target_price
                status = "TARGET"
                exit_time = candle["timestamp"]
                break
        exit_price = candle["close"]
        exit_time = candle["timestamp"]
    pnl = (exit_price - entry) * quantity if signal.side == "BUY" else (entry - exit_price) * quantity
    risk_per_unit = abs(entry - signal.stop_loss)
    r_multiple = pnl / (risk_per_unit * quantity) if risk_per_unit and quantity else 0.0
    return Trade(
        trade_id=str(uuid4()),
        symbol=signal.symbol,
        strategy_name=signal.strategy_name,
        side=signal.side,
        entry_time=entry_candle["timestamp"],
        entry_price=entry,
        stop_loss=signal.stop_loss,
        target_price=signal.target_price,
        exit_time=exit_time,
        exit_price=exit_price,
        quantity=quantity,
        pnl=round(pnl, 2),
        r_multiple=round(r_multiple, 2),
        status=status,
        reason=signal.reason,
        tags=[signal.setup_type],
        metadata={"slippage_placeholder": 0.0, "brokerage_placeholder": 0.0},
    )
