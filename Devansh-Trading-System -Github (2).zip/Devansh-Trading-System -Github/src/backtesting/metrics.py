from __future__ import annotations

from math import inf

from src.models.trade import Trade


def calculate_metrics(trades: list[Trade], initial_equity: float = 100000.0) -> dict:
    pnls = [t.pnl for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    gross_profit = sum(wins)
    gross_loss = sum(losses)
    net = gross_profit + gross_loss
    equity = initial_equity
    peak = initial_equity
    max_dd = 0.0
    for pnl in pnls:
        equity += pnl
        peak = max(peak, equity)
        max_dd = min(max_dd, equity - peak)
    total = len(trades)
    avg_loss = sum(losses) / len(losses) if losses else 0.0
    metrics = {
        "total_trades": total,
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": len(wins) / total * 100 if total else 0.0,
        "loss_rate": len(losses) / total * 100 if total else 0.0,
        "gross_profit": gross_profit,
        "gross_loss": gross_loss,
        "net_pnl": net,
        "average_win": sum(wins) / len(wins) if wins else 0.0,
        "average_loss": avg_loss,
        "profit_factor": gross_profit / abs(gross_loss) if gross_loss else (inf if gross_profit > 0 else 0.0),
        "expectancy": net / total if total else 0.0,
        "average_r": sum(t.r_multiple for t in trades) / total if total else 0.0,
        "largest_win": max(wins) if wins else 0.0,
        "largest_loss": min(losses) if losses else 0.0,
        "max_consecutive_wins": _max_consecutive(pnls, True),
        "max_consecutive_losses": _max_consecutive(pnls, False),
        "max_drawdown": max_dd,
        "recovery_factor": net / abs(max_dd) if max_dd else 0.0,
        "final_equity": initial_equity + net,
    }
    return metrics


def _max_consecutive(pnls: list[float], want_win: bool) -> int:
    best = 0
    current = 0
    for pnl in pnls:
        ok = pnl > 0 if want_win else pnl < 0
        current = current + 1 if ok else 0
        best = max(best, current)
    return best


def group_by_strategy(trades: list[Trade], enabled_strategies: dict | None = None, initial_equity: float = 100000.0) -> dict[str, dict]:
    grouped: dict[str, list[Trade]] = {}
    for trade in trades:
        grouped.setdefault(trade.strategy_name, []).append(trade)
    output: dict[str, dict] = {}
    for strategy_name, rows in grouped.items():
        output[strategy_name] = calculate_metrics(rows, initial_equity)
    if enabled_strategies:
        for key, enabled in enabled_strategies.items():
            if enabled:
                label = key.replace("_", " ").title()
                output.setdefault(label, calculate_metrics([], initial_equity))
    return output
