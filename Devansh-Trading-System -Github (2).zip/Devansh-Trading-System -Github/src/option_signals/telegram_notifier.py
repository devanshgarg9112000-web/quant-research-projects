from __future__ import annotations

import os
import json
from urllib import parse, request

from .models import ExitAlert, OptionSignal


class TelegramNotifier:
    """Official Telegram Bot API transport for signal alerts.

    No token or chat ID is ever included in logs/messages.  Network delivery is
    opt-in through both config and TELEGRAM_ALERTS_ENABLED=true.
    """

    def __init__(self, *, enabled: bool = False, dry_run: bool = True, timeout_seconds: float = 8.0) -> None:
        self.enabled = bool(enabled)
        self.dry_run = bool(dry_run)
        self.timeout_seconds = float(timeout_seconds)
        self._sent_ids: set[str] = set()

    @staticmethod
    def format_entry(signal: OptionSignal) -> str:
        c = signal.contract
        strategies = " + ".join(signal.strategy_ids)
        return "\n".join([
            "🚨 OPTION SELL SIGNAL",
            f"Class: {signal.classification}",
            f"Strategy: {strategies}",
            f"Underlying: {signal.underlying}",
            f"Action: SELL {c.tradingsymbol}",
            f"Expiry: {c.expiry.isoformat()} | Strike: {c.strike:g} {c.option_type}",
            f"Lots: {signal.lots} | Qty: {signal.quantity}",
            f"Spot: {signal.spot_price:.2f}",
            f"Entry reference: ₹{signal.entry_reference:.2f}",
            f"SL reference: ₹{signal.stop_price:.2f}",
            f"Target reference: ₹{signal.target_price:.2f}",
            f"Max exit: {signal.max_exit_time.strftime('%H:%M')}",
            f"Signal time: {signal.signal_time.strftime('%H:%M:%S')}",
            f"Reason: {signal.reason}",
            f"Signal ID: {signal.signal_id}",
            "MANUAL EXECUTION ONLY — NO BROKER ORDER WAS PLACED",
        ])

    @staticmethod
    def format_exit(alert: ExitAlert) -> str:
        c = alert.contract
        return "\n".join([
            "🟠 OPTION EXIT ALERT",
            f"Reason: {alert.reason}",
            f"BUY TO CLOSE: {c.tradingsymbol}",
            f"Lots: {alert.lots} | Qty: {alert.quantity}",
            f"Entry reference: ₹{alert.entry_reference:.2f}",
            f"Exit reference: ₹{alert.exit_reference:.2f}",
            f"Reference P&L: ₹{alert.reference_pnl_rupees:.2f}",
            f"Time: {alert.timestamp.strftime('%H:%M:%S')}",
            f"Signal ID: {alert.signal_id}",
            "MANUAL EXECUTION ONLY — NO BROKER ORDER WAS PLACED",
        ])

    def send_entry(self, signal: OptionSignal) -> bool:
        return self._send(signal.signal_id + ":ENTRY", self.format_entry(signal))

    def send_exit(self, alert: ExitAlert) -> bool:
        return self._send(alert.signal_id + ":EXIT:" + alert.reason, self.format_exit(alert))

    def send_text(self, message_id: str, text: str) -> bool:
        return self._send(message_id, text)

    def _send(self, message_id: str, text: str) -> bool:
        if message_id in self._sent_ids:
            return True
        if self.dry_run or not self.enabled:
            print(text)
            self._sent_ids.add(message_id)
            return False
        if str(os.getenv("TELEGRAM_ALERTS_ENABLED", "")).strip().lower() not in {"1", "true", "yes", "on"}:
            print("Telegram send skipped: TELEGRAM_ALERTS_ENABLED is not true.")
            return False
        token = os.getenv("TELEGRAM_BOT_TOKEN")
        chat_id = os.getenv("TELEGRAM_CHAT_ID")
        if not token or not chat_id:
            print("Telegram send skipped: bot token/chat id missing.")
            return False
        body = parse.urlencode({"chat_id": chat_id, "text": text, "disable_web_page_preview": "true"}).encode("utf-8")
        req = request.Request(f"https://api.telegram.org/bot{token}/sendMessage", data=body, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        try:
            with request.urlopen(req, timeout=self.timeout_seconds) as response:
                ok = 200 <= int(response.status) < 300 and json.loads(response.read()).get("ok") is True
            if ok:
                self._sent_ids.add(message_id)
            return ok
        except Exception as exc:
            print(f"Telegram send failed safely: {type(exc).__name__}")
            return False
