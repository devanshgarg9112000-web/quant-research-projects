from __future__ import annotations

from datetime import datetime

from .models import ExitAlert, OptionSignal, ReferencePosition
from .time_utils import ensure_ist, is_after_forced_squareoff


class ReferencePositionTracker:
    """Tracks model/reference positions for alerts only; never places orders."""

    def __init__(self) -> None:
        self.positions: list[ReferencePosition] = []

    def open_from_signal(self, signal: OptionSignal) -> ReferencePosition:
        position = ReferencePosition(
            signal=signal,
            opened_at=signal.entry_time,
            entry_reference=signal.entry_reference,
            stop_price=signal.stop_price,
            target_price=signal.target_price,
            max_exit_time=signal.max_exit_time,
        )
        self.positions.append(position)
        return position

    def open_for_underlying(self, underlying: str) -> ReferencePosition | None:
        for position in reversed(self.positions):
            if position.is_open and position.signal.underlying == underlying.upper():
                return position
        return None

    def update(self, position: ReferencePosition, *, timestamp: datetime, ltp: float) -> ExitAlert | None:
        if not position.is_open:
            return None
        timestamp = ensure_ist(timestamp)
        reason: str | None = None
        if is_after_forced_squareoff(timestamp):
            reason = "FORCED_1515"
        elif timestamp >= position.max_exit_time:
            reason = "TIME"
        elif float(ltp) >= position.stop_price:
            reason = "STOP"
        elif float(ltp) <= position.target_price:
            reason = "TARGET"
        if reason is None:
            return None
        exit_reference = float(ltp)
        pnl = (position.entry_reference - exit_reference) * position.signal.quantity
        position.is_open = False
        position.exit_time = timestamp
        position.exit_reference = exit_reference
        position.exit_reason = reason
        position.reference_pnl_rupees = pnl
        return ExitAlert(
            signal_id=position.signal.signal_id,
            underlying=position.signal.underlying,
            contract=position.signal.contract,
            timestamp=timestamp,
            reason=reason,
            exit_reference=exit_reference,
            entry_reference=position.entry_reference,
            lots=position.signal.lots,
            quantity=position.signal.quantity,
            reference_pnl_rupees=pnl,
        )
