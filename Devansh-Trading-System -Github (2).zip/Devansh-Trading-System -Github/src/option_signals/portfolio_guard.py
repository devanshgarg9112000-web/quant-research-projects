from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

from .models import OptionSignal, ReferencePosition


@dataclass(frozen=True, slots=True)
class GuardDecision:
    approved: bool
    reason: str


class OptionSignalPortfolioGuard:
    """Signal-only portfolio guard for initial forward validation.

    It deliberately does not call any broker API.  The user executes trades
    manually.  It prevents stacking a second naked option position on the same
    underlying and caps generated actionable signals per day.
    """

    def __init__(self, *, max_open_positions_per_underlying: int = 1, max_signals_per_day: int = 0) -> None:
        self.max_open_positions_per_underlying = int(max_open_positions_per_underlying)
        self.max_signals_per_day = int(max_signals_per_day)
        self._signal_counts: dict[tuple[date, str], int] = {}

    def assess(self, signal: OptionSignal, positions: list[ReferencePosition], now: datetime) -> GuardDecision:
        open_count = sum(p.is_open and p.signal.underlying == signal.underlying for p in positions)
        if open_count >= self.max_open_positions_per_underlying:
            return GuardDecision(False, f"shadow only: {signal.underlying} already has an open reference position")
        key = (now.date(), signal.underlying)
        if self.max_signals_per_day > 0 and self._signal_counts.get(key, 0) >= self.max_signals_per_day:
            return GuardDecision(False, f"daily actionable signal cap reached for {signal.underlying}")
        return GuardDecision(True, "approved for manual-execution alert")

    def record_actionable(self, signal: OptionSignal, now: datetime) -> None:
        key = (now.date(), signal.underlying)
        self._signal_counts[key] = self._signal_counts.get(key, 0) + 1
