"""Signal-only weekly option strategy subsystem.

This package is intentionally isolated from broker order execution.  It may read
Kite market data, generate and track reference signals, and send alerts, but it
must never place broker orders.
"""

from .models import MinuteBar, OptionContract, OptionSignal, ReferencePosition

__all__ = ["MinuteBar", "OptionContract", "OptionSignal", "ReferencePosition"]
