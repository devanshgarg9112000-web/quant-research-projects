from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
import math
from uuid import uuid4

from .models import OptionContract, OptionSignal, StrategyIntent
from .time_utils import ensure_ist, max_exit_time


def build_entry_signal(
    intents: Iterable[StrategyIntent],
    *,
    contract: OptionContract,
    entry_time: datetime,
    entry_reference: float,
    lots: int,
    stop_percent: float,
    target_percent: float,
    max_hold_minutes: int,
    extra_metrics: dict | None = None,
) -> OptionSignal:
    items = list(intents)
    if not items:
        raise ValueError("At least one strategy intent is required")
    if any(item.underlying != items[0].underlying for item in items):
        raise ValueError("Cannot combine intents from different underlyings")
    if any(item.option_type != items[0].option_type for item in items):
        raise ValueError("Conflicting option sides cannot be combined into an entry signal")
    if contract.option_type != items[0].option_type:
        raise ValueError("Resolved option contract does not match strategy intent")
    if not math.isfinite(float(entry_reference)) or entry_reference <= 0:
        raise ValueError("entry_reference must be positive")
    strategy_ids = tuple(sorted({item.strategy_id for item in items}))
    classification = "DOUBLE_CONFIRMATION" if len(strategy_ids) > 1 else "SINGLE"
    quantity = int(lots) * int(contract.lot_size)
    signal_time = max(item.signal_time for item in items)
    metrics: dict = {}
    for item in items:
        for key, value in item.metrics.items():
            metrics[f"{item.strategy_id}.{key}"] = value
    metrics.update(extra_metrics or {})
    return OptionSignal(
        signal_id=f"OPT-{ensure_ist(signal_time).strftime('%Y%m%d-%H%M')}-{uuid4().hex[:8]}",
        strategy_ids=strategy_ids,
        classification=classification,
        underlying=items[0].underlying,
        signal_time=ensure_ist(signal_time),
        entry_time=ensure_ist(entry_time),
        contract=contract,
        action="SELL_TO_OPEN",
        lots=int(lots),
        quantity=quantity,
        spot_price=float(items[0].spot_price),
        entry_reference=float(entry_reference),
        stop_price=float(entry_reference) * (1.0 + float(stop_percent)),
        target_price=float(entry_reference) * (1.0 - float(target_percent)),
        max_exit_time=max_exit_time(entry_time, max_hold_minutes),
        reason=" | ".join(item.reason for item in items),
        metrics=metrics,
        executable=True,
    )


def classify_intents(intents: Iterable[StrategyIntent]) -> tuple[str, list[StrategyIntent]]:
    """Classify intents arriving for the same underlying/minute.

    Same-side intents are a double confirmation. Opposite-side intents are a
    conflict and must not create a trade signal.
    """

    items = list(intents)
    if not items:
        return "NONE", []
    sides = {item.option_type for item in items}
    if len(sides) > 1:
        return "CONFLICT", items
    ids = {item.strategy_id for item in items}
    return ("DOUBLE_CONFIRMATION" if len(ids) > 1 else "SINGLE"), items
