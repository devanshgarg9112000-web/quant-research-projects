from __future__ import annotations

from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")


def ensure_ist(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=IST)
    return value.astimezone(IST)


def session_squareoff(value: datetime) -> datetime:
    local = ensure_ist(value)
    return local.replace(hour=15, minute=15, second=0, microsecond=0)


def max_exit_time(entry_time: datetime, hold_minutes: int) -> datetime:
    local = ensure_ist(entry_time)
    return min(local + timedelta(minutes=int(hold_minutes)), session_squareoff(local))


def is_after_forced_squareoff(value: datetime) -> bool:
    local = ensure_ist(value)
    return local.time().replace(tzinfo=None) >= time(15, 15)
