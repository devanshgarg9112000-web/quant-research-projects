from __future__ import annotations

from collections.abc import Sequence
from datetime import timedelta
import math

from .models import MinuteBar
from .time_utils import ensure_ist


def _has_contiguous_minutes(bars: Sequence[MinuteBar], lookback: int) -> bool:
    if len(bars) < lookback + 1:
        return False
    window = bars[-lookback - 1 :]
    return all(
        ensure_ist(right.timestamp) - ensure_ist(left.timestamp) == timedelta(minutes=1)
        and ensure_ist(right.timestamp).date() == ensure_ist(left.timestamp).date()
        for left, right in zip(window, window[1:])
    )


def close_return_bps(bars: Sequence[MinuteBar], lookback: int) -> float | None:
    if lookback <= 0 or not _has_contiguous_minutes(bars, lookback):
        return None
    start = float(bars[-lookback - 1].close)
    end = float(bars[-1].close)
    if not math.isfinite(start) or not math.isfinite(end) or start <= 0:
        return None
    return (end / start - 1.0) * 10_000.0


def efficiency_ratio(bars: Sequence[MinuteBar], lookback: int) -> float | None:
    """Kaufman-style efficiency ratio over exactly ``lookback`` minute moves."""

    if lookback <= 0 or not _has_contiguous_minutes(bars, lookback):
        return None
    window = list(bars[-lookback - 1 :])
    net = abs(float(window[-1].close) - float(window[0].close))
    path = 0.0
    for left, right in zip(window, window[1:]):
        a, b = float(left.close), float(right.close)
        if not (math.isfinite(a) and math.isfinite(b)):
            return None
        path += abs(b - a)
    if path <= 0:
        return 0.0
    return net / path


def failed_breakout_direction(bars: Sequence[MinuteBar], lookback: int) -> str | None:
    """Return CE/PE to sell for a failed spot breakout, using only closed bars.

    CE: current bar trades above the prior lookback high but closes back below it.
    PE: current bar trades below the prior lookback low but closes back above it.
    If both happen in the same minute, the bar is ambiguous and no signal is used.
    """

    if lookback <= 0 or not _has_contiguous_minutes(bars, lookback):
        return None
    current = bars[-1]
    previous = bars[-lookback - 1 : -1]
    prior_high = max(float(bar.high) for bar in previous)
    prior_low = min(float(bar.low) for bar in previous)
    failed_up = float(current.high) > prior_high and float(current.close) < prior_high
    failed_down = float(current.low) < prior_low and float(current.close) > prior_low
    if failed_up == failed_down:
        return None
    return "CE" if failed_up else "PE"


def option_combined_return_3m(ce_bars: Sequence[MinuteBar], pe_bars: Sequence[MinuteBar]) -> float | None:
    """Average 3-minute return of the current ATM CE and PE complex."""

    def ret3(items: Sequence[MinuteBar]) -> float | None:
        if not _has_contiguous_minutes(items, 3):
            return None
        old = float(items[-4].close)
        new = float(items[-1].close)
        if not (math.isfinite(old) and math.isfinite(new)) or old <= 0:
            return None
        return new / old - 1.0

    if not ce_bars or not pe_bars:
        return None
    if ensure_ist(ce_bars[-1].timestamp) != ensure_ist(pe_bars[-1].timestamp):
        return None
    ce = ret3(ce_bars)
    pe = ret3(pe_bars)
    if ce is None or pe is None:
        return None
    return (ce + pe) / 2.0
