from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date, datetime
from typing import Any


@dataclass(frozen=True, slots=True)
class MinuteBar:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    oi: float = 0.0


@dataclass(frozen=True, slots=True)
class OptionContract:
    underlying: str
    exchange: str
    tradingsymbol: str
    instrument_token: int
    expiry: date
    strike: float
    option_type: str  # CE / PE
    lot_size: int
    tick_size: float = 0.05

    @property
    def quote_symbol(self) -> str:
        return f"{self.exchange}:{self.tradingsymbol}"


@dataclass(frozen=True, slots=True)
class StrategyIntent:
    strategy_id: str
    underlying: str
    signal_time: datetime
    option_type: str  # CE / PE to SELL
    spot_price: float
    reason: str
    metrics: dict[str, float | int | str | bool] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class OptionSignal:
    signal_id: str
    strategy_ids: tuple[str, ...]
    classification: str  # SINGLE / DOUBLE_CONFIRMATION / SHADOW / CONFLICT
    underlying: str
    signal_time: datetime
    entry_time: datetime
    contract: OptionContract
    action: str  # SELL_TO_OPEN / BUY_TO_CLOSE
    lots: int
    quantity: int
    spot_price: float
    entry_reference: float
    stop_price: float
    target_price: float
    max_exit_time: datetime
    reason: str
    metrics: dict[str, Any] = field(default_factory=dict)
    executable: bool = True

    def with_classification(self, classification: str, *, executable: bool | None = None, reason: str | None = None) -> "OptionSignal":
        return replace(
            self,
            classification=classification,
            executable=self.executable if executable is None else executable,
            reason=self.reason if reason is None else reason,
        )


@dataclass(slots=True)
class ReferencePosition:
    signal: OptionSignal
    opened_at: datetime
    entry_reference: float
    stop_price: float
    target_price: float
    max_exit_time: datetime
    is_open: bool = True
    exit_time: datetime | None = None
    exit_reference: float | None = None
    exit_reason: str | None = None
    reference_pnl_rupees: float | None = None


@dataclass(frozen=True, slots=True)
class ExitAlert:
    signal_id: str
    underlying: str
    contract: OptionContract
    timestamp: datetime
    reason: str  # STOP / TARGET / TIME / FORCED_1515
    exit_reference: float
    entry_reference: float
    lots: int
    quantity: int
    reference_pnl_rupees: float
