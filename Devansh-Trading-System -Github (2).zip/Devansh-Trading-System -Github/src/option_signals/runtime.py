from __future__ import annotations

import time as time_module
from dataclasses import replace
from datetime import datetime, timedelta
import math
from pathlib import Path
from typing import Any

from src.brokers.kite_broker import KiteBroker
from src.config_loader import load_dotenv_file

from .config import OptionSignalConfig, load_option_signal_config
from .contract_resolver import resolve_immediate_weekly_atm_pair
from .features import option_combined_return_3m
from .ledger import ForwardSignalLedger
from .market_data import KiteReadOnlyOptionData
from .models import OptionContract, OptionSignal, StrategyIntent
from .portfolio_guard import OptionSignalPortfolioGuard
from .position_tracker import ReferencePositionTracker
from .signal_manager import build_entry_signal, classify_intents
from .strategies import CasRouterStrategy, EfficiencyTrendStrategy
from .telegram_notifier import TelegramNotifier
from .time_utils import IST, ensure_ist


class OptionSignalRuntime:
    """Live read-only signal runtime.

    The runtime has no broker order code.  It reads Kite data, generates model
    signals, tracks reference exits, writes a forward ledger, and optionally
    sends Telegram alerts for manual execution.
    """

    def __init__(
        self,
        *,
        base_dir: Path | str = ".",
        market_data: Any | None = None,
        config: OptionSignalConfig | None = None,
        raw_config: dict[str, Any] | None = None,
        notifier: TelegramNotifier | None = None,
    ) -> None:
        self.base_dir = Path(base_dir)
        load_dotenv_file(self.base_dir)
        if config is None or raw_config is None:
            loaded_config, loaded_raw = load_option_signal_config(self.base_dir)
            config = config or loaded_config
            raw_config = raw_config or loaded_raw
        self.config = config
        self.raw_config = raw_config
        if market_data is None:
            # Read-only broker wrapper; place_order remains intentionally unreachable.
            broker = KiteBroker(broker_name="kite", base_dir=self.base_dir)
            market_data = KiteReadOnlyOptionData(broker)
        self.market_data = market_data
        self.cas = CasRouterStrategy(
            nifty_lookback=int(raw_config.get("strategies", {}).get("cas_router", {}).get("nifty_lookback", 5)),
            nifty_threshold_bps=float(raw_config.get("strategies", {}).get("cas_router", {}).get("nifty_threshold_bps", 6.0)),
            sensex_lookback=int(raw_config.get("strategies", {}).get("cas_router", {}).get("sensex_lookback", 25)),
        )
        eff_cfg = raw_config.get("strategies", {}).get("efficiency_trend", {})
        self.efficiency = EfficiencyTrendStrategy(
            lookback=int(eff_cfg.get("lookback", 15)),
            min_efficiency=float(eff_cfg.get("min_efficiency", 0.70)),
            min_return_bps=float(eff_cfg.get("min_return_bps", 10.0)),
            cooldown_minutes=int(eff_cfg.get("cooldown_minutes", 5)),
        )
        self.guard = OptionSignalPortfolioGuard(
            max_open_positions_per_underlying=config.max_open_positions_per_underlying,
            max_signals_per_day=config.max_signals_per_day,
        )
        self.tracker = ReferencePositionTracker()
        self.ledger = ForwardSignalLedger(self.base_dir)
        self.notifier = notifier or TelegramNotifier(enabled=config.telegram_enabled, dry_run=config.telegram_dry_run)
        self._cooldown_until: dict[tuple[str, str], datetime] = {}
        self._last_evaluated_bar: dict[str, datetime] = {}
        signals, closed_ids = self.ledger.restore_entries()
        for signal in signals:
            previous = self._last_evaluated_bar.get(signal.underlying)
            if previous is None or signal.signal_time > previous:
                self._last_evaluated_bar[signal.underlying] = signal.signal_time
            if not signal.executable:
                continue
            for strategy_id in signal.strategy_ids:
                cooldown = (
                    self.cas.cooldown_minutes(signal.underlying)
                    if strategy_id == self.cas.strategy_id
                    else self.efficiency.cooldown_minutes()
                )
                key = (strategy_id, signal.underlying)
                until = signal.signal_time + timedelta(minutes=cooldown)
                if key not in self._cooldown_until or until > self._cooldown_until[key]:
                    self._cooldown_until[key] = until
            if signal.signal_id not in closed_ids:
                self.tracker.open_from_signal(signal)

    @staticmethod
    def eligible_underlying(now: datetime) -> str | None:
        weekday = ensure_ist(now).weekday()
        if weekday in {0, 1, 4}:
            return "NIFTY"
        if weekday in {2, 3}:
            return "SENSEX"
        return None

    def evaluate_once(self, now: datetime | None = None) -> list[OptionSignal]:
        now = ensure_ist(now or datetime.now(IST))
        underlying = self.eligible_underlying(now)
        if not self.config.enabled or underlying is None:
            return []
        bars = self.market_data.spot_bars(underlying, now=now, history_minutes=90)
        minute_floor = now.replace(second=0, microsecond=0)
        bars = sorted(
            (
                replace(bar, timestamp=ensure_ist(bar.timestamp))
                for bar in bars
                if ensure_ist(bar.timestamp).date() == now.date()
                and ensure_ist(bar.timestamp) < minute_floor
            ),
            key=lambda bar: bar.timestamp,
        )
        if not bars or bars[-1].timestamp != minute_floor - timedelta(minutes=1):
            return []
        latest_bar = bars[-1]
        if self._last_evaluated_bar.get(underlying, latest_bar.timestamp - timedelta(minutes=1)) >= latest_bar.timestamp:
            return []
        self._last_evaluated_bar[underlying] = latest_bar.timestamp

        intents: list[StrategyIntent] = []
        cas_intent = self.cas.evaluate(underlying, bars)
        if cas_intent and self._cooldown_ok(cas_intent):
            intents.append(cas_intent)
        elif cas_intent:
            self.ledger.log_intent(cas_intent, status="COOLDOWN")

        if underlying == "NIFTY":
            eff_intent = self.efficiency.evaluate(underlying, bars)
            if eff_intent and self._cooldown_ok(eff_intent):
                intents.append(eff_intent)
            elif eff_intent:
                self.ledger.log_intent(eff_intent, status="COOLDOWN")
        if not intents:
            return []

        instruments = self.market_data.instrument_master(underlying)
        ce, pe = resolve_immediate_weekly_atm_pair(
            instruments,
            underlying=underlying,
            as_of=now.date(),
            spot=float(latest_bar.close),
        )

        # Apply the frozen NIFTY CAS volatility-expansion filter using only bars
        # known at the signal minute.  Efficiency Trend does not use this filter.
        filtered: list[StrategyIntent] = []
        for intent in intents:
            if intent.strategy_id == self.cas.strategy_id and underlying == "NIFTY":
                ce_bars = self.market_data.option_bars(ce, now=now, history_minutes=10)
                pe_bars = self.market_data.option_bars(pe, now=now, history_minutes=10)
                ce_bars = [bar for bar in ce_bars if ensure_ist(bar.timestamp) <= latest_bar.timestamp]
                pe_bars = [bar for bar in pe_bars if ensure_ist(bar.timestamp) <= latest_bar.timestamp]
                comb3 = option_combined_return_3m(ce_bars, pe_bars)
                if (
                    not ce_bars
                    or not pe_bars
                    or ensure_ist(ce_bars[-1].timestamp) != latest_bar.timestamp
                    or ensure_ist(pe_bars[-1].timestamp) != latest_bar.timestamp
                ):
                    comb3 = None
                if comb3 is None or comb3 > self.config.nifty_combined_option_return_3m_max:
                    metrics = dict(intent.metrics)
                    metrics["combined_option_return_3m"] = comb3 if comb3 is not None else "missing"
                    rejected = StrategyIntent(
                        strategy_id=intent.strategy_id,
                        underlying=intent.underlying,
                        signal_time=intent.signal_time,
                        option_type=intent.option_type,
                        spot_price=intent.spot_price,
                        reason=intent.reason,
                        metrics=metrics,
                    )
                    self.ledger.log_intent(rejected, status="CAS_OPTION_COMPLEX_FILTER_REJECT")
                    continue
                intent.metrics["combined_option_return_3m"] = comb3
            filtered.append(intent)
        intents = filtered
        if not intents:
            return []

        classification, intents = classify_intents(intents)
        for intent in intents:
            self.ledger.log_intent(intent, status=classification)
        if classification == "CONFLICT":
            self.notifier.send_text(
                f"CONFLICT-{underlying}-{latest_bar.timestamp.isoformat()}",
                f"⚠️ {underlying} strategy conflict at {latest_bar.timestamp.strftime('%H:%M')}. No trade. "
                + " | ".join(f"{x.strategy_id}: SELL {x.option_type}" for x in intents),
            )
            return []

        option_type = intents[0].option_type
        contract: OptionContract = ce if option_type == "CE" else pe
        entry_reference = self.market_data.sell_reference(contract)
        signal = build_entry_signal(
            intents,
            contract=contract,
            entry_time=now,
            entry_reference=entry_reference,
            lots=self.config.lots,
            stop_percent=self.config.stop_percent,
            target_percent=self.config.target_percent,
            max_hold_minutes=self.config.max_hold_minutes,
            extra_metrics={"data_bar_time": latest_bar.timestamp.isoformat()},
        )
        decision = self.guard.assess(signal, self.tracker.positions, now)
        if not decision.approved:
            shadow = signal.with_classification("SHADOW", executable=False, reason=signal.reason + f" | {decision.reason}")
            self.ledger.log_entry(shadow)
            return [shadow]

        self.ledger.log_entry(signal)
        self.guard.record_actionable(signal, now)
        self.tracker.open_from_signal(signal)
        self.notifier.send_entry(signal)
        for intent in intents:
            cooldown = self.cas.cooldown_minutes(underlying) if intent.strategy_id == self.cas.strategy_id else self.efficiency.cooldown_minutes()
            self._cooldown_until[(intent.strategy_id, underlying)] = intent.signal_time + timedelta(minutes=cooldown)
        return [signal]

    def monitor_positions_once(self, now: datetime | None = None) -> list[Any]:
        now = ensure_ist(now or datetime.now(IST))
        alerts = []
        for position in list(self.tracker.positions):
            if not position.is_open:
                continue
            try:
                buy_reference = self.market_data.buy_reference(position.signal.contract)
                if not math.isfinite(float(buy_reference)) or float(buy_reference) <= 0:
                    raise ValueError("invalid buy reference")
            except Exception as exc:
                print(f"Position monitor quote failed safely: {type(exc).__name__}")
                if now >= position.max_exit_time:
                    self.notifier.send_text(
                        position.signal.signal_id + ":EXIT_DATA_UNAVAILABLE",
                        "BUY TO CLOSE tracked short "
                        + position.signal.contract.quote_symbol
                        + ": exit deadline reached but quote is unavailable. Verify manually now. "
                        + "Reference position remains open; no fill or P&L was assumed. MANUAL EXECUTION ONLY.",
                    )
                continue
            alert = self.tracker.update(position, timestamp=now, ltp=buy_reference)
            if alert:
                self.ledger.log_exit(alert)
                self.notifier.send_exit(alert)
                alerts.append(alert)
        return alerts

    def run_forever(self, *, poll_seconds: float = 3.0) -> None:
        print("OPTION SIGNAL MONITOR")
        print("Kite: READ ONLY | execution_allowed=false | MANUAL EXECUTION ONLY")
        print(f"Lots per actionable signal: {self.config.lots}")
        print("Press Ctrl+C to stop safely.")
        try:
            while True:
                now = datetime.now(IST)
                self.monitor_positions_once(now)
                try:
                    self.evaluate_once(now)
                except Exception as exc:
                    print(f"Signal evaluation failed safely: {type(exc).__name__}")
                time_module.sleep(max(1.0, float(poll_seconds)))
        except KeyboardInterrupt:
            print("Option signal monitor stopped safely. No broker orders were placed.")

    def _cooldown_ok(self, intent: StrategyIntent) -> bool:
        until = self._cooldown_until.get((intent.strategy_id, intent.underlying))
        return until is None or intent.signal_time >= until
