from __future__ import annotations

import argparse
import os
from pathlib import Path

from src.brokers.kite_broker import KiteBroker
from src.config_loader import load_dotenv_file

from .config import load_option_signal_config
from .contract_resolver import resolve_immediate_weekly_atm_pair
from .market_data import KiteReadOnlyOptionData
from .runtime import OptionSignalRuntime
from .self_test import run_self_test
from .telegram_notifier import TelegramNotifier


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Signal-only weekly options monitor. Never places broker orders.")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("self-test", help="Offline deterministic strategy smoke test.")
    sub.add_parser("preflight", help="Offline credential/config readiness check; no market-data call.")
    lc = sub.add_parser("live-check", help="Kite READ-ONLY spot/instrument/ATM contract check; no orders.")
    lc.add_argument("--underlying", choices=["NIFTY", "SENSEX"], default="NIFTY")
    tg = sub.add_parser("telegram-test", help="Format/test Telegram alert transport.")
    tg.add_argument("--send", action="store_true", help="Actually send a harmless test message if env opt-in is enabled.")
    run = sub.add_parser("run", help="Run live Kite READ-ONLY signal monitor.")
    run.add_argument("--poll-seconds", type=float, default=3.0)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    base = Path(".")
    load_dotenv_file(base)
    cfg, _raw = load_option_signal_config(base)

    if args.command == "self-test":
        result = run_self_test()
        for key, value in result.items():
            print(f"{key}={'PASS' if value else 'FAIL'}")
        print("execution_allowed=false")
        return 0 if all(result.values()) else 1

    if args.command == "preflight":
        broker = KiteBroker(broker_name="kite", base_dir=base)
        missing = broker._missing_read_credentials()
        print("OPTION SIGNAL PREFLIGHT")
        print("execution_allowed=false | signal_only=true | manual_execution_only=true")
        print(f"lots_per_signal={cfg.lots}")
        print(f"telegram_config_enabled={cfg.telegram_enabled}")
        print(f"telegram_env_opt_in={str(os.getenv('TELEGRAM_ALERTS_ENABLED','')).lower() in {'1','true','yes','on'}}")
        print(f"telegram_token_present={bool(os.getenv('TELEGRAM_BOT_TOKEN'))}")
        print(f"telegram_chat_id_present={bool(os.getenv('TELEGRAM_CHAT_ID'))}")
        if missing:
            print("kite_read_credentials=MISSING: " + ", ".join(missing))
            return 1
        print("kite_read_credentials=PRESENT")
        print("No network call was made. No broker order was placed.")
        return 0


    if args.command == "live-check":
        try:
            broker = KiteBroker(broker_name="kite", base_dir=base)
            data = KiteReadOnlyOptionData(broker)
            underlying = str(args.underlying).upper()
            quote = data.spot_quote(underlying)
            spot = float(quote.get("last_price") or 0.0)
            if spot <= 0:
                raise RuntimeError(f"Invalid {underlying} spot last_price from Kite")
            instruments = data.instrument_master(underlying, refresh=True)
            from datetime import datetime
            from .time_utils import IST
            ce, pe = resolve_immediate_weekly_atm_pair(
                instruments, underlying=underlying, as_of=datetime.now(IST).date(), spot=spot
            )
            print("OPTION SIGNAL LIVE CHECK")
            print("execution_allowed=false | KITE READ ONLY | NO ORDER")
            print(f"underlying={underlying}")
            print(f"spot={spot:.2f}")
            print(f"expiry={ce.expiry.isoformat()}")
            print(f"atm_strike={ce.strike:g}")
            print(f"ce={ce.quote_symbol} | lot_size={ce.lot_size}")
            print(f"pe={pe.quote_symbol} | lot_size={pe.lot_size}")
            if ce.expiry != pe.expiry or ce.strike != pe.strike or ce.lot_size != pe.lot_size:
                raise RuntimeError("Resolved ATM CE/PE pair is internally inconsistent")
            print("live_check=PASS")
            return 0
        except Exception as exc:
            print(f"live_check=FAIL | {type(exc).__name__}")
            print("No broker order was placed.")
            return 1

    if args.command == "telegram-test":
        notifier = TelegramNotifier(
            enabled=bool(args.send) and cfg.telegram_enabled,
            dry_run=not bool(args.send) or cfg.telegram_dry_run,
        )
        ok = notifier.send_text("OPTION-SIGNAL-TELEGRAM-TEST", "✅ Devansh Trading System Telegram test. SIGNAL ONLY. No broker order was placed.")
        if args.send:
            print("telegram_send=" + ("OK" if ok else "FAILED_OR_SKIPPED"))
            return 0 if ok else 1
        print("telegram_test=DRY_RUN_ONLY")
        return 0

    if args.command == "run":
        runtime = OptionSignalRuntime(base_dir=base)
        runtime.run_forever(poll_seconds=args.poll_seconds)
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
