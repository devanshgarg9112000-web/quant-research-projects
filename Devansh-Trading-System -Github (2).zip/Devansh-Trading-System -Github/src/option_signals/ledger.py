from __future__ import annotations

import csv
import json
from datetime import date, datetime
from pathlib import Path
from typing import Any

from .models import ExitAlert, OptionContract, OptionSignal, StrategyIntent
from .time_utils import ensure_ist


ENTRY_COLUMNS = [
    "signal_id", "signal_time", "entry_time", "classification", "strategy_ids", "underlying",
    "exchange", "tradingsymbol", "instrument_token", "expiry", "strike", "option_type", "action",
    "lots", "quantity", "spot_price", "entry_reference", "stop_price", "target_price", "max_exit_time",
    "executable", "reason", "metrics_json",
]
EXIT_COLUMNS = [
    "signal_id", "timestamp", "underlying", "exchange", "tradingsymbol", "expiry", "strike",
    "option_type", "lots", "quantity", "entry_reference", "exit_reference", "reference_pnl_rupees", "reason",
]
INTENT_COLUMNS = ["timestamp", "strategy_id", "underlying", "option_type", "spot_price", "reason", "metrics_json", "status"]


class ForwardSignalLedger:
    def __init__(self, base_dir: Path | str = ".") -> None:
        self.root = Path(base_dir) / "reports" / "option_signals"
        self.entries_path = self.root / "forward_entries.csv"
        self.exits_path = self.root / "forward_exits.csv"
        self.intents_path = self.root / "strategy_intents.csv"

    def restore_entries(self) -> tuple[list[OptionSignal], set[str]]:
        """Restore durable reference state after a runtime restart.

        A malformed ledger blocks startup instead of silently losing an open
        manual reference position or emitting a duplicate entry.
        """

        closed_ids: set[str] = set()
        if self.exits_path.exists():
            with self.exits_path.open(newline="", encoding="utf-8") as handle:
                closed_ids = {
                    str(row.get("signal_id") or "").strip()
                    for row in csv.DictReader(handle)
                    if str(row.get("signal_id") or "").strip()
                }

        signals: list[OptionSignal] = []
        if not self.entries_path.exists():
            return signals, closed_ids
        try:
            with self.entries_path.open(newline="", encoding="utf-8") as handle:
                for row in csv.DictReader(handle):
                    lots = int(row["lots"])
                    quantity = int(row["quantity"])
                    if lots <= 0 or quantity <= 0 or quantity % lots:
                        raise ValueError("invalid persisted lots/quantity")
                    contract = OptionContract(
                        underlying=row["underlying"],
                        exchange=row["exchange"],
                        tradingsymbol=row["tradingsymbol"],
                        instrument_token=int(row["instrument_token"]),
                        expiry=date.fromisoformat(row["expiry"]),
                        strike=float(row["strike"]),
                        option_type=row["option_type"],
                        lot_size=quantity // lots,
                    )
                    signals.append(
                        OptionSignal(
                            signal_id=row["signal_id"],
                            strategy_ids=tuple(filter(None, row["strategy_ids"].split("+"))),
                            classification=row["classification"],
                            underlying=row["underlying"],
                            signal_time=ensure_ist(datetime.fromisoformat(row["signal_time"])),
                            entry_time=ensure_ist(datetime.fromisoformat(row["entry_time"])),
                            contract=contract,
                            action=row["action"],
                            lots=lots,
                            quantity=quantity,
                            spot_price=float(row["spot_price"]),
                            entry_reference=float(row["entry_reference"]),
                            stop_price=float(row["stop_price"]),
                            target_price=float(row["target_price"]),
                            max_exit_time=ensure_ist(datetime.fromisoformat(row["max_exit_time"])),
                            reason=row["reason"],
                            metrics=json.loads(row.get("metrics_json") or "{}"),
                            executable=str(row.get("executable") or "").strip().lower() == "true",
                        )
                    )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise RuntimeError("Option signal ledger recovery failed safely") from exc
        return signals, closed_ids

    def log_intent(self, intent: StrategyIntent, *, status: str) -> None:
        row = {
            "timestamp": intent.signal_time.isoformat(),
            "strategy_id": intent.strategy_id,
            "underlying": intent.underlying,
            "option_type": intent.option_type,
            "spot_price": intent.spot_price,
            "reason": intent.reason,
            "metrics_json": json.dumps(intent.metrics, sort_keys=True),
            "status": status,
        }
        self._append(self.intents_path, INTENT_COLUMNS, row)

    def log_entry(self, signal: OptionSignal) -> None:
        c = signal.contract
        row = {
            "signal_id": signal.signal_id,
            "signal_time": signal.signal_time.isoformat(),
            "entry_time": signal.entry_time.isoformat(),
            "classification": signal.classification,
            "strategy_ids": "+".join(signal.strategy_ids),
            "underlying": signal.underlying,
            "exchange": c.exchange,
            "tradingsymbol": c.tradingsymbol,
            "instrument_token": c.instrument_token,
            "expiry": c.expiry.isoformat(),
            "strike": c.strike,
            "option_type": c.option_type,
            "action": signal.action,
            "lots": signal.lots,
            "quantity": signal.quantity,
            "spot_price": signal.spot_price,
            "entry_reference": signal.entry_reference,
            "stop_price": signal.stop_price,
            "target_price": signal.target_price,
            "max_exit_time": signal.max_exit_time.isoformat(),
            "executable": signal.executable,
            "reason": signal.reason,
            "metrics_json": json.dumps(signal.metrics, sort_keys=True, default=str),
        }
        self._append(self.entries_path, ENTRY_COLUMNS, row)

    def log_exit(self, alert: ExitAlert) -> None:
        c = alert.contract
        row = {
            "signal_id": alert.signal_id,
            "timestamp": alert.timestamp.isoformat(),
            "underlying": alert.underlying,
            "exchange": c.exchange,
            "tradingsymbol": c.tradingsymbol,
            "expiry": c.expiry.isoformat(),
            "strike": c.strike,
            "option_type": c.option_type,
            "lots": alert.lots,
            "quantity": alert.quantity,
            "entry_reference": alert.entry_reference,
            "exit_reference": alert.exit_reference,
            "reference_pnl_rupees": alert.reference_pnl_rupees,
            "reason": alert.reason,
        }
        self._append(self.exits_path, EXIT_COLUMNS, row)

    @staticmethod
    def _append(path: Path, columns: list[str], row: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        write_header = not path.exists() or path.stat().st_size == 0
        with path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            if write_header:
                writer.writeheader()
            writer.writerow({column: row.get(column, "") for column in columns})
