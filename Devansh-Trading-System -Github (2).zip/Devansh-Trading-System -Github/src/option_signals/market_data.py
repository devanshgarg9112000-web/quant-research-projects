from __future__ import annotations

from datetime import datetime, timedelta
import math
from typing import Any

from src.brokers.kite_broker import KiteBroker

from .models import MinuteBar, OptionContract
from .time_utils import IST, ensure_ist


SPOT_QUOTE_SYMBOLS = {
    "NIFTY": "NSE:NIFTY 50",
    "SENSEX": "BSE:SENSEX",
}
OPTION_EXCHANGES = {"NIFTY": "NFO", "SENSEX": "BFO"}


class KiteReadOnlyOptionData:
    """Read-only market-data adapter around the existing KiteBroker.

    This class intentionally exposes no order method.
    """

    def __init__(self, broker: KiteBroker) -> None:
        self.broker = broker
        self._instruments: dict[str, list[dict[str, Any]]] = {}
        self._instrument_dates: dict[str, Any] = {}
        self._spot_tokens: dict[str, int] = {}

    def instrument_master(self, underlying: str, *, refresh: bool = False) -> list[dict[str, Any]]:
        underlying = underlying.upper()
        today = datetime.now(IST).date()
        if underlying in self._instruments and not refresh and self._instrument_dates.get(underlying) == today:
            return self._instruments[underlying]
        exchange = OPTION_EXCHANGES[underlying]
        response = self.broker.get_instruments(exchange)
        if not isinstance(response, list):
            raise RuntimeError(f"Kite instrument master unavailable for {exchange}: {_safe_status(response)}")
        self._instruments[underlying] = response
        self._instrument_dates[underlying] = today
        return response

    def spot_quote(self, underlying: str) -> dict[str, Any]:
        underlying = underlying.upper()
        symbol = SPOT_QUOTE_SYMBOLS[underlying]
        response = self.broker.get_quote([symbol])
        if not isinstance(response, dict) or symbol not in response:
            raise RuntimeError(f"Kite spot quote unavailable for {symbol}: {_safe_status(response)}")
        payload = response[symbol]
        if not isinstance(payload, dict):
            raise RuntimeError(f"Unexpected Kite spot quote payload for {symbol}")
        token = payload.get("instrument_token")
        if token is not None:
            self._spot_tokens[underlying] = int(token)
        return payload

    def spot_bars(self, underlying: str, *, now: datetime, history_minutes: int = 120) -> list[MinuteBar]:
        underlying = underlying.upper()
        token = self._spot_tokens.get(underlying)
        if token is None:
            self.spot_quote(underlying)
            token = self._spot_tokens.get(underlying)
        if token is None:
            raise RuntimeError(f"No instrument token returned for {underlying} spot")
        return self._historical_bars(token, now=now, history_minutes=history_minutes, oi=False)

    def option_bars(self, contract: OptionContract, *, now: datetime, history_minutes: int = 20) -> list[MinuteBar]:
        return self._historical_bars(contract.instrument_token, now=now, history_minutes=history_minutes, oi=True)

    def sell_reference(self, contract: OptionContract) -> float:
        payload = self._contract_quote(contract)
        bid = _best_depth_price(payload, "buy")
        if bid is not None and bid > 0:
            return bid
        ltp = _number(payload.get("last_price"))
        if ltp is None or ltp <= 0:
            raise RuntimeError(f"No valid sell reference for {contract.quote_symbol}")
        return ltp

    def buy_reference(self, contract: OptionContract) -> float:
        payload = self._contract_quote(contract)
        ask = _best_depth_price(payload, "sell")
        if ask is not None and ask > 0:
            return ask
        ltp = _number(payload.get("last_price"))
        if ltp is None or ltp <= 0:
            raise RuntimeError(f"No valid buy reference for {contract.quote_symbol}")
        return ltp

    def _contract_quote(self, contract: OptionContract) -> dict[str, Any]:
        response = self.broker.get_quote([contract.quote_symbol])
        if not isinstance(response, dict) or contract.quote_symbol not in response:
            raise RuntimeError(f"Kite quote unavailable for {contract.quote_symbol}: {_safe_status(response)}")
        payload = response[contract.quote_symbol]
        if not isinstance(payload, dict):
            raise RuntimeError(f"Unexpected Kite quote payload for {contract.quote_symbol}")
        return payload

    def _historical_bars(self, instrument_token: int, *, now: datetime, history_minutes: int, oi: bool) -> list[MinuteBar]:
        local_now = ensure_ist(now)
        # Pull extra history so morning/session boundaries and API timestamp rounding
        # do not starve a 25-minute lookback.
        start = local_now - timedelta(minutes=max(int(history_minutes), 45) + 15)
        response = self.broker.get_historical_data(
            int(instrument_token),
            start,
            local_now,
            "minute",
            continuous=False,
            oi=oi,
        )
        if not isinstance(response, list):
            raise RuntimeError(f"Kite historical minute data unavailable: {_safe_status(response)}")
        minute_floor = local_now.replace(second=0, microsecond=0)
        by_time: dict[datetime, MinuteBar] = {}
        for raw in response:
            if not isinstance(raw, dict):
                continue
            ts = raw.get("date") or raw.get("timestamp")
            if not isinstance(ts, datetime):
                try:
                    ts = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                except Exception:
                    continue
            ts = ensure_ist(ts)
            # Never use the current, still-forming minute.
            if ts >= minute_floor:
                continue
            try:
                bar = MinuteBar(
                    timestamp=ts,
                    open=float(raw["open"]),
                    high=float(raw["high"]),
                    low=float(raw["low"]),
                    close=float(raw["close"]),
                    volume=float(raw.get("volume") or 0.0),
                    oi=float(raw.get("oi") or 0.0),
                )
            except (KeyError, TypeError, ValueError):
                continue
            values = (bar.open, bar.high, bar.low, bar.close)
            if ts.date() != local_now.date() or not all(math.isfinite(value) and value > 0 for value in values):
                continue
            if bar.low > min(bar.open, bar.close) or bar.high < max(bar.open, bar.close) or bar.low > bar.high:
                continue
            by_time[ts] = bar
        bars = [by_time[key] for key in sorted(by_time)]
        if history_minutes > 0:
            bars = bars[-max(history_minutes, 1) :]
        return bars


def _number(value: Any) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def _best_depth_price(payload: dict[str, Any], side: str) -> float | None:
    depth = payload.get("depth")
    if not isinstance(depth, dict):
        return None
    rows = depth.get(side)
    if not isinstance(rows, list) or not rows:
        return None
    prices = [
        _number(row.get("price"))
        for row in rows
        if isinstance(row, dict) and (_number(row.get("quantity")) or 0) > 0
    ]
    prices = [price for price in prices if price is not None and price > 0]
    return (max(prices) if side == "buy" else min(prices)) if prices else None


def _safe_status(payload: Any) -> str:
    if isinstance(payload, dict):
        status = payload.get("status")
        if status:
            return str(status)
    return type(payload).__name__
