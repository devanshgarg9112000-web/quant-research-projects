from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True, slots=True)
class OptionSignalConfig:
    enabled: bool
    signal_only: bool
    manual_execution_only: bool
    lots: int
    stop_percent: float
    target_percent: float
    max_hold_minutes: int
    forced_exit_time: str
    max_open_positions_per_underlying: int
    double_confirmation_additional_lots: int
    max_signals_per_day: int
    telegram_enabled: bool
    telegram_dry_run: bool
    nifty_combined_option_return_3m_max: float

    @classmethod
    def from_mapping(cls, data: dict[str, Any]) -> "OptionSignalConfig":
        system = data.get("system", {})
        risk = data.get("risk", {})
        exits = data.get("exits", {})
        alerts = data.get("alerts", {})
        cas = data.get("strategies", {}).get("cas_router", {})
        cfg = cls(
            enabled=bool(system.get("enabled", True)),
            signal_only=bool(system.get("signal_only", True)),
            manual_execution_only=bool(system.get("manual_execution_only", True)),
            lots=int(risk.get("lots_per_signal", 3)),
            stop_percent=float(exits.get("stop_percent", 0.50)),
            target_percent=float(exits.get("target_percent", 0.25)),
            max_hold_minutes=int(exits.get("max_hold_minutes", 30)),
            forced_exit_time=str(exits.get("forced_exit_time", "15:15")),
            max_open_positions_per_underlying=int(risk.get("max_open_positions_per_underlying", 1)),
            double_confirmation_additional_lots=int(risk.get("double_confirmation_additional_lots", 0)),
            max_signals_per_day=int(risk.get("max_signals_per_day", 0)),
            telegram_enabled=bool(alerts.get("telegram_enabled", False)),
            telegram_dry_run=bool(alerts.get("telegram_dry_run", True)),
            nifty_combined_option_return_3m_max=float(cas.get("nifty_combined_option_return_3m_max", 0.01)),
        )
        cfg.validate()
        return cfg

    def validate(self) -> None:
        if not self.signal_only or not self.manual_execution_only:
            raise ValueError("Option signal system must remain signal_only=true and manual_execution_only=true.")
        if (
            self.lots,
            self.stop_percent,
            self.target_percent,
            self.max_hold_minutes,
            self.forced_exit_time,
            self.max_signals_per_day,
        ) != (3, 0.50, 0.25, 30, "15:15", 0):
            raise ValueError("Frozen common forward-validation parameters must remain unchanged.")
        if self.lots <= 0:
            raise ValueError("lots_per_signal must be positive")
        if self.max_open_positions_per_underlying != 1:
            raise ValueError("Forward-validation safety requires exactly one open position per underlying.")
        if self.double_confirmation_additional_lots != 0:
            raise ValueError("Forward-validation safety requires zero extra lots for double confirmation.")
        if not 0 < self.target_percent < 1:
            raise ValueError("target_percent must be between 0 and 1")
        if self.stop_percent <= 0:
            raise ValueError("stop_percent must be positive")
        if self.max_hold_minutes <= 0:
            raise ValueError("max_hold_minutes must be positive")
        if self.max_signals_per_day < 0:
            raise ValueError("max_signals_per_day must be >= 0 (0 disables the cap)")


def load_option_signal_config(base_dir: Path | str = ".") -> tuple[OptionSignalConfig, dict[str, Any]]:
    path = Path(base_dir) / "config" / "option_signals.yaml"
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    _validate_frozen_strategy_spec(data)
    return OptionSignalConfig.from_mapping(data), data


def _validate_frozen_strategy_spec(data: dict[str, Any]) -> None:
    """Prevent silent drift between live-forward rules and the backtested specification."""
    strategies = data.get("strategies", {})
    cas = strategies.get("cas_router", {})
    eff = strategies.get("efficiency_trend", {})
    expected_cas = {
        "enabled": True,
        "nifty_days": ["Monday", "Tuesday", "Friday"],
        "nifty_start": "09:30",
        "nifty_end": "14:00",
        "nifty_lookback": 5,
        "nifty_threshold_bps": 6.0,
        "nifty_cooldown_minutes": 7,
        "nifty_combined_option_return_3m_max": 0.01,
        "sensex_days": ["Wednesday", "Thursday"],
        "sensex_start": "09:16",
        "sensex_end": "15:13",
        "sensex_excluded_start": "11:00",
        "sensex_excluded_end": "13:30",
        "sensex_lookback": 25,
        "sensex_cooldown_minutes": 5,
    }
    expected_eff = {
        "enabled": True,
        "days": ["Monday", "Tuesday", "Friday"],
        "start": "10:00",
        "end": "14:00",
        "lookback": 15,
        "min_efficiency": 0.70,
        "min_return_bps": 10.0,
        "cooldown_minutes": 5,
    }
    for key, expected in expected_cas.items():
        if cas.get(key) != expected:
            raise ValueError(f"Frozen CAS forward-validation parameter drift: {key} must be {expected!r}")
    for key, expected in expected_eff.items():
        if eff.get(key) != expected:
            raise ValueError(f"Frozen Efficiency forward-validation parameter drift: {key} must be {expected!r}")
