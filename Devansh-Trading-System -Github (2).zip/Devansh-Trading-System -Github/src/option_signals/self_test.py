from __future__ import annotations

from datetime import datetime, timedelta

from .features import efficiency_ratio
from .models import MinuteBar
from .strategies import CasRouterStrategy, EfficiencyTrendStrategy
from .time_utils import IST


def run_self_test() -> dict[str, bool]:
    base = datetime(2026, 10, 5, 9, 40, tzinfo=IST)  # Monday
    bars: list[MinuteBar] = []
    price = 25_000.0
    for i in range(60):
        price *= 1.00015
        ts = base + timedelta(minutes=i)
        bars.append(MinuteBar(ts, price - 1, price + 2, price - 2, price, 0, 0))
    cas = CasRouterStrategy().evaluate("NIFTY", bars)
    eff = EfficiencyTrendStrategy().evaluate("NIFTY", bars)
    er = efficiency_ratio(bars, 15)
    return {
        "cas_signal": cas is not None and cas.option_type == "PE",
        "efficiency_signal": eff is not None and eff.option_type == "PE",
        "efficiency_ratio_valid": er is not None and 0.99 <= er <= 1.0,
    }
