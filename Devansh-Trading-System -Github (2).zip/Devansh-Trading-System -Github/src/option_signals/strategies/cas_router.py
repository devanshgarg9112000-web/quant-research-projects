from __future__ import annotations

from collections.abc import Sequence
from datetime import time

from src.option_signals.features import close_return_bps, failed_breakout_direction
from src.option_signals.models import MinuteBar, StrategyIntent


class CasRouterStrategy:
    """Frozen August/September 2026 CAS-era strategy rules.

    NIFTY: 5-minute momentum, Mon/Tue/Fri, 09:30..14:00, +/-6 bps.
    SENSEX: 25-minute failed breakout, Wed/Thu, excluding 11:00..13:30.

    The NIFTY ATM option-complex filter is intentionally evaluated by the
    orchestration layer after the ATM contracts have been resolved.
    """

    strategy_id = "CAS_ROUTER_V1"

    def __init__(
        self,
        *,
        nifty_lookback: int = 5,
        nifty_threshold_bps: float = 6.0,
        sensex_lookback: int = 25,
    ) -> None:
        self.nifty_lookback = int(nifty_lookback)
        self.nifty_threshold_bps = float(nifty_threshold_bps)
        self.sensex_lookback = int(sensex_lookback)

    def evaluate(self, underlying: str, bars: Sequence[MinuteBar]) -> StrategyIntent | None:
        if not bars:
            return None
        underlying = underlying.upper()
        latest = bars[-1]
        weekday = latest.timestamp.weekday()  # Mon=0
        clock = latest.timestamp.time().replace(tzinfo=None)

        if underlying == "NIFTY":
            if weekday not in {0, 1, 4}:
                return None
            if not (time(9, 30) <= clock <= time(14, 0)):
                return None
            ret_bps = close_return_bps(bars, self.nifty_lookback)
            if ret_bps is None:
                return None
            if ret_bps >= self.nifty_threshold_bps:
                option_type = "PE"
            elif ret_bps <= -self.nifty_threshold_bps:
                option_type = "CE"
            else:
                return None
            return StrategyIntent(
                strategy_id=self.strategy_id,
                underlying="NIFTY",
                signal_time=latest.timestamp,
                option_type=option_type,
                spot_price=float(latest.close),
                reason=f"NIFTY {self.nifty_lookback}m momentum {ret_bps:.2f} bps",
                metrics={"return_bps": ret_bps, "lookback": self.nifty_lookback},
            )

        if underlying == "SENSEX":
            if weekday not in {2, 3}:
                return None
            # Full allowed signal universe is 09:16..15:13, with weak midday excluded.
            if not (time(9, 16) <= clock <= time(15, 13)):
                return None
            if time(11, 0) <= clock <= time(13, 30):
                return None
            option_type = failed_breakout_direction(bars, self.sensex_lookback)
            if option_type is None:
                return None
            return StrategyIntent(
                strategy_id=self.strategy_id,
                underlying="SENSEX",
                signal_time=latest.timestamp,
                option_type=option_type,
                spot_price=float(latest.close),
                reason=f"SENSEX failed breakout over prior {self.sensex_lookback}m",
                metrics={"lookback": self.sensex_lookback},
            )
        return None

    def cooldown_minutes(self, underlying: str) -> int:
        return 7 if underlying.upper() == "NIFTY" else 5
