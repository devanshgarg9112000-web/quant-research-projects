from __future__ import annotations

from collections.abc import Sequence
from datetime import time

from src.option_signals.features import close_return_bps, efficiency_ratio
from src.option_signals.models import MinuteBar, StrategyIntent


class EfficiencyTrendStrategy:
    """Frozen selective NIFTY 15-minute Efficiency Trend candidate.

    Mon/Tue/Fri, 10:00..14:00, ER >= 0.70 and |15m return| >= 10 bps.
    Positive spot trend sells ATM PE; negative spot trend sells ATM CE.
    """

    strategy_id = "NIFTY_EFFICIENCY_TREND_V1"

    def __init__(
        self,
        *,
        lookback: int = 15,
        min_efficiency: float = 0.70,
        min_return_bps: float = 10.0,
        cooldown_minutes: int = 5,
    ) -> None:
        self.lookback = int(lookback)
        self.min_efficiency = float(min_efficiency)
        self.min_return_bps = float(min_return_bps)
        self._cooldown_minutes = int(cooldown_minutes)

    def evaluate(self, underlying: str, bars: Sequence[MinuteBar]) -> StrategyIntent | None:
        if underlying.upper() != "NIFTY" or not bars:
            return None
        latest = bars[-1]
        if latest.timestamp.weekday() not in {0, 1, 4}:
            return None
        clock = latest.timestamp.time().replace(tzinfo=None)
        if not (time(10, 0) <= clock <= time(14, 0)):
            return None

        ret_bps = close_return_bps(bars, self.lookback)
        er = efficiency_ratio(bars, self.lookback)
        if ret_bps is None or er is None:
            return None
        if er < self.min_efficiency or abs(ret_bps) < self.min_return_bps:
            return None
        option_type = "PE" if ret_bps > 0 else "CE"
        return StrategyIntent(
            strategy_id=self.strategy_id,
            underlying="NIFTY",
            signal_time=latest.timestamp,
            option_type=option_type,
            spot_price=float(latest.close),
            reason=f"NIFTY {self.lookback}m efficiency trend ER={er:.3f}, return={ret_bps:.2f} bps",
            metrics={"efficiency_ratio": er, "return_bps": ret_bps, "lookback": self.lookback},
        )

    def cooldown_minutes(self) -> int:
        return self._cooldown_minutes
