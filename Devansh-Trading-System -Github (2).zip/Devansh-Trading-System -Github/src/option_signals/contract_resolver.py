from __future__ import annotations

from datetime import date, datetime
import math
from typing import Any

from .models import OptionContract


UNDERLYING_EXCHANGE = {"NIFTY": "NFO", "SENSEX": "BFO"}


def _as_date(value: Any) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text[:10]).date()
    except ValueError:
        return None


def _normalized_option_rows(instruments: list[dict[str, Any]], underlying: str, as_of: date) -> list[dict[str, Any]]:
    underlying = underlying.upper()
    exchange = UNDERLYING_EXCHANGE[underlying]
    rows: list[dict[str, Any]] = []
    for raw in instruments:
        if str(raw.get("exchange") or "").upper() != exchange:
            continue
        if str(raw.get("name") or raw.get("underlying") or "").upper() != underlying:
            continue
        option_type = str(raw.get("instrument_type") or raw.get("option_type") or "").upper()
        if option_type not in {"CE", "PE"}:
            continue
        expiry = _as_date(raw.get("expiry"))
        if expiry is None or expiry < as_of:
            continue
        try:
            strike = float(raw.get("strike"))
            token = int(raw.get("instrument_token"))
            lot_size = int(raw.get("lot_size"))
            tick_size = float(raw.get("tick_size") or 0.05)
        except (TypeError, ValueError):
            continue
        if (
            not math.isfinite(strike)
            or not math.isfinite(tick_size)
            or strike <= 0
            or token <= 0
            or lot_size <= 0
            or tick_size <= 0
            or not str(raw.get("tradingsymbol") or "").strip()
        ):
            continue
        row = dict(raw)
        row.update(expiry=expiry, strike=strike, instrument_token=token, lot_size=lot_size, tick_size=tick_size, instrument_type=option_type)
        rows.append(row)
    return rows


def resolve_immediate_weekly_atm_pair(
    instruments: list[dict[str, Any]],
    *,
    underlying: str,
    as_of: date,
    spot: float,
) -> tuple[OptionContract, OptionContract]:
    """Resolve actual nearest listed expiry and a common ATM strike CE/PE pair.

    No weekday arithmetic is used; holiday-shifted expiries are therefore handled
    by the broker instrument master itself.
    """

    underlying = underlying.upper()
    if underlying not in UNDERLYING_EXCHANGE:
        raise ValueError(f"Unsupported underlying: {underlying}")
    if not math.isfinite(float(spot)) or float(spot) <= 0:
        raise ValueError("Invalid spot reference")
    rows = _normalized_option_rows(instruments, underlying, as_of)
    if not rows:
        raise LookupError(f"No live {underlying} option instruments found on/after {as_of}")
    expiry = min(row["expiry"] for row in rows)
    exp_rows = [row for row in rows if row["expiry"] == expiry]
    ce = {row["strike"]: row for row in exp_rows if row["instrument_type"] == "CE"}
    pe = {row["strike"]: row for row in exp_rows if row["instrument_type"] == "PE"}
    common = sorted(set(ce).intersection(pe))
    if not common:
        raise LookupError(f"No common CE/PE strikes for {underlying} expiry {expiry}")
    atm = min(common, key=lambda strike: (abs(float(strike) - float(spot)), float(strike)))
    if ce[atm]["lot_size"] != pe[atm]["lot_size"]:
        raise ValueError("Resolved ATM CE/PE pair has inconsistent lot sizes")
    return _to_contract(underlying, ce[atm]), _to_contract(underlying, pe[atm])


def resolve_immediate_weekly_atm(
    instruments: list[dict[str, Any]],
    *,
    underlying: str,
    as_of: date,
    spot: float,
    option_type: str,
) -> OptionContract:
    ce, pe = resolve_immediate_weekly_atm_pair(instruments, underlying=underlying, as_of=as_of, spot=spot)
    option_type = option_type.upper()
    if option_type == "CE":
        return ce
    if option_type == "PE":
        return pe
    raise ValueError(f"Unsupported option type: {option_type}")


def _to_contract(underlying: str, row: dict[str, Any]) -> OptionContract:
    return OptionContract(
        underlying=underlying,
        exchange=str(row["exchange"]).upper(),
        tradingsymbol=str(row["tradingsymbol"]),
        instrument_token=int(row["instrument_token"]),
        expiry=row["expiry"],
        strike=float(row["strike"]),
        option_type=str(row["instrument_type"]).upper(),
        lot_size=int(row["lot_size"]),
        tick_size=float(row.get("tick_size") or 0.05),
    )
