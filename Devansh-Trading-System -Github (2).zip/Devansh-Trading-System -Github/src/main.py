from __future__ import annotations

import csv
from pathlib import Path

from src.alerts.telegram import send_trade_alert
from src.alerts.whatsapp import send_whatsapp_trade_alert
from src.backtesting.engine import BacktestEngine
from src.backtesting.reports import save_backtest_report
from src.brokers.paper_broker import PaperBroker
from src.config_loader import load_configs
from src.data.sample_data import generate_sample_candles, generate_sample_ticks
from src.data_feeds.candle_builder import build_candles_from_ticks_seconds
from src.data_feeds.tick_storage import TickCsvError, append_daily_ticks, default_tick_file, load_normalized_ticks, resolve_tick_file, save_normalized_ticks
from src.data_feeds.truedata_feed import TrueDataFeed
from src.filters.data_quality_guard import validate_candles
from src.indicators.order_flow import analyze_order_flow
from src.journal.trade_journal import TradeJournal
from src.risk.risk_engine import RiskEngine
from src.replay.replay_engine import filter_replay_ticks, group_replay_ticks, parse_replay_symbols
from src.strategies.strategy_engine import StrategyEngine
from src.utils.environment_check import run_environment_check
from src.utils.logger import log_event, setup_logs


MIN_REPLAY_TICKS = 4


def run_system(base_dir: Path | str = ".", data_feed: str = "sample", symbols: str | None = None, seconds: int = 60, tick_file: str | None = None) -> None:
    base = Path(base_dir)
    setup_logs(base)
    configs = load_configs(base)
    settings = configs["settings"]
    risk_config = configs["risk"]
    strategies = configs["strategies"]
    instruments = configs["instruments"]
    mode = settings.get("mode", "PAPER")
    live_trading = bool(settings.get("enable_live_trading"))

    print("Devansh Trading System")
    print(f"Mode: {mode}")
    print(f"Live trading: {'ENABLED' if live_trading else 'DISABLED'}")
    print(f"Data feed mode: {data_feed.upper()}")
    active = [name for name, enabled in strategies.items() if enabled]
    print("Active strategies: " + ", ".join(active))
    print(f"Risk per trade: {risk_config.get('risk_per_trade_percent')}%")

    check = run_environment_check(base)
    for warning in check["warnings"]:
        print("Environment warning:", warning)

    if data_feed == "truedata":
        run_truedata_paper_mode(base, settings, risk_config, strategies, symbols or "BANKNIFTY", seconds, instruments)
        return

    if data_feed == "replay":
        run_replay_paper_mode(base, settings, risk_config, strategies, symbols, tick_file, instruments)
        return

    candles = generate_sample_candles()
    ticks = generate_sample_ticks()
    quality_ok, quality_errors = validate_candles(candles)
    if not quality_ok:
        print("Data quality failed:", quality_errors)
        return

    engine = StrategyEngine(settings, strategies)
    result = engine.run(candles, ticks)
    print(f"Market Mode: {result.market_mode}")
    print("Candidate signals:")
    for signal in result.candidates:
        print(f"- {signal.strategy_name} {signal.side} {signal.symbol} entry={signal.entry_price} stop={signal.stop_loss} target={signal.target_price} score={signal.score}")
    print("Rejected / notes:")
    for reason in result.rejected_reasons[:12]:
        print(f"- {reason}")

    journal = TradeJournal(base)
    if result.best_signal:
        print(f"Accepted best signal: {result.best_signal.strategy_name}")
        journal.log_signal(result.best_signal)
        decision = RiskEngine(risk_config, settings, instruments=instruments).validate_signal(result.best_signal, mode=mode, data_quality_ok=quality_ok)
        if decision.approved:
            broker = PaperBroker(journal)
            order, trade = broker.place_order(result.best_signal, decision.quantity)
            print(f"Paper trade simulated: order={order.order_id} quantity={decision.quantity}")
            send_trade_alert(result.best_signal, mode, live_trading, settings.get("enable_telegram_alerts", False), decision.risk_amount)
            send_whatsapp_trade_alert(result.best_signal, mode, live_trading, settings.get("enable_whatsapp_alerts", False))
        else:
            print("Risk rejected signal:")
            for reason in decision.reasons:
                print(f"- {reason}")
    else:
        print("No accepted signal.")

    backtest = BacktestEngine(settings, risk_config, strategies, instruments).run(candles, ticks)
    report_path = save_backtest_report(backtest.combined_trades, backtest.strategy_trades, strategies, base / "reports" / "backtest_reports")
    print(f"Backtest report generated: {report_path}")
    print("Final instruction: stay in PAPER mode until real-data validation, paper trading, broker sessions, and all live safety gates are verified.")
    log_event("Sample PAPER run completed.", base)


def run_truedata_paper_mode(
    base: Path,
    settings: dict,
    risk_config: dict,
    strategies: dict,
    symbols_text: str,
    seconds: int,
    instruments: dict | None = None,
) -> None:
    print("TrueData PAPER live-data mode. Broker orders disabled.")
    print("No Kite orders will be placed. This run only collects market data and paper-simulates signals.")
    settings = dict(settings)
    settings["mode"] = "PAPER"
    settings["enable_live_trading"] = False
    settings["enable_true_data"] = True
    symbols = [symbol.strip() for symbol in symbols_text.split(",") if symbol.strip()]
    report = _new_paper_report(symbols, "TRUEDATA", "TRUE DATA PAPER LIVE RUN SUMMARY", "PAPER MODE ONLY. No broker orders were placed.")
    if not symbols:
        print("TrueData PAPER mode skipped: no symbols supplied.")
        report["notes"].append("No symbols supplied.")
        _finalize_live_paper_report(base, report)
        return

    feed = TrueDataFeed(settings, base, allow_network=True)
    ticks = feed.collect_live_ticks(symbols, max(1, seconds), echo=False)
    tick_path = save_normalized_ticks(ticks, default_tick_file(base))
    print(f"Normalized ticks saved: {tick_path}")
    daily_result = append_daily_ticks(ticks, base, source="TRUEDATA")
    print(
        "Daily tick recorder: "
        f"{daily_result['rows_written']} new rows across {daily_result['files_touched']} files"
    )
    report["total_ticks"] = len(ticks)
    print(f"TrueData ticks collected: {len(ticks)}")
    if not ticks:
        print("No normalized ticks received. No signal evaluation performed.")
        report["notes"].append("No normalized ticks received. No signal evaluation performed.")
        _finalize_live_paper_report(base, report)
        return

    _evaluate_paper_ticks(base, settings, risk_config, strategies, symbols, ticks, report, candle_label="live", instruments=instruments)
    _finalize_live_paper_report(base, report)
    log_event("TrueData PAPER live-data run completed with broker orders disabled.", base)


def run_replay_paper_mode(
    base: Path,
    settings: dict,
    risk_config: dict,
    strategies: dict,
    symbols_text: str | None,
    tick_file: str | None = None,
    instruments: dict | None = None,
) -> None:
    print("Replay PAPER mode. Broker orders disabled.")
    print("PAPER MODE ONLY. No broker orders were placed.")
    settings = dict(settings)
    settings["mode"] = "PAPER"
    settings["enable_live_trading"] = False
    tick_path = resolve_tick_file(base, tick_file)
    symbols = parse_replay_symbols(symbols_text)
    report = _new_paper_report(
        symbols,
        "REPLAY",
        "REPLAY PAPER RUN SUMMARY",
        "PAPER MODE ONLY. No broker orders were placed.",
        tick_file=str(tick_path),
    )
    try:
        source_ticks = load_normalized_ticks(tick_path)
    except FileNotFoundError:
        message = f"Replay tick file missing: {tick_path}. Record ticks first with python run.py --data-feed truedata --symbols \"GOLD-I,SILVER-I\" --seconds 300"
        print(message)
        report["notes"].append(message)
        _finalize_live_paper_report(base, report)
        return
    except TickCsvError as exc:
        message = f"Replay tick CSV invalid: {exc}"
        print(message)
        report["notes"].append(message)
        _finalize_live_paper_report(base, report)
        return

    if not symbols:
        symbols = _symbols_from_ticks(source_ticks)
        report["symbols"] = symbols
    ticks = filter_replay_ticks(source_ticks, symbols)
    report["total_ticks"] = len(ticks)
    print(f"Tick File: {tick_path}")
    print(f"Replay ticks loaded: {len(ticks)} matching ticks from {len(source_ticks)} file ticks.")
    if len(ticks) < MIN_REPLAY_TICKS:
        message = f"Replay tick file has only {len(ticks)} ticks. This is too few for reliable strategy diagnostics; continuing safely."
        print(message)
        report["notes"].append(message)
    if not ticks:
        if source_ticks and symbols:
            message = f"Replay tick file contains no ticks matching requested symbols: {', '.join(symbols)}."
        else:
            message = "Replay tick file is empty. No signal evaluation performed."
        print(message)
        report["notes"].append(message)
        _finalize_live_paper_report(base, report)
        return

    _evaluate_paper_ticks(base, settings, risk_config, strategies, symbols, ticks, report, candle_label="replay", instruments=instruments)
    _finalize_live_paper_report(base, report)
    log_event("Replay PAPER run completed with broker orders disabled.", base)


def _evaluate_paper_ticks(
    base: Path,
    settings: dict,
    risk_config: dict,
    strategies: dict,
    symbols: list[str],
    ticks: list[dict],
    report: dict,
    candle_label: str,
    instruments: dict | None = None,
    journal_signals: bool = True,
) -> None:
    journal = TradeJournal(base)
    engine = StrategyEngine(settings, strategies)
    grouped_ticks = group_replay_ticks(ticks)
    for symbol in symbols:
        symbol_ticks = grouped_ticks.get(symbol, [])
        symbol_report = _build_symbol_report(symbol, symbol_ticks)
        report["symbols_data"][symbol] = symbol_report
        print(f"\nSymbol: {symbol}")
        print(f"Ticks: {len(symbol_ticks)}")
        if not symbol_ticks:
            print("No ticks received for this symbol.")
            symbol_report["notes"].append("No ticks received for this symbol.")
            continue
        order_flow = analyze_order_flow(symbol_ticks)
        symbol_report["order_flow_delta"] = order_flow["total_delta"]
        symbol_report["order_flow_event"] = order_flow["event"]
        print(f"Order-flow total delta: {order_flow['total_delta']}")
        print(f"Order-flow event: {order_flow['event']}")
        candles = build_candles_from_ticks_seconds(symbol_ticks, timeframe_seconds=15)
        symbol_report["candles_built"] = len(candles)
        print(f"Built {candle_label} candles: {len(candles)} using 15-second buckets")
        quality_ok, quality_errors = validate_candles(candles)
        if not quality_ok:
            print(f"{candle_label.title()} candle quality failed:", quality_errors)
            symbol_report["notes"].extend(f"{candle_label.title()} candle quality failed: {error}" for error in quality_errors)
            continue
        if len(candles) < 4:
            print(f"Not enough {candle_label} candles for strategy engine yet. Collect or replay more ticks if needed.")
            symbol_report["notes"].append(f"Not enough {candle_label} candles for strategy engine yet. Collect or replay more ticks if needed.")
            continue
        result = engine.run(candles, symbol_ticks)
        symbol_report["market_mode"] = result.market_mode
        context = getattr(result, "context", {}) or {}
        diagnostics = context.get("cluster_diagnostics") or {}
        cluster_gate = context.get("cluster_gate") or {}
        if cluster_gate.get("applicable"):
            symbol_report["cluster_diagnostic_status"] = cluster_gate.get("diagnostic_status", "NOT_EVALUATED")
            symbol_report["cluster_data_sufficient"] = bool(cluster_gate.get("data_sufficient"))
            symbol_report["cluster_directional_bias"] = cluster_gate.get("preferred_side") or "NONE"
            symbol_report["cluster_gate_status"] = cluster_gate.get("gate_status", "NOT_EVALUATED")
            symbol_report["cluster_gate_reason"] = cluster_gate.get("reason", "No cluster gate reason.")
            symbol_report["cluster_buy_imbalance_levels"] = diagnostics.get("buy_imbalance_levels", [])
            symbol_report["cluster_sell_imbalance_levels"] = diagnostics.get("sell_imbalance_levels", [])
            print(f"MCX Cluster Diagnostic: {symbol_report['cluster_diagnostic_status']}")
            print(f"MCX Cluster Data Sufficient: {'YES' if symbol_report['cluster_data_sufficient'] else 'NO'}")
            print(f"MCX Cluster Gate: {symbol_report['cluster_gate_status']} bias={symbol_report['cluster_directional_bias']}")
            print(f"MCX Cluster Gate Reason: {symbol_report['cluster_gate_reason']}")
        print(f"Market Mode: {result.market_mode}")
        print("Candidate signals:")
        for signal in result.candidates:
            print(f"- {signal.strategy_name} {signal.side} entry={signal.entry_price} stop={signal.stop_loss} target={signal.target_price} score={signal.score}")
        if result.best_signal:
            symbol_report["candidate_signal"] = _signal_dashboard_snapshot(result.best_signal)
            if journal_signals:
                journal.log_signal(result.best_signal)
            decision = RiskEngine(risk_config, settings, instruments=instruments).validate_signal(result.best_signal, mode="PAPER", data_quality_ok=quality_ok)
            sizing = getattr(decision, "sizing", {}) or {}
            symbol_report["risk_sizing"] = sizing
            if decision.approved:
                _print_accepted_paper_signal(result.best_signal, decision)
                signal_row = _paper_signal_row(result.best_signal, decision, live_trading=False)
                report["paper_signals"].append(signal_row)
                symbol_report["accepted_signals"].append(signal_row)
            else:
                symbol_report["risk_rejection_reasons"] = list(decision.reasons)
                print("Risk rejected PAPER signal:")
                for reason in decision.reasons:
                    print(f"- {reason}")
                _print_risk_sizing_details(sizing)
                symbol_report["notes"].extend(f"Risk rejected: {reason}" for reason in decision.reasons)
        else:
            print("No accepted signal.")
            symbol_report["notes"].append("No accepted signal.")
        print("Rejected / notes:")
        for reason in result.rejected_reasons[:8]:
            print(f"- {reason}")
            symbol_report["notes"].append(reason)


def _new_paper_report(symbols: list[str], data_feed: str, title: str, safety_line: str, tick_file: str | None = None) -> dict:
    return {
        "title": title,
        "mode": "PAPER",
        "data_feed": data_feed,
        "tick_file": tick_file,
        "live_trading": False,
        "broker_order_status": "DISABLED",
        "symbols": symbols,
        "total_ticks": 0,
        "symbols_data": {},
        "paper_signals": [],
        "notes": [],
        "safety_line": safety_line,
    }


def _symbols_from_ticks(ticks: list[dict]) -> list[str]:
    symbols: list[str] = []
    for tick in ticks:
        symbol = tick.get("symbol")
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _build_symbol_report(symbol: str, ticks: list[dict]) -> dict:
    first_tick = ticks[0]["timestamp"] if ticks else None
    last_tick = ticks[-1]["timestamp"] if ticks else None
    latest_ltp = ticks[-1]["ltp"] if ticks else None
    bid_count = sum(1 for tick in ticks if tick.get("bid") is not None)
    ask_count = sum(1 for tick in ticks if tick.get("ask") is not None)
    return {
        "symbol": symbol,
        "ticks": len(ticks),
        "first_tick_time": first_tick,
        "last_tick_time": last_tick,
        "latest_ltp": latest_ltp,
        "bid_ask_availability": f"{bid_count}/{ask_count} of {len(ticks)} ticks",
        "candles_built": 0,
        "market_mode": "NOT_EVALUATED",
        "order_flow_delta": 0.0,
        "order_flow_event": "NOT_EVALUATED",
        "cluster_diagnostic_status": "NOT_APPLICABLE",
        "cluster_data_sufficient": False,
        "cluster_directional_bias": "NONE",
        "cluster_gate_status": "NOT_APPLICABLE",
        "cluster_gate_reason": "MCX cluster gate not applicable.",
        "cluster_buy_imbalance_levels": [],
        "cluster_sell_imbalance_levels": [],
        "risk_sizing": None,
        "candidate_signal": None,
        "risk_rejection_reasons": [],
        "accepted_signals": [],
        "notes": [],
    }


def _paper_signal_row(signal, decision, live_trading: bool) -> dict:
    sizing = getattr(decision, "sizing", {}) or {}
    return {
        "timestamp": signal.timestamp,
        "symbol": signal.symbol,
        "strategy": signal.strategy_name,
        "side": signal.side,
        "entry": signal.entry_price,
        "stop_loss": signal.stop_loss,
        "target": signal.target_price,
        "quantity": decision.quantity,
        "score": signal.score,
        "market_mode": signal.market_mode,
        "reason": signal.reason,
        "cluster_gate_result": signal.metadata.get("cluster_gate_result", "NOT_APPLICABLE"),
        "cluster_gate_reason": signal.metadata.get("cluster_gate_reason", "MCX cluster gate not applicable."),
        "cluster_diagnostic_status": signal.metadata.get("cluster_diagnostic_status", "NOT_APPLICABLE"),
        "cluster_data_sufficient": bool(signal.metadata.get("cluster_data_sufficient", False)),
        "risk_per_unit": sizing.get("risk_per_unit"),
        "estimated_risk_amount": sizing.get("estimated_risk_amount", decision.risk_amount),
        "point_value": sizing.get("point_value"),
        "min_qty": sizing.get("min_qty"),
        "lot_size": sizing.get("lot_size"),
        "execution_allowed": False,
        "live_trading": bool(live_trading),
    }


def _finalize_live_paper_report(base: Path, report: dict) -> None:
    lines = _format_live_paper_summary(report)
    dashboard_rows = _build_paper_dashboard_rows(report)
    dashboard_lines = _format_paper_signal_dashboard(dashboard_rows)
    summary_text = "\n".join(lines)
    dashboard_text = "\n".join(dashboard_lines)
    text = summary_text + "\n\n" + dashboard_text
    print("\n" + text)
    report_dir = base / "reports" / "daily_trade_reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "latest_live_paper_report.txt").write_text(text + "\n", encoding="utf-8")
    _write_paper_signals_csv(report_dir / "latest_paper_signals.csv", report["paper_signals"])
    (report_dir / "latest_paper_signal_dashboard.txt").write_text(dashboard_text + "\n", encoding="utf-8")
    _write_paper_signal_dashboard_csv(report_dir / "latest_paper_signal_dashboard.csv", dashboard_rows)


def _format_live_paper_summary(report: dict) -> list[str]:
    lines = [
        report.get("title", "PAPER RUN SUMMARY"),
        f"Mode: {report['mode']}",
        f"Data Feed: {report['data_feed']}",
    ]
    if report.get("tick_file"):
        lines.append(f"Tick File: {report['tick_file']}")
    lines.extend([
        f"Live Trading: {'ENABLED' if report['live_trading'] else 'DISABLED'}",
        f"Broker Orders: {report['broker_order_status']}",
        f"Subscribed Symbols: {', '.join(report['symbols']) if report['symbols'] else 'NONE'}",
        f"Total Ticks Collected: {report['total_ticks']}",
        "",
        "SYMBOL DETAILS",
    ])
    for symbol in report["symbols"]:
        data = report["symbols_data"].get(symbol) or _build_symbol_report(symbol, [])
        lines.extend([
            f"- {symbol}",
            f"  Ticks: {data['ticks']}",
            f"  First Tick Time: {_fmt_value(data['first_tick_time'])}",
            f"  Last Tick Time: {_fmt_value(data['last_tick_time'])}",
            f"  Latest LTP: {_fmt_value(data['latest_ltp'])}",
            f"  Bid/Ask Availability: {data['bid_ask_availability']}",
            f"  Candles Built: {data['candles_built']}",
            f"  Market Mode: {data['market_mode']}",
            f"  Order-flow Delta: {data['order_flow_delta']}",
            f"  Order-flow Event: {data['order_flow_event']}",
            f"  Cluster Diagnostic Status: {data['cluster_diagnostic_status']}",
            f"  Cluster Data Sufficient: {'YES' if data['cluster_data_sufficient'] else 'NO'}",
            f"  Cluster Directional Bias: {data['cluster_directional_bias']}",
            f"  Cluster Gate Status: {data['cluster_gate_status']}",
            f"  Cluster Gate Reason: {data['cluster_gate_reason']}",
            "  Execution Allowed: false",
        ])
        if data.get("risk_sizing"):
            sizing = data["risk_sizing"]
            lines.extend([
                f"  Risk Budget: {sizing.get('allowed_risk_amount')}",
                f"  Stop Distance: {sizing.get('stop_distance')}",
                f"  Point Value: {sizing.get('point_value')}",
                f"  Risk Per Unit: {sizing.get('risk_per_unit')}",
                f"  Minimum Quantity: {sizing.get('min_qty')}",
                f"  Lot Size: {sizing.get('lot_size')}",
                f"  Calculated Quantity: {sizing.get('calculated_qty')}",
                f"  Estimated Risk Amount: {sizing.get('estimated_risk_amount')}",
            ])
        if data["accepted_signals"]:
            for signal in data["accepted_signals"]:
                lines.append(f"  Accepted PAPER Signal: {signal['strategy']} {signal['side']} qty={signal['quantity']} entry={signal['entry']} score={signal['score']}")
        else:
            lines.append("  Accepted PAPER Signal: NONE")
        if data["notes"]:
            lines.append("  Rejected/No-Setup Notes:")
            for note in data["notes"][:10]:
                lines.append(f"    - {note}")
        else:
            lines.append("  Rejected/No-Setup Notes: NONE")
    lines.extend(["", "ACCEPTED PAPER SIGNALS"])
    if report["paper_signals"]:
        for signal in report["paper_signals"]:
            lines.append(f"- {signal['timestamp']} {signal['symbol']} {signal['strategy']} {signal['side']} qty={signal['quantity']} score={signal['score']}")
    else:
        lines.append("- NONE")
    if report["notes"]:
        lines.extend(["", "RUN NOTES"])
        lines.extend(f"- {note}" for note in report["notes"])
    lines.extend(["", report.get("safety_line", "PAPER MODE ONLY. No broker orders were placed.")])
    return lines


def _write_paper_signals_csv(path: Path, paper_signals: list[dict]) -> None:
    columns = [
        "timestamp", "symbol", "strategy", "side", "entry", "stop_loss", "target", "quantity",
        "score", "market_mode", "reason", "cluster_gate_result", "cluster_gate_reason",
        "cluster_diagnostic_status", "cluster_data_sufficient", "risk_per_unit",
        "estimated_risk_amount", "point_value", "min_qty", "lot_size",
        "execution_allowed", "live_trading",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for signal in paper_signals:
            row = dict(signal)
            row["cluster_data_sufficient"] = "true" if row["cluster_data_sufficient"] else "false"
            row["execution_allowed"] = "false"
            row["live_trading"] = "true" if row["live_trading"] else "false"
            writer.writerow(row)


def _signal_dashboard_snapshot(signal) -> dict:
    return {
        "direction": signal.side,
        "strategy": signal.strategy_name,
        "entry": signal.entry_price,
        "stop": signal.stop_loss,
        "target": signal.target_price,
        "rr": signal.reward_risk,
        "score": signal.score,
        "key_reason": signal.reason,
    }


def _build_paper_dashboard_rows(report: dict) -> list[dict]:
    rows: list[dict] = []
    for symbol in report.get("symbols", []):
        data = report.get("symbols_data", {}).get(symbol) or _build_symbol_report(symbol, [])
        accepted = data.get("accepted_signals") or []
        candidate = data.get("candidate_signal") or {}
        sizing = data.get("risk_sizing") or {}
        rejection_reasons = data.get("risk_rejection_reasons") or []
        if accepted:
            accepted_signal = accepted[0]
            status = "ACCEPTED_PAPER_SIGNAL"
            signal_data = {
                "signal_time": accepted_signal.get("timestamp"),
                "direction": accepted_signal.get("side"),
                "strategy": accepted_signal.get("strategy"),
                "entry": accepted_signal.get("entry"),
                "stop": accepted_signal.get("stop_loss"),
                "target": accepted_signal.get("target"),
                "rr": candidate.get("rr"),
                "score": accepted_signal.get("score"),
                "key_reason": accepted_signal.get("reason"),
            }
        elif candidate and rejection_reasons:
            status = "RISK_REJECTED"
            signal_data = candidate
        else:
            status = "NO_SIGNAL"
            signal_data = candidate
        key_reason = signal_data.get("key_reason")
        if not key_reason:
            key_reason = _dashboard_no_signal_reason(data)
        rows.append({
            "symbol": symbol,
            "status": status,
            "signal_time": signal_data.get("signal_time"),
            "direction": signal_data.get("direction"),
            "strategy": signal_data.get("strategy"),
            "entry": signal_data.get("entry"),
            "stop": signal_data.get("stop"),
            "target": signal_data.get("target"),
            "rr": signal_data.get("rr"),
            "score": signal_data.get("score"),
            "qty": sizing.get("calculated_qty", accepted[0].get("quantity") if accepted else None),
            "risk_budget": sizing.get("allowed_risk_amount"),
            "estimated_risk_amount": sizing.get("estimated_risk_amount"),
            "key_reason": key_reason,
            "rejection_reason": "; ".join(str(reason) for reason in rejection_reasons) or None,
            "cluster_status": data.get("cluster_diagnostic_status", "NOT_APPLICABLE"),
            "cluster_gate_status": data.get("cluster_gate_status", "NOT_APPLICABLE"),
            "market_mode": data.get("market_mode", "NOT_EVALUATED"),
            "execution_allowed": False,
        })
    return rows


def _dashboard_no_signal_reason(data: dict) -> str:
    notes = data.get("notes") or []
    if notes:
        return str(notes[0])
    if not data.get("ticks"):
        return "No ticks available for signal evaluation."
    return "No strategy produced an accepted signal."


def _format_paper_signal_dashboard(rows: list[dict]) -> list[str]:
    lines = ["FINAL PAPER SIGNAL DASHBOARD"]
    if not rows:
        lines.extend([
            "No symbols were available for dashboard evaluation.",
            "Execution Allowed: false",
            "Broker Orders: DISABLED",
        ])
        return lines
    for row in rows:
        lines.extend([
            "",
            f"Symbol: {row['symbol']}",
            f"Status: {row['status']}",
            f"Direction: {_fmt_value(row['direction'])}",
            f"Strategy: {_fmt_value(row['strategy'])}",
            f"Entry: {_fmt_value(row['entry'])}",
            f"Stop: {_fmt_value(row['stop'])}",
            f"Target: {_fmt_value(row['target'])}",
            f"RR: {_fmt_value(row['rr'])}",
            f"Score: {_fmt_value(row['score'])}",
            f"Qty: {_fmt_value(row['qty'])}",
            f"Risk Budget: {_fmt_value(row['risk_budget'])}",
            f"Estimated Risk Amount: {_fmt_value(row['estimated_risk_amount'])}",
            f"Key Reason: {_fmt_value(row['key_reason'])}",
            f"Rejection Reason: {_fmt_value(row['rejection_reason'])}",
            f"Cluster Diagnostic Status: {row['cluster_status']}",
            f"Cluster Gate Status: {row['cluster_gate_status']}",
            f"Market Mode: {row['market_mode']}",
            "Execution Allowed: false",
            "Broker Orders: DISABLED",
        ])
    return lines


def _write_paper_signal_dashboard_csv(path: Path, rows: list[dict]) -> None:
    columns = [
        "symbol", "status", "direction", "strategy", "entry", "stop", "target", "rr",
        "score", "qty", "risk_budget", "estimated_risk_amount", "key_reason",
        "rejection_reason", "cluster_status", "cluster_gate_status", "market_mode",
        "execution_allowed",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for item in rows:
            row = dict(item)
            row["execution_allowed"] = "false"
            writer.writerow(row)


def _fmt_value(value) -> str:
    return "N/A" if value is None else str(value)


def _print_risk_sizing_details(sizing: dict) -> None:
    if not sizing:
        print("- Position sizing details unavailable.")
        return
    print("Position sizing details:")
    fields = [
        ("symbol", "Symbol"),
        ("account_capital", "Account Capital"),
        ("risk_per_trade_pct", "Risk Per Trade Pct"),
        ("allowed_risk_amount", "Risk Amount"),
        ("entry", "Entry"),
        ("stop_loss", "Stop Loss"),
        ("stop_distance", "Stop Distance"),
        ("point_value", "Point Value"),
        ("risk_per_unit", "Risk Per Unit"),
        ("min_qty", "Min Qty"),
        ("lot_size", "Lot Size"),
        ("calculated_qty", "Calculated Qty"),
        ("rejection_reason", "Rejection Reason"),
    ]
    for key, label in fields:
        print(f"- {label}: {sizing.get(key)}")
    print("- execution_allowed=false")


def _print_accepted_paper_signal(signal, decision) -> None:
    sizing = getattr(decision, "sizing", {}) or {}
    print("Accepted PAPER signal:")
    print(f"- Symbol: {signal.symbol}")
    print(f"- Direction: {signal.side}")
    print(f"- Entry: {signal.entry_price}")
    print(f"- Stop: {signal.stop_loss}")
    print(f"- Target: {signal.target_price}")
    print(f"- RR: {signal.reward_risk}")
    print(f"- Score: {signal.score}")
    print(f"- Qty: {decision.quantity}")
    print(f"- Risk Per Unit: {sizing.get('risk_per_unit', 'N/A')}")
    print(f"- Estimated Risk Amount: {sizing.get('estimated_risk_amount', decision.risk_amount)}")
    print("- execution_allowed=false")
    print("- PAPER MODE ONLY")
    print("- Broker orders disabled.")
