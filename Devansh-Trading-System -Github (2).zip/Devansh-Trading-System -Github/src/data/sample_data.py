from __future__ import annotations

from datetime import datetime, timedelta


def _candle(ts: datetime, o: float, h: float, l: float, c: float, v: int, symbol: str) -> dict:
    return {"timestamp": ts, "open": o, "high": h, "low": l, "close": c, "volume": v, "symbol": symbol}


def generate_sample_candles(symbol: str = "BANKNIFTY") -> list[dict]:
    """Deterministic sample candles containing trend, trap, and range examples."""

    base = datetime(2026, 1, 1, 9, 15)
    rows = [
        (48200, 48240, 48190, 48230, 1000),
        (48230, 48270, 48210, 48260, 1200),
        (48260, 48300, 48240, 48285, 1300),
        (48290, 48360, 48270, 48280, 2200),  # Failed breakout above ORH.
        (48270, 48280, 48180, 48200, 1900),
        (48195, 48255, 48140, 48235, 2300),  # Failed breakdown below ORL.
        (48240, 48310, 48220, 48290, 1600),
        (48295, 48380, 48290, 48360, 2400),  # Breakout acceptance.
        (48365, 48450, 48350, 48430, 2100),
        (48380, 48440, 48290, 48410, 1500),  # VWAP pullback area.
        (48415, 48480, 48400, 48460, 1700),
        (48200, 48215, 48120, 48150, 2600),  # Breakdown acceptance.
        (48145, 48170, 48070, 48095, 2200),
        (48110, 48320, 48100, 48305, 2500),  # VWAP reclaim.
        (48300, 48360, 48280, 48345, 1800),
        (48290, 48320, 48195, 48210, 2100),  # VWAP rejection.
        (48220, 48345, 48205, 48265, 1700),  # Value area rejection.
        (48260, 48290, 48210, 48235, 1300),  # POC magnet style.
        (48305, 48370, 48260, 48275, 2600),  # Cluster/failed breakout trap.
        (48270, 48300, 48190, 48215, 1500),
    ]
    return [_candle(base + timedelta(minutes=5 * i), *row, symbol) for i, row in enumerate(rows)]


def generate_sample_ticks(symbol: str = "BANKNIFTY") -> list[dict]:
    base = datetime(2026, 1, 1, 9, 40)
    ticks: list[dict] = []
    for i, price in enumerate([48320, 48325, 48330, 48335, 48340]):
        ticks.append({"timestamp": base + timedelta(seconds=i), "symbol": symbol, "ltp": price, "ltq": 80, "bid": price - 1, "ask": price, "bid_qty": 50, "ask_qty": 20})
    for i, price in enumerate([48180, 48175, 48170, 48165, 48160], start=10):
        ticks.append({"timestamp": base + timedelta(seconds=i), "symbol": symbol, "ltp": price, "ltq": 90, "bid": price, "ask": price + 1, "bid_qty": 20, "ask_qty": 70})
    for i, price in enumerate([48210, 48215, 48220, 48225], start=20):
        ticks.append({"timestamp": base + timedelta(seconds=i), "symbol": symbol, "ltp": price, "ltq": 30, "bid": price - 1, "ask": price + 1, "bid_qty": 40, "ask_qty": 40})
    return ticks


def trend_up_sample(symbol: str = "BANKNIFTY") -> list[dict]:
    base = datetime(2026, 1, 2, 9, 15)
    return [_candle(base + timedelta(minutes=5 * i), 100 + i * 8, 106 + i * 8, 98 + i * 8, 104 + i * 8, 1000 + i * 30, symbol) for i in range(12)]


def trend_down_sample(symbol: str = "BANKNIFTY") -> list[dict]:
    base = datetime(2026, 1, 3, 9, 15)
    return [_candle(base + timedelta(minutes=5 * i), 220 - i * 8, 224 - i * 8, 214 - i * 8, 216 - i * 8, 1000 + i * 30, symbol) for i in range(12)]


def range_sample(symbol: str = "BANKNIFTY") -> list[dict]:
    base = datetime(2026, 1, 4, 9, 15)
    closes = [100, 102, 99, 101, 100, 102, 99, 101, 100, 102, 99, 101]
    return [_candle(base + timedelta(minutes=5 * i), c - 1, c + 3, c - 3, c, 900 + i * 10, symbol) for i, c in enumerate(closes)]


def trap_sample(symbol: str = "BANKNIFTY") -> list[dict]:
    candles = range_sample(symbol)
    candles.append(_candle(candles[-1]["timestamp"] + timedelta(minutes=5), 101, 110, 100, 99, 2200, symbol))
    return candles
