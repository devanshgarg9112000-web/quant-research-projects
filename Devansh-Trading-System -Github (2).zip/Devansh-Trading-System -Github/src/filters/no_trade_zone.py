from __future__ import annotations


def is_no_trade_zone(settings: dict) -> bool:
    return bool(settings.get("avoid_trading_today"))
