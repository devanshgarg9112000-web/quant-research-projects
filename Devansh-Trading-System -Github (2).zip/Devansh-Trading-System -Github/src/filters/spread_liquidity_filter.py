from __future__ import annotations


def spread_ok(spread_percent: float, max_spread_percent: float) -> bool:
    return spread_percent <= max_spread_percent
