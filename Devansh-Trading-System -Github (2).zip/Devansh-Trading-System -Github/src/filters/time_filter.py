from __future__ import annotations


def is_trading_time(timestamp) -> bool:
    return True
