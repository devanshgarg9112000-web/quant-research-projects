from __future__ import annotations


def validate_candles(candles: list[dict]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    required = {"timestamp", "open", "high", "low", "close", "volume", "symbol"}
    if not candles:
        return False, ["No candles supplied."]
    previous_ts = None
    for idx, candle in enumerate(candles):
        missing = required - set(candle)
        if missing:
            errors.append(f"Candle {idx} missing {sorted(missing)}")
        if candle.get("volume", 0) < 0:
            errors.append(f"Candle {idx} has negative volume")
        if candle.get("high", 0) < candle.get("low", 0):
            errors.append(f"Candle {idx} high is below low")
        if previous_ts and candle["timestamp"] < previous_ts:
            errors.append(f"Candle {idx} timestamp out of order")
        previous_ts = candle["timestamp"]
    return not errors, errors
