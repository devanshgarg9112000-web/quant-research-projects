from __future__ import annotations


def event_allows_trading(settings: dict) -> bool:
    return not (settings.get("event_day") and settings.get("high_impact_event"))
