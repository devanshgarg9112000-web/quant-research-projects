from __future__ import annotations


def too_far_from_vwap(distance_percent: float, max_percent: float = 1.5) -> bool:
    return abs(distance_percent) > max_percent
