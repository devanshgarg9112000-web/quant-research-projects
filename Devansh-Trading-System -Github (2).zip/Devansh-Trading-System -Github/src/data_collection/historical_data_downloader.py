from __future__ import annotations

import argparse
import csv
import time
from dataclasses import dataclass
from datetime import date, datetime, time as datetime_time, timedelta
from pathlib import Path
from typing import Any

from src.brokers.kite_broker import KiteBroker
from src.config_loader import load_configs
from src.data_feeds.truedata_feed import TrueDataFeed, normalize_historical_bar_response, normalize_historical_tick_response


TICK_COLUMNS = ["timestamp", "symbol", "ltp", "ltq", "bid", "ask", "bid_qty", "ask_qty", "source", "received_at"]
BAR_COLUMNS = ["timestamp", "symbol", "open", "high", "low", "close", "volume", "oi", "source", "interval"]


@dataclass
class SavedDataFile:
    path: Path
    rows_written: int
    rows_seen: int


@dataclass
class HistoricalDownloadResult:
    files: list[SavedDataFile]
    source: str
    data_type: str

    @property
    def rows_written(self) -> int:
        return sum(item.rows_written for item in self.files)

    @property
    def files_touched(self) -> int:
        return sum(1 for item in self.files if item.rows_written > 0)


class HistoricalDownloadError(ValueError):
    """Safe CLI-facing error for read-only historical data downloads."""


def parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise HistoricalDownloadError(f"Invalid date '{value}'. Use YYYY-MM-DD.") from exc


def iter_dates(from_date: date, to_date: date) -> list[date]:
    if to_date < from_date:
        raise HistoricalDownloadError("--to-date must be on or after --from-date.")
    days = []
    current = from_date
    while current <= to_date:
        days.append(current)
        current += timedelta(days=1)
    return days


def day_bounds(day: date) -> tuple[datetime, datetime]:
    return (
        datetime.combine(day, datetime_time(0, 0, 0)),
        datetime.combine(day, datetime_time(23, 59, 59)),
    )


def build_historical_data_path(
    base_dir: Path | str,
    source: str,
    data_type: str,
    day: date,
    symbol: str,
    interval: str | None = None,
) -> Path:
    safe_symbol = safe_symbol_filename(symbol)
    base = Path(base_dir) / "data" / "historical" / source.lower()
    if source.lower() == "truedata" and data_type == "ticks":
        return base / "ticks" / day.isoformat() / f"{safe_symbol}_ticks.csv"
    if source.lower() == "truedata" and data_type == "bars":
        safe_interval = safe_symbol_filename(interval or "1minute")
        return base / "bars" / day.isoformat() / f"{safe_symbol}_{safe_interval}_bars.csv"
    if source.lower() == "kite" and data_type == "candles":
        safe_interval = safe_symbol_filename(interval or "minute")
        return base / "candles" / day.isoformat() / f"{safe_symbol}_{safe_interval}_candles.csv"
    raise HistoricalDownloadError(f"Unsupported save path combination: source={source}, data_type={data_type}")


def normalize_truedata_tick_rows(rows: list[dict[str, Any]], symbol: str, received_at: datetime | None = None) -> list[dict[str, Any]]:
    received = received_at or datetime.now().astimezone()
    return [
        {
            "timestamp": serialize_value(row.get("timestamp")),
            "symbol": symbol,
            "ltp": serialize_value(row.get("ltp")),
            "ltq": serialize_value(row.get("ltq")),
            "bid": serialize_value(row.get("bid")),
            "ask": serialize_value(row.get("ask")),
            "bid_qty": serialize_value(row.get("bid_qty")),
            "ask_qty": serialize_value(row.get("ask_qty")),
            "source": "TRUEDATA",
            "received_at": serialize_value(received),
        }
        for row in rows
    ]


def normalize_truedata_tick_response(response_text: str, symbol: str, received_at: datetime | None = None) -> list[dict[str, Any]]:
    return normalize_truedata_tick_rows(normalize_historical_tick_response(response_text, symbol), symbol, received_at)


def normalize_truedata_bar_rows(rows: list[dict[str, Any]], symbol: str, interval: str) -> list[dict[str, Any]]:
    return [
        {
            "timestamp": serialize_value(row.get("timestamp")),
            "symbol": symbol,
            "open": serialize_value(row.get("open")),
            "high": serialize_value(row.get("high")),
            "low": serialize_value(row.get("low")),
            "close": serialize_value(row.get("close")),
            "volume": serialize_value(row.get("volume")),
            "oi": serialize_value(row.get("oi")),
            "source": "TRUEDATA",
            "interval": interval,
        }
        for row in rows
    ]


def normalize_truedata_bar_response(response_text: str, symbol: str, interval: str) -> list[dict[str, Any]]:
    return normalize_truedata_bar_rows(normalize_historical_bar_response(response_text, symbol), symbol, interval)


def normalize_kite_candle_response(candles: list[dict[str, Any]], symbol: str, interval: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for candle in candles:
        timestamp = candle.get("date") or candle.get("timestamp")
        rows.append({
            "timestamp": serialize_value(timestamp),
            "symbol": symbol,
            "open": serialize_value(candle.get("open")),
            "high": serialize_value(candle.get("high")),
            "low": serialize_value(candle.get("low")),
            "close": serialize_value(candle.get("close")),
            "volume": serialize_value(candle.get("volume", 0)),
            "oi": serialize_value(candle.get("oi")),
            "source": "KITE",
            "interval": interval,
        })
    return rows


def download_historical_data(
    base_dir: Path | str = ".",
    source: str = "truedata",
    data_type: str = "ticks",
    symbols_text: str | None = None,
    from_date_text: str | None = None,
    to_date_text: str | None = None,
    interval: str = "1minute",
    rate_limit_seconds: float = 0.2,
    truedata_client: Any | None = None,
    kite_broker: Any | None = None,
    configs: dict[str, Any] | None = None,
) -> HistoricalDownloadResult:
    base = Path(base_dir)
    source = source.lower()
    data_type = data_type.lower()
    if source not in {"truedata", "kite"}:
        raise HistoricalDownloadError("--source must be truedata or kite.")
    if source == "truedata" and data_type not in {"ticks", "bars"}:
        raise HistoricalDownloadError("TrueData supports --data-type ticks or bars.")
    if source == "kite" and data_type != "candles":
        raise HistoricalDownloadError("Kite supports --data-type candles for this downloader.")
    symbols = parse_symbols(symbols_text)
    if not symbols:
        raise HistoricalDownloadError("No symbols supplied.")
    if not from_date_text or not to_date_text:
        raise HistoricalDownloadError("--from-date and --to-date are required.")

    from_date = parse_date(from_date_text)
    to_date = parse_date(to_date_text)
    days = iter_dates(from_date, to_date)
    configs = configs or load_configs(base)
    print("LAUNCH 1 HISTORICAL DATA DOWNLOADER")
    print("Mode: PAPER")
    print(f"Source: {source.upper()}")
    print(f"Data Type: {data_type.upper()}")
    print(f"Symbols: {', '.join(symbols)}")
    print(f"Date Range: {from_date.isoformat()} to {to_date.isoformat()}")
    print("Live Trading: DISABLED")
    print("Broker Orders: DISABLED")
    print("execution_allowed=false")
    print("Read-only historical data fetch only. Secrets are not printed.")

    if source == "truedata":
        result = _download_truedata(
            base,
            configs,
            data_type,
            symbols,
            days,
            interval,
            rate_limit_seconds,
            truedata_client,
        )
    else:
        result = _download_kite(
            base,
            configs,
            data_type,
            symbols,
            days,
            interval,
            rate_limit_seconds,
            kite_broker,
        )
    print(f"Files touched: {result.files_touched}")
    print(f"Rows written: {result.rows_written}")
    for item in result.files:
        print(f"- {item.path}: wrote {item.rows_written} new rows from {item.rows_seen} rows")
    print("PAPER MODE ONLY. No broker orders were placed.")
    return result


def _download_truedata(
    base: Path,
    configs: dict[str, Any],
    data_type: str,
    symbols: list[str],
    days: list[date],
    interval: str,
    rate_limit_seconds: float,
    client: Any | None,
) -> HistoricalDownloadResult:
    settings = dict(configs.get("settings", {}))
    settings["mode"] = "PAPER"
    settings["enable_live_trading"] = False
    settings["enable_true_data"] = True
    feed = client or TrueDataFeed(settings, base, allow_network=True)
    missing = getattr(getattr(feed, "credentials", None), "missing", [])
    if missing:
        raise HistoricalDownloadError("TrueData historical download skipped: missing " + ", ".join(missing) + ".")
    saved: list[SavedDataFile] = []
    for day in days:
        start, end = day_bounds(day)
        for symbol in symbols:
            try:
                rows = feed.get_historical(symbol, start, end, "ticks" if data_type == "ticks" else interval)
            except Exception as exc:
                raise HistoricalDownloadError(f"TrueData historical fetch failed safely for {symbol} {day}: {type(exc).__name__}") from exc
            if data_type == "ticks":
                normalized = normalize_truedata_tick_rows(rows, symbol)
                path = build_historical_data_path(base, "truedata", "ticks", day, symbol)
                saved.append(save_rows_dedup(path, TICK_COLUMNS, normalized, ["timestamp", "symbol", "ltp", "ltq"]))
            else:
                normalized = normalize_truedata_bar_rows(rows, symbol, interval)
                path = build_historical_data_path(base, "truedata", "bars", day, symbol, interval)
                saved.append(save_rows_dedup(path, BAR_COLUMNS, normalized, ["timestamp", "symbol", "interval"]))
            _sleep_rate_limit(rate_limit_seconds)
    return HistoricalDownloadResult(saved, "truedata", data_type)


def _download_kite(
    base: Path,
    configs: dict[str, Any],
    data_type: str,
    symbols: list[str],
    days: list[date],
    interval: str,
    rate_limit_seconds: float,
    broker: Any | None,
) -> HistoricalDownloadResult:
    broker = broker or KiteBroker(
        configs.get("settings", {}),
        configs.get("risk", {}),
        broker_name="kite",
        base_dir=base,
    )
    missing = broker._missing_read_credentials() if hasattr(broker, "_missing_read_credentials") else []
    if missing:
        raise HistoricalDownloadError("Kite historical download skipped: missing " + ", ".join(missing) + ".")
    saved: list[SavedDataFile] = []
    token_cache: dict[str, int] = {}
    for symbol in symbols:
        token_cache[symbol] = _resolve_kite_instrument_token(broker, symbol)
    for day in days:
        start, end = day_bounds(day)
        for symbol in symbols:
            try:
                candles = broker.get_historical_data(token_cache[symbol], start, end, interval, oi=True)
            except Exception as exc:
                raise HistoricalDownloadError(f"Kite historical fetch failed safely for {symbol} {day}: {type(exc).__name__}") from exc
            normalized = normalize_kite_candle_response(candles, symbol, interval)
            path = build_historical_data_path(base, "kite", data_type, day, symbol, interval)
            saved.append(save_rows_dedup(path, BAR_COLUMNS, normalized, ["timestamp", "symbol", "interval"]))
            _sleep_rate_limit(rate_limit_seconds)
    return HistoricalDownloadResult(saved, "kite", data_type)


def _resolve_kite_instrument_token(broker: Any, symbol: str) -> int:
    exchange, tradingsymbol = _split_kite_symbol(symbol)
    instruments = broker.get_instruments(exchange)
    if isinstance(instruments, dict) and instruments.get("status"):
        if instruments.get("status") == "credentials_missing":
            raise HistoricalDownloadError("Kite historical download skipped: missing " + ", ".join(instruments.get("missing", [])) + ".")
        raise HistoricalDownloadError(f"Kite instruments lookup failed safely for {symbol}: {instruments.get('status')}")
    for item in instruments or []:
        if str(item.get("exchange") or exchange) == exchange and str(item.get("tradingsymbol") or "") == tradingsymbol:
            token = item.get("instrument_token")
            if token is None:
                raise HistoricalDownloadError(f"Kite symbol found without instrument_token: {symbol}")
            return int(token)
    raise HistoricalDownloadError(f"Kite symbol not found: {symbol}")


def _split_kite_symbol(symbol: str) -> tuple[str, str]:
    if ":" not in symbol:
        raise HistoricalDownloadError(f"Kite symbol must include exchange prefix, e.g. NSE:RELIANCE. Got: {symbol}")
    exchange, tradingsymbol = symbol.split(":", 1)
    exchange = exchange.strip()
    tradingsymbol = tradingsymbol.strip()
    if not exchange or not tradingsymbol:
        raise HistoricalDownloadError(f"Kite symbol must include exchange and tradingsymbol. Got: {symbol}")
    return exchange, tradingsymbol


def save_rows_dedup(path: Path, columns: list[str], rows: list[dict[str, Any]], key_columns: list[str]) -> SavedDataFile:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = _read_existing_keys(path, key_columns)
    write_header = not path.exists() or path.stat().st_size == 0
    new_rows: list[dict[str, Any]] = []
    for row in rows:
        key = _row_key(row, key_columns)
        if key in existing:
            continue
        existing.add(key)
        new_rows.append({column: row.get(column, "") for column in columns})
    if new_rows:
        with path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=columns)
            if write_header:
                writer.writeheader()
            writer.writerows(new_rows)
    return SavedDataFile(path=path, rows_written=len(new_rows), rows_seen=len(rows))


def safe_symbol_filename(symbol: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in str(symbol).strip())


def serialize_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    return value


def _read_existing_keys(path: Path, key_columns: list[str]) -> set[tuple[str, ...]]:
    if not path.exists() or path.stat().st_size == 0:
        return set()
    with path.open("r", newline="", encoding="utf-8") as f:
        return {_row_key(row, key_columns) for row in csv.DictReader(f)}


def _row_key(row: dict[str, Any], key_columns: list[str]) -> tuple[str, ...]:
    return tuple(_normalized_key_value(row.get(column)) for column in key_columns)


def _normalized_key_value(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text == "":
        return ""
    try:
        return str(float(text))
    except ValueError:
        return text


def _sleep_rate_limit(seconds: float) -> None:
    if seconds > 0:
        time.sleep(seconds)


def main() -> int:
    parser = argparse.ArgumentParser(description="Launch 1 read-only historical data downloader. Never places broker orders.")
    parser.add_argument("--source", choices=["truedata", "kite"], required=True)
    parser.add_argument("--data-type", choices=["ticks", "bars", "candles"], required=True)
    parser.add_argument("--symbols", required=True)
    parser.add_argument("--from-date", required=True)
    parser.add_argument("--to-date", required=True)
    parser.add_argument("--interval", default="1minute")
    parser.add_argument("--rate-limit-seconds", type=float, default=0.2)
    args = parser.parse_args()
    try:
        download_historical_data(
            source=args.source,
            data_type=args.data_type,
            symbols_text=args.symbols,
            from_date_text=args.from_date,
            to_date_text=args.to_date,
            interval=args.interval,
            rate_limit_seconds=args.rate_limit_seconds,
        )
        return 0
    except HistoricalDownloadError as exc:
        print(f"Historical data downloader stopped safely: {exc}")
        print("Live Trading: DISABLED")
        print("Broker Orders: DISABLED")
        print("execution_allowed=false")
        print("PAPER MODE ONLY. No broker orders were placed.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
