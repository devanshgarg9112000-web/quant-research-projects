from __future__ import annotations

import argparse
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs
from src.data_collection.kite_credentials import (
    KiteCredentialState,
    format_kite_credential_status,
    load_kite_credentials,
)


REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_monday_checklist.txt"
PREFLIGHT_REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_monday_preflight_report.txt"
PIPELINE_REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"
RUNBOOK_PATH = Path("docs") / "MONDAY_KITE_RECORDING_RUNBOOK.md"


@dataclass
class KiteMondayChecklistResult:
    timestamp: datetime
    symbols: list[str]
    credential_status: str
    safety_flags: dict[str, bool]
    preflight_report_exists: bool
    pipeline_report_exists: bool
    runbook_exists: bool
    expected_preflight_command: str
    expected_short_command: str
    expected_recording_command: str
    expected_reports: list[str]
    warnings: list[str] = field(default_factory=list)
    report_path: Path | None = None

    @property
    def safety_ok(self) -> bool:
        return all(self.safety_flags.values())


def run_kite_monday_checklist(
    base_dir: Path | str = ".",
    *,
    symbols_text: str = "GOLD-I",
    now_fn: Callable[[], datetime] | None = None,
    configs: dict[str, Any] | None = None,
    credential_state: KiteCredentialState | None = None,
) -> KiteMondayChecklistResult:
    """Generate a local Monday operator checklist without network or broker calls."""

    base = Path(base_dir)
    now = now_fn or (lambda: datetime.now().astimezone())
    symbols = _parse_symbols(symbols_text)
    quoted_symbols = ",".join(symbols) or "GOLD-I"
    state = credential_state or load_kite_credentials(base)
    configs = configs or _safe_configs(base)
    safety_flags = _safety_flags(configs)
    expected_reports = [
        str(PREFLIGHT_REPORT_PATH),
        str(PIPELINE_REPORT_PATH),
        str(Path("reports") / "kite_daily_pipeline" / "kite_daily_pipeline_runs.csv"),
        str(Path("reports") / "forward_validation" / "latest_forward_validation_summary.txt"),
    ]
    result = KiteMondayChecklistResult(
        timestamp=now(),
        symbols=symbols,
        credential_status=state.credential_status,
        safety_flags=safety_flags,
        preflight_report_exists=(base / PREFLIGHT_REPORT_PATH).exists(),
        pipeline_report_exists=(base / PIPELINE_REPORT_PATH).exists(),
        runbook_exists=(base / RUNBOOK_PATH).exists(),
        expected_preflight_command=(
            f'python -m src.data_collection.kite_monday_preflight --symbols "{quoted_symbols}" --dry-run false'
        ),
        expected_short_command=(
            f'python -m src.data_collection.kite_daily_pipeline --symbols "{quoted_symbols}" '
            "--duration-seconds 60 --record-depth true --dry-run false"
        ),
        expected_recording_command=(
            f'python -m src.data_collection.kite_daily_pipeline --symbols "{quoted_symbols}" '
            "--duration-seconds 25200 --record-depth true --dry-run false"
        ),
        expected_reports=expected_reports,
    )
    if state.credential_status != "PRESENT":
        result.warnings.append("Kite credentials are MISSING; update the access token locally before real preflight.")
    if not result.safety_ok:
        result.warnings.append("One or more safety flags are not in the required disabled/PAPER state.")
    if not result.preflight_report_exists:
        result.warnings.append("Latest Monday preflight report does not exist yet.")
    if not result.pipeline_report_exists:
        result.warnings.append("Latest Kite daily pipeline report does not exist yet.")
    if not result.runbook_exists:
        result.warnings.append("Monday recording runbook is missing.")

    _write_report(base, result, state)
    _print_checklist(result, state)
    return result


def _write_report(base: Path, result: KiteMondayChecklistResult, state: KiteCredentialState) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "MONDAY KITE RECORDING AUTO CHECKLIST",
        f"Generated: {result.timestamp.isoformat()}",
        f"Project folder: {base.resolve()}",
        f"Symbols: {', '.join(result.symbols) if result.symbols else 'NONE'}",
        "",
        "CREDENTIAL STATUS (VALUES MASKED)",
        *format_kite_credential_status(state),
        f"Overall credential_status: {result.credential_status}",
        "",
        "SAFETY FLAGS",
    ]
    lines.extend(f"- {name}: {'OK' if value else 'FAIL'}" for name, value in result.safety_flags.items())
    lines.extend(
        [
            f"Safety overall: {'OK' if result.safety_ok else 'FAIL'}",
            "execution_allowed=false",
            "Production WhatsApp Alerts: BLOCKED",
            "Broker Orders: DISABLED",
            "Live Trading: DISABLED",
            "",
            "EXPECTED COMMANDS",
            f"Preflight: {result.expected_preflight_command}",
            f"Short test: {result.expected_short_command}",
            f"Full recording: {result.expected_recording_command}",
            "",
            "EXPECTED REPORTS",
        ]
    )
    lines.extend(f"- {item}" for item in result.expected_reports)
    lines.extend(
        [
            "",
            f"Latest preflight report exists: {str(result.preflight_report_exists).lower()}",
            f"Latest pipeline report exists: {str(result.pipeline_report_exists).lower()}",
            f"Runbook exists: {str(result.runbook_exists).lower()}",
            f"Runbook path: {RUNBOOK_PATH}",
            "",
            "WARNINGS",
            *([f"- {warning}" for warning in result.warnings] if result.warnings else ["NONE"]),
            "",
            "REMINDER",
            "This checklist makes no network or broker calls.",
            "PAPER MODE ONLY. Data collection and research only.",
            "No strategy is approved yet. Forward validation remains RESEARCH_ONLY.",
            "READ ONLY. NO BROKER ORDERS. NO LIVE TRADING.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _print_checklist(result: KiteMondayChecklistResult, state: KiteCredentialState) -> None:
    print("MONDAY KITE RECORDING AUTO CHECKLIST")
    print(f"Today: {result.timestamp.isoformat()}")
    print(f"Symbols: {', '.join(result.symbols) if result.symbols else 'NONE'}")
    print("Credential status values are masked:")
    for line in format_kite_credential_status(state):
        print(line)
    print(f"Overall Credential Status: {result.credential_status}")
    print("Safety Flags:")
    for name, value in result.safety_flags.items():
        print(f"- {name}: {'OK' if value else 'FAIL'}")
    print(f"Expected Preflight Command: {result.expected_preflight_command}")
    print(f"Expected Short Test Command: {result.expected_short_command}")
    print(f"Expected Recording Command: {result.expected_recording_command}")
    print("Expected Reports:")
    for item in result.expected_reports:
        print(f"- {item}")
    print(f"Latest Preflight Report Exists: {str(result.preflight_report_exists).lower()}")
    print(f"Latest Pipeline Report Exists: {str(result.pipeline_report_exists).lower()}")
    print(f"Runbook: {RUNBOOK_PATH}")
    print("Production WhatsApp: BLOCKED")
    print("Live Trading: DISABLED")
    print("Broker Orders: DISABLED")
    print("execution_allowed=false")
    print("READ ONLY. NO BROKER ORDERS. NO LIVE TRADING.")
    print(f"Checklist Report: {result.report_path}")


def _safety_flags(configs: dict[str, Any]) -> dict[str, bool]:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    return {
        "mode=PAPER": str(settings.get("mode", "PAPER")).upper() == "PAPER",
        "enable_live_trading=false": not bool(settings.get("enable_live_trading", False)),
        "ENABLE_LIVE_TRADING=false": not _truthy(os.environ.get("ENABLE_LIVE_TRADING")),
        "I_UNDERSTAND_LIVE_TRADING_RISK=false": not _truthy(
            os.environ.get("I_UNDERSTAND_LIVE_TRADING_RISK")
        ),
        "production_alerts_allowed=false": not bool(forward.get("production_alerts_allowed", False)),
    }


def _safe_configs(base: Path) -> dict[str, Any]:
    try:
        return load_configs(base)
    except (FileNotFoundError, OSError):
        return {
            "settings": {"mode": "PAPER", "enable_live_trading": False},
            "forward_validation": {"production_alerts_allowed": False},
        }


def _parse_symbols(symbols_text: str | None) -> list[str]:
    output: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in output:
            output.append(symbol)
    return output


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Local Monday Kite recording checklist. No network calls.")
    parser.add_argument("--symbols", default="GOLD-I")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = run_kite_monday_checklist(symbols_text=args.symbols)
    return 0 if result.safety_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
