from __future__ import annotations

import argparse
import csv
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from src.brokers.kite_broker import KiteBroker
from src.config_loader import load_configs
from src.data_collection.kite_credentials import format_kite_credential_status, load_kite_credentials
from src.data_collection.kite_instrument_resolver import KiteInstrumentMapping, resolve_kite_instruments
from src.data_collection.market_data_schema import (
    KITE_DEPTH_COLUMNS,
    KITE_TICK_COLUMNS,
    count_csv_data_rows,
    kite_depth_path,
    kite_tick_path,
    normalize_kite_depth_rows,
    normalize_kite_tick_row,
)


REPORT_PATH = Path("reports") / "kite_data_collection" / "latest_kite_data_collection_report.txt"
RECORDER_HEARTBEAT_PATH = Path("reports") / "kite_data_collection" / "latest_kite_recorder_heartbeat.txt"
OPERATIONS_LOG_PATH = Path("reports") / "kite_data_collection" / "kite_data_collection_operations.csv"
OPERATION_COLUMNS = [
    "timestamp",
    "operation_type",
    "credential_status",
    "tick_rows_recorded",
    "depth_rows_recorded",
    "candle_rows_downloaded",
    "features_generated",
    "files_touched",
    "missing_fields",
    "errors",
    "execution_allowed",
]


@dataclass
class KiteRecordingResult:
    operation_type: str = "unknown"
    credential_status: str = "NOT_CHECKED"
    quote_status: str = "NOT_CHECKED"
    depth_status: str = "NOT_CHECKED"
    market_data_status: str = "NOT_CHECKED"
    feature_mode: str = "NOT_CHECKED"
    zero_feature_reason: str = ""
    tick_rows_loaded: int = 0
    depth_rows_loaded: int = 0
    real_tick_rows_used: int = 0
    real_depth_rows_used: int = 0
    synthetic_rows_ignored: int = 0
    stale_output_rows_removed: int = 0
    output_csv_data_rows: int = 0
    contract_consistency_status: str = "NOT_CHECKED"
    selected_contract: str = ""
    ignored_contracts: list[str] = field(default_factory=list)
    synthetic_contracts_ignored: list[str] = field(default_factory=list)
    contract_action_required: bool = False
    output_real_contract_count: int = 0
    report_csv_contract_match: bool = True
    contract_metadata_complete: bool = False
    missing_contract_fields: list[str] = field(default_factory=list)
    expiry_missing_warning: bool = False
    expiry_rows_enriched: int = 0
    input_files: list[str] = field(default_factory=list)
    symbol_resolutions: list[KiteInstrumentMapping] = field(default_factory=list)
    tick_rows_recorded: int = 0
    depth_rows_recorded: int = 0
    candle_rows_downloaded: int = 0
    features_generated: int = 0
    files: list[Path] = field(default_factory=list)
    missing_fields: list[str] = field(default_factory=list)
    optional_missing_fields: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    memory_safe_streaming: bool = True
    flush_rows: int = 100
    resume: bool = True
    recorder_completed_normally: bool = False
    recorder_failed_safely: bool = False
    partial_data_usable: bool = False
    heartbeat_path: Path | None = None
    report_path: Path | None = None


def record_kite_live_data(
    base_dir: Path | str = ".",
    *,
    symbols_text: str,
    duration_seconds: int = 60,
    record_depth: bool = True,
    poll_interval_seconds: float = 1.0,
    dry_run: bool = True,
    broker: Any | None = None,
    configs: dict[str, Any] | None = None,
    now_fn: Callable[[], datetime] | None = None,
    sleep_fn: Callable[[float], None] | None = None,
    flush_rows: int = 100,
    resume: bool = True,
) -> KiteRecordingResult:
    base = Path(base_dir)
    configs = configs or load_configs(base)
    now = now_fn or (lambda: datetime.now().astimezone())
    resolver_as_of = now().date()
    sleeper = sleep_fn or time.sleep
    symbols = _parse_symbols(symbols_text)
    result = KiteRecordingResult(operation_type="recorder", flush_rows=max(1, int(flush_rows)), resume=resume)
    credential_state = load_kite_credentials(base)
    result.credential_status = credential_state.credential_status
    print("KITE LIVE DATA RECORDER")
    print("Mode: PAPER | Kite: READ ONLY | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Credential Status: {result.credential_status}")
    for line in format_kite_credential_status(credential_state):
        print(line)
    print(f"Symbols: {', '.join(symbols) if symbols else 'NONE'}")
    print(f"Record Depth: {record_depth}")
    print(f"Dry Run: {dry_run}")
    print("memory_safe_streaming=true")
    print(f"flush_rows={result.flush_rows}")
    print(f"resume={str(result.resume).lower()}")
    if not symbols:
        result.errors.append("No symbols supplied.")
        _write_report(base, result)
        return result

    resolution = resolve_kite_instruments(
        base,
        symbols_text=symbols_text,
        exchange="MCX",
        dry_run=dry_run,
        instrument_client_factory=_instrument_client_factory_from_broker(broker),
        as_of=resolver_as_of,
    )
    result.symbol_resolutions = resolution.mappings
    for mapping in result.symbol_resolutions:
        print(f"Resolved Symbol: {mapping.internal_symbol} -> {mapping.quote_symbol if mapping.resolved else 'NOT_FOUND'} ({mapping.status})")
    if resolution.errors and not dry_run:
        result.errors.extend(resolution.errors)

    if not dry_run and not credential_state.all_present and broker is None:
        result.errors.append(
            "Kite live recorder skipped safely: missing "
            + ", ".join(credential_state.missing_keys())
            + ". Use --dry-run true until env/.env credentials are configured."
        )
        _write_report(base, result)
        print(result.errors[-1])
        print("READ ONLY CHECK ONLY. NO ORDERS.")
        print("No broker orders were placed.")
        return result

    kite_broker = broker or KiteBroker(
        configs.get("settings", {}),
        configs.get("risk", {}),
        broker_name="kite",
        base_dir=base,
    )
    missing = []
    if hasattr(kite_broker, "_missing_read_credentials"):
        missing = list(kite_broker._missing_read_credentials())
    if missing and not dry_run:
        result.errors.append("Kite live recorder skipped safely: missing " + ", ".join(missing) + ".")
        _write_report(base, result)
        print(result.errors[-1])
        print("No broker orders were placed.")
        return result

    resolution_by_symbol = {mapping.internal_symbol: mapping for mapping in result.symbol_resolutions}
    quote_symbols = [
        resolution_by_symbol.get(symbol).quote_symbol
        if resolution_by_symbol.get(symbol) and resolution_by_symbol[symbol].resolved
        else _to_kite_quote_symbol(symbol, configs.get("instruments", {}))
        for symbol in symbols
    ]
    end_at = time.monotonic() + max(0, int(duration_seconds))
    first_iteration = True
    writers: dict[str, _StreamingCsvAppender] = {}
    try:
        while first_iteration or (time.monotonic() < end_at and int(duration_seconds) > 0):
            first_iteration = False
            received_at = now()
            quote = (
                _sample_quote(symbols, quote_symbols, received_at, resolution_by_symbol)
                if dry_run
                else _safe_get_quote(kite_broker, quote_symbols, result)
            )
            if quote:
                _record_quote_snapshot(
                    base,
                    symbols,
                    quote_symbols,
                    quote,
                    received_at,
                    record_depth,
                    dry_run,
                    result,
                    writers,
                )
                result.quote_status = "OK"
                _refresh_market_data_status(result)
            else:
                result.quote_status = "NO_QUOTE"
                _refresh_market_data_status(result)
            _write_recorder_heartbeat(base, result, received_at)
            if dry_run or int(duration_seconds) <= 0:
                break
            remaining = end_at - time.monotonic()
            if remaining <= 0:
                break
            sleeper(max(0.0, min(float(poll_interval_seconds), remaining)))
        result.recorder_completed_normally = True
    except MemoryError:
        result.recorder_failed_safely = True
        result.errors.append("Kite live recorder failed safely: MemoryError.")
    except KeyboardInterrupt:
        result.recorder_failed_safely = True
        result.errors.append("Kite live recorder stopped safely by KeyboardInterrupt.")
    finally:
        for writer in writers.values():
            writer.close()
        if result.recorder_failed_safely:
            _recount_recorded_files(result)

    _refresh_market_data_status(result)
    result.partial_data_usable = result.tick_rows_recorded > 0 or result.depth_rows_recorded > 0
    _write_report(base, result)
    if result.market_data_status == "NO_LIVE_TICKS":
        print("No live ticks recorded. This may be normal if market is closed.")
    print(f"Market data status: {result.market_data_status}")
    print(f"Tick rows recorded: {result.tick_rows_recorded}")
    print(f"Depth rows recorded: {result.depth_rows_recorded}")
    print(f"memory_safe_streaming={str(result.memory_safe_streaming).lower()}")
    print(f"recorder_completed_normally={str(result.recorder_completed_normally).lower()}")
    print(f"recorder_failed_safely={str(result.recorder_failed_safely).lower()}")
    print(f"partial_data_usable={str(result.partial_data_usable).lower()}")
    print(f"Report: {result.report_path}")
    print("PAPER MODE ONLY. Kite read-only data calls only. No broker orders were placed.")
    return result



class _StreamingCsvAppender:
    """Append CSV rows without loading the growing file into memory."""

    def __init__(
        self,
        path: Path,
        columns: list[str],
        key_columns: list[str],
        *,
        flush_rows: int,
        resume: bool,
    ) -> None:
        self.path = path
        self.columns = columns
        self.key_columns = key_columns
        self.flush_rows = max(1, int(flush_rows))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        mode = "a" if resume else "w"
        write_header = mode == "w" or not self.path.exists() or self.path.stat().st_size == 0
        self._file = self.path.open(mode, newline="", encoding="utf-8")
        self._writer = csv.DictWriter(self._file, fieldnames=columns)
        if write_header:
            self._writer.writeheader()
            self._file.flush()
        self._pending = 0
        self._recent_keys: set[tuple[str, ...]] = set()
        self.rows_written = 0

    def append_rows(self, rows: list[dict[str, Any]]) -> int:
        written = 0
        for row in rows:
            key = tuple(str(row.get(column, "")) for column in self.key_columns)
            if key in self._recent_keys:
                continue
            self._recent_keys.add(key)
            if len(self._recent_keys) > 5000:
                self._recent_keys.clear()
                self._recent_keys.add(key)
            self._writer.writerow({column: row.get(column, "") for column in self.columns})
            self._pending += 1
            self.rows_written += 1
            written += 1
            if self._pending >= self.flush_rows:
                self.flush()
        return written

    def flush(self) -> None:
        self._file.flush()
        self._pending = 0

    def close(self) -> None:
        if self._file.closed:
            return
        self.flush()
        self._file.close()


def _get_stream_writer(
    writers: dict[str, _StreamingCsvAppender],
    path: Path,
    columns: list[str],
    key_columns: list[str],
    result: KiteRecordingResult,
) -> _StreamingCsvAppender:
    key = str(path)
    writer = writers.get(key)
    if writer is None:
        writer = _StreamingCsvAppender(
            path,
            columns,
            key_columns,
            flush_rows=result.flush_rows,
            resume=result.resume,
        )
        writers[key] = writer
        result.files.append(path)
    return writer

def _record_quote_snapshot(
    base: Path,
    symbols: list[str],
    quote_symbols: list[str],
    quote: dict[str, Any],
    received_at: datetime,
    record_depth: bool,
    dry_run: bool,
    result: KiteRecordingResult,
    writers: dict[str, _StreamingCsvAppender],
) -> None:
    resolution_by_symbol = {mapping.internal_symbol: mapping for mapping in result.symbol_resolutions}
    for original_symbol, quote_symbol in zip(symbols, quote_symbols):
        mapping = resolution_by_symbol.get(original_symbol)
        payload = quote.get(quote_symbol) or quote.get(original_symbol) or {}
        if not isinstance(payload, dict) or not payload:
            result.errors.append(f"Kite quote missing for {original_symbol}.")
            continue
        missing_required, missing_optional = _missing_quote_fields(payload)
        result.missing_fields.extend(f"{original_symbol}:{field}" for field in missing_required)
        result.optional_missing_fields.extend(f"{original_symbol}:{field}" for field in missing_optional)
        tick_row = normalize_kite_tick_row(
            original_symbol,
            payload,
            received_at=received_at,
            internal_symbol=original_symbol,
            kite_exchange=mapping.exchange if mapping else "",
            kite_tradingsymbol=mapping.tradingsymbol if mapping else "",
            expiry=mapping.expiry if mapping else "",
            data_mode="DRY_RUN" if dry_run else "REAL_READ_ONLY",
            is_synthetic=dry_run,
        )
        tick_day = received_at.date()
        tick_path = kite_tick_path(base, tick_day, original_symbol)
        tick_writer = _get_stream_writer(
            writers,
            tick_path,
            KITE_TICK_COLUMNS,
            ["timestamp", "symbol", "ltp", "received_at"],
            result,
        )
        result.tick_rows_recorded += tick_writer.append_rows([tick_row])
        if record_depth:
            depth_rows = normalize_kite_depth_rows(
                original_symbol,
                payload,
                received_at=received_at,
                internal_symbol=original_symbol,
                kite_exchange=mapping.exchange if mapping else "",
                kite_tradingsymbol=mapping.tradingsymbol if mapping else "",
                expiry=mapping.expiry if mapping else "",
                data_mode="DRY_RUN" if dry_run else "REAL_READ_ONLY",
                is_synthetic=dry_run,
            )
            depth_path = kite_depth_path(base, tick_day, original_symbol)
            depth_writer = _get_stream_writer(
                writers,
                depth_path,
                KITE_DEPTH_COLUMNS,
                ["timestamp", "symbol", "level", "bid_price", "ask_price"],
                result,
            )
            result.depth_rows_recorded += depth_writer.append_rows(depth_rows)





def _recount_recorded_files(result: KiteRecordingResult) -> None:
    tick_paths = {path for path in result.files if str(path).lower().endswith("_ticks.csv")}
    depth_paths = {path for path in result.files if str(path).lower().endswith("_depth.csv")}
    if tick_paths:
        result.tick_rows_recorded = sum(count_csv_data_rows(path) for path in tick_paths)
    if depth_paths:
        result.depth_rows_recorded = sum(count_csv_data_rows(path) for path in depth_paths)


def _write_recorder_heartbeat(base: Path, result: KiteRecordingResult, timestamp: datetime) -> None:
    path = base / RECORDER_HEARTBEAT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(
            [
                "KITE RECORDER HEARTBEAT",
                f"timestamp: {timestamp.isoformat()}",
                f"rows_written_tick: {result.tick_rows_recorded}",
                f"rows_written_depth: {result.depth_rows_recorded}",
                "memory_safe_streaming=true",
                "execution_allowed=false",
                "Broker Orders: DISABLED",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    result.heartbeat_path = path
    if path not in result.files:
        result.files.append(path)


def _refresh_market_data_status(result: KiteRecordingResult) -> None:
    if result.tick_rows_recorded > 0 and result.depth_rows_recorded > 0:
        result.market_data_status = "RECORDED"
        result.depth_status = "PRESENT"
    elif result.tick_rows_recorded > 0:
        result.market_data_status = "PARTIAL_QUOTE"
        result.depth_status = result.depth_status if result.depth_status != "NOT_CHECKED" else "MISSING"
    elif result.depth_rows_recorded > 0:
        result.market_data_status = "PARTIAL_QUOTE"
        result.depth_status = "PRESENT"
    elif result.quote_status == "OK":
        result.market_data_status = "NO_LIVE_TICKS"
        if result.depth_status == "NOT_CHECKED":
            result.depth_status = "MISSING"
    else:
        result.market_data_status = "NO_LIVE_TICKS"
        if result.depth_status == "NOT_CHECKED":
            result.depth_status = "MISSING"


def _instrument_client_factory_from_broker(broker: Any | None):
    if broker is None or not hasattr(broker, "get_instruments"):
        return None

    class _InstrumentClient:
        def instruments(self, exchange: str | None = None):
            return broker.get_instruments(exchange)

    return lambda _api_key, _access_token: _InstrumentClient()


def _safe_get_quote(broker: Any, quote_symbols: list[str], result: KiteRecordingResult) -> dict[str, Any]:
    try:
        quote = broker.get_quote(quote_symbols)
    except Exception as exc:
        result.errors.append(f"Kite quote read failed safely: {type(exc).__name__}.")
        return {}
    if isinstance(quote, dict) and quote.get("status"):
        status = quote.get("status")
        if status == "credentials_missing":
            result.errors.append("Kite quote read skipped safely: missing " + ", ".join(quote.get("missing", [])) + ".")
        else:
            result.errors.append(f"Kite quote read skipped safely: {status}.")
        return {}
    return quote if isinstance(quote, dict) else {}


def _sample_quote(
    symbols: list[str],
    quote_symbols: list[str],
    received_at: datetime,
    resolution_by_symbol: dict[str, KiteInstrumentMapping] | None = None,
) -> dict[str, Any]:
    output: dict[str, Any] = {}
    resolution_by_symbol = resolution_by_symbol or {}
    for index, (internal_symbol, quote_symbol) in enumerate(zip(symbols, quote_symbols)):
        mapping = resolution_by_symbol.get(internal_symbol)
        instrument_token = mapping.instrument_token if mapping and mapping.instrument_token else 100000 + index
        output[quote_symbol] = {
            "instrument_token": instrument_token,
            "timestamp": received_at,
            "last_price": 150000.0 + index,
            "volume_traded": 1000 + index,
            "oi": 5000 + index,
            "depth": {
                "buy": [
                    {"price": 149999 - level, "quantity": 10 + level, "orders": 1 + level}
                    for level in range(5)
                ],
                "sell": [
                    {"price": 150001 + level, "quantity": 12 + level, "orders": 2 + level}
                    for level in range(5)
                ],
            },
        }
    return output


def _missing_quote_fields(payload: dict[str, Any]) -> tuple[list[str], list[str]]:
    required_missing: list[str] = []
    optional_missing: list[str] = []
    if payload.get("last_price") is None and payload.get("ltp") is None:
        required_missing.append("last_price")
    for field in ("volume_traded", "last_quantity", "average_price", "oi"):
        value = payload.get(field)
        if value is None or value == "":
            optional_missing.append(field)
    depth = payload.get("depth")
    if not (isinstance(depth, dict) and (depth.get("buy") or depth.get("sell"))):
        optional_missing.append("depth")
    return required_missing, optional_missing


def _to_kite_quote_symbol(symbol: str, instruments: dict[str, Any]) -> str:
    if ":" in symbol:
        return symbol
    instrument = instruments.get(symbol, {}) if isinstance(instruments, dict) else {}
    exchange = instrument.get("exchange") if isinstance(instrument, dict) else None
    return f"{exchange}:{symbol}" if exchange else symbol


def _parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _write_report(base: Path, result: KiteRecordingResult) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    unique_files = list(dict.fromkeys(str(path) for path in result.files))
    operation_log_path = _append_operation_log(base, result, unique_files)
    cumulative = _read_cumulative_operations(operation_log_path)
    lines = [
        "KITE DATA COLLECTION REPORT",
        "Mode: PAPER",
        "Kite Mode: READ_ONLY",
        f"credential_status: {result.credential_status}",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
        "LAST OPERATION",
        f"Last operation type: {result.operation_type}",
        f"Tick rows recorded in last operation: {result.tick_rows_recorded}",
        f"Depth rows recorded in last operation: {result.depth_rows_recorded}",
        "memory_safe_streaming: true",
        f"flush_rows: {result.flush_rows}",
        f"resume: {str(result.resume).lower()}",
        f"recorder_completed_normally: {str(result.recorder_completed_normally).lower()}",
        f"recorder_failed_safely: {str(result.recorder_failed_safely).lower()}",
        f"partial_data_usable: {str(result.partial_data_usable).lower()}",
        f"tick_output_paths: {'; '.join(str(path) for path in result.files if str(path).lower().endswith('_ticks.csv')) or 'NONE'}",
        f"depth_output_paths: {'; '.join(str(path) for path in result.files if str(path).lower().endswith('_depth.csv')) or 'NONE'}",
        f"Candle rows downloaded in last operation: {result.candle_rows_downloaded}",
        f"Features generated in last operation: {result.features_generated}",
        f"Tick rows loaded: {result.tick_rows_loaded}",
        f"Depth rows loaded: {result.depth_rows_loaded}",
        f"Real tick rows used: {result.real_tick_rows_used}",
        f"Real depth rows used: {result.real_depth_rows_used}",
        f"Synthetic/dry-run rows ignored: {result.synthetic_rows_ignored}",
        f"Stale output rows removed: {result.stale_output_rows_removed}",
        f"Output CSV data row count: {result.output_csv_data_rows}",
        f"Feature mode: {result.feature_mode}",
        f"Reason if 0 features: {result.zero_feature_reason or 'N/A'}",
        f"Quote check status: {result.quote_status}",
        f"Depth check status: {result.depth_status}",
        f"Market data status: {result.market_data_status}",
        f"Contract consistency status: {result.contract_consistency_status}",
        f"Selected contract: {result.selected_contract or 'NONE'}",
        "Ignored contracts: " + ("; ".join(result.ignored_contracts) if result.ignored_contracts else "NONE"),
        "Synthetic/dry-run contracts ignored: " + ("; ".join(result.synthetic_contracts_ignored) if result.synthetic_contracts_ignored else "NONE"),
        f"Contract action required: {str(result.contract_action_required).lower()}",
        f"Output real contract count: {result.output_real_contract_count}",
        f"Report/CSV contract match: {str(result.report_csv_contract_match).lower()}",
        f"Contract metadata complete: {str(result.contract_metadata_complete).lower()}",
        "Missing contract fields: " + ("; ".join(result.missing_contract_fields) if result.missing_contract_fields else "NONE"),
        f"Expiry missing warning: {'yes' if result.expiry_missing_warning else 'no'}",
        f"Expiry rows enriched: {result.expiry_rows_enriched}",
        f"Files touched in last operation: {len(unique_files)}",
    ]
    lines.extend(f"- {item}" for item in unique_files[:20])
    if result.input_files:
        lines.extend(["", "INPUT FILES"])
        lines.extend(f"- {item}" for item in result.input_files[:20])
    if result.symbol_resolutions:
        lines.extend(["", "SYMBOL RESOLUTION"])
        lines.extend(mapping.as_report_line() for mapping in result.symbol_resolutions)
    lines.extend(
        [
            "",
            "Missing required fields: " + ("; ".join(sorted(set(result.missing_fields))) if result.missing_fields else "NONE"),
            "Optional missing field warnings: " + ("; ".join(sorted(set(result.optional_missing_fields))) if result.optional_missing_fields else "NONE"),
            "Errors: " + ("; ".join(result.errors) if result.errors else "NONE"),
            "",
            "CUMULATIVE OPERATION LOG",
            f"Operations logged: {cumulative['operations']}",
            f"Total tick rows recorded: {cumulative['tick_rows_recorded']}",
            f"Total depth rows recorded: {cumulative['depth_rows_recorded']}",
            f"Total candle rows downloaded: {cumulative['candle_rows_downloaded']}",
            f"Total features generated: {cumulative['features_generated']}",
            f"Operation log: {operation_log_path}",
            "",
            "PAPER MODE ONLY. Kite read-only data calls only. No broker orders were placed.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _append_operation_log(base: Path, result: KiteRecordingResult, unique_files: list[str]) -> Path:
    path = base / OPERATIONS_LOG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    _upgrade_operation_log_header(path)
    write_header = not path.exists() or path.stat().st_size == 0
    row = {
        "timestamp": datetime.now().astimezone().isoformat(),
        "operation_type": result.operation_type,
        "credential_status": result.credential_status,
        "tick_rows_recorded": result.tick_rows_recorded,
        "depth_rows_recorded": result.depth_rows_recorded,
        "candle_rows_downloaded": result.candle_rows_downloaded,
        "features_generated": result.features_generated,
        "files_touched": len(unique_files),
        "missing_fields": ";".join(sorted(set(result.missing_fields))) if result.missing_fields else "NONE",
        "errors": ";".join(result.errors) if result.errors else "NONE",
        "execution_allowed": "false",
    }
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=OPERATION_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    return path



def _upgrade_operation_log_header(path: Path) -> None:
    if not path.exists() or path.stat().st_size == 0:
        return
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if not rows:
        return
    header = rows[0]
    if header == OPERATION_COLUMNS:
        return
    normalized_rows: list[dict[str, str]] = []
    for values in rows[1:]:
        if not values:
            continue
        if "credential_status" not in header and len(values) == len(OPERATION_COLUMNS):
            source = dict(zip(OPERATION_COLUMNS, values))
        else:
            source = dict(zip(header, values))
            source.setdefault("credential_status", "NOT_CHECKED")
        normalized_rows.append({column: source.get(column, "") for column in OPERATION_COLUMNS})
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=OPERATION_COLUMNS)
        writer.writeheader()
        writer.writerows(normalized_rows)


def _read_cumulative_operations(path: Path) -> dict[str, int]:
    totals = {
        "operations": 0,
        "tick_rows_recorded": 0,
        "depth_rows_recorded": 0,
        "candle_rows_downloaded": 0,
        "features_generated": 0,
    }
    if not path.exists():
        return totals
    with path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            totals["operations"] += 1
            for field in (
                "tick_rows_recorded",
                "depth_rows_recorded",
                "candle_rows_downloaded",
                "features_generated",
            ):
                totals[field] += _as_int(row.get(field))
    return totals


def _as_int(value) -> int:
    try:
        return int(float(str(value or "0")))
    except (TypeError, ValueError):
        return 0

def _parse_bool(value: str | bool | None) -> bool:
    return value is True or str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read-only Kite live tick/depth recorder. Never places broker orders.")
    parser.add_argument("--symbols", required=True)
    parser.add_argument("--duration-seconds", type=int, default=60)
    parser.add_argument("--record-depth", default="true")
    parser.add_argument("--poll-interval-seconds", type=float, default=1.0)
    parser.add_argument("--dry-run", default="true", help="true uses one synthetic snapshot and no credentials.")
    parser.add_argument("--flush-rows", type=int, default=100)
    parser.add_argument("--resume", default="true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = record_kite_live_data(
        symbols_text=args.symbols,
        duration_seconds=args.duration_seconds,
        record_depth=_parse_bool(args.record_depth),
        poll_interval_seconds=args.poll_interval_seconds,
        dry_run=_parse_bool(args.dry_run),
        flush_rows=args.flush_rows,
        resume=_parse_bool(args.resume),
    )
    return 0 if not result.errors or _parse_bool(args.dry_run) else 1


if __name__ == "__main__":
    raise SystemExit(main())
