from __future__ import annotations

import argparse
import time
from dataclasses import dataclass, field
from datetime import date, datetime, time as datetime_time, timedelta
from pathlib import Path
from typing import Any, Callable

from src.brokers.kite_broker import KiteBroker
from src.config_loader import load_configs
from src.data_collection.kite_credentials import format_kite_credential_status, load_kite_credentials
from src.data_collection.kite_live_recorder import KiteRecordingResult, _write_report
from src.data_collection.market_data_schema import (
    PROVIDER_BAR_COLUMNS,
    kite_historical_bar_path,
    normalize_kite_bar_rows,
    safe_symbol_filename,
    save_rows_dedup,
)


class KiteHistoricalDownloadError(ValueError):
    """CLI-safe error for read-only Kite historical downloads."""


@dataclass
class KiteHistoricalDownloadResult:
    rows_downloaded: int = 0
    files: list[Path] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    report_path: Path | None = None
    credential_status: str = "NOT_CHECKED"


def download_kite_historical_bars(
    base_dir: Path | str = ".",
    *,
    symbols_text: str,
    from_date: str | date,
    to_date: str | date,
    interval: str = "minute",
    output_dir: str = "data/historical/kite/bars",
    rate_limit_seconds: float = 0.2,
    broker: Any | None = None,
    configs: dict[str, Any] | None = None,
    sleep_fn: Callable[[float], None] | None = None,
) -> KiteHistoricalDownloadResult:
    base = Path(base_dir)
    configs = configs or load_configs(base)
    symbols = _parse_symbols(symbols_text)
    start_day = _parse_date(from_date)
    end_day = _parse_date(to_date)
    if end_day < start_day:
        raise KiteHistoricalDownloadError("--to-date must be on or after --from-date.")
    result = KiteHistoricalDownloadResult()
    credential_state = load_kite_credentials(base)
    result.credential_status = credential_state.credential_status
    print("KITE HISTORICAL CANDLE DOWNLOADER")
    print("Mode: PAPER | Kite: READ ONLY | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Credential Status: {result.credential_status}")
    for line in format_kite_credential_status(credential_state):
        print(line)
    print(f"Symbols: {', '.join(symbols) if symbols else 'NONE'}")
    print(f"Date Range: {start_day} to {end_day}")
    print(f"Interval: {interval}")
    if not symbols:
        result.errors.append("No symbols supplied.")
        _write_download_report(base, result)
        return result

    if broker is None and not credential_state.all_present:
        result.errors.append(
            "Kite historical downloader skipped safely: missing "
            + ", ".join(credential_state.missing_keys())
            + ". Configure env/.env credentials before real read-only downloads."
        )
        _write_download_report(base, result)
        print(result.errors[-1])
        print("READ ONLY CHECK ONLY. NO ORDERS.")
        return result

    kite_broker = broker or KiteBroker(
        configs.get("settings", {}),
        configs.get("risk", {}),
        broker_name="kite",
        base_dir=base,
    )
    missing = []
    if hasattr(kite_broker, "_missing_read_credentials"):
        missing = list(kite_broker._missing_read_credentials())
    if missing:
        result.errors.append("Kite historical downloader skipped safely: missing " + ", ".join(missing) + ".")
        _write_download_report(base, result)
        print(result.errors[-1])
        return result

    sleeper = sleep_fn or time.sleep
    token_cache = {
        symbol: resolve_instrument_token(kite_broker, symbol, configs.get("instruments", {}))
        for symbol in symbols
    }
    for day in _iter_days(start_day, end_day):
        day_start = datetime.combine(day, datetime_time(0, 0, 0))
        day_end = datetime.combine(day, datetime_time(23, 59, 59))
        for symbol in symbols:
            try:
                candles = kite_broker.get_historical_data(token_cache[symbol], day_start, day_end, interval, oi=True)
            except Exception as exc:
                result.errors.append(f"Kite historical read failed safely for {symbol} {day}: {type(exc).__name__}.")
                continue
            if isinstance(candles, dict) and candles.get("status"):
                result.errors.append(f"Kite historical read skipped for {symbol} {day}: {candles.get('status')}.")
                continue
            normalized = normalize_kite_bar_rows(list(candles or []), symbol, interval)
            path = _output_bar_path(base, output_dir, day, symbol)
            saved = save_rows_dedup(path, PROVIDER_BAR_COLUMNS, normalized, ["timestamp", "symbol", "interval"])
            result.rows_downloaded += saved.rows_written
            result.files.append(saved.path)
            if rate_limit_seconds > 0:
                sleeper(rate_limit_seconds)
    _write_download_report(base, result)
    print(f"Candle rows downloaded: {result.rows_downloaded}")
    print(f"Report: {result.report_path}")
    print("PAPER MODE ONLY. Kite read-only historical data calls only. No broker orders were placed.")
    return result


def resolve_instrument_token(broker: Any, symbol: str, instruments_config: dict[str, Any] | None = None) -> int:
    instruments_config = instruments_config or {}
    configured = instruments_config.get(symbol, {}) if isinstance(instruments_config, dict) else {}
    token = configured.get("instrument_token") if isinstance(configured, dict) else None
    if token not in {None, "", "null"}:
        return int(token)
    exchange, tradingsymbol = _split_symbol(symbol, configured if isinstance(configured, dict) else {})
    instruments = broker.get_instruments(exchange)
    if isinstance(instruments, dict) and instruments.get("status"):
        raise KiteHistoricalDownloadError(f"Kite instruments lookup failed safely for {symbol}: {instruments.get('status')}.")
    for item in instruments or []:
        if str(item.get("exchange") or exchange) == exchange and str(item.get("tradingsymbol") or "") == tradingsymbol:
            found = item.get("instrument_token")
            if found in {None, ""}:
                raise KiteHistoricalDownloadError(f"Kite symbol found without instrument_token: {symbol}.")
            return int(found)
    raise KiteHistoricalDownloadError(f"Kite symbol not found: {symbol}.")


def _split_symbol(symbol: str, configured: dict[str, Any]) -> tuple[str, str]:
    if ":" in symbol:
        exchange, tradingsymbol = symbol.split(":", 1)
        return exchange.strip(), tradingsymbol.strip()
    exchange = str(configured.get("exchange") or "").strip()
    if not exchange:
        raise KiteHistoricalDownloadError(
            f"Kite symbol needs an exchange prefix or config/instruments.yaml exchange: {symbol}."
        )
    return exchange, symbol


def _output_bar_path(base: Path, output_dir: str, day: date, symbol: str) -> Path:
    if output_dir == "data/historical/kite/bars":
        return kite_historical_bar_path(base, day, symbol)
    directory = Path(output_dir)
    directory = directory if directory.is_absolute() else base / directory
    return directory / day.isoformat() / f"{safe_symbol_filename(symbol)}_bars.csv"


def _write_download_report(base: Path, result: KiteHistoricalDownloadResult) -> None:
    report = KiteRecordingResult(
        operation_type="downloader",
        credential_status=result.credential_status,
        candle_rows_downloaded=result.rows_downloaded,
        files=result.files,
        errors=result.errors,
    )
    _write_report(base, report)
    result.report_path = report.report_path


def _parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _parse_date(value: str | date) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def _iter_days(start: date, end: date) -> list[date]:
    days: list[date] = []
    current = start
    while current <= end:
        days.append(current)
        current += timedelta(days=1)
    return days


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read-only Kite historical candle downloader. Never places broker orders.")
    parser.add_argument("--symbols", required=True)
    parser.add_argument("--from-date", required=True)
    parser.add_argument("--to-date", required=True)
    parser.add_argument("--interval", default="minute")
    parser.add_argument("--output-dir", default="data/historical/kite/bars")
    parser.add_argument("--rate-limit-seconds", type=float, default=0.2)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = download_kite_historical_bars(
            symbols_text=args.symbols,
            from_date=args.from_date,
            to_date=args.to_date,
            interval=args.interval,
            output_dir=args.output_dir,
            rate_limit_seconds=args.rate_limit_seconds,
        )
    except KiteHistoricalDownloadError as exc:
        print(f"Kite historical downloader stopped safely: {exc}")
        print("Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false")
        return 1
    return 0 if not result.errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
