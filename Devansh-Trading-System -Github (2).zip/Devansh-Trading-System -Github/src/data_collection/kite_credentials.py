from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Mapping
from zoneinfo import ZoneInfo

from src.config_loader import load_dotenv_file


KITE_CREDENTIAL_KEYS = ("KITE_API_KEY", "KITE_API_SECRET", "KITE_ACCESS_TOKEN")
IST = ZoneInfo("Asia/Kolkata")


@dataclass(frozen=True)
class KiteCredentialState:
    """Credential state that never exposes secret values through repr/reporting."""

    api_key: str | None = field(default=None, repr=False)
    api_secret: str | None = field(default=None, repr=False)
    access_token: str | None = field(default=None, repr=False)
    api_key_source: str = "MISSING"
    api_secret_source: str = "MISSING"
    access_token_source: str = "MISSING"
    daily_token_file_present: bool = False
    daily_token_date: str = ""

    def status_for(self, key: str) -> str:
        value = {
            "KITE_API_KEY": self.api_key,
            "KITE_API_SECRET": self.api_secret,
            "KITE_ACCESS_TOKEN": self.access_token,
        }.get(key)
        return "PRESENT" if str(value or "").strip() else "MISSING"

    @property
    def credential_status(self) -> str:
        return "PRESENT" if self.all_present else "MISSING"

    @property
    def all_present(self) -> bool:
        return all(self.status_for(key) == "PRESENT" for key in KITE_CREDENTIAL_KEYS)

    @property
    def read_ready(self) -> bool:
        return self.status_for("KITE_API_KEY") == "PRESENT" and self.status_for("KITE_ACCESS_TOKEN") == "PRESENT"

    def missing_keys(self) -> list[str]:
        return [key for key in KITE_CREDENTIAL_KEYS if self.status_for(key) == "MISSING"]

    def public_status_rows(self) -> list[tuple[str, str]]:
        return [(key, self.status_for(key)) for key in KITE_CREDENTIAL_KEYS]

    def redacted_message(self, message: str) -> str:
        safe = str(message or "")
        for secret in (self.api_key, self.api_secret, self.access_token):
            if secret:
                safe = safe.replace(secret, "[REDACTED]")
        return safe


def load_kite_credentials(
    base_dir: Path | str = ".",
    *,
    env: Mapping[str, str] | None = None,
    require_daily_token: bool = False,
    as_of: date | None = None,
) -> KiteCredentialState:
    """Load Kite credentials without exposing their values.

    The current IST-date token file always wins when present. Broker clients set
    ``require_daily_token=True`` so a stale process/.env token cannot silently
    replace the session created by today's manual login.
    """

    explicit_env = env is not None
    if env is None:
        process_api_key = _clean(os.environ.get("KITE_API_KEY"))
        process_api_secret = _clean(os.environ.get("KITE_API_SECRET"))
        process_access_token = _clean(os.environ.get("KITE_ACCESS_TOKEN"))
        load_dotenv_file(base_dir)
        env = os.environ
        api_key_source = "ENV" if process_api_key else ("DOTENV" if _clean(env.get("KITE_API_KEY")) else "MISSING")
        api_secret_source = "ENV" if process_api_secret else ("DOTENV" if _clean(env.get("KITE_API_SECRET")) else "MISSING")
        env_token_source = "ENV" if process_access_token else ("DOTENV" if _clean(env.get("KITE_ACCESS_TOKEN")) else "MISSING")
    else:
        api_key_source = "ENV" if _clean(env.get("KITE_API_KEY")) else "MISSING"
        api_secret_source = "ENV" if _clean(env.get("KITE_API_SECRET")) else "MISSING"
        env_token_source = "ENV" if _clean(env.get("KITE_ACCESS_TOKEN")) else "MISSING"

    session_date = kite_session_date(as_of)
    token_path = kite_daily_token_path(base_dir, session_date)
    token_file_present = token_path.is_file()
    file_token = load_daily_access_token(base_dir, session_date) if token_file_present else None
    if file_token:
        access_token = file_token
        access_token_source = "DAILY_TOKEN_FILE"
    elif token_file_present:
        access_token = None
        access_token_source = "INVALID_DAILY_TOKEN_FILE"
    elif require_daily_token:
        access_token = None
        access_token_source = "MISSING"
    else:
        access_token = _clean(env.get("KITE_ACCESS_TOKEN"))
        access_token_source = env_token_source

    # Explicit mappings are test/dependency-injection inputs. They remain
    # filesystem-independent unless strict daily-token policy was requested.
    if explicit_env and not require_daily_token:
        access_token = _clean(env.get("KITE_ACCESS_TOKEN"))
        access_token_source = env_token_source
        token_file_present = False

    return KiteCredentialState(
        api_key=_clean(env.get("KITE_API_KEY")),
        api_secret=_clean(env.get("KITE_API_SECRET")),
        access_token=access_token,
        api_key_source=api_key_source,
        api_secret_source=api_secret_source,
        access_token_source=access_token_source,
        daily_token_file_present=token_file_present,
        daily_token_date=session_date.isoformat(),
    )


def format_kite_credential_status(state: KiteCredentialState) -> list[str]:
    return [f"{key}: {status}" for key, status in state.public_status_rows()]


def kite_session_date(as_of: date | None = None) -> date:
    return as_of or datetime.now(IST).date()


def kite_daily_token_path(base_dir: Path | str = ".", as_of: date | None = None) -> Path:
    session_date = kite_session_date(as_of)
    return Path(base_dir) / ".tokens" / f"kite_access_token_{session_date.isoformat()}.txt"


def load_daily_access_token(base_dir: Path | str = ".", as_of: date | None = None) -> str | None:
    path = kite_daily_token_path(base_dir, as_of)
    if not path.is_file():
        return None
    return _clean(path.read_text(encoding="utf-8"))


def _clean(value: str | None) -> str | None:
    text = str(value or "").strip().strip('"').strip("'")
    return text or None
