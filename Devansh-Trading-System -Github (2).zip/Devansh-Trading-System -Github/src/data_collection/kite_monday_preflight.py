from __future__ import annotations

import argparse
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs
from src.data_collection.kite_credentials import format_kite_credential_status, load_kite_credentials
from src.data_collection.kite_instrument_resolver import (
    KiteInstrumentMapping,
    instrument_cache_path,
    load_cached_instruments,
    resolve_kite_instruments,
)
from src.data_collection.kite_readonly_check import run_kite_readonly_check


REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_monday_preflight_report.txt"


@dataclass
class KiteMondayPreflightResult:
    timestamp: datetime
    symbols: list[str]
    dry_run: bool
    credential_status: str = "NOT_CHECKED"
    profile_status: str = "NOT_CHECKED"
    quote_status: str = "NOT_CHECKED"
    depth_status: str = "NOT_CHECKED"
    mappings: list[KiteInstrumentMapping] = field(default_factory=list)
    selected_contracts: list[str] = field(default_factory=list)
    expiry_available: bool = False
    safety_flags_ok: bool = False
    production_whatsapp_status: str = "BLOCKED"
    market_note: str = ""
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    report_path: Path | None = None

    @property
    def success(self) -> bool:
        return not self.errors

    @property
    def status(self) -> str:
        if self.errors:
            return "FAILED_SAFE"
        if self.market_note:
            return "READY_WITH_MARKET_NOTE"
        return "READY_READ_ONLY"


def run_kite_monday_preflight(
    base_dir: Path | str = ".",
    *,
    symbols_text: str = "GOLD-I",
    dry_run: bool = True,
    configs: dict[str, Any] | None = None,
    resolver_func: Callable[..., Any] = resolve_kite_instruments,
    readonly_check_func: Callable[..., Any] = run_kite_readonly_check,
    now_fn: Callable[[], datetime] | None = None,
) -> KiteMondayPreflightResult:
    base = Path(base_dir)
    now = now_fn or (lambda: datetime.now().astimezone())
    symbols = _parse_symbols(symbols_text)
    result = KiteMondayPreflightResult(timestamp=now(), symbols=symbols, dry_run=dry_run)
    resolver_as_of = result.timestamp.date()
    state = load_kite_credentials(base)
    result.credential_status = state.credential_status
    configs = configs or _safe_configs(base)

    print("KITE MONDAY READ-ONLY PREFLIGHT")
    print("READ ONLY CHECK ONLY. NO ORDERS.")
    print("Mode: PAPER | Live Trading: DISABLED | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Symbols: {', '.join(symbols) if symbols else 'NONE'}")
    print(f"Dry Run: {str(dry_run).lower()}")
    print(f"Credential Status: {result.credential_status}")
    for line in format_kite_credential_status(state):
        print(line)

    _check_safety(configs, result)
    if not symbols:
        result.errors.append("No symbols supplied.")
    if not dry_run and not state.all_present:
        result.errors.append(
            "Monday preflight stopped safely: real read-only mode requires PRESENT Kite credentials."
        )
    if result.errors:
        _write_report(base, result)
        _print_summary(result)
        return result

    try:
        resolver_kwargs: dict[str, Any] = {
            "symbols_text": symbols_text,
            "exchange": "MCX",
            "dry_run": dry_run,
            "as_of": resolver_as_of,
        }
        cache_rows = load_cached_instruments(instrument_cache_path(base, "MCX")) if dry_run else []
        if cache_rows:
            resolver_kwargs["instruments"] = cache_rows
        resolved = resolver_func(base, **resolver_kwargs)
        result.mappings = list(getattr(resolved, "mappings", []) or [])
        resolution_errors = list(getattr(resolved, "errors", []) or [])
        result.warnings.extend(resolution_errors)
        unresolved = [mapping.internal_symbol for mapping in result.mappings if not mapping.resolved]
        if not result.mappings or unresolved:
            result.errors.append(
                "Symbol resolution failed for: " + ", ".join(unresolved or symbols) + "."
            )
        for mapping in result.mappings:
            selected = (
                f"{mapping.internal_symbol}:{mapping.exchange}:{mapping.tradingsymbol} "
                f"instrument_token={mapping.instrument_token or 'N/A'} "
                f"expiry={mapping.expiry or 'MISSING'}"
            )
            result.selected_contracts.append(selected)
            print(f"Selected Contract: {selected}")
        result.expiry_available = bool(result.mappings) and all(
            mapping.resolved and bool(str(mapping.expiry or "").strip())
            for mapping in result.mappings
        )
        if not result.expiry_available:
            result.warnings.append("One or more selected contracts have missing expiry metadata.")
    except Exception as exc:  # pragma: no cover - defensive CLI boundary
        result.errors.append(f"Symbol resolution failed safely: {type(exc).__name__}.")

    if not result.errors:
        try:
            check = readonly_check_func(
                base,
                symbols_text=symbols_text,
                dry_run="true" if dry_run else "false",
                configs=configs,
                exchange="MCX",
                as_of=resolver_as_of,
            )
            result.profile_status = str(getattr(check, "profile_status", "NOT_CHECKED"))
            result.quote_status = str(getattr(check, "quote_status", "NOT_CHECKED"))
            result.depth_status = str(getattr(check, "depth_status", "NOT_CHECKED"))
            check_errors = list(getattr(check, "errors", []) or [])
            if check_errors:
                result.warnings.extend(check_errors)
            if result.quote_status not in {"OK", "DRY_RUN_OK"}:
                result.market_note = (
                    f"Quote status is {result.quote_status}; market may be closed or live data may be unavailable."
                )
            if result.depth_status == "MISSING":
                result.market_note = (
                    result.market_note + " " if result.market_note else ""
                ) + "Depth is currently missing; continue quote-only checks safely."
        except Exception as exc:  # pragma: no cover - defensive CLI boundary
            result.market_note = f"Read-only quote/depth check failed safely: {type(exc).__name__}."

    _write_report(base, result)
    _print_summary(result)
    return result


def _check_safety(configs: dict[str, Any], result: KiteMondayPreflightResult) -> None:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    checks = {
        "mode PAPER": str(settings.get("mode", "PAPER")).upper() == "PAPER",
        "enable_live_trading false": not bool(settings.get("enable_live_trading", False)),
        "ENABLE_LIVE_TRADING false": not _truthy(os.environ.get("ENABLE_LIVE_TRADING")),
        "I_UNDERSTAND_LIVE_TRADING_RISK false": not _truthy(
            os.environ.get("I_UNDERSTAND_LIVE_TRADING_RISK")
        ),
        "production WhatsApp blocked": not bool(forward.get("production_alerts_allowed", False)),
    }
    result.safety_flags_ok = all(checks.values())
    if not result.safety_flags_ok:
        failed = [name for name, passed in checks.items() if not passed]
        result.errors.append("Safety preflight failed: " + ", ".join(failed) + ".")


def _write_report(base: Path, result: KiteMondayPreflightResult) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "KITE MONDAY READ-ONLY PREFLIGHT REPORT",
        f"Timestamp: {result.timestamp.isoformat()}",
        "Mode: PAPER",
        "Kite Mode: READ_ONLY_DATA",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
        f"Status: {result.status}",
        f"Symbols: {', '.join(result.symbols) if result.symbols else 'NONE'}",
        f"dry_run: {str(result.dry_run).lower()}",
        f"credential_status: {result.credential_status}",
        f"profile_status: {result.profile_status}",
        f"quote_status: {result.quote_status}",
        f"depth_status: {result.depth_status}",
        f"safety_flags_ok: {str(result.safety_flags_ok).lower()}",
        f"production_whatsapp_status: {result.production_whatsapp_status}",
        "",
        "SELECTED CONTRACTS",
    ]
    lines.extend(f"- {item}" for item in result.selected_contracts)
    if not result.selected_contracts:
        lines.append("- NONE")
    lines.extend(
        [
            f"expiry_available: {str(result.expiry_available).lower()}",
            "",
            f"Market note: {result.market_note or 'NONE'}",
            "Warnings: " + ("; ".join(result.warnings) if result.warnings else "NONE"),
            "Errors: " + ("; ".join(result.errors) if result.errors else "NONE"),
            "",
            "SAFETY CONFIRMATION",
            "ENABLE_LIVE_TRADING=false",
            "I_UNDERSTAND_LIVE_TRADING_RISK=false",
            "Production WhatsApp Alerts: BLOCKED",
            "READ ONLY CHECK ONLY. NO ORDERS.",
            "PAPER MODE ONLY. No broker orders were placed.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _print_summary(result: KiteMondayPreflightResult) -> None:
    print("\nMONDAY PREFLIGHT SUMMARY")
    print(f"Status: {result.status}")
    print(f"Profile check: {result.profile_status}")
    print(f"Quote check: {result.quote_status}")
    print(f"Depth check: {result.depth_status}")
    print(f"Expiry available: {str(result.expiry_available).lower()}")
    print(f"Safety flags OK: {str(result.safety_flags_ok).lower()}")
    print(f"Production WhatsApp: {result.production_whatsapp_status}")
    print(f"Report: {result.report_path}")
    if result.errors:
        print("Errors: " + "; ".join(result.errors))
    else:
        print("Errors: NONE")
    print("READ ONLY CHECK ONLY. NO ORDERS.")


def _safe_configs(base: Path) -> dict[str, Any]:
    try:
        return load_configs(base)
    except (FileNotFoundError, OSError):
        return {
            "settings": {"mode": "PAPER", "enable_live_trading": False},
            "risk": {},
            "strategies": {},
            "approved_strategies": {},
            "instruments": {"GOLD-I": {"exchange": "MCX"}},
            "alerts": {"enable_whatsapp_alerts": False},
            "forward_validation": {"production_alerts_allowed": False},
        }


def _parse_symbols(symbols_text: str | None) -> list[str]:
    output: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in output:
            output.append(symbol)
    return output


def _parse_bool(value: str | bool | None) -> bool:
    return value is True or str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Safe Monday Kite read-only readiness preflight.")
    parser.add_argument("--symbols", default="GOLD-I")
    parser.add_argument("--dry-run", default="true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = run_kite_monday_preflight(
        symbols_text=args.symbols,
        dry_run=_parse_bool(args.dry_run),
    )
    return 0 if result.success else 1


if __name__ == "__main__":
    raise SystemExit(main())
