from __future__ import annotations

import argparse
import csv
import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


REQUIRED_COLUMNS = [
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "symbol",
    "provider",
    "timeframe",
    "contract",
    "expiry",
    "is_continuous",
    "source_file",
]
MANIFEST_TXT_PATH = Path("reports") / "historical_imports" / "latest_historical_ohlcv_import_manifest.txt"
MANIFEST_CSV_PATH = Path("reports") / "historical_imports" / "historical_ohlcv_import_manifest.csv"
MANIFEST_COLUMNS = [
    "timestamp",
    "input_file",
    "status",
    "dry_run",
    "provider",
    "symbol",
    "timeframe",
    "contract",
    "expiry",
    "is_continuous",
    "rows_read",
    "rows_valid",
    "date_range",
    "duplicate_timestamps",
    "warnings",
    "errors",
    "source_file_hash",
    "output_file",
    "output_file_hash",
    "execution_allowed",
]
COMMON_COLUMN_MAP = {
    "date": "timestamp",
    "datetime": "timestamp",
    "time": "timestamp",
    "o": "open",
    "h": "high",
    "l": "low",
    "c": "close",
    "vol": "volume",
}


@dataclass(frozen=True)
class ImportRequest:
    input_files: tuple[Path, ...]
    provider: str
    symbol: str
    timeframe: str
    contract: str
    expiry: str = ""
    is_continuous: bool = False
    dry_run: bool = True


@dataclass
class FileImportResult:
    input_file: Path
    status: str
    rows_read: int = 0
    rows_valid: int = 0
    date_range: str = "NONE"
    duplicate_timestamps: int = 0
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    source_file_hash: str = ""
    output_file: Path | None = None
    output_file_hash: str = ""

    @property
    def success(self) -> bool:
        return self.status == "SUCCESS"


@dataclass(frozen=True)
class HistoricalOhlcvImportResult:
    manifest_txt_path: Path
    manifest_csv_path: Path
    file_results: tuple[FileImportResult, ...]
    dry_run: bool

    @property
    def success(self) -> bool:
        return all(result.success for result in self.file_results) and bool(self.file_results)


def run_historical_ohlcv_import(
    base_dir: Path | str = ".",
    *,
    input_file: str | Path | None = None,
    input_dir: str | Path | None = None,
    provider: str,
    symbol: str,
    timeframe: str,
    contract: str,
    expiry: str = "",
    is_continuous: bool = False,
    dry_run: bool = True,
    now: datetime | None = None,
) -> HistoricalOhlcvImportResult:
    base = Path(base_dir)
    files = _resolve_input_files(input_file=input_file, input_dir=input_dir)
    request = ImportRequest(
        input_files=tuple(files),
        provider=provider,
        symbol=symbol,
        timeframe=timeframe,
        contract=contract,
        expiry=expiry,
        is_continuous=is_continuous,
        dry_run=dry_run,
    )
    timestamp = now or datetime.now().astimezone()
    results = tuple(_process_file(base, request, path) for path in request.input_files)
    _write_manifests(base, request, results, timestamp)
    return HistoricalOhlcvImportResult(
        manifest_txt_path=base / MANIFEST_TXT_PATH,
        manifest_csv_path=base / MANIFEST_CSV_PATH,
        file_results=results,
        dry_run=dry_run,
    )


def _resolve_input_files(*, input_file: str | Path | None, input_dir: str | Path | None) -> list[Path]:
    files: list[Path] = []
    if input_file:
        files.append(Path(input_file))
    if input_dir:
        root = Path(input_dir)
        if root.exists():
            files.extend(sorted(root.glob("*.csv")))
    return tuple(dict.fromkeys(files))  # type: ignore[return-value]


def _process_file(base: Path, request: ImportRequest, path: Path) -> FileImportResult:
    result = FileImportResult(input_file=path, status="FAILED")
    result.source_file_hash = _sha256(path)
    if not path.exists():
        result.errors.append("input file missing")
        return result
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                result.errors.append("missing header row")
                return result
            mapping = _column_mapping(reader.fieldnames)
            missing = [column for column in ["timestamp", "open", "high", "low", "close"] if column not in mapping.values()]
            if missing:
                result.errors.append("missing required OHLC/timestamp columns: " + ",".join(missing))
                return result
            if "volume" not in mapping.values():
                result.warnings.append("volume missing; filled as 0")
            rows = list(reader)
    except (OSError, UnicodeDecodeError, csv.Error) as exc:
        result.errors.append(f"read failed: {type(exc).__name__}")
        return result

    result.rows_read = len(rows)
    normalized: list[dict[str, str]] = []
    seen: set[str] = set()
    for index, row in enumerate(rows, start=2):
        normalized_row, errors, warnings = _normalize_row(row, mapping, request, path, index)
        result.warnings.extend(warnings)
        if errors:
            result.errors.extend(errors)
            continue
        ts = normalized_row["timestamp"]
        if ts in seen:
            result.duplicate_timestamps += 1
            result.errors.append(f"duplicate timestamp at row {index}: {ts}")
            continue
        seen.add(ts)
        normalized.append(normalized_row)
    if result.errors:
        result.status = "FAILED"
        return result
    normalized.sort(key=lambda item: item["timestamp"])
    result.rows_valid = len(normalized)
    result.date_range = _date_range(normalized)
    _session_gap_warning(normalized, result.warnings)
    if request.dry_run:
        result.status = "SUCCESS"
        return result
    if normalized:
        written_files = _write_outputs(base, request, normalized)
        result.output_file = written_files[0] if len(written_files) == 1 else None
        result.output_file_hash = _sha256(written_files[0]) if len(written_files) == 1 else "MULTIPLE_FILES"
    result.status = "SUCCESS"
    return result


def _column_mapping(fieldnames: list[str]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for field in fieldnames:
        key = str(field or "").strip()
        canonical = key.lower().strip().replace(" ", "_")
        canonical = COMMON_COLUMN_MAP.get(canonical, canonical)
        if canonical in REQUIRED_COLUMNS or canonical in {"timestamp", "open", "high", "low", "close", "volume"}:
            mapping[key] = canonical
    return mapping


def _normalize_row(
    row: dict[str, Any],
    mapping: dict[str, str],
    request: ImportRequest,
    path: Path,
    row_number: int,
) -> tuple[dict[str, str], list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    by_canonical = {canonical: row.get(original, "") for original, canonical in mapping.items()}
    timestamp = _parse_timestamp(by_canonical.get("timestamp"))
    if timestamp is None:
        errors.append(f"row {row_number}: timestamp parse failed")
    values: dict[str, float] = {}
    for column in ("open", "high", "low", "close"):
        value = _to_float(by_canonical.get(column))
        if value is None:
            errors.append(f"row {row_number}: missing {column}")
        elif value <= 0:
            errors.append(f"row {row_number}: {column} must be positive")
        else:
            values[column] = value
    volume_value = by_canonical.get("volume")
    if volume_value in (None, ""):
        volume = 0.0
        warnings.append(f"row {row_number}: volume missing; filled as 0")
    else:
        volume = _to_float(volume_value)
        if volume is None:
            warnings.append(f"row {row_number}: volume parse failed; filled as 0")
            volume = 0.0
        elif volume < 0:
            errors.append(f"row {row_number}: volume must not be negative")
    if "high" in values and "low" in values and values["high"] < values["low"]:
        errors.append(f"row {row_number}: high < low")
    if errors:
        return {}, errors, warnings
    return (
        {
            "timestamp": timestamp.isoformat(),  # type: ignore[union-attr]
            "open": _format_number(values["open"]),
            "high": _format_number(values["high"]),
            "low": _format_number(values["low"]),
            "close": _format_number(values["close"]),
            "volume": _format_number(volume),
            "symbol": request.symbol,
            "provider": request.provider,
            "timeframe": request.timeframe,
            "contract": request.contract,
            "expiry": request.expiry,
            "is_continuous": "true" if request.is_continuous else "false",
            "source_file": str(path),
        },
        [],
        warnings,
    )


def _parse_timestamp(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d-%m-%Y %H:%M:%S", "%d/%m/%Y %H:%M:%S"):
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
    return None


def _to_float(value: Any) -> float | None:
    try:
        text = str(value).strip()
        if text == "":
            return None
        return float(text)
    except (TypeError, ValueError):
        return None


def _format_number(value: float) -> str:
    if float(value).is_integer():
        return str(int(value))
    return f"{value:.6f}".rstrip("0").rstrip(".")


def _date_range(rows: list[dict[str, str]]) -> str:
    if not rows:
        return "NONE"
    return f"{rows[0]['timestamp']} to {rows[-1]['timestamp']}"


def _session_gap_warning(rows: list[dict[str, str]], warnings: list[str]) -> None:
    if len(rows) < 2:
        return
    parsed = [_parse_timestamp(row["timestamp"]) for row in rows]
    parsed = [value for value in parsed if value is not None]
    if len(parsed) < 2:
        return
    max_gap = max((parsed[index] - parsed[index - 1]).total_seconds() for index in range(1, len(parsed)))
    if max_gap > 24 * 60 * 60:
        warnings.append(f"missing sessions/gaps possible: max timestamp gap {int(max_gap)} seconds")


def _write_outputs(base: Path, request: ImportRequest, rows: list[dict[str, str]]) -> list[Path]:
    by_year: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        year = row["timestamp"][:4]
        by_year.setdefault(year, []).append(row)
    paths: list[Path] = []
    for year, year_rows in sorted(by_year.items()):
        output = (
            base
            / "data"
            / "historical"
            / "ohlcv"
            / _safe_name(request.provider)
            / _safe_name(request.symbol)
            / _safe_name(request.timeframe)
            / f"{year}.csv"
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=REQUIRED_COLUMNS)
            writer.writeheader()
            for row in year_rows:
                writer.writerow({column: row.get(column, "") for column in REQUIRED_COLUMNS})
        paths.append(output)
    return paths


def _write_manifests(base: Path, request: ImportRequest, results: tuple[FileImportResult, ...], timestamp: datetime) -> None:
    txt_path = base / MANIFEST_TXT_PATH
    csv_path = base / MANIFEST_CSV_PATH
    txt_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "HISTORICAL OHLCV IMPORT MANIFEST",
        f"generated_at: {timestamp.isoformat()}",
        f"dry_run: {str(request.dry_run).lower()}",
        f"provider: {request.provider}",
        f"symbol: {request.symbol}",
        f"timeframe: {request.timeframe}",
        f"contract: {request.contract}",
        f"expiry: {request.expiry}",
        f"is_continuous: {str(request.is_continuous).lower()}",
        "timezone_assumption: timestamps are parsed as provided; normalize source data before import if needed",
        "no_lookahead_roll_adjustment: true",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Production WhatsApp: BLOCKED",
        "execution_allowed=false",
        "",
        "FILE RESULTS",
    ]
    for result in results:
        lines.extend(
            [
                f"input_file: {result.input_file}",
                f"status: {result.status}",
                f"rows_read: {result.rows_read}",
                f"rows_valid: {result.rows_valid}",
                f"date_range: {result.date_range}",
                f"duplicate_timestamps: {result.duplicate_timestamps}",
                f"warnings: {'; '.join(result.warnings) if result.warnings else 'NONE'}",
                f"errors: {'; '.join(result.errors) if result.errors else 'NONE'}",
                f"source_file_hash: {result.source_file_hash}",
                f"output_file: {result.output_file or 'DRY_RUN_OR_FAILED'}",
                f"output_file_hash: {result.output_file_hash or 'NONE'}",
                "",
            ]
        )
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_header = not csv_path.exists()
    with csv_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=MANIFEST_COLUMNS)
        if write_header:
            writer.writeheader()
        for result in results:
            writer.writerow(
                {
                    "timestamp": timestamp.isoformat(),
                    "input_file": str(result.input_file),
                    "status": result.status,
                    "dry_run": str(request.dry_run).lower(),
                    "provider": request.provider,
                    "symbol": request.symbol,
                    "timeframe": request.timeframe,
                    "contract": request.contract,
                    "expiry": request.expiry,
                    "is_continuous": str(request.is_continuous).lower(),
                    "rows_read": result.rows_read,
                    "rows_valid": result.rows_valid,
                    "date_range": result.date_range,
                    "duplicate_timestamps": result.duplicate_timestamps,
                    "warnings": "; ".join(result.warnings) if result.warnings else "NONE",
                    "errors": "; ".join(result.errors) if result.errors else "NONE",
                    "source_file_hash": result.source_file_hash,
                    "output_file": str(result.output_file or ""),
                    "output_file_hash": result.output_file_hash,
                    "execution_allowed": "false",
                }
            )


def _sha256(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_name(value: str) -> str:
    return str(value or "UNKNOWN").replace(":", "_").replace("/", "_").replace("\\", "_").replace(" ", "_")


def _parse_bool(value: str | bool) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate/import local historical OHLCV CSV files safely.")
    parser.add_argument("--input-file")
    parser.add_argument("--input-dir")
    parser.add_argument("--provider", required=True)
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--timeframe", required=True)
    parser.add_argument("--contract", required=True)
    parser.add_argument("--expiry", default="")
    parser.add_argument("--is-continuous", default="false")
    parser.add_argument("--dry-run", default="true")
    args = parser.parse_args(argv)
    result = run_historical_ohlcv_import(
        input_file=args.input_file,
        input_dir=args.input_dir,
        provider=args.provider,
        symbol=args.symbol,
        timeframe=args.timeframe,
        contract=args.contract,
        expiry=args.expiry,
        is_continuous=_parse_bool(args.is_continuous),
        dry_run=_parse_bool(args.dry_run),
    )
    print("HISTORICAL OHLCV IMPORTER")
    print(f"Manifest: {result.manifest_txt_path}")
    print(f"Manifest CSV: {result.manifest_csv_path}")
    print(f"dry_run: {str(result.dry_run).lower()}")
    print(f"files_processed: {len(result.file_results)}")
    print(f"success: {str(result.success).lower()}")
    for file_result in result.file_results:
        print(f"{file_result.input_file}: {file_result.status} rows={file_result.rows_valid} output={file_result.output_file or 'NONE'}")
    print("Live Trading: DISABLED | Broker Orders: DISABLED | Production WhatsApp: BLOCKED | execution_allowed=false")
    return 0 if result.success else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
