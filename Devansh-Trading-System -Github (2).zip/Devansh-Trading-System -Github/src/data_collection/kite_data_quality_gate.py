from __future__ import annotations

from dataclasses import dataclass


READY_FOR_FORWARD_VALIDATION = "READY_FOR_FORWARD_VALIDATION"
USABLE_QUOTE_ONLY = "USABLE_QUOTE_ONLY"
PARTIAL_DATA_KEEP_RECORDING = "PARTIAL_DATA_KEEP_RECORDING"
MARKET_CLOSED_OR_NO_LIVE_DATA = "MARKET_CLOSED_OR_NO_LIVE_DATA"
TOKEN_OR_CREDENTIAL_PROBLEM = "TOKEN_OR_CREDENTIAL_PROBLEM"
SYMBOL_RESOLUTION_PROBLEM = "SYMBOL_RESOLUTION_PROBLEM"
FEATURE_GENERATION_PROBLEM = "FEATURE_GENERATION_PROBLEM"
INVESTIGATE_BEFORE_NEXT_RUN = "INVESTIGATE_BEFORE_NEXT_RUN"


@dataclass(frozen=True)
class KiteDataQualityInput:
    dry_run: bool
    credential_status: str
    symbol_resolution_status: str
    quote_check_status: str
    depth_check_status: str
    market_data_status: str
    tick_rows_recorded: int
    depth_rows_recorded: int
    feature_rows_generated: int
    feature_output_csv_data_rows: int
    feature_mode: str
    synthetic_rows_ignored: int
    stale_rows_removed: int
    forward_validation_decision: str
    synthetic_rows_used: int = 0
    contract_consistency_status: str = "NOT_CHECKED"
    feature_output_real_contract_count: int = 0
    report_csv_contract_match: bool = True


@dataclass(frozen=True)
class KiteDataQualityResult:
    status: str
    reason: str
    next_action: str
    usable_for_forward_validation: bool
    usable_for_orderflow_features: bool
    needs_investigation: bool


def evaluate_kite_data_quality(data: KiteDataQualityInput) -> KiteDataQualityResult:
    """Classify one Kite pipeline run without changing trading or approval state."""

    credential_status = _upper(data.credential_status)
    resolution_status = _upper(data.symbol_resolution_status)
    quote_status = _upper(data.quote_check_status)
    depth_status = _upper(data.depth_check_status)
    market_status = _upper(data.market_data_status)
    feature_mode = _upper(data.feature_mode)
    forward_decision = _upper(data.forward_validation_decision) or "NOT_AVAILABLE"
    contract_status = _upper(data.contract_consistency_status)

    if not data.dry_run and credential_status != "PRESENT":
        return _result(
            TOKEN_OR_CREDENTIAL_PROBLEM,
            "Real read-only mode was requested, but the required Kite credential status is not PRESENT.",
            "Check or refresh the Kite access token locally before the next real read-only run.",
            needs_investigation=True,
        )

    if resolution_status in {"NOT_FOUND", "PARTIAL", "FAIL", "FAILED", "ERROR"}:
        return _result(
            SYMBOL_RESOLUTION_PROBLEM,
            f"Kite symbol resolution status is {resolution_status or 'UNKNOWN'}; recording cannot be trusted for the requested internal symbol.",
            "Refresh the MCX instrument cache and verify the internal-to-Kite symbol mapping.",
            needs_investigation=True,
        )

    if contract_status == "CONTRACT_MISMATCH_INVESTIGATE":
        return _result(
            INVESTIGATE_BEFORE_NEXT_RUN,
            "Contract consistency guard found multiple competing real contracts for the same internal symbol/date.",
            "Verify the selected contract, remove stale competing contract rows, and rebuild features before the next run.",
            needs_investigation=True,
        )

    if data.feature_output_real_contract_count > 1:
        return _result(
            INVESTIGATE_BEFORE_NEXT_RUN,
            "Feature output contains rows from multiple real contracts.",
            "Rebuild features with mixed contracts disabled and confirm one selected contract in the CSV.",
            needs_investigation=True,
        )

    if not data.report_csv_contract_match:
        return _result(
            INVESTIGATE_BEFORE_NEXT_RUN,
            "The selected contract in the report does not match the contract identity in the feature CSV.",
            "Rebuild the feature file and verify report/CSV contract identity consistency.",
            needs_investigation=True,
        )

    if data.feature_rows_generated != data.feature_output_csv_data_rows:
        return _result(
            INVESTIGATE_BEFORE_NEXT_RUN,
            "Feature report count does not match the output CSV data-row count.",
            "Rebuild the feature file and inspect the deterministic overwrite/report consistency checks.",
            needs_investigation=True,
        )

    if not data.dry_run and data.synthetic_rows_used > 0:
        return _result(
            INVESTIGATE_BEFORE_NEXT_RUN,
            f"Real mode used {data.synthetic_rows_used} synthetic/dry-run row(s), which can contaminate research output.",
            "Remove synthetic rows, rebuild features in real-only mode, and verify the output before research use.",
            needs_investigation=True,
        )

    if data.tick_rows_recorded <= 0:
        reason = "No live tick rows were recorded."
        if market_status:
            reason += f" Market data status is {market_status}."
        return _result(
            MARKET_CLOSED_OR_NO_LIVE_DATA,
            reason,
            "Market likely closed; no action needed unless this occurred during expected market hours.",
        )

    if data.depth_rows_recorded <= 0:
        if quote_status in {"OK", "DRY_RUN_OK"} and feature_mode in {"QUOTE_LITE", "NO_FEATURES", "NOT_CHECKED"}:
            return _result(
                USABLE_QUOTE_ONLY,
                f"Tick/quote data was recorded, but depth was unavailable ({depth_status or 'MISSING'}).",
                "Continue recording during market hours; quote-only data is usable for limited research but not full depth orderflow.",
                usable_for_forward_validation=True,
            )
        return _result(
            PARTIAL_DATA_KEEP_RECORDING,
            "Some tick data was recorded, but quote/depth checks indicate incomplete market data.",
            "Continue recording during market hours and recheck quote/depth availability.",
        )

    if data.feature_rows_generated <= 0:
        return _result(
            FEATURE_GENERATION_PROBLEM,
            "Tick and depth rows exist, but no feature rows were generated.",
            "Run the feature builder again and inspect filtering, required fields, and the zero-feature reason.",
            usable_for_orderflow_features=False,
            needs_investigation=True,
        )

    if feature_mode == "QUOTE_LITE":
        return _result(
            USABLE_QUOTE_ONLY,
            "Feature rows were generated in QUOTE_LITE mode without complete depth-derived orderflow.",
            "Keep recording depth during market hours; quote-lite data can support limited forward-validation research.",
            usable_for_forward_validation=True,
        )

    if feature_mode in {"DEPTH_ORDERFLOW_LITE", "MIXED"}:
        return _result(
            READY_FOR_FORWARD_VALIDATION,
            (
                f"Ticks, depth, and {data.feature_rows_generated} feature row(s) are available; "
                f"forward-validation decision remains {forward_decision} and is not changed automatically."
            ),
            "Data usable for forward-validation research. Continue recording to increase the professional sample size.",
            usable_for_forward_validation=True,
            usable_for_orderflow_features=True,
        )

    return _result(
        INVESTIGATE_BEFORE_NEXT_RUN,
        f"Feature rows exist, but feature mode {feature_mode or 'UNKNOWN'} is not a recognized research-ready mode.",
        "Inspect the feature output mode and pipeline report before the next run.",
        needs_investigation=True,
    )


def _result(
    status: str,
    reason: str,
    next_action: str,
    *,
    usable_for_forward_validation: bool = False,
    usable_for_orderflow_features: bool = False,
    needs_investigation: bool = False,
) -> KiteDataQualityResult:
    return KiteDataQualityResult(
        status=status,
        reason=reason,
        next_action=next_action,
        usable_for_forward_validation=usable_for_forward_validation,
        usable_for_orderflow_features=usable_for_orderflow_features,
        needs_investigation=needs_investigation,
    )


def _upper(value: str) -> str:
    return str(value or "").strip().upper()
