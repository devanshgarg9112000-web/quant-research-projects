﻿from __future__ import annotations

import argparse
import csv
import os
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs
from src.data_collection.kite_credentials import (
    format_kite_credential_status,
    load_kite_credentials,
)
from src.data_collection.kite_data_quality_gate import (
    KiteDataQualityInput,
    KiteDataQualityResult,
    evaluate_kite_data_quality,
)
from src.data_collection.kite_instrument_resolver import (
    KiteInstrumentMapping,
    resolve_kite_instruments,
)
from src.data_collection.kite_live_recorder import record_kite_live_data
from src.data_collection.kite_orderflow_features import build_kite_orderflow_lite_features
from src.data_collection.market_data_schema import count_csv_data_rows, kite_depth_path, kite_tick_path
from src.data_collection.kite_readonly_check import run_kite_readonly_check
from src.research.forward_validation import summarize_forward_validation, update_pending_outcomes
from src.research.kite_vwap_forward_bridge import run_kite_vwap_forward_bridge


REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"
RUN_LOG_PATH = Path("reports") / "kite_daily_pipeline" / "kite_daily_pipeline_runs.csv"
RUN_LOG_COLUMNS = [
    "timestamp",
    "symbols",
    "dry_run",
    "credential_status",
    "resolution_status",
    "quote_status",
    "depth_status",
    "recorder_tick_rows",
    "recorder_depth_rows",
    "memory_safe_streaming",
    "chunked_recording_enabled",
    "chunk_seconds",
    "flush_rows",
    "chunks_attempted",
    "chunks_completed",
    "recorder_completed_normally",
    "recorder_failed_safely",
    "partial_data_usable",
    "feature_rows_generated",
    "feature_output_csv_data_rows",
    "feature_mode",
    "market_data_status",
    "synthetic_rows_ignored",
    "stale_rows_removed",
    "contract_consistency_status",
    "selected_contract",
    "ignored_contracts",
    "synthetic_contracts_ignored",
    "contract_action_required",
    "contract_metadata_complete",
    "missing_contract_fields",
    "expiry_missing_warning",
    "expiry_rows_enriched",
    "data_quality_status",
    "usable_for_forward_validation",
    "usable_for_orderflow_features",
    "needs_investigation",
    "vwap_bridge_status",
    "vwap_candles_built",
    "vwap_candidates_found",
    "vwap_ledger_rows_added",
    "vwap_duplicate_signals_skipped",
    "forward_validation_decision",
    "production_whatsapp_status",
    "errors",
    "warnings",
    "execution_allowed",
]


@dataclass
class KiteDailyPipelineResult:
    run_timestamp: datetime
    symbols: list[str]
    dry_run: bool
    credential_status: str = "NOT_CHECKED"
    step_status: dict[str, str] = field(default_factory=dict)
    symbol_resolutions: list[KiteInstrumentMapping] = field(default_factory=list)
    resolution_source: str = "NOT_LOADED"
    quote_status: str = "NOT_CHECKED"
    depth_status: str = "NOT_CHECKED"
    recorder_tick_rows: int = 0
    recorder_depth_rows: int = 0
    recorder_market_data_status: str = "NOT_CHECKED"
    memory_safe_streaming: bool = True
    chunked_recording_enabled: bool = False
    chunk_seconds: int = 0
    flush_rows: int = 100
    resume: bool = True
    chunks_attempted: int = 0
    chunks_completed: int = 0
    recorder_completed_normally: bool = False
    recorder_failed_safely: bool = False
    partial_data_usable: bool = False
    feature_rows_generated: int = 0
    feature_output_csv_data_rows: int = 0
    feature_mode: str = "NO_FEATURES"
    feature_market_data_status: str = "NO_INPUT"
    feature_reason: str = ""
    feature_synthetic_rows_ignored: int = 0
    feature_stale_rows_removed: int = 0
    feature_synthetic_rows_used: int = 0
    contract_consistency_status: str = "NOT_CHECKED"
    selected_contract: str = ""
    ignored_contracts: list[str] = field(default_factory=list)
    synthetic_contracts_ignored: list[str] = field(default_factory=list)
    contract_action_required: bool = False
    feature_output_real_contract_count: int = 0
    report_csv_contract_match: bool = True
    contract_metadata_complete: bool = False
    missing_contract_fields: list[str] = field(default_factory=list)
    expiry_missing_warning: bool = False
    expiry_rows_enriched: int = 0
    vwap_bridge_status: str = "NOT_RUN"
    vwap_bridge_reason: str = ""
    vwap_candles_built: int = 0
    vwap_candidates_found: int = 0
    vwap_ledger_rows_added: int = 0
    vwap_duplicate_signals_skipped: int = 0
    pending_outcomes_checked: int = 0
    pending_outcomes_resolved: int = 0
    pending_outcomes_still_pending: int = 0
    pending_outcomes_no_tick_data: int = 0
    pending_outcomes_no_later_tick: int = 0
    forward_validation_decision: str = "NOT_AVAILABLE"
    forward_validation_reason: str = ""
    production_whatsapp_status: str = "BLOCKED"
    data_quality: KiteDataQualityResult | None = None
    files: list[Path] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    report_path: Path | None = None
    run_log_path: Path | None = None

    @property
    def success(self) -> bool:
        return not self.errors

    @property
    def market_data_status(self) -> str:
        if self.recorder_market_data_status in {"NO_LIVE_TICKS", "PARTIAL_QUOTE"}:
            return self.recorder_market_data_status
        if self.feature_market_data_status and self.feature_market_data_status not in {"NO_INPUT", "NOT_CHECKED"}:
            return self.feature_market_data_status
        return self.recorder_market_data_status


def run_kite_daily_pipeline(
    base_dir: Path | str = ".",
    *,
    symbols_text: str,
    duration_seconds: int = 60,
    record_depth: bool = True,
    dry_run: bool = True,
    poll_interval_seconds: float = 1.0,
    chunk_seconds: int | None = None,
    flush_rows: int = 100,
    resume: bool = True,
    now_fn: Callable[[], datetime] | None = None,
    configs: dict[str, Any] | None = None,
    resolver_func: Callable[..., Any] = resolve_kite_instruments,
    readonly_check_func: Callable[..., Any] = run_kite_readonly_check,
    recorder_func: Callable[..., Any] = record_kite_live_data,
    feature_builder_func: Callable[..., Any] = build_kite_orderflow_lite_features,
    vwap_bridge_func: Callable[..., Any] = run_kite_vwap_forward_bridge,
    pending_outcome_updater_func: Callable[..., Any] = update_pending_outcomes,
    forward_summary_func: Callable[..., Any] = summarize_forward_validation,
) -> KiteDailyPipelineResult:
    """Run the safe Kite read-only daily collection pipeline sequentially."""

    base = Path(base_dir)
    now = now_fn or (lambda: datetime.now().astimezone())
    run_timestamp = now()
    symbols = _parse_symbols(symbols_text)
    effective_chunk_seconds = max(0, int(chunk_seconds or 0))
    result = KiteDailyPipelineResult(
        run_timestamp=run_timestamp,
        symbols=symbols,
        dry_run=dry_run,
        chunked_recording_enabled=effective_chunk_seconds > 0 and int(duration_seconds) > effective_chunk_seconds,
        chunk_seconds=effective_chunk_seconds,
        flush_rows=max(1, int(flush_rows)),
        resume=resume,
    )

    print("KITE DAILY PIPELINE RUNNER")
    print("Mode: PAPER | Kite: READ ONLY DATA | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Symbols: {', '.join(symbols) if symbols else 'NONE'}")
    print(f"Dry Run: {str(dry_run).lower()}")
    print(f"Duration Seconds: {duration_seconds}")
    print(f"Record Depth: {str(record_depth).lower()}")
    print("memory_safe_streaming=true")
    print(f"Chunked Recording Enabled: {str(result.chunked_recording_enabled).lower()}")
    print(f"Chunk Seconds: {result.chunk_seconds}")
    print(f"Flush Rows: {result.flush_rows}")
    print(f"Resume: {str(result.resume).lower()}")

    state = load_kite_credentials(base)
    result.credential_status = state.credential_status
    result.step_status["credential_check"] = "SUCCESS"
    print("\nSTEP 1 - KITE CREDENTIAL STATUS CHECK")
    print(f"Credential Status: {result.credential_status}")
    for line in format_kite_credential_status(state):
        print(line)

    configs = configs or _load_configs_safely(base)
    _check_safety_flags(configs, result)
    if result.errors:
        result.step_status["safety_check"] = "FAIL"
        _finalize_pipeline(base, result)
        return result
    result.step_status["safety_check"] = "SUCCESS"

    if not symbols:
        result.errors.append("No symbols supplied.")
        result.step_status["symbol_resolution"] = "SKIPPED"
        _finalize_pipeline(base, result)
        return result

    if not dry_run and not state.all_present:
        result.errors.append(
            "Kite daily pipeline stopped safely before recording: missing "
            + ", ".join(state.missing_keys())
            + ". Run --dry-run true until credentials are configured locally."
        )
        result.step_status["symbol_resolution"] = "SKIPPED"
        result.step_status["readonly_precheck"] = "SKIPPED"
        result.step_status["recorder"] = "SKIPPED"
        result.step_status["feature_builder"] = "SKIPPED"
        result.step_status["forward_validation"] = "SKIPPED"
        _finalize_pipeline(base, result)
        return result

    print("\nSTEP 2 - SYMBOL RESOLUTION")
    try:
        resolution = resolver_func(
            base,
            symbols_text=symbols_text,
            exchange="MCX",
            dry_run=dry_run,
            as_of=run_timestamp.date(),
        )
        result.symbol_resolutions = list(getattr(resolution, "mappings", []) or [])
        result.resolution_source = str(getattr(resolution, "source", "UNKNOWN"))
        resolution_errors = list(getattr(resolution, "errors", []) or [])
        if resolution_errors:
            result.warnings.extend(resolution_errors)
        for mapping in result.symbol_resolutions:
            print(f"Resolved Symbol: {mapping.internal_symbol} -> {mapping.quote_symbol if mapping.resolved else 'NOT_FOUND'} ({mapping.status})")
        if not result.symbol_resolutions:
            result.warnings.append("No symbol resolution mappings were returned.")
        unresolved = [mapping.internal_symbol for mapping in result.symbol_resolutions if not mapping.resolved]
        if unresolved and not dry_run:
            result.errors.append("Symbol resolution failed for: " + ", ".join(unresolved) + ".")
            result.step_status["symbol_resolution"] = "FAIL"
            _finalize_pipeline(base, result)
            return result
        result.step_status["symbol_resolution"] = "SUCCESS"
    except Exception as exc:  # pragma: no cover - defensive guard for CLI runs
        result.errors.append(f"Symbol resolution failed safely: {type(exc).__name__}.")
        result.step_status["symbol_resolution"] = "FAIL"
        _finalize_pipeline(base, result)
        return result

    print("\nSTEP 3 - READ-ONLY QUOTE/DEPTH PRECHECK")
    try:
        precheck = readonly_check_func(
            base,
            symbols_text=symbols_text,
            dry_run="true" if dry_run else "false",
            configs=configs,
            exchange="MCX",
            as_of=run_timestamp.date(),
        )
        result.quote_status = str(getattr(precheck, "quote_status", "NOT_CHECKED"))
        result.depth_status = str(getattr(precheck, "depth_status", "NOT_CHECKED"))
        if getattr(precheck, "report_path", None):
            result.files.append(Path(precheck.report_path))
        precheck_errors = list(getattr(precheck, "errors", []) or [])
        if precheck_errors:
            result.warnings.extend(precheck_errors)
        result.step_status["readonly_precheck"] = "SUCCESS"
    except Exception as exc:  # pragma: no cover - defensive guard for CLI runs
        result.warnings.append(f"Read-only precheck failed safely: {type(exc).__name__}.")
        result.step_status["readonly_precheck"] = "WARNING"

    print("\nSTEP 4 - KITE LIVE RECORDER")
    chunk_durations = _recording_chunk_durations(
        duration_seconds=int(duration_seconds),
        chunk_seconds=result.chunk_seconds,
        dry_run=dry_run,
    )
    returned_tick_rows = 0
    returned_depth_rows = 0
    for chunk_index, chunk_duration in enumerate(chunk_durations, start=1):
        result.chunks_attempted += 1
        print(f"Recorder chunk {chunk_index}/{len(chunk_durations)}: {chunk_duration}s")
        try:
            recording = recorder_func(
                base,
                symbols_text=symbols_text,
                duration_seconds=chunk_duration,
                record_depth=record_depth,
                poll_interval_seconds=poll_interval_seconds,
                dry_run=dry_run,
                configs=configs,
                now_fn=now,
                flush_rows=result.flush_rows,
                resume=result.resume,
            )
            returned_tick_rows += int(getattr(recording, "tick_rows_recorded", 0) or 0)
            returned_depth_rows += int(getattr(recording, "depth_rows_recorded", 0) or 0)
            result.recorder_market_data_status = str(getattr(recording, "market_data_status", "NOT_CHECKED"))
            result.memory_safe_streaming = bool(getattr(recording, "memory_safe_streaming", True))
            chunk_completed_normally = bool(getattr(recording, "recorder_completed_normally", True))
            chunk_failed_safely = bool(getattr(recording, "recorder_failed_safely", False))
            chunk_tick_rows = int(getattr(recording, "tick_rows_recorded", 0) or 0)
            chunk_depth_rows = int(getattr(recording, "depth_rows_recorded", 0) or 0)
            result.recorder_completed_normally = result.recorder_completed_normally or chunk_completed_normally
            result.recorder_failed_safely = result.recorder_failed_safely or chunk_failed_safely
            result.files.extend(Path(path) for path in getattr(recording, "files", []) or [])
            if getattr(recording, "report_path", None):
                result.files.append(Path(recording.report_path))
            recorder_errors = list(getattr(recording, "errors", []) or [])
            if recorder_errors:
                result.warnings.extend(recorder_errors)
            if chunk_completed_normally or chunk_tick_rows > 0 or chunk_depth_rows > 0:
                result.chunks_completed += 1
            elif recorder_errors:
                result.recorder_failed_safely = True
            if chunk_failed_safely or result.recorder_failed_safely:
                break
        except (MemoryError, KeyboardInterrupt) as exc:
            result.recorder_failed_safely = True
            result.warnings.append(f"Kite live recorder failed safely: {type(exc).__name__}.")
            break
        except Exception as exc:  # pragma: no cover - defensive guard for CLI runs
            result.recorder_failed_safely = True
            result.warnings.append(f"Kite live recorder failed safely: {type(exc).__name__}.")
            break

    file_tick_rows, file_depth_rows, recorded_files = _count_recorded_rows(
        base,
        run_timestamp.date(),
        symbols,
    )
    result.files.extend(recorded_files)
    result.recorder_tick_rows = file_tick_rows if file_tick_rows > 0 else returned_tick_rows
    result.recorder_depth_rows = file_depth_rows if file_depth_rows > 0 else returned_depth_rows
    result.partial_data_usable = result.recorder_tick_rows > 0 or result.recorder_depth_rows > 0
    if result.recorder_tick_rows > 0 and result.recorder_depth_rows > 0:
        result.recorder_market_data_status = "RECORDED"
    elif result.recorder_tick_rows > 0:
        result.recorder_market_data_status = "PARTIAL_QUOTE"
    elif result.recorder_market_data_status == "NOT_CHECKED":
        result.recorder_market_data_status = "NO_LIVE_TICKS"
    if result.recorder_failed_safely:
        result.step_status["recorder"] = "FAILED_SAFE_PARTIAL_USABLE" if result.partial_data_usable else "FAIL"
    else:
        result.step_status["recorder"] = "SUCCESS"
    if result.recorder_market_data_status in {"NO_LIVE_TICKS", "PARTIAL_QUOTE"}:
        result.warnings.append(
            f"MARKET_CLOSED_POSSIBLE: recorder market data status was {result.recorder_market_data_status}."
        )

    print("\nSTEP 5 - ORDERFLOW LITE FEATURE BUILDER")
    try:
        feature_day = run_timestamp.date()
        features = feature_builder_func(
            base,
            symbols_text=symbols_text,
            day=feature_day,
            include_synthetic=False,
            allow_mixed_contracts=False,
        )
        result.feature_rows_generated = int(getattr(features, "rows_generated", 0) or 0)
        result.feature_output_csv_data_rows = int(getattr(features, "output_csv_data_rows", result.feature_rows_generated) or 0)
        result.feature_mode = str(getattr(features, "feature_mode", "NO_FEATURES"))
        result.feature_market_data_status = str(getattr(features, "market_data_status", "NO_INPUT"))
        result.feature_reason = str(getattr(features, "zero_feature_reason", "") or "")
        result.feature_synthetic_rows_ignored = int(getattr(features, "synthetic_rows_ignored", 0) or 0)
        result.feature_stale_rows_removed = int(getattr(features, "stale_output_rows_removed", 0) or 0)
        result.feature_synthetic_rows_used = 0
        result.contract_consistency_status = str(getattr(features, "contract_consistency_status", "NOT_CHECKED"))
        result.selected_contract = str(getattr(features, "selected_contract", "") or "")
        result.ignored_contracts = list(getattr(features, "ignored_contracts", []) or [])
        result.synthetic_contracts_ignored = list(getattr(features, "synthetic_contracts_ignored", []) or [])
        result.contract_action_required = bool(getattr(features, "contract_action_required", False))
        result.feature_output_real_contract_count = int(getattr(features, "output_real_contract_count", 0) or 0)
        result.report_csv_contract_match = bool(getattr(features, "report_csv_contract_match", True))
        result.contract_metadata_complete = bool(getattr(features, "contract_metadata_complete", False))
        result.missing_contract_fields = list(getattr(features, "missing_contract_fields", []) or [])
        result.expiry_missing_warning = bool(getattr(features, "expiry_missing_warning", False))
        result.expiry_rows_enriched = int(getattr(features, "expiry_rows_enriched", 0) or 0)
        result.files.extend(Path(path) for path in getattr(features, "files", []) or [])
        if getattr(features, "report_path", None):
            result.files.append(Path(features.report_path))
        feature_errors = list(getattr(features, "errors", []) or [])
        feature_warnings = list(getattr(features, "warnings", []) or [])
        result.warnings.extend(feature_warnings)
        if feature_errors:
            result.errors.extend(feature_errors)
            result.step_status["feature_builder"] = "FAIL"
        else:
            result.step_status["feature_builder"] = "SUCCESS"
        if result.feature_rows_generated != result.feature_output_csv_data_rows:
            result.errors.append("Feature count mismatch: generated rows and output CSV data rows differ.")
            result.step_status["feature_builder"] = "FAIL"
    except Exception as exc:  # pragma: no cover - defensive guard for CLI runs
        result.errors.append(f"OrderFlow Lite feature builder failed safely: {type(exc).__name__}.")
        result.step_status["feature_builder"] = "FAIL"

    print("\nSTEP 6 - GOLD-I VWAP FORWARD BRIDGE")
    try:
        if "GOLD-I" in {symbol.upper() for symbol in symbols}:
            bridge = vwap_bridge_func(
                base,
                symbol="GOLD-I",
                day=run_timestamp.date(),
                configs=configs,
            )
            result.vwap_bridge_status = str(getattr(bridge, "status", "NOT_AVAILABLE"))
            result.vwap_bridge_reason = str(getattr(bridge, "reason", "") or "")
            result.vwap_candles_built = int(getattr(bridge, "candles_built", 0) or 0)
            result.vwap_candidates_found = int(getattr(bridge, "candidates_found", 0) or 0)
            result.vwap_ledger_rows_added = int(getattr(bridge, "ledger_rows_added", 0) or 0)
            result.vwap_duplicate_signals_skipped = int(
                getattr(bridge, "duplicate_signals_skipped", 0) or 0
            )
            result.warnings.extend(list(getattr(bridge, "warnings", []) or []))
            result.step_status["vwap_forward_bridge"] = "SUCCESS"
        else:
            result.vwap_bridge_status = "SKIPPED"
            result.vwap_bridge_reason = "GOLD-I was not included in this pipeline run."
            result.step_status["vwap_forward_bridge"] = "SKIPPED"
    except Exception as exc:
        result.vwap_bridge_status = "FAILED_SAFE"
        result.vwap_bridge_reason = f"VWAP forward bridge failed safely: {type(exc).__name__}."
        result.warnings.append(result.vwap_bridge_reason)
        result.step_status["vwap_forward_bridge"] = "WARNING"

    print("\nSTEP 7 - FORWARD VALIDATION SUMMARY")
    try:
        if "GOLD-I" in {symbol.upper() for symbol in symbols}:
            forward = pending_outcome_updater_func(base)
            pending_update = getattr(forward, "pending_update", None)
            result.pending_outcomes_checked = int(getattr(pending_update, "checked", 0) or 0)
            result.pending_outcomes_resolved = int(getattr(pending_update, "resolved", 0) or 0)
            result.pending_outcomes_still_pending = int(getattr(pending_update, "still_pending", 0) or 0)
            result.pending_outcomes_no_tick_data = int(getattr(pending_update, "no_tick_data", 0) or 0)
            result.pending_outcomes_no_later_tick = int(getattr(pending_update, "no_later_tick", 0) or 0)
            if pending_update is None:
                forward = forward_summary_func(base)
            decision = getattr(forward, "decision", None)
            result.forward_validation_decision = str(getattr(decision, "status", "NOT_AVAILABLE"))
            result.forward_validation_reason = str(getattr(decision, "reason", "") or "")
            if getattr(forward, "ledger_path", None):
                result.files.append(Path(forward.ledger_path))
            if getattr(forward, "summary_path", None):
                result.files.append(Path(forward.summary_path))
            result.step_status["forward_validation"] = "SUCCESS"
        else:
            result.forward_validation_decision = "SKIPPED"
            result.forward_validation_reason = "GOLD-I was not included in this pipeline run."
            result.step_status["forward_validation"] = "SKIPPED"
    except Exception as exc:
        result.forward_validation_decision = "NOT_AVAILABLE"
        result.forward_validation_reason = f"Forward validation summary failed safely: {type(exc).__name__}."
        result.warnings.append(result.forward_validation_reason)
        result.step_status["forward_validation"] = "WARNING"

    print("\nSTEP 8 - FINAL DAILY REPORT")
    _finalize_pipeline(base, result)
    return result


def _finalize_pipeline(base: Path, result: KiteDailyPipelineResult) -> None:
    resolution_status = _resolution_status(result.symbol_resolutions)
    if result.step_status.get("symbol_resolution") == "FAIL":
        resolution_status = "FAIL"
    result.data_quality = evaluate_kite_data_quality(
        KiteDataQualityInput(
            dry_run=result.dry_run,
            credential_status=result.credential_status,
            symbol_resolution_status=resolution_status,
            quote_check_status=result.quote_status,
            depth_check_status=result.depth_status,
            market_data_status=result.market_data_status,
            tick_rows_recorded=result.recorder_tick_rows,
            depth_rows_recorded=result.recorder_depth_rows,
            feature_rows_generated=result.feature_rows_generated,
            feature_output_csv_data_rows=result.feature_output_csv_data_rows,
            feature_mode=result.feature_mode,
            synthetic_rows_ignored=result.feature_synthetic_rows_ignored,
            stale_rows_removed=result.feature_stale_rows_removed,
            forward_validation_decision=result.forward_validation_decision,
            synthetic_rows_used=result.feature_synthetic_rows_used,
            contract_consistency_status=result.contract_consistency_status,
            feature_output_real_contract_count=result.feature_output_real_contract_count,
            report_csv_contract_match=result.report_csv_contract_match,
        )
    )
    result.step_status["data_quality_gate"] = result.data_quality.status
    _write_daily_report(base, result)
    _append_run_log(base, result)
    _print_final_summary(result)


def _write_daily_report(base: Path, result: KiteDailyPipelineResult) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    unique_files = _unique_paths([*result.files, path, base / RUN_LOG_PATH])
    lines = [
        "KITE DAILY PIPELINE REPORT",
        "Mode: PAPER",
        "Kite Mode: READ_ONLY_DATA",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
        f"Run timestamp: {result.run_timestamp.isoformat()}",
        f"Symbols: {', '.join(result.symbols) if result.symbols else 'NONE'}",
        f"dry_run: {str(result.dry_run).lower()}",
        f"credential_status: {result.credential_status}",
        f"production_whatsapp_status: {result.production_whatsapp_status}",
        "",
        "STEP STATUS",
    ]
    lines.extend(f"- {step}: {status}" for step, status in result.step_status.items())
    lines.extend(
        [
            "",
            "SYMBOL RESOLUTION",
            f"Resolution source: {result.resolution_source}",
        ]
    )
    if result.symbol_resolutions:
        lines.extend(mapping.as_report_line() for mapping in result.symbol_resolutions)
    else:
        lines.append("No mappings recorded.")
    lines.extend(
        [
            "",
            "READ-ONLY PRECHECK",
            f"Quote check status: {result.quote_status}",
            f"Depth check status: {result.depth_status}",
            "",
            "RECORDER",
            f"Recorder tick rows: {result.recorder_tick_rows}",
            f"Recorder depth rows: {result.recorder_depth_rows}",
            f"Recorder market data status: {result.recorder_market_data_status}",
            "memory_safe_streaming: true",
            f"chunked_recording_enabled: {_bool_text(result.chunked_recording_enabled)}",
            f"chunk_seconds: {result.chunk_seconds}",
            f"flush_rows: {result.flush_rows}",
            f"resume: {_bool_text(result.resume)}",
            f"chunks_attempted: {result.chunks_attempted}",
            f"chunks_completed: {result.chunks_completed}",
            f"rows_written_tick: {result.recorder_tick_rows}",
            f"rows_written_depth: {result.recorder_depth_rows}",
            f"recorder_completed_normally: {_bool_text(result.recorder_completed_normally)}",
            f"recorder_failed_safely: {_bool_text(result.recorder_failed_safely)}",
            f"partial_data_usable: {_bool_text(result.partial_data_usable)}",
            "",
            "ORDERFLOW LITE FEATURES",
            f"Feature rows generated: {result.feature_rows_generated}",
            f"Feature output CSV data rows: {result.feature_output_csv_data_rows}",
            f"Feature mode: {result.feature_mode}",
            f"Feature market data status: {result.feature_market_data_status}",
            f"Synthetic rows ignored: {result.feature_synthetic_rows_ignored}",
            f"Stale rows removed: {result.feature_stale_rows_removed}",
            f"Feature reason: {result.feature_reason or 'N/A'}",
            "",
            "GOLD-I VWAP FORWARD BRIDGE",
            f"VWAP bridge status: {result.vwap_bridge_status}",
            f"candles_built: {result.vwap_candles_built}",
            f"candidates_found: {result.vwap_candidates_found}",
            f"pending_post_lock_rows_added: {result.vwap_ledger_rows_added}",
            f"duplicate_signals_skipped: {result.vwap_duplicate_signals_skipped}",
            f"reason: {result.vwap_bridge_reason or 'N/A'}",
            "execution_allowed=false",
            "Production WhatsApp alerts: BLOCKED",
            "",
            "FORWARD VALIDATION",
            "Strategy: GOLD-I VWAP Rejection Short",
            f"Forward-validation decision: {result.forward_validation_decision}",
            f"Forward-validation reason: {result.forward_validation_reason or 'N/A'}",
            f"pending_outcomes_checked: {result.pending_outcomes_checked}",
            f"pending_outcomes_resolved: {result.pending_outcomes_resolved}",
            f"pending_outcomes_still_pending: {result.pending_outcomes_still_pending}",
            f"pending_outcomes_no_tick_data: {result.pending_outcomes_no_tick_data}",
            f"pending_outcomes_no_later_tick: {result.pending_outcomes_no_later_tick}",
            "Automatic approval: DISABLED",
            "",
            "CONTRACT CONSISTENCY",
            f"status: {result.contract_consistency_status}",
            f"selected_contract: {result.selected_contract or 'NONE'}",
            "ignored_contracts: " + ("; ".join(result.ignored_contracts) if result.ignored_contracts else "NONE"),
            "synthetic_contracts_ignored: " + ("; ".join(result.synthetic_contracts_ignored) if result.synthetic_contracts_ignored else "NONE"),
            f"action_required: {_bool_text(result.contract_action_required)}",
            f"feature_output_real_contract_count: {result.feature_output_real_contract_count}",
            f"report_csv_contract_match: {_bool_text(result.report_csv_contract_match)}",
            f"metadata_complete: {_bool_text(result.contract_metadata_complete)}",
            "missing_contract_fields: " + ("; ".join(result.missing_contract_fields) if result.missing_contract_fields else "NONE"),
            f"expiry_missing_warning: {'yes' if result.expiry_missing_warning else 'no'}",
            f"expiry_rows_enriched: {result.expiry_rows_enriched}",
            "",
            "DATA QUALITY GATE",
            f"status: {result.data_quality.status if result.data_quality else 'NOT_EVALUATED'}",
            f"reason: {result.data_quality.reason if result.data_quality else 'Quality gate was not evaluated.'}",
            f"next_action: {result.data_quality.next_action if result.data_quality else 'Investigate pipeline finalization.'}",
            f"usable_for_forward_validation: {_bool_text(result.data_quality.usable_for_forward_validation) if result.data_quality else 'false'}",
            f"usable_for_orderflow_features: {_bool_text(result.data_quality.usable_for_orderflow_features) if result.data_quality else 'false'}",
            f"needs_investigation: {_bool_text(result.data_quality.needs_investigation) if result.data_quality else 'true'}",
            "",
            "FILES GENERATED / TOUCHED",
        ]
    )
    lines.extend(f"- {path}" for path in unique_files)
    lines.extend(
        [
            "",
            "WARNINGS",
            *(_format_items(result.warnings) if result.warnings else ["NONE"]),
            "",
            "ERRORS",
            *(_format_items(result.errors) if result.errors else ["NONE"]),
            "",
            "SAFETY CONFIRMATION",
            "ENABLE_LIVE_TRADING=false",
            "I_UNDERSTAND_LIVE_TRADING_RISK=false",
            "execution_allowed=false",
            "Production WhatsApp alerts: BLOCKED",
            "PAPER MODE ONLY. Kite read-only data collection only. No broker orders were placed.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _append_run_log(base: Path, result: KiteDailyPipelineResult) -> None:
    path = base / RUN_LOG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    _upgrade_run_log_header(path)
    write_header = not path.exists() or path.stat().st_size == 0
    quality = result.data_quality
    row = {
        "timestamp": result.run_timestamp.isoformat(),
        "symbols": ",".join(result.symbols),
        "dry_run": str(result.dry_run).lower(),
        "credential_status": result.credential_status,
        "resolution_status": _resolution_status(result.symbol_resolutions),
        "quote_status": result.quote_status,
        "depth_status": result.depth_status,
        "recorder_tick_rows": result.recorder_tick_rows,
        "recorder_depth_rows": result.recorder_depth_rows,
        "memory_safe_streaming": "true",
        "chunked_recording_enabled": _bool_text(result.chunked_recording_enabled),
        "chunk_seconds": result.chunk_seconds,
        "flush_rows": result.flush_rows,
        "chunks_attempted": result.chunks_attempted,
        "chunks_completed": result.chunks_completed,
        "recorder_completed_normally": _bool_text(result.recorder_completed_normally),
        "recorder_failed_safely": _bool_text(result.recorder_failed_safely),
        "partial_data_usable": _bool_text(result.partial_data_usable),
        "feature_rows_generated": result.feature_rows_generated,
        "feature_output_csv_data_rows": result.feature_output_csv_data_rows,
        "feature_mode": result.feature_mode,
        "market_data_status": result.market_data_status,
        "synthetic_rows_ignored": result.feature_synthetic_rows_ignored,
        "stale_rows_removed": result.feature_stale_rows_removed,
        "contract_consistency_status": result.contract_consistency_status,
        "selected_contract": result.selected_contract or "NONE",
        "ignored_contracts": ";".join(result.ignored_contracts) if result.ignored_contracts else "NONE",
        "synthetic_contracts_ignored": ";".join(result.synthetic_contracts_ignored) if result.synthetic_contracts_ignored else "NONE",
        "contract_action_required": _bool_text(result.contract_action_required),
        "contract_metadata_complete": _bool_text(result.contract_metadata_complete),
        "missing_contract_fields": ";".join(result.missing_contract_fields) if result.missing_contract_fields else "NONE",
        "expiry_missing_warning": "yes" if result.expiry_missing_warning else "no",
        "expiry_rows_enriched": result.expiry_rows_enriched,
        "data_quality_status": quality.status if quality else "NOT_EVALUATED",
        "usable_for_forward_validation": _bool_text(quality.usable_for_forward_validation) if quality else "false",
        "usable_for_orderflow_features": _bool_text(quality.usable_for_orderflow_features) if quality else "false",
        "needs_investigation": _bool_text(quality.needs_investigation) if quality else "true",
        "vwap_bridge_status": result.vwap_bridge_status,
        "vwap_candles_built": result.vwap_candles_built,
        "vwap_candidates_found": result.vwap_candidates_found,
        "vwap_ledger_rows_added": result.vwap_ledger_rows_added,
        "vwap_duplicate_signals_skipped": result.vwap_duplicate_signals_skipped,
        "forward_validation_decision": result.forward_validation_decision,
        "production_whatsapp_status": result.production_whatsapp_status,
        "errors": ";".join(result.errors) if result.errors else "NONE",
        "warnings": ";".join(result.warnings) if result.warnings else "NONE",
        "execution_allowed": "false",
    }
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=RUN_LOG_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    result.run_log_path = path


def _print_final_summary(result: KiteDailyPipelineResult) -> None:
    print("\nKITE DAILY PIPELINE FINAL SUMMARY")
    print(f"Status: {'SUCCESS' if result.success else 'FAILED_SAFE'}")
    print(f"Credential Status: {result.credential_status}")
    print(f"Recorder tick rows: {result.recorder_tick_rows}")
    print(f"Recorder depth rows: {result.recorder_depth_rows}")
    print("memory_safe_streaming=true")
    print(f"Chunked recording enabled: {_bool_text(result.chunked_recording_enabled)}")
    print(f"Chunks attempted/completed: {result.chunks_attempted}/{result.chunks_completed}")
    print(f"Recorder completed normally: {_bool_text(result.recorder_completed_normally)}")
    print(f"Recorder failed safely: {_bool_text(result.recorder_failed_safely)}")
    print(f"Partial data usable: {_bool_text(result.partial_data_usable)}")
    print(f"Feature rows generated: {result.feature_rows_generated}")
    print(f"Feature output CSV data rows: {result.feature_output_csv_data_rows}")
    print(f"Feature mode: {result.feature_mode}")
    print(f"Market data status: {result.market_data_status}")
    print(f"Contract Consistency Status: {result.contract_consistency_status}")
    print(f"Selected Contract: {result.selected_contract or 'NONE'}")
    print("Ignored Contracts: " + ("; ".join(result.ignored_contracts) if result.ignored_contracts else "NONE"))
    print(f"Contract Metadata Complete: {str(result.contract_metadata_complete).lower()}")
    print(f"Expiry Missing Warning: {'yes' if result.expiry_missing_warning else 'no'}")
    if result.data_quality:
        print(f"Data Quality Status: {result.data_quality.status}")
        print(f"Data Quality Reason: {result.data_quality.reason}")
        print(f"Next Recommended Action: {result.data_quality.next_action}")
    print(f"VWAP bridge status: {result.vwap_bridge_status}")
    print(f"VWAP candles built: {result.vwap_candles_built}")
    print(f"VWAP candidates found: {result.vwap_candidates_found}")
    print(f"VWAP pending rows added: {result.vwap_ledger_rows_added}")
    print(f"VWAP duplicate signals skipped: {result.vwap_duplicate_signals_skipped}")
    print(f"Forward-validation decision: {result.forward_validation_decision}")
    print(f"Report: {result.report_path}")
    print(f"Run log: {result.run_log_path}")
    if result.errors:
        print("Errors: " + "; ".join(result.errors))
    else:
        print("Errors: NONE")
    print("PAPER MODE ONLY. No broker orders were placed.")


def _upgrade_run_log_header(path: Path) -> None:
    if not path.exists() or path.stat().st_size == 0:
        return
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        existing_columns = list(reader.fieldnames or [])
        rows = list(reader)
    if existing_columns == RUN_LOG_COLUMNS:
        return
    normalized = [{column: row.get(column, "") for column in RUN_LOG_COLUMNS} for row in rows]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=RUN_LOG_COLUMNS)
        writer.writeheader()
        writer.writerows(normalized)



def _recording_chunk_durations(*, duration_seconds: int, chunk_seconds: int, dry_run: bool) -> list[int]:
    duration = max(0, int(duration_seconds))
    if duration == 0 or chunk_seconds <= 0 or duration <= chunk_seconds:
        return [duration]
    chunks: list[int] = []
    remaining = duration
    while remaining > 0:
        current = min(chunk_seconds, remaining)
        chunks.append(current)
        remaining -= current
    return chunks


def _count_recorded_rows(base: Path, day: date, symbols: list[str]) -> tuple[int, int, list[Path]]:
    tick_rows = 0
    depth_rows = 0
    files: list[Path] = []
    for symbol in symbols:
        tick_path = kite_tick_path(base, day, symbol)
        depth_path = kite_depth_path(base, day, symbol)
        if tick_path.exists():
            tick_rows += count_csv_data_rows(tick_path)
            files.append(tick_path)
        if depth_path.exists():
            depth_rows += count_csv_data_rows(depth_path)
            files.append(depth_path)
    return tick_rows, depth_rows, files


def _bool_text(value: bool) -> str:
    return "true" if bool(value) else "false"


def _load_configs_safely(base: Path) -> dict[str, Any]:
    config_dir = base / "config"
    required = ["settings.yaml", "risk.yaml", "strategies.yaml", "approved_strategies.yaml", "instruments.yaml", "alerts.yaml"]
    if all((config_dir / name).exists() for name in required):
        return load_configs(base)
    return {
        "settings": {"mode": "PAPER", "enable_live_trading": False},
        "risk": {},
        "strategies": {},
        "approved_strategies": {},
        "instruments": {"GOLD-I": {"exchange": "MCX"}, "SILVER-I": {"exchange": "MCX"}},
        "alerts": {"enable_whatsapp_alerts": False},
        "forward_validation": {
            "production_alerts_allowed": False,
            "send_research_whatsapp_preview": False,
        },
    }


def _check_safety_flags(configs: dict[str, Any], result: KiteDailyPipelineResult) -> None:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    if str(settings.get("mode", "PAPER")).upper() != "PAPER":
        result.errors.append("Safety check failed: config mode must remain PAPER.")
    if bool(settings.get("enable_live_trading", False)):
        result.errors.append("Safety check failed: enable_live_trading must remain false.")
    if bool(forward.get("production_alerts_allowed", False)):
        result.errors.append("Safety check failed: production WhatsApp alerts must remain blocked.")
    if _truthy(os.environ.get("ENABLE_LIVE_TRADING")):
        result.errors.append("Safety check failed: ENABLE_LIVE_TRADING env flag must remain false.")
    if _truthy(os.environ.get("I_UNDERSTAND_LIVE_TRADING_RISK")):
        result.errors.append("Safety check failed: I_UNDERSTAND_LIVE_TRADING_RISK env flag must remain false.")


def _parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _parse_bool(value: str | bool | None) -> bool:
    return value is True or str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _resolution_status(mappings: list[KiteInstrumentMapping]) -> str:
    if not mappings:
        return "NOT_RUN"
    if all(mapping.resolved for mapping in mappings):
        return "RESOLVED"
    if any(mapping.resolved for mapping in mappings):
        return "PARTIAL"
    return "NOT_FOUND"


def _unique_paths(paths: list[Path]) -> list[Path]:
    output: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        text = str(path)
        if not text or text in seen:
            continue
        seen.add(text)
        output.append(path)
    return output


def _format_items(items: list[str]) -> list[str]:
    return [f"- {item}" for item in items]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Safe daily Kite read-only data pipeline. No broker execution.")
    parser.add_argument("--symbols", required=True)
    parser.add_argument("--duration-seconds", type=int, default=60)
    parser.add_argument("--record-depth", default="true")
    parser.add_argument("--poll-interval-seconds", type=float, default=1.0)
    parser.add_argument("--dry-run", default="true")
    parser.add_argument("--chunk-seconds", type=int, default=0)
    parser.add_argument("--flush-rows", type=int, default=100)
    parser.add_argument("--resume", default="true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = run_kite_daily_pipeline(
        symbols_text=args.symbols,
        duration_seconds=args.duration_seconds,
        record_depth=_parse_bool(args.record_depth),
        poll_interval_seconds=args.poll_interval_seconds,
        dry_run=_parse_bool(args.dry_run),
        chunk_seconds=args.chunk_seconds,
        flush_rows=args.flush_rows,
        resume=_parse_bool(args.resume),
    )
    return 0 if result.success else 1


if __name__ == "__main__":
    raise SystemExit(main())




