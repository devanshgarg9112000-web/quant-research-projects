from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any


KITE_TICK_COLUMNS = [
    "timestamp",
    "symbol",
    "internal_symbol",
    "kite_exchange",
    "kite_tradingsymbol",
    "instrument_token",
    "expiry",
    "data_mode",
    "is_synthetic",
    "ltp",
    "ltq",
    "average_price",
    "volume",
    "oi",
    "bid",
    "ask",
    "bid_qty",
    "ask_qty",
    "source",
    "received_at",
]
KITE_DEPTH_COLUMNS = [
    "timestamp",
    "symbol",
    "internal_symbol",
    "kite_exchange",
    "kite_tradingsymbol",
    "instrument_token",
    "expiry",
    "data_mode",
    "is_synthetic",
    "level",
    "bid_price",
    "bid_qty",
    "bid_orders",
    "ask_price",
    "ask_qty",
    "ask_orders",
    "source",
    "received_at",
]
PROVIDER_BAR_COLUMNS = [
    "timestamp",
    "symbol",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "oi",
    "source",
    "interval",
]
ORDERFLOW_LITE_COLUMNS = [
    "timestamp",
    "symbol",
    "internal_symbol",
    "kite_exchange",
    "kite_tradingsymbol",
    "instrument_token",
    "expiry",
    "data_mode",
    "is_synthetic",
    "last_price",
    "price_change_from_prev",
    "price_change_pct_from_prev",
    "rolling_price_change_5",
    "rolling_price_change_10",
    "quote_update_count",
    "has_depth",
    "has_volume_traded",
    "data_quality",
    "feature_mode",
    "bid_qty_total_top5",
    "ask_qty_total_top5",
    "depth_imbalance",
    "spread",
    "bid_stack_change",
    "ask_stack_change",
    "depth_pull_proxy",
    "volume_burst",
    "price_vs_vwap",
    "oi_change",
    "source",
]


@dataclass(frozen=True)
class SaveRowsResult:
    path: Path
    rows_seen: int
    rows_written: int
    rows_removed: int = 0


def kite_tick_path(base_dir: Path | str, day: date, symbol: str) -> Path:
    return Path(base_dir) / "data" / "kite_recorded" / "ticks" / day.isoformat() / f"{safe_symbol_filename(symbol)}_ticks.csv"


def kite_depth_path(base_dir: Path | str, day: date, symbol: str) -> Path:
    return Path(base_dir) / "data" / "kite_recorded" / "depth" / day.isoformat() / f"{safe_symbol_filename(symbol)}_depth.csv"


def kite_feature_path(base_dir: Path | str, day: date, symbol: str) -> Path:
    return Path(base_dir) / "data" / "kite_recorded" / "features" / day.isoformat() / f"{safe_symbol_filename(symbol)}_orderflow_lite.csv"


def kite_historical_bar_path(base_dir: Path | str, day: date, symbol: str) -> Path:
    return Path(base_dir) / "data" / "historical" / "kite" / "bars" / day.isoformat() / f"{safe_symbol_filename(symbol)}_bars.csv"


def normalize_kite_tick_row(
    symbol: str,
    quote: dict[str, Any],
    *,
    received_at: datetime | None = None,
    timestamp: datetime | None = None,
    internal_symbol: str | None = None,
    kite_exchange: str | None = None,
    kite_tradingsymbol: str | None = None,
    expiry: str | None = None,
    data_mode: str | None = None,
    is_synthetic: bool = False,
) -> dict[str, Any]:
    depth = quote.get("depth") if isinstance(quote.get("depth"), dict) else {}
    buy = depth.get("buy") if isinstance(depth.get("buy"), list) else []
    sell = depth.get("sell") if isinstance(depth.get("sell"), list) else []
    best_bid = buy[0] if buy and isinstance(buy[0], dict) else {}
    best_ask = sell[0] if sell and isinstance(sell[0], dict) else {}
    row_time = timestamp or quote.get("timestamp") or quote.get("last_trade_time") or received_at or datetime.now().astimezone()
    received = received_at or datetime.now().astimezone()
    return {
        "timestamp": serialize_value(row_time),
        "symbol": symbol,
        "internal_symbol": internal_symbol or symbol,
        "kite_exchange": kite_exchange or "",
        "kite_tradingsymbol": kite_tradingsymbol or "",
        "instrument_token": serialize_value(quote.get("instrument_token")),
        "expiry": expiry or "",
        "data_mode": data_mode or "",
        "is_synthetic": "true" if is_synthetic else "false",
        "ltp": serialize_value(quote.get("last_price") if quote.get("last_price") is not None else quote.get("ltp")),
        "ltq": serialize_value(quote.get("last_quantity") if quote.get("last_quantity") is not None else quote.get("ltq", 0)),
        "average_price": serialize_value(quote.get("average_price")),
        "volume": serialize_value(quote.get("volume_traded") if quote.get("volume_traded") is not None else quote.get("volume", 0)),
        "oi": serialize_value(quote.get("oi")),
        "bid": serialize_value(best_bid.get("price")),
        "ask": serialize_value(best_ask.get("price")),
        "bid_qty": serialize_value(best_bid.get("quantity")),
        "ask_qty": serialize_value(best_ask.get("quantity")),
        "source": "KITE",
        "received_at": serialize_value(received),
    }


def normalize_kite_depth_rows(
    symbol: str,
    quote: dict[str, Any],
    *,
    received_at: datetime | None = None,
    timestamp: datetime | None = None,
    internal_symbol: str | None = None,
    kite_exchange: str | None = None,
    kite_tradingsymbol: str | None = None,
    expiry: str | None = None,
    data_mode: str | None = None,
    is_synthetic: bool = False,
) -> list[dict[str, Any]]:
    depth = quote.get("depth") if isinstance(quote.get("depth"), dict) else {}
    buy = depth.get("buy") if isinstance(depth.get("buy"), list) else []
    sell = depth.get("sell") if isinstance(depth.get("sell"), list) else []
    row_time = timestamp or quote.get("timestamp") or quote.get("last_trade_time") or received_at or datetime.now().astimezone()
    received = received_at or datetime.now().astimezone()
    rows: list[dict[str, Any]] = []
    for index in range(5):
        bid = buy[index] if index < len(buy) and isinstance(buy[index], dict) else {}
        ask = sell[index] if index < len(sell) and isinstance(sell[index], dict) else {}
        rows.append(
            {
                "timestamp": serialize_value(row_time),
                "symbol": symbol,
                "internal_symbol": internal_symbol or symbol,
                "kite_exchange": kite_exchange or "",
                "kite_tradingsymbol": kite_tradingsymbol or "",
                "instrument_token": serialize_value(quote.get("instrument_token")),
                "expiry": expiry or "",
                "data_mode": data_mode or "",
                "is_synthetic": "true" if is_synthetic else "false",
                "level": index + 1,
                "bid_price": serialize_value(bid.get("price")),
                "bid_qty": serialize_value(bid.get("quantity")),
                "bid_orders": serialize_value(bid.get("orders")),
                "ask_price": serialize_value(ask.get("price")),
                "ask_qty": serialize_value(ask.get("quantity")),
                "ask_orders": serialize_value(ask.get("orders")),
                "source": "KITE",
                "received_at": serialize_value(received),
            }
        )
    return rows


def normalize_kite_bar_rows(candles: list[dict[str, Any]], symbol: str, interval: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for candle in candles:
        rows.append(
            {
                "timestamp": serialize_value(candle.get("date") or candle.get("timestamp")),
                "symbol": symbol,
                "open": serialize_value(candle.get("open")),
                "high": serialize_value(candle.get("high")),
                "low": serialize_value(candle.get("low")),
                "close": serialize_value(candle.get("close")),
                "volume": serialize_value(candle.get("volume", 0)),
                "oi": serialize_value(candle.get("oi")),
                "source": "KITE",
                "interval": interval,
            }
        )
    return rows


def save_rows_dedup(path: Path, columns: list[str], rows: list[dict[str, Any]], key_columns: list[str]) -> SaveRowsResult:
    path.parent.mkdir(parents=True, exist_ok=True)
    _upgrade_csv_columns(path, columns)
    existing = _read_existing_keys(path, key_columns)
    write_header = not path.exists() or path.stat().st_size == 0
    new_rows: list[dict[str, Any]] = []
    for row in rows:
        key = _row_key(row, key_columns)
        if key in existing:
            continue
        existing.add(key)
        new_rows.append({column: row.get(column, "") for column in columns})
    if new_rows:
        with path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=columns)
            if write_header:
                writer.writeheader()
            writer.writerows(new_rows)
    return SaveRowsResult(path=path, rows_seen=len(rows), rows_written=len(new_rows))


def save_rows_overwrite(path: Path, columns: list[str], rows: list[dict[str, Any]]) -> SaveRowsResult:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows_removed = count_csv_data_rows(path)
    normalized_rows = [{column: row.get(column, "") for column in columns} for row in rows]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(normalized_rows)
    return SaveRowsResult(path=path, rows_seen=len(rows), rows_written=len(normalized_rows), rows_removed=rows_removed)


def count_csv_data_rows(path: Path) -> int:
    if not path.exists() or path.stat().st_size == 0:
        return 0
    with path.open(newline="", encoding="utf-8") as f:
        return sum(1 for _row in csv.DictReader(f))


def load_csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def safe_symbol_filename(symbol: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in str(symbol).strip())


def serialize_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    return value


def parse_timestamp(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    text = str(value or "").strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    return datetime.fromisoformat(text)


def to_float(value: Any, default: float = 0.0) -> float:
    if value in {None, ""}:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default



def _upgrade_csv_columns(path: Path, columns: list[str]) -> None:
    if not path.exists() or path.stat().st_size == 0:
        return
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        existing_columns = list(reader.fieldnames or [])
        if existing_columns == columns:
            return
        rows = list(reader)
    normalized_rows = [{column: row.get(column, "") for column in columns} for row in rows]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(normalized_rows)


def _read_existing_keys(path: Path, key_columns: list[str]) -> set[tuple[str, ...]]:
    if not path.exists() or path.stat().st_size == 0:
        return set()
    with path.open(newline="", encoding="utf-8") as f:
        return {_row_key(row, key_columns) for row in csv.DictReader(f)}


def _row_key(row: dict[str, Any], key_columns: list[str]) -> tuple[str, ...]:
    return tuple(_normalized_key_value(row.get(column)) for column in key_columns)


def _normalized_key_value(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if not text:
        return ""
    try:
        return str(float(text))
    except ValueError:
        return text
