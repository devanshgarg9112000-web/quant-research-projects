from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable

from src.data_collection.kite_credentials import format_kite_credential_status, load_kite_credentials
from src.data_collection.market_data_schema import safe_symbol_filename


INSTRUMENT_CACHE_COLUMNS = [
    "instrument_token",
    "exchange",
    "tradingsymbol",
    "name",
    "expiry",
    "lot_size",
    "tick_size",
    "instrument_type",
    "segment",
]
INTERNAL_ROOTS = {
    "GOLD-I": "GOLD",
    "SILVER-I": "SILVER",
}


@dataclass(frozen=True)
class KiteInstrumentMapping:
    internal_symbol: str
    status: str
    exchange: str = ""
    tradingsymbol: str = ""
    instrument_token: str = ""
    expiry: str = ""
    name: str = ""
    lot_size: str = ""
    tick_size: str = ""
    reason: str = ""

    @property
    def resolved(self) -> bool:
        return self.status in {"RESOLVED", "RESOLVED_DIRECT"}

    @property
    def quote_symbol(self) -> str:
        if self.exchange and self.tradingsymbol:
            return f"{self.exchange}:{self.tradingsymbol}"
        return self.internal_symbol

    def as_report_line(self) -> str:
        return (
            f"internal_symbol={self.internal_symbol}, status={self.status}, "
            f"exchange={self.exchange or 'N/A'}, tradingsymbol={self.tradingsymbol or 'N/A'}, "
            f"instrument_token={self.instrument_token or 'N/A'}, expiry={self.expiry or 'N/A'}, "
            f"name={self.name or 'N/A'}, lot_size={self.lot_size or 'N/A'}, tick_size={self.tick_size or 'N/A'}, "
            f"reason={self.reason or 'N/A'}"
        )


@dataclass
class KiteInstrumentResolveResult:
    mappings: list[KiteInstrumentMapping] = field(default_factory=list)
    source: str = "NOT_LOADED"
    cache_path: Path | None = None
    rows_loaded: int = 0
    rows_cached: int = 0
    credential_status: str = "NOT_CHECKED"
    errors: list[str] = field(default_factory=list)

    @property
    def all_resolved(self) -> bool:
        return bool(self.mappings) and all(mapping.resolved for mapping in self.mappings)

    def by_internal_symbol(self) -> dict[str, KiteInstrumentMapping]:
        return {mapping.internal_symbol: mapping for mapping in self.mappings}


def resolve_kite_instruments(
    base_dir: Path | str = ".",
    *,
    symbols_text: str = "",
    exchange: str = "MCX",
    dry_run: bool = True,
    refresh: bool = False,
    instruments: list[dict[str, Any]] | None = None,
    instrument_client_factory: Callable[[str, str], Any] | None = None,
    as_of: date | None = None,
) -> KiteInstrumentResolveResult:
    base = Path(base_dir)
    exchange = str(exchange or "MCX").upper()
    symbols = _parse_symbols(symbols_text)
    as_of = as_of or date.today()
    state = load_kite_credentials(base)
    result = KiteInstrumentResolveResult(
        cache_path=instrument_cache_path(base, exchange),
        credential_status=state.credential_status,
    )
    if symbols and all(":" in symbol for symbol in symbols):
        result.source = "DIRECT_SYMBOLS"
        result.mappings = [resolve_one_symbol(symbol, [], exchange=exchange, as_of=as_of) for symbol in symbols]
        return result

    rows: list[dict[str, Any]]
    if instruments is not None:
        rows = [normalize_instrument_row(row) for row in instruments]
        result.source = "PROVIDED_FIXTURE"
    elif dry_run:
        rows = synthetic_instruments(exchange, as_of)
        result.source = "DRY_RUN_SYNTHETIC"
    elif result.cache_path.exists() and not refresh:
        rows = load_cached_instruments(result.cache_path)
        result.source = "CACHE"
    elif state.all_present or instrument_client_factory is not None:
        rows = _load_instruments_from_kite(exchange, state, instrument_client_factory, result)
        result.source = "KITE_READ_ONLY" if rows else "KITE_READ_ONLY_EMPTY"
        if rows:
            result.rows_cached = save_instruments_cache(result.cache_path, rows)
    else:
        rows = []
        result.source = "NOT_LOADED"
        result.errors.append(
            "Kite instrument resolver skipped safely: missing "
            + ", ".join(state.missing_keys())
            + ". Use --dry-run true or add env/.env credentials locally."
        )

    result.rows_loaded = len(rows)
    if refresh and dry_run and rows:
        result.rows_cached = save_instruments_cache(result.cache_path, rows)
    result.mappings = [resolve_one_symbol(symbol, rows, exchange=exchange, as_of=as_of) for symbol in symbols]
    return result


def resolve_one_symbol(
    internal_symbol: str,
    instruments: list[dict[str, Any]],
    *,
    exchange: str = "MCX",
    as_of: date | None = None,
) -> KiteInstrumentMapping:
    symbol = str(internal_symbol or "").strip()
    if not symbol:
        return KiteInstrumentMapping(internal_symbol="", status="NOT_FOUND", reason="empty symbol")
    if ":" in symbol:
        direct_exchange, tradingsymbol = symbol.split(":", 1)
        return KiteInstrumentMapping(
            internal_symbol=symbol,
            status="RESOLVED_DIRECT",
            exchange=direct_exchange.strip().upper(),
            tradingsymbol=tradingsymbol.strip(),
            reason="exchange-prefixed Kite symbol supplied directly",
        )
    as_of = as_of or date.today()
    root = INTERNAL_ROOTS.get(symbol.upper()) or symbol.upper().replace("-I", "")
    candidates: list[tuple[date, int, dict[str, Any]]] = []
    for row in instruments:
        if str(row.get("exchange") or "").upper() != str(exchange or "MCX").upper():
            continue
        if str(row.get("instrument_type") or "").upper() != "FUT":
            continue
        expiry = _parse_date(row.get("expiry"))
        if expiry is None or expiry < as_of:
            continue
        score = _symbol_match_score(root, row)
        if score is None:
            continue
        candidates.append((expiry, score, row))
    if not candidates:
        return KiteInstrumentMapping(
            internal_symbol=symbol,
            status="NOT_FOUND",
            reason=f"no active {exchange} future matched root {root}",
        )
    expiry, _score, row = sorted(candidates, key=lambda item: (item[1], item[0], str(item[2].get("tradingsymbol"))))[0]
    return KiteInstrumentMapping(
        internal_symbol=symbol,
        status="RESOLVED",
        exchange=str(row.get("exchange") or exchange).upper(),
        tradingsymbol=str(row.get("tradingsymbol") or ""),
        instrument_token=str(row.get("instrument_token") or ""),
        expiry=expiry.isoformat(),
        name=str(row.get("name") or root),
        lot_size=str(row.get("lot_size") or ""),
        tick_size=str(row.get("tick_size") or ""),
        reason="nearest active MCX FUT",
    )


def instrument_cache_path(base_dir: Path | str, exchange: str = "MCX") -> Path:
    return Path(base_dir) / "data" / "kite_instruments" / f"instruments_{safe_symbol_filename(exchange.lower())}.csv"


def load_cached_instruments(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as f:
        return [normalize_instrument_row(row) for row in csv.DictReader(f)]


def find_cached_instrument(
    base_dir: Path | str,
    *,
    exchange: str,
    tradingsymbol: str,
    instrument_token: str | int,
) -> dict[str, str] | None:
    """Find public contract metadata without credentials or network access."""

    rows = load_cached_instruments(instrument_cache_path(base_dir, exchange))
    exchange_text = str(exchange or "").strip().upper()
    symbol_text = str(tradingsymbol or "").strip()
    token_text = str(instrument_token or "").strip()
    for row in rows:
        if (
            str(row.get("exchange") or "").upper() == exchange_text
            and str(row.get("tradingsymbol") or "") == symbol_text
            and str(row.get("instrument_token") or "") == token_text
        ):
            return row
    for row in rows:
        if token_text and str(row.get("instrument_token") or "") == token_text:
            return row
    return None


def enrich_contract_rows_from_cache(
    base_dir: Path | str,
    rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], int]:
    """Fill missing public expiry metadata in recorded rows from the local cache."""

    enriched: list[dict[str, Any]] = []
    updated = 0
    cache: dict[tuple[str, str, str], dict[str, str] | None] = {}
    for source in rows:
        row = dict(source)
        exchange = str(row.get("kite_exchange") or "").strip().upper()
        tradingsymbol = str(row.get("kite_tradingsymbol") or "").strip()
        token = str(row.get("instrument_token") or "").strip()
        if exchange and tradingsymbol and token and not str(row.get("expiry") or "").strip():
            key = exchange, tradingsymbol, token
            if key not in cache:
                cache[key] = find_cached_instrument(
                    base_dir,
                    exchange=exchange,
                    tradingsymbol=tradingsymbol,
                    instrument_token=token,
                )
            metadata = cache[key]
            expiry = str((metadata or {}).get("expiry") or "").strip()
            if expiry:
                row["expiry"] = expiry
                updated += 1
        enriched.append(row)
    return enriched, updated


def save_instruments_cache(path: Path, rows: list[dict[str, Any]]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized = [normalize_instrument_row(row) for row in rows]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=INSTRUMENT_CACHE_COLUMNS)
        writer.writeheader()
        writer.writerows({column: row.get(column, "") for column in INSTRUMENT_CACHE_COLUMNS} for row in normalized)
    return len(normalized)


def normalize_instrument_row(row: dict[str, Any]) -> dict[str, str]:
    return {
        "instrument_token": str(row.get("instrument_token") or ""),
        "exchange": str(row.get("exchange") or "").upper(),
        "tradingsymbol": str(row.get("tradingsymbol") or ""),
        "name": str(row.get("name") or ""),
        "expiry": _format_date(row.get("expiry")),
        "lot_size": str(row.get("lot_size") or ""),
        "tick_size": str(row.get("tick_size") or ""),
        "instrument_type": str(row.get("instrument_type") or "").upper(),
        "segment": str(row.get("segment") or ""),
    }


def synthetic_instruments(exchange: str = "MCX", as_of: date | None = None) -> list[dict[str, str]]:
    as_of = as_of or date.today()
    expiry = as_of + timedelta(days=30)
    month = expiry.strftime("%b").upper()
    year = expiry.strftime("%y")
    return [
        normalize_instrument_row({
            "instrument_token": "900001",
            "exchange": exchange,
            "tradingsymbol": f"GOLD{year}{month}FUT",
            "name": "GOLD",
            "expiry": expiry,
            "lot_size": "1",
            "tick_size": "1",
            "instrument_type": "FUT",
            "segment": f"{exchange}-FUT",
        }),
        normalize_instrument_row({
            "instrument_token": "900002",
            "exchange": exchange,
            "tradingsymbol": f"SILVER{year}{month}FUT",
            "name": "SILVER",
            "expiry": expiry,
            "lot_size": "1",
            "tick_size": "1",
            "instrument_type": "FUT",
            "segment": f"{exchange}-FUT",
        }),
    ]


def _load_instruments_from_kite(exchange: str, state, instrument_client_factory, result: KiteInstrumentResolveResult) -> list[dict[str, Any]]:
    try:
        client = _build_kite_client(state.api_key or "", state.access_token or "", instrument_client_factory)
        if client is None:
            result.errors.append("kiteconnect package missing; cannot refresh instruments.")
            return []
        rows = client.instruments(exchange)
    except Exception as exc:
        result.errors.append(f"Kite instruments read failed safely: {type(exc).__name__}.")
        return []
    if isinstance(rows, dict) and rows.get("status"):
        result.errors.append(f"Kite instruments read skipped safely: {rows.get('status')}.")
        return []
    return [normalize_instrument_row(row) for row in list(rows or [])]


def _build_kite_client(api_key: str, access_token: str, instrument_client_factory):
    if instrument_client_factory is not None:
        return instrument_client_factory(api_key, access_token)
    try:
        from kiteconnect import KiteConnect
    except Exception:
        return None
    client = KiteConnect(api_key=api_key)
    client.set_access_token(access_token)
    return client


def _symbol_match_score(root: str, row: dict[str, Any]) -> int | None:
    name = str(row.get("name") or "").upper()
    tradingsymbol = str(row.get("tradingsymbol") or "").upper()
    if name == root:
        return 0
    if tradingsymbol.startswith(root):
        next_char = tradingsymbol[len(root):len(root) + 1]
        if not next_char or not next_char.isalpha():
            return 1
    if root in tradingsymbol.split("-"):
        return 2
    return None


def _format_date(value: Any) -> str:
    parsed = _parse_date(value)
    return parsed.isoformat() if parsed else ""


def _parse_date(value: Any) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def _parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _parse_bool(value: str | bool | None) -> bool:
    return value is True or str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Resolve internal symbols to public Kite instruments. Read-only only.")
    parser.add_argument("--symbols", default="")
    parser.add_argument("--exchange", default="MCX")
    parser.add_argument("--dry-run", default="true")
    parser.add_argument("--refresh", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    dry_run = _parse_bool(args.dry_run)
    result = resolve_kite_instruments(
        symbols_text=args.symbols,
        exchange=args.exchange,
        dry_run=dry_run,
        refresh=bool(args.refresh),
    )
    print("KITE INSTRUMENT RESOLVER")
    print("Mode: PAPER | Kite: READ ONLY | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Credential Status: {result.credential_status}")
    for line in format_kite_credential_status(load_kite_credentials(".")):
        print(line)
    print(f"Exchange: {str(args.exchange).upper()}")
    print(f"Dry Run: {dry_run}")
    print(f"Refresh Cache: {bool(args.refresh)}")
    print(f"Instrument Source: {result.source}")
    print(f"Rows Loaded: {result.rows_loaded}")
    print(f"Rows Cached: {result.rows_cached}")
    print(f"Cache Path: {result.cache_path}")
    if result.errors:
        print("Errors: " + "; ".join(result.errors))
    else:
        print("Errors: NONE")
    for mapping in result.mappings:
        print(mapping.as_report_line())
    print("READ ONLY CHECK ONLY. NO ORDERS.")
    print("PAPER MODE ONLY. No broker orders were placed.")
    return 0 if not result.errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
