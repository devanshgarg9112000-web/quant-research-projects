from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs
from src.data_collection.kite_credentials import format_kite_credential_status, load_kite_credentials
from src.data_collection.kite_instrument_resolver import KiteInstrumentMapping, resolve_kite_instruments
from src.data_collection.kite_live_recorder import KiteRecordingResult, _write_report


@dataclass
class KiteReadOnlyCheckResult:
    credential_status: str = "NOT_CHECKED"
    dry_run: bool = True
    profile_status: str = "NOT_CHECKED"
    quote_status: str = "NOT_CHECKED"
    depth_status: str = "NOT_CHECKED"
    symbol_resolutions: list[KiteInstrumentMapping] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    report_path: Path | None = None


def run_kite_readonly_check(
    base_dir: Path | str = ".",
    *,
    symbols_text: str = "GOLD-I",
    dry_run: str | bool = "auto",
    configs: dict[str, Any] | None = None,
    kite_client_factory: Callable[[str, str], Any] | None = None,
    exchange: str = "MCX",
    as_of: date | None = None,
) -> KiteReadOnlyCheckResult:
    base = Path(base_dir)
    state = load_kite_credentials(base)
    configs = configs or load_configs(base)
    result = KiteReadOnlyCheckResult(credential_status=state.credential_status)
    symbols = _parse_symbols(symbols_text)
    dry_mode = _resolve_dry_run(dry_run, state.all_present)
    result.dry_run = dry_mode
    resolution = resolve_kite_instruments(
        base,
        symbols_text=symbols_text,
        exchange=exchange,
        dry_run=dry_mode,
        instrument_client_factory=kite_client_factory,
        as_of=as_of,
    )
    result.symbol_resolutions = resolution.mappings
    quote_symbols = [
        mapping.quote_symbol if mapping.resolved else _to_quote_symbol(mapping.internal_symbol, configs.get("instruments", {}))
        for mapping in result.symbol_resolutions
    ]
    if resolution.errors and not dry_mode:
        result.errors.extend(resolution.errors)

    print("KITE READ ONLY CHECK")
    print("READ ONLY CHECK ONLY. NO ORDERS.")
    print("Mode: PAPER | Kite: READ ONLY | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Credential Status: {result.credential_status}")
    for line in format_kite_credential_status(state):
        print(line)
    print(f"Symbols: {', '.join(symbols) if symbols else 'NONE'}")
    for mapping in result.symbol_resolutions:
        print(f"Resolved Symbol: {mapping.internal_symbol} -> {mapping.quote_symbol if mapping.resolved else 'NOT_FOUND'} ({mapping.status})")
    print(f"Dry Run: {dry_mode}")

    if not symbols:
        result.errors.append("No symbols supplied.")
        _write_check_report(base, result)
        print("Profile check: SKIPPED")
        print("Quote check: SKIPPED")
        print("Depth check: SKIPPED")
        print("PAPER MODE ONLY. No broker orders were placed.")
        return result

    if not dry_mode and not state.all_present:
        result.errors.append(
            "Kite read-only check skipped safely: missing "
            + ", ".join(state.missing_keys())
            + ". Run dry-run first or configure env/.env credentials locally."
        )
        _write_check_report(base, result)
        print(result.errors[-1])
        print("Profile check: SKIPPED")
        print("Quote check: SKIPPED")
        print("Depth check: SKIPPED")
        print("PAPER MODE ONLY. No broker orders were placed.")
        return result

    if dry_mode:
        sample_quote = _sample_readonly_quote(quote_symbols)
        result.profile_status = "DRY_RUN"
        result.quote_status = "DRY_RUN_OK" if sample_quote else "DRY_RUN_EMPTY"
        result.depth_status = "PRESENT" if _has_depth(sample_quote) else "MISSING"
    else:
        client = _build_kite_client(state.api_key or "", state.access_token or "", kite_client_factory)
        if client is None:
            result.errors.append("kiteconnect package missing; install dependencies before real read-only checks.")
            result.profile_status = "SKIPPED"
            result.quote_status = "SKIPPED"
            result.depth_status = "SKIPPED"
        else:
            result.profile_status = _safe_profile_status(client, result, state)
            quote = _safe_quote(client, quote_symbols, result, state)
            result.quote_status = "OK" if quote else "FAILED"
            result.depth_status = "PRESENT" if _has_depth(quote) else "MISSING"

    _write_check_report(base, result)
    print(f"Profile check: {result.profile_status}")
    print(f"Quote check: {result.quote_status}")
    print(f"Depth check: {result.depth_status}")
    print(f"Report: {result.report_path}")
    print("PAPER MODE ONLY. Kite read-only data calls only. No broker orders were placed.")
    return result


def _write_check_report(base: Path, result: KiteReadOnlyCheckResult) -> None:
    report = KiteRecordingResult(
        operation_type="readonly_check",
        credential_status=result.credential_status,
        quote_status=result.quote_status,
        depth_status=result.depth_status,
        symbol_resolutions=result.symbol_resolutions,
        errors=result.errors,
    )
    _write_report(base, report)
    result.report_path = report.report_path


def _build_kite_client(api_key: str, access_token: str, kite_client_factory: Callable[[str, str], Any] | None):
    if kite_client_factory is not None:
        return kite_client_factory(api_key, access_token)
    try:
        from kiteconnect import KiteConnect
    except Exception:
        return None
    client = KiteConnect(api_key=api_key)
    client.set_access_token(access_token)
    return client


def _safe_profile_status(client: Any, result: KiteReadOnlyCheckResult, state) -> str:
    try:
        profile = client.profile()
    except Exception as exc:
        result.errors.append("Kite profile read failed safely: " + state.redacted_message(type(exc).__name__) + ".")
        return "FAILED"
    return "OK" if isinstance(profile, dict) else "UNEXPECTED_RESPONSE"


def _safe_quote(client: Any, quote_symbols: list[str], result: KiteReadOnlyCheckResult, state) -> dict[str, Any]:
    try:
        quote = client.quote(quote_symbols)
    except Exception as exc:
        result.errors.append("Kite quote/depth read failed safely: " + state.redacted_message(type(exc).__name__) + ".")
        return {}
    return quote if isinstance(quote, dict) else {}


def _sample_readonly_quote(quote_symbols: list[str]) -> dict[str, Any]:
    now = datetime.now().astimezone()
    output: dict[str, Any] = {}
    for index, symbol in enumerate(quote_symbols):
        output[symbol] = {
            "instrument_token": 100000 + index,
            "timestamp": now,
            "last_price": 150000.0 + index,
            "volume_traded": 1000 + index,
            "oi": 5000 + index,
            "depth": {
                "buy": [{"price": 149999 - level, "quantity": 10 + level} for level in range(5)],
                "sell": [{"price": 150001 + level, "quantity": 12 + level} for level in range(5)],
            },
        }
    return output


def _has_depth(quote: dict[str, Any]) -> bool:
    for payload in quote.values():
        if not isinstance(payload, dict):
            continue
        depth = payload.get("depth")
        if isinstance(depth, dict) and (depth.get("buy") or depth.get("sell")):
            return True
    return False


def _to_quote_symbol(symbol: str, instruments: dict[str, Any]) -> str:
    if ":" in symbol:
        return symbol
    instrument = instruments.get(symbol, {}) if isinstance(instruments, dict) else {}
    exchange = instrument.get("exchange") if isinstance(instrument, dict) else None
    return f"{exchange}:{symbol}" if exchange else symbol


def _parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _resolve_dry_run(value: str | bool, credentials_present: bool) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value or "auto").strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return not credentials_present


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Safe Kite read-only credential and data readiness check.")
    parser.add_argument("--symbols", default="GOLD-I")
    parser.add_argument("--exchange", default="MCX")
    parser.add_argument("--dry-run", default="auto", choices=["auto", "true", "false"])
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = run_kite_readonly_check(symbols_text=args.symbols, dry_run=args.dry_run, exchange=args.exchange)
    if result.errors and not result.dry_run:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
