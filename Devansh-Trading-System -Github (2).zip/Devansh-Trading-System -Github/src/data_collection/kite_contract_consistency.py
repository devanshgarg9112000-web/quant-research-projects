from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any, Iterable


CONSISTENT = "CONSISTENT"
DRY_RUN_SYNTHETIC_ONLY = "DRY_RUN_SYNTHETIC_ONLY"
REAL_CONTRACT_SELECTED = "REAL_CONTRACT_SELECTED"
MIXED_CONTRACTS_WARNING = "MIXED_CONTRACTS_WARNING"
CONTRACT_MISMATCH_INVESTIGATE = "CONTRACT_MISMATCH_INVESTIGATE"
INSUFFICIENT_CONTRACT_METADATA = "INSUFFICIENT_CONTRACT_METADATA"


@dataclass(frozen=True)
class KiteContractIdentity:
    internal_symbol: str
    kite_exchange: str
    kite_tradingsymbol: str
    instrument_token: str
    expiry: str = ""
    data_mode: str = ""
    is_synthetic: bool = False

    @property
    def key(self) -> tuple[str, str, str]:
        return self.kite_exchange, self.kite_tradingsymbol, self.instrument_token

    @property
    def display(self) -> str:
        expiry = self.expiry or "UNKNOWN"
        mode = self.data_mode or ("DRY_RUN" if self.is_synthetic else "REAL_READ_ONLY")
        return (
            f"{self.internal_symbol}:{self.kite_exchange}:{self.kite_tradingsymbol} "
            f"instrument_token={self.instrument_token} expiry={expiry} data_mode={mode} "
            f"synthetic={str(self.is_synthetic).lower()}"
        )


@dataclass(frozen=True)
class KiteContractConsistencyResult:
    status: str
    selected_contract: KiteContractIdentity | None
    ignored_contracts: tuple[str, ...]
    synthetic_contracts_ignored: tuple[str, ...]
    action_required: bool
    real_contract_count: int
    synthetic_contract_count: int
    missing_metadata_rows: int
    selected_key: tuple[str, str, str] | None
    allowed_mixed_contracts: bool = False
    metadata_complete: bool = False
    missing_contract_fields: tuple[str, ...] = ()
    expiry_missing_warning: bool = False

    @property
    def selected_contract_text(self) -> str:
        return self.selected_contract.display if self.selected_contract else "NONE"


def evaluate_contract_consistency(
    rows: Iterable[dict[str, Any]],
    *,
    internal_symbol: str,
    allow_mixed_contracts: bool = False,
    preferred_contract: tuple[str, str, str] | None = None,
) -> KiteContractConsistencyResult:
    """Inspect public contract metadata and select one deterministic real contract."""

    normalized_rows = [
        row for row in rows
        if not internal_symbol or str(row.get("internal_symbol") or row.get("symbol") or "").strip() == internal_symbol
    ]
    real_groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    synthetic_groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    missing_metadata_rows = 0

    for row in normalized_rows:
        key = contract_key(row)
        if key is None:
            missing_metadata_rows += 1
            continue
        if is_synthetic_contract_row(row):
            synthetic_groups[key].append(row)
        else:
            real_groups[key].append(row)

    real_identities = {
        key: _identity_from_group(internal_symbol, key, group, is_synthetic=False)
        for key, group in real_groups.items()
    }
    synthetic_identities = {
        key: _identity_from_group(internal_symbol, key, group, is_synthetic=True)
        for key, group in synthetic_groups.items()
    }

    if not real_groups:
        if synthetic_groups:
            selected_key = _select_contract_key(synthetic_groups, preferred_contract)
            selected = synthetic_identities.get(selected_key) if selected_key else None
            ignored_synthetic = tuple(
                identity.display for key, identity in sorted(synthetic_identities.items()) if key != selected_key
            )
            return _contract_result(
                status=DRY_RUN_SYNTHETIC_ONLY,
                selected_contract=selected,
                ignored_contracts=(),
                synthetic_contracts_ignored=ignored_synthetic,
                action_required=False,
                real_contract_count=0,
                synthetic_contract_count=len(synthetic_groups),
                missing_metadata_rows=missing_metadata_rows,
                selected_key=selected_key,
                allowed_mixed_contracts=allow_mixed_contracts,
            )
        return _contract_result(
            status=INSUFFICIENT_CONTRACT_METADATA,
            selected_contract=None,
            ignored_contracts=(),
            synthetic_contracts_ignored=(),
            action_required=True,
            real_contract_count=0,
            synthetic_contract_count=0,
            missing_metadata_rows=missing_metadata_rows or len(normalized_rows),
            selected_key=None,
            allowed_mixed_contracts=allow_mixed_contracts,
        )

    selected_key = _select_contract_key(real_groups, preferred_contract)
    selected = real_identities.get(selected_key) if selected_key else None
    ignored_real = tuple(
        identity.display for key, identity in sorted(real_identities.items()) if key != selected_key
    )
    ignored_synthetic = tuple(identity.display for _, identity in sorted(synthetic_identities.items()))

    if len(real_groups) > 1:
        return _contract_result(
            status=MIXED_CONTRACTS_WARNING if allow_mixed_contracts else CONTRACT_MISMATCH_INVESTIGATE,
            selected_contract=selected,
            ignored_contracts=ignored_real,
            synthetic_contracts_ignored=ignored_synthetic,
            action_required=not allow_mixed_contracts,
            real_contract_count=len(real_groups),
            synthetic_contract_count=len(synthetic_groups),
            missing_metadata_rows=missing_metadata_rows,
            selected_key=selected_key,
            allowed_mixed_contracts=allow_mixed_contracts,
        )

    return _contract_result(
        status=REAL_CONTRACT_SELECTED if synthetic_groups else CONSISTENT,
        selected_contract=selected,
        ignored_contracts=(),
        synthetic_contracts_ignored=ignored_synthetic,
        action_required=False,
        real_contract_count=1,
        synthetic_contract_count=len(synthetic_groups),
        missing_metadata_rows=missing_metadata_rows,
        selected_key=selected_key,
        allowed_mixed_contracts=allow_mixed_contracts,
    )


def contract_key(row: dict[str, Any]) -> tuple[str, str, str] | None:
    exchange = str(row.get("kite_exchange") or "").strip().upper()
    tradingsymbol = str(row.get("kite_tradingsymbol") or "").strip()
    instrument_token = str(row.get("instrument_token") or "").strip()
    if not exchange or not tradingsymbol or not instrument_token:
        return None
    return exchange, tradingsymbol, instrument_token


def is_synthetic_contract_row(row: dict[str, Any]) -> bool:
    if _truthy(row.get("is_synthetic")):
        return True
    data_mode = str(row.get("data_mode") or row.get("mode") or "").strip().upper()
    if data_mode in {"DRY_RUN", "SYNTHETIC", "SIMULATED"}:
        return True
    token = _token_as_int(row.get("instrument_token"))
    return token is not None and 100000 <= token <= 999999


def count_real_contracts(rows: Iterable[dict[str, Any]]) -> int:
    return len({
        key for row in rows
        if (key := contract_key(row)) is not None and not is_synthetic_contract_row(row)
    })


def rows_for_selected_contract(
    rows: Iterable[dict[str, Any]],
    decision: KiteContractConsistencyResult,
    *,
    include_synthetic: bool = False,
    allow_mixed_contracts: bool = False,
) -> list[dict[str, Any]]:
    rows = list(rows)
    if allow_mixed_contracts and decision.real_contract_count > 0:
        return [row for row in rows if contract_key(row) is not None and not is_synthetic_contract_row(row)]
    if decision.selected_key is None:
        return []
    if decision.status == DRY_RUN_SYNTHETIC_ONLY and include_synthetic:
        return [
            row for row in rows
            if contract_key(row) == decision.selected_key and is_synthetic_contract_row(row)
        ]
    return [
        row for row in rows
        if contract_key(row) == decision.selected_key and not is_synthetic_contract_row(row)
    ]


def _contract_result(**kwargs: Any) -> KiteContractConsistencyResult:
    result = KiteContractConsistencyResult(**kwargs)
    selected = result.selected_contract
    if selected is None:
        missing = (
            "internal_symbol",
            "kite_exchange",
            "kite_tradingsymbol",
            "instrument_token",
            "expiry",
            "data_mode",
        )
    else:
        required = {
            "internal_symbol": selected.internal_symbol,
            "kite_exchange": selected.kite_exchange,
            "kite_tradingsymbol": selected.kite_tradingsymbol,
            "instrument_token": selected.instrument_token,
            "expiry": selected.expiry,
            "data_mode": selected.data_mode,
        }
        missing = tuple(field for field, value in required.items() if not str(value or "").strip())
    return replace(
        result,
        metadata_complete=not missing,
        missing_contract_fields=missing,
        expiry_missing_warning="expiry" in missing,
    )


def _identity_from_group(
    internal_symbol: str,
    key: tuple[str, str, str],
    rows: list[dict[str, Any]],
    *,
    is_synthetic: bool,
) -> KiteContractIdentity:
    latest = max(rows, key=lambda row: _timestamp_sort_key(row.get("timestamp") or row.get("received_at")))
    expiry = next((str(row.get("expiry") or "").strip() for row in reversed(rows) if row.get("expiry")), "")
    data_mode = str(latest.get("data_mode") or latest.get("mode") or "").strip().upper()
    if not data_mode:
        data_mode = "DRY_RUN" if is_synthetic else "REAL_READ_ONLY"
    return KiteContractIdentity(
        internal_symbol=internal_symbol or str(latest.get("internal_symbol") or latest.get("symbol") or ""),
        kite_exchange=key[0],
        kite_tradingsymbol=key[1],
        instrument_token=key[2],
        expiry=expiry,
        data_mode=data_mode,
        is_synthetic=is_synthetic,
    )


def _select_contract_key(
    groups: dict[tuple[str, str, str], list[dict[str, Any]]],
    preferred_contract: tuple[str, str, str] | None,
) -> tuple[str, str, str] | None:
    if preferred_contract in groups:
        return preferred_contract
    if not groups:
        return None
    return max(
        groups,
        key=lambda key: (
            max(_timestamp_sort_key(row.get("timestamp") or row.get("received_at")) for row in groups[key]),
            len(groups[key]),
            key,
        ),
    )


def _timestamp_sort_key(value: Any) -> float:
    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value or "").strip()
        if not text:
            return 0.0
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(text)
        except ValueError:
            return 0.0
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def _token_as_int(value: Any) -> int | None:
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None
