from __future__ import annotations

import argparse
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import date, timezone
from pathlib import Path
from typing import Any

from src.data_collection.kite_contract_consistency import (
    CONSISTENT,
    CONTRACT_MISMATCH_INVESTIGATE,
    DRY_RUN_SYNTHETIC_ONLY,
    INSUFFICIENT_CONTRACT_METADATA,
    MIXED_CONTRACTS_WARNING,
    REAL_CONTRACT_SELECTED,
    KiteContractConsistencyResult,
    contract_key,
    count_real_contracts,
    evaluate_contract_consistency,
    rows_for_selected_contract,
)
from src.data_collection.kite_instrument_resolver import enrich_contract_rows_from_cache
from src.data_collection.kite_live_recorder import KiteRecordingResult, _write_report
from src.data_collection.market_data_schema import (
    ORDERFLOW_LITE_COLUMNS,
    kite_depth_path,
    kite_feature_path,
    kite_tick_path,
    load_csv_rows,
    parse_timestamp,
    save_rows_overwrite,
    to_float,
)


@dataclass
class KiteOrderFlowFeatureResult:
    rows_generated: int = 0
    tick_rows_loaded: int = 0
    depth_rows_loaded: int = 0
    real_tick_rows_used: int = 0
    real_depth_rows_used: int = 0
    synthetic_rows_ignored: int = 0
    stale_output_rows_removed: int = 0
    output_csv_data_rows: int = 0
    feature_mode: str = "NO_FEATURES"
    market_data_status: str = "NO_INPUT"
    zero_feature_reason: str = ""
    files: list[Path] = field(default_factory=list)
    input_files: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    missing_required_fields: list[str] = field(default_factory=list)
    contract_consistency_status: str = "NOT_CHECKED"
    selected_contract: str = ""
    ignored_contracts: list[str] = field(default_factory=list)
    synthetic_contracts_ignored: list[str] = field(default_factory=list)
    contract_action_required: bool = False
    output_real_contract_count: int = 0
    report_csv_contract_match: bool = True
    contract_metadata_complete: bool = True
    missing_contract_fields: list[str] = field(default_factory=list)
    expiry_missing_warning: bool = False
    expiry_rows_enriched: int = 0
    report_path: Path | None = None


@dataclass
class _FilteredFeatureRows:
    tick_rows: list[dict[str, Any]]
    depth_rows: list[dict[str, Any]]
    ignored_rows: int = 0
    selected_identity: tuple[str, str, str] | None = None
    contract_decision: KiteContractConsistencyResult | None = None
    warnings: list[str] = field(default_factory=list)


def build_kite_orderflow_lite_features(
    base_dir: Path | str = ".",
    *,
    symbols_text: str,
    day: str | date,
    include_synthetic: bool = False,
    allow_mixed_contracts: bool = False,
) -> KiteOrderFlowFeatureResult:
    base = Path(base_dir)
    feature_day = _parse_date(day)
    symbols = _parse_symbols(symbols_text)
    result = KiteOrderFlowFeatureResult()
    print("KITE ORDERFLOW LITE FEATURE BUILDER")
    print("Mode: PAPER | Kite recorded data only | Broker Orders: DISABLED | execution_allowed=false")
    print(f"Symbols: {', '.join(symbols) if symbols else 'NONE'}")
    print(f"Date: {feature_day}")
    print(f"Include synthetic: {str(include_synthetic).lower()}")
    print(f"Allow mixed contracts: {str(allow_mixed_contracts).lower()}")
    for symbol in symbols:
        depth_path = kite_depth_path(base, feature_day, symbol)
        tick_path = kite_tick_path(base, feature_day, symbol)
        output_path = kite_feature_path(base, feature_day, symbol)
        result.input_files.extend([f"tick input: {tick_path}", f"depth input: {depth_path}"])
        depth_rows = load_csv_rows(depth_path)
        tick_rows = load_csv_rows(tick_path)
        result.tick_rows_loaded += len(tick_rows)
        result.depth_rows_loaded += len(depth_rows)
        tick_rows, tick_expiry_enriched = enrich_contract_rows_from_cache(base, tick_rows)
        depth_rows, depth_expiry_enriched = enrich_contract_rows_from_cache(base, depth_rows)
        expiry_enriched = tick_expiry_enriched + depth_expiry_enriched
        result.expiry_rows_enriched += expiry_enriched
        if expiry_enriched:
            result.warnings.append(
                f"Enriched expiry metadata from local Kite instrument cache for {expiry_enriched} {symbol} row(s)."
            )

        filtered = _filter_feature_rows(
            symbol,
            tick_rows,
            depth_rows,
            include_synthetic=include_synthetic,
            allow_mixed_contracts=allow_mixed_contracts,
        )
        result.real_tick_rows_used += len(filtered.tick_rows)
        result.real_depth_rows_used += len(filtered.depth_rows)
        result.synthetic_rows_ignored += filtered.ignored_rows
        result.warnings.extend(filtered.warnings)
        if filtered.contract_decision:
            _merge_contract_decision(result, filtered.contract_decision)
            if (
                filtered.contract_decision.status == DRY_RUN_SYNTHETIC_ONLY
                and not include_synthetic
                and filtered.contract_decision.selected_contract
            ):
                selected_synthetic = filtered.contract_decision.selected_contract.display
                if selected_synthetic not in result.synthetic_contracts_ignored:
                    result.synthetic_contracts_ignored.append(selected_synthetic)

        features: list[dict[str, Any]] = []
        symbol_mode = "NO_FEATURES"
        symbol_status = "NO_INPUT" if not tick_rows and not depth_rows else "INSUFFICIENT_ROWS"
        symbol_reason = ""

        if not tick_rows and not depth_rows:
            result.missing_required_fields.append(f"{symbol}:tick_or_depth_input")
            symbol_reason = f"No tick or depth input rows found for {symbol} {feature_day}."
        elif not filtered.tick_rows and not filtered.depth_rows:
            symbol_reason = (
                f"NO_REAL_ROWS_AFTER_FILTER: no usable real Kite rows remained for {symbol} {feature_day} "
                "after default real-only filtering."
            )
            result.missing_required_fields.append(f"{symbol}:real_kite_rows")
        elif len(filtered.depth_rows) >= 2:
            if not filtered.tick_rows:
                result.warnings.append(f"No usable real Kite tick rows found for {symbol} {feature_day}; volume/price-derived features defaulted to 0.")
            elif _volume_missing_or_zero(filtered.tick_rows):
                result.warnings.append(f"Missing volume data for {symbol} {feature_day}; volume_burst may be 0.")
            features = calculate_orderflow_lite_features(symbol, filtered.depth_rows, filtered.tick_rows)
            symbol_mode = "DEPTH_ORDERFLOW_LITE"
            symbol_status = "FULL_DEPTH"
            if not features:
                symbol_reason = f"INSUFFICIENT_REAL_ROWS: real depth rows existed for {symbol}, but no feature rows could be generated."
        elif len(filtered.tick_rows) >= 2:
            result.warnings.append(f"No usable real Kite depth rows found for {symbol} {feature_day}; generated quote-lite features only.")
            if _volume_missing_or_zero(filtered.tick_rows):
                result.warnings.append(f"Missing volume data for {symbol} {feature_day}; quote-lite has_volume_traded=false.")
                symbol_status = "PARTIAL_QUOTE"
            else:
                symbol_status = "QUOTE_ONLY"
            features = calculate_quote_lite_features(symbol, filtered.tick_rows)
            symbol_mode = "QUOTE_LITE"
            if not features:
                symbol_reason = f"INSUFFICIENT_REAL_ROWS: quote-lite rows existed for {symbol}, but no feature rows could be generated."
        else:
            real_rows = len(filtered.tick_rows) + len(filtered.depth_rows)
            symbol_reason = (
                f"INSUFFICIENT_REAL_ROWS: only {real_rows} usable real Kite row(s) remained for {symbol} {feature_day}; "
                "need at least 2 real tick rows for QUOTE_LITE or 2 real depth rows for DEPTH_ORDERFLOW_LITE."
            )
            symbol_status = "INSUFFICIENT_ROWS"

        if features:
            _set_feature_status(result, symbol_mode, symbol_status)
        else:
            _set_feature_status(result, "NO_FEATURES", symbol_status)
            if symbol_reason:
                result.zero_feature_reason = _append_reason(result.zero_feature_reason, symbol_reason)

        output_real_contracts = count_real_contracts(features)
        result.output_real_contract_count = max(result.output_real_contract_count, output_real_contracts)
        if features and filtered.contract_decision and not allow_mixed_contracts:
            selected_key = filtered.contract_decision.selected_key
            if selected_key is None or any(contract_key(row) != selected_key for row in features):
                result.report_csv_contract_match = False
                result.contract_consistency_status = CONTRACT_MISMATCH_INVESTIGATE
                result.contract_action_required = True
                result.warnings.append(f"Feature output contract mismatch detected for {symbol}.")
        if output_real_contracts > 1 and not allow_mixed_contracts:
            result.report_csv_contract_match = False
            result.contract_consistency_status = CONTRACT_MISMATCH_INVESTIGATE
            result.contract_action_required = True
            result.warnings.append(f"Feature output contained multiple real contracts for {symbol}.")

        saved = save_rows_overwrite(output_path, ORDERFLOW_LITE_COLUMNS, features)
        result.rows_generated += saved.rows_written
        result.stale_output_rows_removed += saved.rows_removed
        result.output_csv_data_rows += saved.rows_written
        result.files.append(saved.path)

    if result.rows_generated == 0 and not result.zero_feature_reason:
        result.zero_feature_reason = "No feature rows were generated."
    if result.output_csv_data_rows != result.rows_generated:
        result.errors.append("Feature output row count mismatch after rebuild.")
    _write_feature_report(base, result)
    print(f"Tick rows loaded: {result.tick_rows_loaded}")
    print(f"Depth rows loaded: {result.depth_rows_loaded}")
    print(f"Real tick rows used: {result.real_tick_rows_used}")
    print(f"Real depth rows used: {result.real_depth_rows_used}")
    print(f"Synthetic/dry-run rows ignored: {result.synthetic_rows_ignored}")
    print(f"Stale output rows removed: {result.stale_output_rows_removed}")
    print(f"Output CSV data row count: {result.output_csv_data_rows}")
    print(f"Feature mode: {result.feature_mode}")
    print(f"Market data status: {result.market_data_status}")
    print(f"Contract consistency status: {result.contract_consistency_status}")
    print(f"Selected contract: {result.selected_contract or 'NONE'}")
    print("Ignored contracts: " + ("; ".join(result.ignored_contracts) if result.ignored_contracts else "NONE"))
    print("Synthetic/dry-run contracts ignored: " + ("; ".join(result.synthetic_contracts_ignored) if result.synthetic_contracts_ignored else "NONE"))
    print(f"Contract action required: {str(result.contract_action_required).lower()}")
    print(f"Contract metadata complete: {str(result.contract_metadata_complete).lower()}")
    print("Missing contract fields: " + ("; ".join(result.missing_contract_fields) if result.missing_contract_fields else "NONE"))
    print(f"Expiry missing warning: {'yes' if result.expiry_missing_warning else 'no'}")
    print(f"Expiry rows enriched: {result.expiry_rows_enriched}")
    if result.rows_generated == 0:
        print(f"Reason: {result.zero_feature_reason}")
    print(f"Features generated: {result.rows_generated}")
    print(f"Report: {result.report_path}")
    print("PAPER MODE ONLY. No broker orders were placed.")
    return result


def calculate_orderflow_lite_features(
    symbol: str,
    depth_rows: list[dict[str, Any]],
    tick_rows: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    tick_rows = sorted(tick_rows or [], key=lambda row: _timestamp_sort_key(row.get("timestamp", "")))
    ticks_by_timestamp = {str(row.get("timestamp")): row for row in tick_rows}
    depth_by_timestamp: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in depth_rows:
        depth_by_timestamp[str(row.get("timestamp"))].append(row)

    previous_bid_total = 0.0
    previous_ask_total = 0.0
    previous_volume: float | None = None
    previous_oi: float | None = None
    previous_ltp: float | None = None
    prices: list[float] = []
    volume_deltas: deque[float] = deque(maxlen=20)
    cumulative_pv = 0.0
    cumulative_volume = 0.0
    output: list[dict[str, Any]] = []

    for timestamp in sorted(depth_by_timestamp, key=_timestamp_sort_key):
        rows = sorted(depth_by_timestamp[timestamp], key=lambda row: int(float(row.get("level") or 0)))
        bid_total = sum(to_float(row.get("bid_qty")) for row in rows[:5])
        ask_total = sum(to_float(row.get("ask_qty")) for row in rows[:5])
        denominator = bid_total + ask_total
        imbalance = (bid_total - ask_total) / denominator if denominator else 0.0
        best_bid = rows[0] if rows else {}
        best_ask = rows[0] if rows else {}
        spread = to_float(best_ask.get("ask_price")) - to_float(best_bid.get("bid_price"))
        bid_stack_change = bid_total - previous_bid_total
        ask_stack_change = ask_total - previous_ask_total
        depth_pull_proxy = bid_stack_change - ask_stack_change

        tick = ticks_by_timestamp.get(timestamp) or _nearest_prior_tick(timestamp, tick_rows)
        volume = to_float(tick.get("volume")) if tick else 0.0
        ltp = to_float(tick.get("ltp") or tick.get("last_price")) if tick else 0.0
        oi = to_float(tick.get("oi")) if tick else 0.0
        volume_delta = 0.0 if previous_volume is None else max(0.0, volume - previous_volume)
        average_delta = sum(volume_deltas) / len(volume_deltas) if volume_deltas else 0.0
        volume_burst = volume_delta / average_delta if average_delta > 0 else 0.0
        if volume_delta > 0 and ltp > 0:
            cumulative_volume += volume_delta
            cumulative_pv += ltp * volume_delta
        vwap = cumulative_pv / cumulative_volume if cumulative_volume > 0 else ltp
        price_vs_vwap = ltp - vwap if ltp and vwap else 0.0
        oi_change = 0.0 if previous_oi is None else oi - previous_oi
        price_change = 0.0 if previous_ltp is None or ltp <= 0 else ltp - previous_ltp
        price_change_pct = (price_change / previous_ltp * 100.0) if previous_ltp and previous_ltp > 0 else 0.0
        rolling_5 = (ltp - prices[-5]) if ltp > 0 and len(prices) >= 5 else 0.0
        rolling_10 = (ltp - prices[-10]) if ltp > 0 and len(prices) >= 10 else 0.0
        first_row = rows[0] if rows else {}

        output.append(
            {
                "timestamp": timestamp,
                "symbol": symbol,
                "internal_symbol": first_row.get("internal_symbol") or symbol,
                "kite_exchange": first_row.get("kite_exchange", ""),
                "kite_tradingsymbol": first_row.get("kite_tradingsymbol", ""),
                "instrument_token": first_row.get("instrument_token", ""),
                "expiry": first_row.get("expiry", ""),
                "data_mode": first_row.get("data_mode") or "REAL_READ_ONLY",
                "is_synthetic": first_row.get("is_synthetic") or "false",
                "last_price": round(ltp, 2) if ltp else "",
                "price_change_from_prev": round(price_change, 2),
                "price_change_pct_from_prev": round(price_change_pct, 6),
                "rolling_price_change_5": round(rolling_5, 2),
                "rolling_price_change_10": round(rolling_10, 2),
                "quote_update_count": len(output) + 1,
                "has_depth": "true",
                "has_volume_traded": "true" if volume > 0 else "false",
                "data_quality": "DEPTH_AVAILABLE",
                "feature_mode": "DEPTH_ORDERFLOW_LITE",
                "bid_qty_total_top5": round(bid_total, 2),
                "ask_qty_total_top5": round(ask_total, 2),
                "depth_imbalance": round(imbalance, 6),
                "spread": round(spread, 2),
                "bid_stack_change": round(bid_stack_change, 2),
                "ask_stack_change": round(ask_stack_change, 2),
                "depth_pull_proxy": round(depth_pull_proxy, 2),
                "volume_burst": round(volume_burst, 6),
                "price_vs_vwap": round(price_vs_vwap, 2),
                "oi_change": round(oi_change, 2),
                "source": "KITE_ORDERFLOW_LITE",
            }
        )
        previous_bid_total = bid_total
        previous_ask_total = ask_total
        previous_volume = volume
        previous_oi = oi
        if ltp > 0:
            prices.append(ltp)
            previous_ltp = ltp
        if volume_delta > 0:
            volume_deltas.append(volume_delta)
    return output


def calculate_quote_lite_features(symbol: str, tick_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    sorted_ticks = sorted(tick_rows or [], key=lambda row: _timestamp_sort_key(row.get("timestamp", "")))
    output: list[dict[str, Any]] = []
    prices: list[float] = []
    previous_ltp: float | None = None
    for row in sorted_ticks:
        ltp = to_float(row.get("ltp") or row.get("last_price"))
        if ltp <= 0:
            continue
        price_change = 0.0 if previous_ltp is None else ltp - previous_ltp
        price_change_pct = (price_change / previous_ltp * 100.0) if previous_ltp and previous_ltp > 0 else 0.0
        rolling_5 = (ltp - prices[-5]) if len(prices) >= 5 else 0.0
        rolling_10 = (ltp - prices[-10]) if len(prices) >= 10 else 0.0
        has_volume = row.get("volume") not in {None, ""} and to_float(row.get("volume")) > 0
        output.append({
            "timestamp": row.get("timestamp", ""),
            "symbol": symbol,
            "internal_symbol": row.get("internal_symbol") or symbol,
            "kite_exchange": row.get("kite_exchange", ""),
            "kite_tradingsymbol": row.get("kite_tradingsymbol", ""),
            "instrument_token": row.get("instrument_token", ""),
            "expiry": row.get("expiry", ""),
            "data_mode": row.get("data_mode") or "REAL_READ_ONLY",
            "is_synthetic": row.get("is_synthetic") or "false",
            "last_price": round(ltp, 2),
            "price_change_from_prev": round(price_change, 2),
            "price_change_pct_from_prev": round(price_change_pct, 6),
            "rolling_price_change_5": round(rolling_5, 2),
            "rolling_price_change_10": round(rolling_10, 2),
            "quote_update_count": len(output) + 1,
            "has_depth": "false",
            "has_volume_traded": "true" if has_volume else "false",
            "data_quality": "QUOTE_ONLY" if has_volume else "PARTIAL_QUOTE",
            "feature_mode": "QUOTE_LITE",
            "bid_qty_total_top5": "",
            "ask_qty_total_top5": "",
            "depth_imbalance": "",
            "spread": "",
            "bid_stack_change": "",
            "ask_stack_change": "",
            "depth_pull_proxy": "",
            "volume_burst": 0.0,
            "price_vs_vwap": 0.0,
            "oi_change": 0.0,
            "source": "KITE_QUOTE_LITE",
        })
        prices.append(ltp)
        previous_ltp = ltp
    return output


def _filter_feature_rows(
    symbol: str,
    tick_rows: list[dict[str, Any]],
    depth_rows: list[dict[str, Any]],
    *,
    include_synthetic: bool,
    allow_mixed_contracts: bool,
) -> _FilteredFeatureRows:
    decision = evaluate_contract_consistency(
        [*tick_rows, *depth_rows],
        internal_symbol=symbol,
        allow_mixed_contracts=allow_mixed_contracts,
    )
    filtered_ticks = rows_for_selected_contract(
        tick_rows,
        decision,
        include_synthetic=include_synthetic,
        allow_mixed_contracts=allow_mixed_contracts,
    )
    filtered_depth = rows_for_selected_contract(
        depth_rows,
        decision,
        include_synthetic=include_synthetic,
        allow_mixed_contracts=allow_mixed_contracts,
    )
    ignored = len(tick_rows) + len(depth_rows) - len(filtered_ticks) - len(filtered_depth)
    warnings: list[str] = []
    if decision.selected_contract:
        warnings.append(f"Contract guard selected {decision.selected_contract.display}.")
    if decision.ignored_contracts:
        warnings.append("Ignored competing real contracts: " + "; ".join(decision.ignored_contracts) + ".")
    if decision.synthetic_contracts_ignored:
        warnings.append("Synthetic/dry-run contracts ignored: " + "; ".join(decision.synthetic_contracts_ignored) + ".")
    if ignored:
        warnings.append(f"Contract guard ignored {ignored} non-selected/synthetic row(s) for {symbol}.")
    if decision.status == CONTRACT_MISMATCH_INVESTIGATE:
        warnings.append(
            f"CONTRACT_MISMATCH_INVESTIGATE: multiple real contracts were present for {symbol}; "
            "only the selected contract was written to features."
        )
    elif decision.status == MIXED_CONTRACTS_WARNING:
        warnings.append(
            f"MIXED_CONTRACTS_WARNING: multiple real contracts were explicitly allowed for {symbol}."
        )
    return _FilteredFeatureRows(
        tick_rows=filtered_ticks,
        depth_rows=filtered_depth,
        ignored_rows=ignored,
        selected_identity=decision.selected_key,
        contract_decision=decision,
        warnings=warnings,
    )

def _is_real_kite_row(row: dict[str, Any]) -> bool:
    if _is_synthetic_row(row):
        return False
    exchange = str(row.get("kite_exchange") or "").strip()
    tradingsymbol = str(row.get("kite_tradingsymbol") or "").strip()
    instrument_token = str(row.get("instrument_token") or "").strip()
    return bool(exchange and tradingsymbol and instrument_token)


def _is_synthetic_row(row: dict[str, Any]) -> bool:
    if _truthy(row.get("is_synthetic")):
        return True
    data_mode = str(row.get("data_mode") or row.get("mode") or "").strip().upper()
    if data_mode in {"DRY_RUN", "SYNTHETIC", "SIMULATED"}:
        return True
    token = _token_as_int(row.get("instrument_token"))
    return token is not None and 100000 <= token <= 999999


def _select_latest_identity(rows: list[dict[str, Any]]) -> tuple[str, str, str] | None:
    best_identity: tuple[str, str, str] | None = None
    best_sort_key: tuple[float, int] = (-1.0, -1)
    counts: dict[tuple[str, str, str], int] = defaultdict(int)
    latest: dict[tuple[str, str, str], float] = defaultdict(float)
    for row in rows:
        identity = _row_identity(row)
        if not identity:
            continue
        counts[identity] += 1
        latest[identity] = max(latest[identity], _timestamp_sort_key(row.get("timestamp", "")))
    for identity, count in counts.items():
        sort_key = (latest[identity], count)
        if sort_key > best_sort_key:
            best_identity = identity
            best_sort_key = sort_key
    return best_identity


def _row_identity(row: dict[str, Any]) -> tuple[str, str, str] | None:
    exchange = str(row.get("kite_exchange") or "").strip()
    tradingsymbol = str(row.get("kite_tradingsymbol") or "").strip()
    instrument_token = str(row.get("instrument_token") or "").strip()
    if not exchange or not tradingsymbol or not instrument_token:
        return None
    return exchange, tradingsymbol, instrument_token


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def _token_as_int(value: Any) -> int | None:
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def _nearest_prior_tick(timestamp: str, ticks: list[dict[str, Any]]) -> dict[str, Any] | None:
    target = _timestamp_sort_key(timestamp)
    prior = None
    for tick in ticks:
        tick_time = _timestamp_sort_key(tick.get("timestamp"))
        if tick_time <= target:
            prior = tick
        else:
            break
    return prior


def _timestamp_sort_key(value: Any) -> float:
    try:
        parsed = parse_timestamp(value)
    except (TypeError, ValueError):
        return 0.0
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


def _volume_missing_or_zero(rows: list[dict[str, Any]]) -> bool:
    return not rows or any(row.get("volume") in {None, ""} for row in rows) or all(to_float(row.get("volume")) == 0 for row in rows)


def _merge_contract_decision(
    result: KiteOrderFlowFeatureResult,
    decision: KiteContractConsistencyResult,
) -> None:
    priority = {
        "NOT_CHECKED": 0,
        INSUFFICIENT_CONTRACT_METADATA: 1,
        DRY_RUN_SYNTHETIC_ONLY: 2,
        CONSISTENT: 3,
        REAL_CONTRACT_SELECTED: 4,
        MIXED_CONTRACTS_WARNING: 5,
        CONTRACT_MISMATCH_INVESTIGATE: 6,
    }
    if priority.get(decision.status, 0) >= priority.get(result.contract_consistency_status, 0):
        result.contract_consistency_status = decision.status
    if decision.selected_contract:
        selected = decision.selected_contract.display
        existing = [item.strip() for item in result.selected_contract.split(" | ") if item.strip()]
        if selected not in existing:
            existing.append(selected)
        result.selected_contract = " | ".join(existing)
    result.ignored_contracts = list(dict.fromkeys([*result.ignored_contracts, *decision.ignored_contracts]))
    result.synthetic_contracts_ignored = list(
        dict.fromkeys([*result.synthetic_contracts_ignored, *decision.synthetic_contracts_ignored])
    )
    result.contract_action_required = result.contract_action_required or decision.action_required
    result.contract_metadata_complete = result.contract_metadata_complete and decision.metadata_complete
    result.missing_contract_fields = list(
        dict.fromkeys([*result.missing_contract_fields, *decision.missing_contract_fields])
    )
    result.expiry_missing_warning = result.expiry_missing_warning or decision.expiry_missing_warning


def _set_feature_status(result: KiteOrderFlowFeatureResult, feature_mode: str, market_data_status: str) -> None:
    if result.feature_mode in {"NO_FEATURES", "NOT_CHECKED"}:
        result.feature_mode = feature_mode
    elif result.feature_mode != feature_mode and feature_mode != "NO_FEATURES":
        result.feature_mode = "MIXED"
    if result.market_data_status in {"NO_INPUT", "NOT_CHECKED"}:
        result.market_data_status = market_data_status
    elif result.market_data_status != market_data_status and market_data_status != "NO_INPUT":
        if "FULL_DEPTH" in {result.market_data_status, market_data_status}:
            result.market_data_status = "FULL_DEPTH"
        else:
            result.market_data_status = "PARTIAL_QUOTE"


def _append_reason(existing: str, reason: str) -> str:
    if not existing:
        return reason
    if reason in existing:
        return existing
    return existing + " | " + reason


def _write_feature_report(base: Path, result: KiteOrderFlowFeatureResult) -> None:
    report = KiteRecordingResult(
        operation_type="feature_builder",
        features_generated=result.rows_generated,
        tick_rows_loaded=result.tick_rows_loaded,
        depth_rows_loaded=result.depth_rows_loaded,
        real_tick_rows_used=result.real_tick_rows_used,
        real_depth_rows_used=result.real_depth_rows_used,
        synthetic_rows_ignored=result.synthetic_rows_ignored,
        stale_output_rows_removed=result.stale_output_rows_removed,
        output_csv_data_rows=result.output_csv_data_rows,
        contract_consistency_status=result.contract_consistency_status,
        selected_contract=result.selected_contract,
        ignored_contracts=result.ignored_contracts,
        synthetic_contracts_ignored=result.synthetic_contracts_ignored,
        contract_action_required=result.contract_action_required,
        output_real_contract_count=result.output_real_contract_count,
        report_csv_contract_match=result.report_csv_contract_match,
        contract_metadata_complete=result.contract_metadata_complete,
        missing_contract_fields=result.missing_contract_fields,
        expiry_missing_warning=result.expiry_missing_warning,
        expiry_rows_enriched=result.expiry_rows_enriched,
        feature_mode=result.feature_mode,
        market_data_status=result.market_data_status,
        zero_feature_reason=result.zero_feature_reason,
        input_files=result.input_files,
        files=result.files,
        missing_fields=result.missing_required_fields,
        errors=result.errors,
        optional_missing_fields=result.warnings,
    )
    _write_report(base, report)
    result.report_path = report.report_path


def _parse_symbols(symbols_text: str | None) -> list[str]:
    symbols: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _parse_date(value: str | date) -> date:
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def _parse_bool(value: str | bool | None) -> bool:
    return value is True or str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build Kite OrderFlow Lite features from recorded depth/ticks.")
    parser.add_argument("--symbols", required=True)
    parser.add_argument("--date", required=True)
    parser.add_argument("--include-synthetic", default="false", help="false is the default real-only mode.")
    parser.add_argument(
        "--allow-mixed-contracts",
        default="false",
        help="false selects one real contract and flags competing contracts for investigation.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = build_kite_orderflow_lite_features(
        symbols_text=args.symbols,
        day=args.date,
        include_synthetic=_parse_bool(args.include_synthetic),
        allow_mixed_contracts=_parse_bool(args.allow_mixed_contracts),
    )
    return 0 if not result.errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
