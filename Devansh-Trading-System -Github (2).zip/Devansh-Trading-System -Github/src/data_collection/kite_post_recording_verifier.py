from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs
from src.data_collection.kite_contract_consistency import (
    contract_key,
    is_synthetic_contract_row,
)
from src.data_collection.market_data_schema import (
    kite_depth_path,
    kite_feature_path,
    kite_tick_path,
    load_csv_rows,
)


DAY_ACCEPTED_FOR_RESEARCH = "DAY_ACCEPTED_FOR_RESEARCH"
DAY_PARTIAL_BUT_KEEP = "DAY_PARTIAL_BUT_KEEP"
DAY_MARKET_CLOSED_OR_NO_DATA = "DAY_MARKET_CLOSED_OR_NO_DATA"
DAY_REQUIRES_INVESTIGATION = "DAY_REQUIRES_INVESTIGATION"
DAY_REJECTED_BAD_DATA = "DAY_REJECTED_BAD_DATA"

REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_post_recording_verifier_report.txt"
RUN_LOG_PATH = Path("reports") / "kite_daily_pipeline" / "post_recording_verifier_runs.csv"
PIPELINE_REPORT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"
DATA_COLLECTION_REPORT_PATH = Path("reports") / "kite_data_collection" / "latest_kite_data_collection_report.txt"
FORWARD_SUMMARY_PATH = Path("reports") / "forward_validation" / "latest_forward_validation_summary.txt"
RUN_LOG_COLUMNS = [
    "timestamp",
    "date",
    "symbols",
    "tick_rows",
    "depth_rows",
    "feature_rows",
    "reported_feature_rows",
    "authoritative_feature_source",
    "feature_rebuild_reconciliation_status",
    "pipeline_report_status",
    "data_collection_report_status",
    "selected_contract",
    "real_contract_count",
    "synthetic_rows_found",
    "mixed_contracts_found",
    "data_quality_status",
    "forward_validation_decision",
    "production_whatsapp_status",
    "execution_allowed",
    "verdict",
    "next_action",
]


@dataclass
class SymbolVerification:
    symbol: str
    tick_path: Path
    depth_path: Path
    feature_path: Path
    tick_rows: int = 0
    depth_rows: int = 0
    feature_rows: int = 0
    selected_contract: str = "NONE"
    real_contract_count: int = 0
    synthetic_rows_found: int = 0
    mixed_contracts_found: bool = False
    expected_contract_match: bool = True
    contract_metadata_complete: bool = True
    feature_modes: tuple[str, ...] = ()
    warnings: list[str] = field(default_factory=list)


@dataclass
class KitePostRecordingVerificationResult:
    timestamp: datetime
    day: date
    symbols: list[str]
    symbol_results: list[SymbolVerification]
    pipeline_report_exists: bool
    data_collection_report_exists: bool
    forward_summary_exists: bool
    reported_feature_rows: int | None
    data_collection_reported_feature_rows: int | None
    report_feature_count_match: bool
    data_collection_feature_count_match: bool
    authoritative_feature_source: str
    pipeline_report_status: str
    data_collection_report_status: str
    feature_rebuild_reconciliation_status: str
    pipeline_report_stale_or_failed: bool
    manual_feature_rebuild_reconciled: bool
    pipeline_data_quality_status: str
    data_collection_market_status: str
    data_collection_contract_status: str
    pipeline_contract_status: str
    forward_validation_decision: str
    production_whatsapp_status: str
    execution_allowed: str
    safety_ok: bool
    verdict: str
    next_action: str
    warnings: list[str] = field(default_factory=list)
    report_path: Path | None = None
    run_log_path: Path | None = None

    @property
    def tick_rows(self) -> int:
        return sum(item.tick_rows for item in self.symbol_results)

    @property
    def depth_rows(self) -> int:
        return sum(item.depth_rows for item in self.symbol_results)

    @property
    def feature_rows(self) -> int:
        return sum(item.feature_rows for item in self.symbol_results)

    @property
    def synthetic_rows_found(self) -> int:
        return sum(item.synthetic_rows_found for item in self.symbol_results)

    @property
    def mixed_contracts_found(self) -> bool:
        return any(item.mixed_contracts_found for item in self.symbol_results)


def verify_kite_post_recording(
    base_dir: Path | str = ".",
    *,
    symbols_text: str = "GOLD-I",
    day: str | date | None = None,
    configs: dict[str, Any] | None = None,
    now_fn: Callable[[], datetime] | None = None,
) -> KitePostRecordingVerificationResult:
    """Audit saved Kite files and reports without network or broker calls."""

    base = Path(base_dir)
    now = now_fn or (lambda: datetime.now().astimezone())
    timestamp = now()
    verify_day = _parse_date(day) if day else timestamp.date()
    symbols = _parse_symbols(symbols_text)
    pipeline_path = base / PIPELINE_REPORT_PATH
    data_collection_path = base / DATA_COLLECTION_REPORT_PATH
    forward_path = base / FORWARD_SUMMARY_PATH
    pipeline_text = _read_text(pipeline_path)
    data_collection_text = _read_text(data_collection_path)
    forward_text = _read_text(forward_path)
    configs = configs or _safe_configs(base)

    symbol_results = [_verify_symbol(base, verify_day, symbol) for symbol in symbols]
    reported_feature_rows = _extract_int(pipeline_text, "Feature output CSV data rows:")
    data_collection_reported_feature_rows = _extract_int(data_collection_text, "Output CSV data row count:")
    total_features = sum(item.feature_rows for item in symbol_results)
    report_feature_count_match = reported_feature_rows is None or reported_feature_rows == total_features
    data_collection_feature_count_match = (
        data_collection_reported_feature_rows is not None
        and data_collection_reported_feature_rows == total_features
    )
    pipeline_quality = _extract_value(pipeline_text, "status:", section="DATA QUALITY GATE") or "NOT_AVAILABLE"
    pipeline_contract = _extract_value(pipeline_text, "status:", section="CONTRACT CONSISTENCY") or "NOT_AVAILABLE"
    data_collection_market = _extract_value(data_collection_text, "Market data status:") or "NOT_AVAILABLE"
    data_collection_contract = _extract_value(data_collection_text, "Contract consistency status:") or "NOT_AVAILABLE"
    pipeline_status = _pipeline_report_status(pipeline_text, report_feature_count_match, total_features)
    data_collection_status = _data_collection_report_status(data_collection_text, data_collection_feature_count_match)
    feature_reconciliation = _feature_rebuild_reconciliation_status(
        data_collection_text=data_collection_text,
        data_collection_feature_count_match=data_collection_feature_count_match,
    )
    pipeline_stale_or_failed = pipeline_status in {"STALE_OR_FAILED", "FAILED_OR_ERROR"}
    manual_reconciled = feature_reconciliation == "RECONCILED"
    authoritative_feature_source = _authoritative_feature_source(
        report_feature_count_match=report_feature_count_match,
        pipeline_stale_or_failed=pipeline_stale_or_failed,
        manual_reconciled=manual_reconciled,
    )
    forward_decision = _extract_value(forward_text, "Approval Decision:") or "NOT_AVAILABLE"
    production_whatsapp = _production_whatsapp_status(pipeline_text, forward_text, configs)
    execution_allowed = _execution_allowed_status(pipeline_text, forward_text)
    safety_ok = _safety_ok(pipeline_text, forward_text, configs, production_whatsapp, execution_allowed)
    warnings: list[str] = []
    if reported_feature_rows is None:
        warnings.append("Pipeline report feature count was unavailable; CSV count was used.")
    if not pipeline_path.exists():
        warnings.append(f"Latest pipeline report is missing: {PIPELINE_REPORT_PATH}.")
    if not data_collection_path.exists():
        warnings.append(f"Latest data collection report is missing: {DATA_COLLECTION_REPORT_PATH}.")
    if not forward_path.exists():
        warnings.append(f"Latest forward-validation summary is missing: {FORWARD_SUMMARY_PATH}.")
    if pipeline_stale_or_failed:
        if manual_reconciled:
            warnings.append(
                "Daily pipeline report was stale/failed due to MemoryError or mismatched zero-feature output; "
                "feature output was reconciled using latest feature builder/data collection report."
            )
        else:
            warnings.append(
                "Daily pipeline report was stale/failed and no clean feature-builder reconciliation was available."
            )
        warnings.append(
            "Long continuous recorder failed with MemoryError. Prefer chunked recording until recorder "
            "streaming/chunk flushing is improved."
        )
    for item in symbol_results:
        warnings.extend(item.warnings)

    verdict, next_action = _decide_verdict(
        symbol_results=symbol_results,
        safety_ok=safety_ok,
        report_feature_count_match=report_feature_count_match,
        manual_feature_rebuild_reconciled=manual_reconciled,
        pipeline_quality=pipeline_quality,
        pipeline_contract=pipeline_contract,
        data_collection_contract=data_collection_contract,
    )
    result = KitePostRecordingVerificationResult(
        timestamp=timestamp,
        day=verify_day,
        symbols=symbols,
        symbol_results=symbol_results,
        pipeline_report_exists=pipeline_path.exists(),
        data_collection_report_exists=data_collection_path.exists(),
        forward_summary_exists=forward_path.exists(),
        reported_feature_rows=reported_feature_rows,
        data_collection_reported_feature_rows=data_collection_reported_feature_rows,
        report_feature_count_match=report_feature_count_match,
        data_collection_feature_count_match=data_collection_feature_count_match,
        authoritative_feature_source=authoritative_feature_source,
        pipeline_report_status=pipeline_status,
        data_collection_report_status=data_collection_status,
        feature_rebuild_reconciliation_status=feature_reconciliation,
        pipeline_report_stale_or_failed=pipeline_stale_or_failed,
        manual_feature_rebuild_reconciled=manual_reconciled,
        pipeline_data_quality_status=pipeline_quality,
        data_collection_market_status=data_collection_market,
        data_collection_contract_status=data_collection_contract,
        pipeline_contract_status=pipeline_contract,
        forward_validation_decision=forward_decision,
        production_whatsapp_status=production_whatsapp,
        execution_allowed=execution_allowed,
        safety_ok=safety_ok,
        verdict=verdict,
        next_action=next_action,
        warnings=warnings,
    )
    _write_report(base, result)
    _append_run_log(base, result)
    _print_summary(result)
    return result


def _verify_symbol(base: Path, day: date, symbol: str) -> SymbolVerification:
    tick_path = kite_tick_path(base, day, symbol)
    depth_path = kite_depth_path(base, day, symbol)
    feature_path = kite_feature_path(base, day, symbol)
    ticks = load_csv_rows(tick_path)
    depth = load_csv_rows(depth_path)
    features = load_csv_rows(feature_path)
    real_keys = {
        key for row in features
        if (key := contract_key(row)) is not None and not is_synthetic_contract_row(row)
    }
    synthetic_rows = sum(1 for row in features if is_synthetic_contract_row(row))
    selected_contract = "NONE"
    metadata_complete = True
    if len(real_keys) == 1:
        exchange, tradingsymbol, token = next(iter(real_keys))
        matching = next(row for row in features if contract_key(row) == (exchange, tradingsymbol, token))
        expiry = str(matching.get("expiry") or "").strip() or "UNKNOWN"
        selected_contract = (
            f"{symbol}:{exchange}:{tradingsymbol} instrument_token={token} expiry={expiry}"
        )
        metadata_complete = expiry != "UNKNOWN"
    expected_match = _expected_contract_match(symbol, day, real_keys, features)
    modes = tuple(sorted({
        str(row.get("feature_mode") or "").strip()
        for row in features
        if str(row.get("feature_mode") or "").strip()
    }))
    warnings: list[str] = []
    if not tick_path.exists():
        warnings.append(f"{symbol}: tick file missing.")
    if not depth_path.exists():
        warnings.append(f"{symbol}: depth file missing.")
    if not feature_path.exists():
        warnings.append(f"{symbol}: feature file missing.")
    if synthetic_rows:
        warnings.append(f"{symbol}: {synthetic_rows} synthetic row(s) found in real feature output.")
    if len(real_keys) > 1:
        warnings.append(f"{symbol}: multiple real contracts found in feature output.")
    if real_keys and not expected_match:
        warnings.append(f"{symbol}: selected real contract does not match expected contract metadata.")
    if real_keys and not metadata_complete:
        warnings.append(f"{symbol}: selected contract expiry metadata is incomplete.")
    return SymbolVerification(
        symbol=symbol,
        tick_path=tick_path,
        depth_path=depth_path,
        feature_path=feature_path,
        tick_rows=len(ticks),
        depth_rows=len(depth),
        feature_rows=len(features),
        selected_contract=selected_contract,
        real_contract_count=len(real_keys),
        synthetic_rows_found=synthetic_rows,
        mixed_contracts_found=len(real_keys) > 1,
        expected_contract_match=expected_match,
        contract_metadata_complete=metadata_complete,
        feature_modes=modes,
        warnings=warnings,
    )


def _expected_contract_match(
    symbol: str,
    day: date,
    real_keys: set[tuple[str, str, str]],
    feature_rows: list[dict[str, str]],
) -> bool:
    if not real_keys:
        return True
    if len(real_keys) != 1:
        return False
    exchange, tradingsymbol, _token = next(iter(real_keys))
    expected_root = symbol.upper().replace("-I", "")
    if exchange != "MCX" or not tradingsymbol.upper().startswith(expected_root) or not tradingsymbol.upper().endswith("FUT"):
        return False
    expiry_values = {
        str(row.get("expiry") or "").strip()
        for row in feature_rows
        if contract_key(row) == (exchange, tradingsymbol, _token)
    }
    if not expiry_values or "" in expiry_values:
        return False
    try:
        return all(date.fromisoformat(expiry) >= day for expiry in expiry_values)
    except ValueError:
        return False


def _decide_verdict(
    *,
    symbol_results: list[SymbolVerification],
    safety_ok: bool,
    report_feature_count_match: bool,
    manual_feature_rebuild_reconciled: bool,
    pipeline_quality: str,
    pipeline_contract: str,
    data_collection_contract: str,
) -> tuple[str, str]:
    if not safety_ok:
        return (
            DAY_REJECTED_BAD_DATA,
            "Restore PAPER/no-order safety flags and regenerate trusted reports before using this day.",
        )
    if not report_feature_count_match and not manual_feature_rebuild_reconciled:
        return (
            DAY_REQUIRES_INVESTIGATION,
            "Rebuild the feature CSV and reconcile its data-row count with a trusted pipeline or feature-builder report.",
        )
    if (
        pipeline_contract == "CONTRACT_MISMATCH_INVESTIGATE"
        or data_collection_contract == "CONTRACT_MISMATCH_INVESTIGATE"
    ):
        return (
            DAY_REQUIRES_INVESTIGATION,
            "Resolve the reported contract mismatch and rebuild single-contract features.",
        )
    if any(
        item.synthetic_rows_found
        or item.mixed_contracts_found
        or not item.expected_contract_match
        for item in symbol_results
    ):
        return (
            DAY_REQUIRES_INVESTIGATION,
            "Remove synthetic/mixed/unexpected contract rows and rebuild deterministic real-only features.",
        )
    if sum(item.tick_rows for item in symbol_results) == 0:
        return (
            DAY_MARKET_CLOSED_OR_NO_DATA,
            "Confirm market hours, token, internet, and resolved contract; retain the report if the market was closed.",
        )
    if sum(item.feature_rows for item in symbol_results) == 0:
        if pipeline_quality in {"FEATURE_GENERATION_PROBLEM", "INVESTIGATE_BEFORE_NEXT_RUN"}:
            return (
                DAY_REQUIRES_INVESTIGATION,
                "Inspect the zero-feature reason and rebuild features without deleting the recorded ticks.",
            )
        return (
            DAY_PARTIAL_BUT_KEEP,
            "Keep the tick/depth files and run the deterministic feature builder again.",
        )
    if any(item.depth_rows == 0 or "QUOTE_LITE" in item.feature_modes for item in symbol_results):
        return (
            DAY_PARTIAL_BUT_KEEP,
            "Keep the quote-only data, but collect full depth before treating the day as professional orderflow evidence.",
        )
    return (
        DAY_ACCEPTED_FOR_RESEARCH,
        "Archive the day, update forward-validation research, and continue collecting additional sessions.",
    )


def _write_report(base: Path, result: KitePostRecordingVerificationResult) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "KITE POST-RECORDING VERIFIER REPORT",
        f"Generated: {result.timestamp.isoformat()}",
        f"Date: {result.day.isoformat()}",
        f"Symbols: {', '.join(result.symbols) if result.symbols else 'NONE'}",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
        "FILE AND ROW CHECKS",
    ]
    for item in result.symbol_results:
        lines.extend(
            [
                f"Symbol: {item.symbol}",
                f"Tick file: {item.tick_path} | exists={str(item.tick_path.exists()).lower()} | rows={item.tick_rows}",
                f"Depth file: {item.depth_path} | exists={str(item.depth_path.exists()).lower()} | rows={item.depth_rows}",
                f"Feature file: {item.feature_path} | exists={str(item.feature_path.exists()).lower()} | rows={item.feature_rows}",
                f"Selected contract: {item.selected_contract}",
                f"Real contract count: {item.real_contract_count}",
                f"Synthetic rows found: {item.synthetic_rows_found}",
                f"Mixed contracts found: {str(item.mixed_contracts_found).lower()}",
                f"Expected contract match: {str(item.expected_contract_match).lower()}",
                f"Contract metadata complete: {str(item.contract_metadata_complete).lower()}",
                f"Feature modes: {','.join(item.feature_modes) if item.feature_modes else 'NONE'}",
                "",
            ]
        )
    lines.extend(
        [
            "REPORT CROSS-CHECKS",
            f"Latest pipeline report exists: {str(result.pipeline_report_exists).lower()}",
            f"Latest data collection report exists: {str(result.data_collection_report_exists).lower()}",
            f"Latest forward summary exists: {str(result.forward_summary_exists).lower()}",
            f"Pipeline reported feature rows: {result.reported_feature_rows if result.reported_feature_rows is not None else 'NOT_AVAILABLE'}",
            f"Data collection reported feature rows: {result.data_collection_reported_feature_rows if result.data_collection_reported_feature_rows is not None else 'NOT_AVAILABLE'}",
            f"Actual feature rows: {result.feature_rows}",
            f"Pipeline report/CSV feature count match: {str(result.report_feature_count_match).lower()}",
            f"Data collection report/CSV feature count match: {str(result.data_collection_feature_count_match).lower()}",
            f"Pipeline report status: {result.pipeline_report_status}",
            f"Data collection report status: {result.data_collection_report_status}",
            f"Feature rebuild reconciliation status: {result.feature_rebuild_reconciliation_status}",
            f"Authoritative feature source used: {result.authoritative_feature_source}",
            f"Pipeline report stale/failed: {str(result.pipeline_report_stale_or_failed).lower()}",
            f"Manual feature rebuild reconciled day: {str(result.manual_feature_rebuild_reconciled).lower()}",
            f"Pipeline contract status: {result.pipeline_contract_status}",
            f"Data collection contract status: {result.data_collection_contract_status}",
            f"Data collection market data status: {result.data_collection_market_status}",
            f"Data Quality Gate status: {result.pipeline_data_quality_status}",
            f"Forward validation decision: {result.forward_validation_decision}",
            f"Production WhatsApp status: {result.production_whatsapp_status}",
            f"execution_allowed: {result.execution_allowed}",
            "",
            f"VERDICT: {result.verdict}",
            f"Next action: {result.next_action}",
            "",
            "WARNINGS",
            *([f"- {warning}" for warning in result.warnings] if result.warnings else ["NONE"]),
            "",
            "SAFETY CONFIRMATION",
            f"Safety checks passed: {str(result.safety_ok).lower()}",
            "Production WhatsApp Alerts: BLOCKED",
            "PAPER MODE ONLY. Data verification only.",
            "No broker orders were placed.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _append_run_log(base: Path, result: KitePostRecordingVerificationResult) -> None:
    path = base / RUN_LOG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    row = {
        "timestamp": result.timestamp.isoformat(),
        "date": result.day.isoformat(),
        "symbols": ",".join(result.symbols),
        "tick_rows": result.tick_rows,
        "depth_rows": result.depth_rows,
        "feature_rows": result.feature_rows,
        "reported_feature_rows": result.reported_feature_rows if result.reported_feature_rows is not None else "",
        "authoritative_feature_source": result.authoritative_feature_source,
        "feature_rebuild_reconciliation_status": result.feature_rebuild_reconciliation_status,
        "pipeline_report_status": result.pipeline_report_status,
        "data_collection_report_status": result.data_collection_report_status,
        "selected_contract": " | ".join(item.selected_contract for item in result.symbol_results),
        "real_contract_count": sum(item.real_contract_count for item in result.symbol_results),
        "synthetic_rows_found": result.synthetic_rows_found,
        "mixed_contracts_found": str(result.mixed_contracts_found).lower(),
        "data_quality_status": result.pipeline_data_quality_status,
        "forward_validation_decision": result.forward_validation_decision,
        "production_whatsapp_status": result.production_whatsapp_status,
        "execution_allowed": "false",
        "verdict": result.verdict,
        "next_action": result.next_action,
    }
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=RUN_LOG_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    result.run_log_path = path


def _print_summary(result: KitePostRecordingVerificationResult) -> None:
    print("KITE POST-RECORDING VERIFIER")
    print(f"Date: {result.day.isoformat()}")
    print(f"Symbols: {', '.join(result.symbols) if result.symbols else 'NONE'}")
    print(f"Tick rows: {result.tick_rows}")
    print(f"Depth rows: {result.depth_rows}")
    print(f"Feature rows: {result.feature_rows}")
    for item in result.symbol_results:
        print(f"Selected Contract ({item.symbol}): {item.selected_contract}")
    print(f"Synthetic rows found: {result.synthetic_rows_found}")
    print(f"Mixed contracts found: {str(result.mixed_contracts_found).lower()}")
    print(f"Data Quality Gate: {result.pipeline_data_quality_status}")
    print(f"Pipeline Report Status: {result.pipeline_report_status}")
    print(f"Data Collection Report Status: {result.data_collection_report_status}")
    print(f"Feature Rebuild Reconciliation: {result.feature_rebuild_reconciliation_status}")
    print(f"Authoritative Feature Source: {result.authoritative_feature_source}")
    print(f"Forward Validation: {result.forward_validation_decision}")
    print(f"Verdict: {result.verdict}")
    print(f"Next Action: {result.next_action}")
    print(f"Report: {result.report_path}")
    print(f"Run Log: {result.run_log_path}")
    print("execution_allowed=false")
    print("PAPER MODE ONLY. No broker orders were placed.")


def _safety_ok(
    pipeline_text: str,
    forward_text: str,
    configs: dict[str, Any],
    production_whatsapp: str,
    execution_allowed: str,
) -> bool:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    text = pipeline_text + "\n" + forward_text
    return all(
        [
            str(settings.get("mode", "PAPER")).upper() == "PAPER",
            not bool(settings.get("enable_live_trading", False)),
            not bool(forward.get("production_alerts_allowed", False)),
            "Live Trading: DISABLED" in text,
            "Broker Orders: DISABLED" in text,
            execution_allowed == "false",
            production_whatsapp == "BLOCKED",
        ]
    )


def _production_whatsapp_status(
    pipeline_text: str,
    forward_text: str,
    configs: dict[str, Any],
) -> str:
    text = pipeline_text + "\n" + forward_text
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    statuses: list[str] = []
    for line in text.splitlines():
        upper_line = line.strip().upper()
        if upper_line.startswith("PRODUCTION WHATSAPP"):
            if "ALLOWED" in upper_line:
                statuses.append("ALLOWED")
            elif "BLOCKED" in upper_line:
                statuses.append("BLOCKED")
    if "ALLOWED" in statuses:
        return "ALLOWED"
    if "BLOCKED" in statuses and not bool(forward.get("production_alerts_allowed", False)):
        return "BLOCKED"
    return "UNKNOWN_OR_ALLOWED"


def _execution_allowed_status(pipeline_text: str, forward_text: str) -> str:
    text = (pipeline_text + "\n" + forward_text).lower()
    if "execution_allowed=true" in text:
        return "true"
    return "false" if "execution_allowed=false" in text else "UNKNOWN"


def _pipeline_report_status(
    pipeline_text: str,
    report_feature_count_match: bool,
    actual_feature_rows: int,
) -> str:
    if not pipeline_text.strip():
        return "MISSING"
    upper = pipeline_text.upper()
    reported_rows = _extract_int(pipeline_text, "Feature output CSV data rows:")
    has_errors = "ERRORS\nNONE" not in upper and "ERRORS" in upper
    recorder_failed = "- RECORDER: FAIL" in upper or "RECORDER: FAIL" in upper
    memory_error = "MEMORYERROR" in upper
    stale_zero = reported_rows == 0 and actual_feature_rows > 0
    if has_errors or recorder_failed or memory_error:
        return "STALE_OR_FAILED" if stale_zero or not report_feature_count_match else "FAILED_OR_ERROR"
    if not report_feature_count_match:
        return "STALE_OR_FAILED"
    return "CURRENT"


def _data_collection_report_status(
    data_collection_text: str,
    data_collection_feature_count_match: bool,
) -> str:
    if not data_collection_text.strip():
        return "MISSING"
    if _clean_feature_builder_report(
        data_collection_text,
        data_collection_feature_count_match=data_collection_feature_count_match,
    ):
        return "CLEAN_FEATURE_BUILDER_REPORT"
    if _extract_value(data_collection_text, "Errors:").upper() not in {"", "NONE"}:
        return "ERROR"
    return "NOT_AUTHORITATIVE"


def _feature_rebuild_reconciliation_status(
    *,
    data_collection_text: str,
    data_collection_feature_count_match: bool,
) -> str:
    return (
        "RECONCILED"
        if _clean_feature_builder_report(
            data_collection_text,
            data_collection_feature_count_match=data_collection_feature_count_match,
        )
        else "NOT_RECONCILED"
    )


def _authoritative_feature_source(
    *,
    report_feature_count_match: bool,
    pipeline_stale_or_failed: bool,
    manual_reconciled: bool,
) -> str:
    if manual_reconciled and (pipeline_stale_or_failed or not report_feature_count_match):
        return "DATA_COLLECTION_FEATURE_BUILDER_REPORT"
    if report_feature_count_match and not pipeline_stale_or_failed:
        return "PIPELINE_REPORT"
    return "ACTUAL_CSV_ONLY"


def _clean_feature_builder_report(
    data_collection_text: str,
    *,
    data_collection_feature_count_match: bool,
) -> bool:
    if not data_collection_text.strip():
        return False
    last_operation = _extract_value(data_collection_text, "Last operation type:").lower()
    features = _extract_int(data_collection_text, "Features generated in last operation:") or 0
    tick_rows = _extract_int(data_collection_text, "Tick rows loaded:") or 0
    depth_rows = _extract_int(data_collection_text, "Depth rows loaded:") or 0
    market_status = _extract_value(data_collection_text, "Market data status:").upper()
    contract_status = _extract_value(data_collection_text, "Contract consistency status:").upper()
    contract_match = _extract_value(data_collection_text, "Report/CSV contract match:").lower()
    metadata_complete = _extract_value(data_collection_text, "Contract metadata complete:").lower()
    errors = _extract_value(data_collection_text, "Errors:").upper()
    return all(
        [
            last_operation == "feature_builder",
            features > 0,
            tick_rows > 0,
            depth_rows > 0,
            market_status in {"FULL_DEPTH", "RECORDED"},
            contract_status == "CONSISTENT",
            contract_match == "true",
            metadata_complete == "true",
            errors == "NONE",
            data_collection_feature_count_match,
        ]
    )


def _extract_value(text: str, prefix: str, *, section: str | None = None) -> str:
    source = text
    if section:
        marker = section + "\n"
        if marker not in text:
            return ""
        source = text.split(marker, 1)[1]
        source = source.split("\n\n", 1)[0]
    for line in source.splitlines():
        if line.strip().startswith(prefix):
            return line.split(prefix, 1)[1].strip()
    return ""


def _extract_int(text: str, prefix: str) -> int | None:
    value = _extract_value(text, prefix)
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _safe_configs(base: Path) -> dict[str, Any]:
    try:
        return load_configs(base)
    except (FileNotFoundError, OSError):
        return {
            "settings": {"mode": "PAPER", "enable_live_trading": False},
            "forward_validation": {"production_alerts_allowed": False},
        }


def _parse_date(value: str | date) -> date:
    return value if isinstance(value, date) else date.fromisoformat(str(value))


def _parse_symbols(symbols_text: str | None) -> list[str]:
    output: list[str] = []
    for raw in (symbols_text or "").split(","):
        symbol = raw.strip()
        if symbol and symbol not in output:
            output.append(symbol)
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Audit saved Kite recording files. No network calls.")
    parser.add_argument("--symbols", default="GOLD-I")
    parser.add_argument("--date")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = verify_kite_post_recording(symbols_text=args.symbols, day=args.date)
    return 1 if result.verdict == DAY_REJECTED_BAD_DATA else 0


if __name__ == "__main__":
    raise SystemExit(main())
