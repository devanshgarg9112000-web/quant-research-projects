from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


REPORT_PATH = Path("reports") / "strategy_audits" / "latest_vwap_family_backtest_bias_audit.txt"


@dataclass(frozen=True)
class BiasAuditResult:
    report_path: Path
    approval_ready: bool
    bias_risk: str
    fill_realism_risk: str
    cost_slippage_completeness: str
    evidence_trust_level: str
    findings_count: int


def generate_vwap_family_backtest_bias_audit(
    base_dir: Path | str = ".",
    *,
    now: datetime | None = None,
) -> BiasAuditResult:
    """Create a local-file-only audit of VWAP family backtest/research realism.

    This report performs no live data, broker, alert, approval, or order action.
    """

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    evidence = _collect_evidence(base)
    findings = _build_findings(evidence)
    report = _format_report(timestamp, evidence, findings)
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report + "\n", encoding="utf-8")
    return BiasAuditResult(
        report_path=report_path,
        approval_ready=False,
        bias_risk="MEDIUM",
        fill_realism_risk="HIGH",
        cost_slippage_completeness="PARTIAL",
        evidence_trust_level="LOW",
        findings_count=len(findings),
    )


def _collect_evidence(base: Path) -> dict[str, Any]:
    backtest_code = _read_text(base / "src" / "backtesting" / "strategy_backtest_runner.py")
    deep_dive_code = _read_text(base / "src" / "research" / "vwap_rejection_deep_dive.py")
    forward_code = _read_text(base / "src" / "research" / "forward_validation.py")
    return {
        "vwap_rejection_code": _read_text(base / "src" / "strategies" / "vwap_rejection.py"),
        "vwap_reclaim_code": _read_text(base / "src" / "strategies" / "vwap_reclaim.py"),
        "trend_day_vwap_pullback_code": _read_text(base / "src" / "strategies" / "trend_day_vwap_pullback.py"),
        "backtest_code": backtest_code,
        "deep_dive_code": deep_dive_code,
        "forward_code": forward_code,
        "spec_report": _read_text(base / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt"),
        "identity_report": _read_text(base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt"),
        "deep_dive_report": _read_text(base / "reports" / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.txt"),
        "forward_report": _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"),
        "approval_report": _read_text(base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv"),
        "has_entry_delay": "entry_delay_ticks" in backtest_code,
        "has_backtest_slippage": "slippage_points" in backtest_code,
        "has_backtest_cost": "cost_per_trade" in backtest_code,
        "has_deep_dive_slippage": "SLIPPAGE_POINTS" in deep_dive_code,
        "has_deep_dive_cost": "COST_PER_TRADE" in deep_dive_code,
        "forward_decision": _extract_prefixed_value(
            _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"),
            "Approval Decision:",
        )
        or "RESEARCH_ONLY",
        "forward_trades": _extract_metric(
            _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"),
            "Forward/replay-recorded trades:",
            "trades",
        )
        or "0",
        "forward_pf": _extract_metric(
            _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"),
            "Forward/replay-recorded trades:",
            "PF",
        )
        or "UNKNOWN",
        "approved_strategy_count": _count_csv_status(
            _read_text(base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv"),
            "APPROVED",
        ),
    }


def _build_findings(evidence: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {
            "finding_id": "VWAP-AUDIT-001",
            "severity": "HIGH",
            "area": "sample_size",
            "finding": "Forward validation sample is below approval-review size.",
            "evidence": "reports/forward_validation/latest_forward_validation_summary.txt",
            "impact": "Positive PF cannot be trusted as approval-grade evidence.",
            "recommended_fix": "Collect at least the configured minimum forward sample before any WATCHLIST review.",
        },
        {
            "finding_id": "VWAP-AUDIT-002",
            "severity": "HIGH",
            "area": "fill_realism",
            "finding": "Module signal entries occur at the rejecting/reclaim candle close, while research variants mention delayed/future-bar assumptions.",
            "evidence": "src/strategies/vwap_rejection.py; reports/strategy_specs/latest_gold_vwap_family_spec_report.txt",
            "impact": "Evidence from one timing model can overstate live tradability if applied to another model.",
            "recommended_fix": "Standardize signal timing as signal candle close to next candle open or next available quote.",
        },
        {
            "finding_id": "VWAP-AUDIT-003",
            "severity": "MEDIUM",
            "area": "lookahead_bias",
            "finding": "Current standalone VWAP modules use available candle history only, but research/backtest simulations use future data for entry/exit outcome after the signal.",
            "evidence": "src/strategies/vwap_rejection.py; src/research/vwap_rejection_deep_dive.py; src/backtesting/strategy_backtest_runner.py",
            "impact": "Future bars are valid for outcome simulation only, not for deciding signal eligibility or same-bar fills.",
            "recommended_fix": "Document signal-time cutoff and assert no future rows influence entry conditions.",
        },
        {
            "finding_id": "VWAP-AUDIT-004",
            "severity": "MEDIUM",
            "area": "cost_slippage",
            "finding": "Backtest engine has cost/slippage controls and deep-dive constants, but defaults can be zero in generic runner unless explicitly supplied.",
            "evidence": "src/backtesting/strategy_backtest_runner.py; src/research/vwap_rejection_deep_dive.py",
            "impact": "Some reported strategy rows may be conservative, while others may be incomplete or not comparable.",
            "recommended_fix": "Require non-zero conservative cost, slippage, and spread assumptions in all approval backtests.",
        },
        {
            "finding_id": "VWAP-AUDIT-005",
            "severity": "HIGH",
            "area": "stop_target_execution",
            "finding": "Stop/target simulation uses bar or tick path assumptions; ambiguous same-bar order of stop/target is still a realism risk.",
            "evidence": "src/research/vwap_rejection_deep_dive.py; src/backtesting/strategy_backtest_runner.py",
            "impact": "Optimistic or inconsistent exit ordering can inflate win rate/PF.",
            "recommended_fix": "Use conservative same-bar assumptions and next-available quote/tick execution rules.",
        },
        {
            "finding_id": "VWAP-AUDIT-006",
            "severity": "MEDIUM",
            "area": "identity_mismatch",
            "finding": "VWAP evidence is fragmented across vwap_rejection, vwap_rejection_short, gold_vwap_rejection_short, vwap_reclaim, and vwap_reclaim_long.",
            "evidence": "reports/strategy_identity/latest_strategy_identity_report.txt",
            "impact": "Evidence from a research alias may be accidentally interpreted as production approval.",
            "recommended_fix": "Lock one canonical family and one canonical setup ID before approval testing.",
        },
        {
            "finding_id": "VWAP-AUDIT-007",
            "severity": "HIGH",
            "area": "approval_status",
            "finding": "Reports can show WATCHLIST-like research labels, but forward validation remains RESEARCH_ONLY and approved strategy count is zero.",
            "evidence": "reports/strategy_research; reports/forward_validation; reports/strategy_verification",
            "impact": "Research labels must not unlock production alerts or manual real-money approval.",
            "recommended_fix": "Keep production alerts blocked until manual approval rules are met.",
        },
    ]


def _format_report(timestamp: datetime, evidence: dict[str, Any], findings: list[dict[str, str]]) -> str:
    lines = [
        "GOLD-I VWAP FAMILY BACKTEST BIAS AUDIT",
        f"Generated At: {timestamp.isoformat()}",
        "Recommended Codex Level Used: High",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "Real Money Approval: false",
        "",
        "EXECUTIVE VERDICT",
        "VWAP_FAMILY_BACKTEST_APPROVAL_READY: false",
        "Bias risk: MEDIUM",
        "Fill realism risk: HIGH",
        "Cost/slippage completeness: PARTIAL",
        "Evidence trust level: LOW",
        "Reason: the family is promising enough for research, but not approval-ready because sample size, identity fragmentation, and fill/timing realism are unresolved.",
        "",
        "LOOKAHEAD / FUTURE-BAR AUDIT",
        "1. VWAP Rejection Short module entry: no future candles are required for the signal condition; it uses the latest completed candle and VWAP history available at that point.",
        "2. VWAP Reclaim Long module entry: no future candles are required for the signal condition; it compares previous and latest candle against VWAP.",
        "3. Research/backtest variants: future bars/ticks are used for simulated entry/exit outcomes after signal time; this is acceptable only if clearly separated from signal generation.",
        "4. Required guard: signal candle close must be treated as decision time, with entry at next candle open or next available quote/tick.",
        "",
        "FILL REALISM AUDIT",
        "Entries at candle close are easy to overstate in live manual trading; next available quote/open is safer.",
        "Stop/target fills need conservative handling when both could occur inside the same bar.",
        "MCX/GOLD tick size/liquidity is not yet proven as a complete approval-grade fill model for this VWAP family.",
        "",
        "COST / SLIPPAGE / SPREAD AUDIT",
        f"Backtest engine has slippage controls: {str(evidence['has_backtest_slippage']).lower()}",
        f"Backtest engine has cost controls: {str(evidence['has_backtest_cost']).lower()}",
        f"Backtest engine has entry delay controls: {str(evidence['has_entry_delay']).lower()}",
        f"Deep-dive has slippage constant: {str(evidence['has_deep_dive_slippage']).lower()}",
        f"Deep-dive has cost constant: {str(evidence['has_deep_dive_cost']).lower()}",
        "Completeness: PARTIAL because controls exist, but approval backtests must enforce conservative non-zero assumptions consistently.",
        "",
        "EVIDENCE SUMMARY",
        f"Forward validation decision: {evidence['forward_decision']}",
        f"Forward trades count: {evidence['forward_trades']}",
        f"Forward profit factor: {evidence['forward_pf']}",
        f"Approved strategy count: {evidence['approved_strategy_count']}",
        "Forward validation independent from research/backtest: PARTIAL/LOW confidence because current sample is small and historical/replay evidence is still closely related.",
        "Evidence trustworthy: module signal-condition reading and safety status.",
        "Evidence discounted: low-sample PF, WATCHLIST-like labels, and any result relying on ambiguous fills or alias mixing.",
        "",
        "FINDINGS TABLE",
        "finding_id | severity | area | finding | evidence/file | impact | recommended fix",
    ]
    for finding in findings:
        lines.append(
            " | ".join(
                [
                    finding["finding_id"],
                    finding["severity"],
                    finding["area"],
                    finding["finding"],
                    finding["evidence"],
                    finding["impact"],
                    finding["recommended_fix"],
                ]
            )
        )
    lines.extend(
        [
            "",
            "SPECIFIC CONCLUSIONS",
            "VWAP Rejection Short: not approval-ready. The standalone signal appears non-lookahead, but research/backtest fill timing and sample size keep it research-only.",
            "VWAP Reclaim Long: not approval-ready. Research/watchlist-like evidence exists, but no dedicated forward-validation path is approval-grade.",
            "Trend-day VWAP Pullback: not approval-ready. It overlaps the family and must be separated or consolidated before evidence can be trusted.",
            "",
            "APPROVAL STATUS WARNING",
            "WATCHLIST-like research labels do not unlock production alerts.",
            "Forward validation remains RESEARCH_ONLY.",
            "Real-money approval remains false.",
            "",
            "RECOMMENDED NEXT 5 FIXES",
            "1. Standardize trade timing: signal candle close -> next candle open/next available quote entry.",
            "2. Add explicit cost/slippage/spread model and require it for approval-grade runs.",
            "3. Ensure no future data is used before signal time with tests around signal-time cutoff.",
            "4. Re-run backtests with conservative fills and same-bar stop-first assumptions.",
            "5. Expand forward validation before any signal approval.",
            "",
            "SAFETY SECTION",
            "No live data used.",
            "No broker orders.",
            "No production WhatsApp.",
            "execution_allowed=false.",
            "Real-money trading remains 0% approved.",
            "No strategy, approval, alert, or order logic was changed.",
        ]
    )
    return "\n".join(lines)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _extract_prefixed_value(text: str, prefix: str) -> str:
    for line in text.splitlines():
        if line.lower().startswith(prefix.lower()):
            return line.split(":", 1)[1].strip()
    return ""


def _extract_metric(text: str, line_prefix: str, metric_name: str) -> str:
    for line in text.splitlines():
        if not line.startswith(line_prefix):
            continue
        prefix = metric_name + "="
        for part in line.replace(",", " ").split():
            if part.startswith(prefix):
                return part.split("=", 1)[1]
    return ""


def _count_csv_status(text: str, status: str) -> int:
    if not text.strip():
        return 0
    lines = text.splitlines()
    if len(lines) < 2:
        return 0
    header = [item.strip() for item in lines[0].split(",")]
    try:
        status_index = header.index("status")
    except ValueError:
        return 0
    count = 0
    for line in lines[1:]:
        columns = line.split(",")
        if len(columns) > status_index and columns[status_index].strip().upper() == status.upper():
            count += 1
    return count


def build_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(
        description="Create a local-file-only audit of GOLD-I VWAP family backtest bias and fill realism."
    )


def main(argv: list[str] | None = None) -> int:
    build_parser().parse_args(argv)
    result = generate_vwap_family_backtest_bias_audit()
    print("GOLD-I VWAP FAMILY BACKTEST BIAS AUDIT")
    print(f"Report path: {result.report_path}")
    print(f"VWAP_FAMILY_BACKTEST_APPROVAL_READY: {str(result.approval_ready).lower()}")
    print(f"Bias risk: {result.bias_risk}")
    print(f"Fill realism risk: {result.fill_realism_risk}")
    print(f"Cost/slippage completeness: {result.cost_slippage_completeness}")
    print(f"Evidence trust level: {result.evidence_trust_level}")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    print("Production WhatsApp Alerts: BLOCKED | Real-money trading approval: false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
