from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from statistics import mean
from typing import Any

from src.research.forward_validation import analyze_independent_evidence, load_ledger


SUPPORTED_FAMILY = "gold_vwap_rejection_reclaim_family"
CANONICAL_SETUP = "gold_vwap_rejection_short"
LOCK_VERSION = "GOLD_VWAP_RESEARCH_LOCK_V1"
REPORT_PATH = Path("reports") / "trade_reviews" / "latest_post_lock_trade_review_report.txt"
CSV_PATH = Path("reports") / "trade_reviews" / "post_lock_trade_review.csv"
REAL_MONEY_STATUS = "REAL_MONEY_NOT_ALLOWED"
PRODUCTION_ALERTS_STATUS = "BLOCKED"
OVERALL_DECISION = "RESEARCH_ONLY"

CSV_COLUMNS = [
    "signal_id",
    "date",
    "session_id",
    "signal_time",
    "entry_time",
    "side",
    "entry",
    "stop_loss",
    "target",
    "exit_time",
    "exit_price",
    "result",
    "gross_pnl",
    "net_pnl_after_costs",
    "R_multiple",
    "mfe",
    "mae",
    "market_regime",
    "signal_score",
    "notes",
    "initial_expected_R",
    "actual_R_after_costs",
    "MFE_vs_target",
    "MAE_vs_stop",
    "did_price_nearly_hit_target",
    "did_costs_reduce_edge",
    "risk_review_comment",
    "regime_review_comment",
]


@dataclass(frozen=True)
class PostLockTradeReviewResult:
    report_path: Path
    csv_path: Path
    family: str
    setup: str
    lock_version: str
    completed_post_lock_trades: int
    required_post_lock_trades: int
    session_count: int
    wins: int
    losses: int
    net_pnl: float
    avg_r: float
    overall_decision: str
    real_money: str
    production_alerts: str
    execution_allowed: bool
    warnings: tuple[str, ...]


def generate_post_lock_trade_review_report(
    base_dir: Path | str = ".",
    *,
    family: str = SUPPORTED_FAMILY,
    now: datetime | None = None,
) -> PostLockTradeReviewResult:
    """Generate a descriptive post-lock review without changing strategy or approval logic."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    ledger_rows = load_ledger(base)
    evidence = analyze_independent_evidence(base, ledger_rows)
    trades = [_review_trade(row) for row in evidence.independent_rows]
    trades = [trade for trade in trades if trade["canonical_family"] == family or family == SUPPORTED_FAMILY]

    report_path = base / REPORT_PATH
    csv_path = base / CSV_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    _write_csv(csv_path, trades)
    report_path.write_text(_format_report(timestamp, family, evidence, trades) + "\n", encoding="utf-8")

    wins = sum(1 for trade in trades if trade["result"] == "WIN")
    losses = sum(1 for trade in trades if trade["result"] == "LOSS")
    net_pnl = sum(_to_float(trade["net_pnl_after_costs"]) for trade in trades)
    avg_r = mean([_to_float(trade["actual_R_after_costs"]) for trade in trades]) if trades else 0.0
    warnings = _summary_warnings(trades, evidence.completed_independent_post_lock_trades, evidence.required_forward_trades, evidence.distinct_post_lock_sessions)

    return PostLockTradeReviewResult(
        report_path=report_path,
        csv_path=csv_path,
        family=family,
        setup=CANONICAL_SETUP,
        lock_version=LOCK_VERSION,
        completed_post_lock_trades=evidence.completed_independent_post_lock_trades,
        required_post_lock_trades=evidence.required_forward_trades,
        session_count=evidence.distinct_post_lock_sessions,
        wins=wins,
        losses=losses,
        net_pnl=round(net_pnl, 2),
        avg_r=round(avg_r, 3),
        overall_decision=OVERALL_DECISION,
        real_money=REAL_MONEY_STATUS,
        production_alerts=PRODUCTION_ALERTS_STATUS,
        execution_allowed=False,
        warnings=warnings,
    )


def _write_csv(path: Path, trades: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for trade in trades:
            writer.writerow({column: trade.get(column, "") for column in CSV_COLUMNS})


def _format_report(timestamp: datetime, family: str, evidence: Any, trades: list[dict[str, Any]]) -> str:
    wins = sum(1 for trade in trades if trade["result"] == "WIN")
    losses = sum(1 for trade in trades if trade["result"] == "LOSS")
    net_pnl = sum(_to_float(trade["net_pnl_after_costs"]) for trade in trades)
    avg_r = mean([_to_float(trade["actual_R_after_costs"]) for trade in trades]) if trades else 0.0
    best = max(trades, key=lambda row: _to_float(row["net_pnl_after_costs"]), default={})
    worst = min(trades, key=lambda row: _to_float(row["net_pnl_after_costs"]), default={})
    warnings = _summary_warnings(trades, evidence.completed_independent_post_lock_trades, evidence.required_forward_trades, evidence.distinct_post_lock_sessions)

    lines = [
        "POST-LOCK TRADE REVIEW REPORT",
        f"generated_at: {timestamp.isoformat()}",
        f"family: {family}",
        f"setup: {CANONICAL_SETUP}",
        f"lock_version: {LOCK_VERSION}",
        f"completed_post_lock_trades: {evidence.completed_independent_post_lock_trades}",
        f"required_post_lock_trades: {evidence.required_forward_trades}",
        f"approval_progress: {evidence.completed_independent_post_lock_trades}/{evidence.required_forward_trades}",
        f"session_count: {evidence.distinct_post_lock_sessions}",
        f"required_sessions: {evidence.required_forward_sessions}",
        f"overall_decision: {OVERALL_DECISION}",
        f"strategy_status: {OVERALL_DECISION}",
        f"real_money: {REAL_MONEY_STATUS}",
        f"production_alerts: {PRODUCTION_ALERTS_STATUS}",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "",
        "SUMMARY",
        f"wins: {wins}",
        f"losses: {losses}",
        f"net_pnl: {net_pnl:.2f}",
        f"avg_R: {avg_r:.3f}",
        f"best_trade: {best.get('signal_id', 'NONE')} net={best.get('net_pnl_after_costs', 'N/A')} result={best.get('result', 'N/A')}",
        f"worst_trade: {worst.get('signal_id', 'NONE')} net={worst.get('net_pnl_after_costs', 'N/A')} result={worst.get('result', 'N/A')}",
        "main_warnings: " + ("; ".join(warnings) if warnings else "NONE"),
        "",
        "TRADE-BY-TRADE REVIEW",
    ]
    if not trades:
        lines.append("No completed independent post-lock trades found.")
    for index, trade in enumerate(trades, start=1):
        lines.extend(
            [
                f"Trade {index}: {trade['signal_id']}",
                f"  date: {trade['date']}",
                f"  session_id: {trade['session_id']}",
                f"  signal_time: {trade['signal_time']}",
                f"  entry_time: {trade['entry_time']}",
                f"  side: {trade['side']}",
                f"  entry: {trade['entry']} stop_loss: {trade['stop_loss']} target: {trade['target']}",
                f"  exit_time: {trade['exit_time']} exit_price: {trade['exit_price']}",
                f"  result: {trade['result']}",
                f"  gross_pnl: {trade['gross_pnl']} net_pnl_after_costs: {trade['net_pnl_after_costs']} R_multiple: {trade['R_multiple']}",
                f"  mfe: {trade['mfe']} mae: {trade['mae']}",
                f"  market_regime: {trade['market_regime']} signal_score: {trade['signal_score']}",
                f"  initial_expected_R: {trade['initial_expected_R']} actual_R_after_costs: {trade['actual_R_after_costs']}",
                f"  MFE_vs_target: {trade['MFE_vs_target']} MAE_vs_stop: {trade['MAE_vs_stop']}",
                f"  did_price_nearly_hit_target: {trade['did_price_nearly_hit_target']}",
                f"  did_costs_reduce_edge: {trade['did_costs_reduce_edge']}",
                f"  risk_review_comment: {trade['risk_review_comment']}",
                f"  regime_review_comment: {trade['regime_review_comment']}",
                f"  notes: {trade['notes']}",
            ]
        )
    lines.extend(
        [
            "",
            "WHAT WE LEARNED",
            "- Sample size is too small to call the setup good or bad.",
            "- Current evidence is single-session dependent.",
            "- Cost impact is visible and must remain part of every review.",
            "- Range regime loss observed; keep tagging regime context.",
            "",
            "RECOMMENDATION",
            "- Continue collecting evidence.",
            "- Do not optimize yet.",
            "- Review after 10 trades.",
            "- Formal decision only after 30 independent post-lock trades across at least 5 sessions.",
            "- Do not recommend parameter changes from only 2 trades or any similarly tiny sample.",
            "",
            "SAFETY CONFIRMATION",
            "No live data used by this report.",
            "No broker orders.",
            "No production WhatsApp.",
            "No strategy logic changed.",
            "No thresholds changed.",
            "Real-money trading remains 0% approved.",
            "execution_allowed=false.",
        ]
    )
    return "\n".join(lines)


def _review_trade(row: dict[str, Any]) -> dict[str, Any]:
    entry = _to_float(row.get("entry"))
    stop = _to_float(row.get("stop_loss") or row.get("stop"))
    target = _to_float(row.get("target"))
    side = str(row.get("side") or "SELL").upper()
    mfe = _to_float(row.get("mfe"))
    mae = _to_float(row.get("mae"))
    risk_per_unit = _to_float(row.get("risk_per_unit")) or abs(stop - entry)
    target_distance = abs(entry - target)
    stop_distance = abs(stop - entry)
    if side == "SELL":
        target_distance = entry - target
        stop_distance = stop - entry
    mfe_vs_target = mfe / target_distance if target_distance > 0 else 0.0
    mae_vs_stop = mae / stop_distance if stop_distance > 0 else 0.0
    gross = _to_float(row.get("gross_pnl"))
    net = _to_float(row.get("net_pnl_after_costs"))
    cost_impact = gross - net
    expected_r = _to_float(row.get("expected_R"))
    actual_r = _to_float(row.get("R_multiple")) or (net / risk_per_unit if risk_per_unit else 0.0)
    near_target = mfe_vs_target >= 0.80
    cost_pressure = (gross > 0 and actual_r < 0.75) or (risk_per_unit > 0 and cost_impact / risk_per_unit >= 0.50)
    large_adverse = mae_vs_stop > 1.50
    risk_comment = _risk_comment(near_target, cost_pressure, large_adverse)
    regime = str(row.get("market_regime") or "NOT_TAGGED")
    return {
        "canonical_family": row.get("canonical_family") or "",
        "signal_id": row.get("signal_id") or "",
        "date": row.get("date") or "",
        "session_id": row.get("session_id") or "",
        "signal_time": row.get("signal_time") or "",
        "entry_time": row.get("entry_time") or "",
        "side": side,
        "entry": _fmt(entry),
        "stop_loss": _fmt(stop),
        "target": _fmt(target),
        "exit_time": row.get("exit_time") or "",
        "exit_price": _fmt(_to_float(row.get("exit_price"))),
        "result": str(row.get("result") or row.get("status") or "").upper(),
        "gross_pnl": _fmt(gross),
        "net_pnl_after_costs": _fmt(net),
        "R_multiple": _fmt(_to_float(row.get("R_multiple")), 3),
        "mfe": _fmt(mfe),
        "mae": _fmt(mae),
        "market_regime": regime,
        "signal_score": row.get("signal_score") or "",
        "notes": row.get("notes") or "",
        "initial_expected_R": _fmt(expected_r, 3),
        "actual_R_after_costs": _fmt(actual_r, 3),
        "MFE_vs_target": _fmt(mfe_vs_target, 3),
        "MAE_vs_stop": _fmt(mae_vs_stop, 3),
        "did_price_nearly_hit_target": str(near_target).lower(),
        "did_costs_reduce_edge": str(cost_pressure).lower(),
        "risk_review_comment": risk_comment,
        "regime_review_comment": _regime_comment(regime),
    }


def _risk_comment(near_target: bool, cost_pressure: bool, large_adverse: bool) -> str:
    comments: list[str] = []
    if near_target:
        comments.append("price reached at least 80% of target distance")
    if cost_pressure:
        comments.append("cost pressure visible")
    if large_adverse:
        comments.append("large adverse excursion observed")
    if not comments:
        comments.append("risk path normal for this tiny sample")
    return "; ".join(comments)


def _regime_comment(regime: str) -> str:
    upper = regime.upper()
    if "RANGE" in upper:
        return "range regime loss/fragility must be watched"
    if "TREND" in upper or "TRAP" in upper:
        return "regime tag aligned with rejection/trap research context"
    return "regime evidence is descriptive only"


def _summary_warnings(trades: list[dict[str, Any]], completed: int, required: int, sessions: int) -> tuple[str, ...]:
    warnings: list[str] = []
    if completed < required:
        warnings.append("sample size too small")
    if sessions < 5:
        warnings.append("single-session dependency")
    if any(trade["did_costs_reduce_edge"] == "true" for trade in trades):
        warnings.append("cost impact visible")
    if any("RANGE" in str(trade["market_regime"]).upper() and trade["result"] == "LOSS" for trade in trades):
        warnings.append("range regime loss observed")
    return tuple(dict.fromkeys(warnings))


def _to_float(value: Any) -> float:
    try:
        if value in (None, ""):
            return 0.0
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _fmt(value: float, digits: int = 2) -> str:
    return f"{value:.{digits}f}"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate GOLD-I VWAP post-lock trade review report.")
    parser.add_argument("--family", default=SUPPORTED_FAMILY)
    args = parser.parse_args(argv)
    result = generate_post_lock_trade_review_report(family=args.family)
    print("POST-LOCK TRADE REVIEW REPORT")
    print(f"Report path: {result.report_path}")
    print(f"CSV path: {result.csv_path}")
    print(f"family: {result.family}")
    print(f"setup: {result.setup}")
    print(f"lock_version: {result.lock_version}")
    print(f"completed_post_lock_trades: {result.completed_post_lock_trades}")
    print(f"required_post_lock_trades: {result.required_post_lock_trades}")
    print(f"session_count: {result.session_count}")
    print(f"wins: {result.wins}")
    print(f"losses: {result.losses}")
    print(f"net_pnl: {result.net_pnl:.2f}")
    print(f"avg_R: {result.avg_r:.3f}")
    print(f"overall_decision: {result.overall_decision}")
    print(f"real_money: {result.real_money}")
    print(f"production_alerts: {result.production_alerts}")
    print("execution_allowed=false")
    print("Next action: continue collecting evidence; do not optimize yet; review after 10 trades.")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
