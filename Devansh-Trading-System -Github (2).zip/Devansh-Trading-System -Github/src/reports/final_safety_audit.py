﻿from __future__ import annotations

import argparse
import csv
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs


FINAL_SAFETY_PASS = "FINAL_SAFETY_PASS"
FINAL_SAFETY_PASS_WITH_WARNINGS = "FINAL_SAFETY_PASS_WITH_WARNINGS"
FINAL_SAFETY_BLOCKED = "FINAL_SAFETY_BLOCKED"

REPORT_PATH = Path("reports") / "final_safety" / "latest_final_safety_audit_report.txt"
HISTORY_PATH = Path("reports") / "final_safety" / "final_safety_audit_history.csv"

TEXT_EXTENSIONS = {
    ".py",
    ".yaml",
    ".yml",
    ".txt",
    ".md",
    ".csv",
    ".json",
    ".env",
    ".example",
}
SCAN_DIRS = ["src", "scripts", "config", "docs", "reports"]
ORDER_PATTERNS = [
    "place_order",
    "order_place",
    "placeOrder",
    "kite.place_order",
    "modify_order",
    "cancel_order",
]
SECRET_KEYS = [
    "KITE_API_KEY",
    "KITE_API_SECRET",
    "KITE_ACCESS_TOKEN",
    "request_token",
    "access_token",
    "api_secret",
]
HISTORY_COLUMNS = [
    "timestamp",
    "verdict",
    "execution_allowed",
    "live_trading_disabled",
    "broker_orders_disabled",
    "production_whatsapp_status",
    "strategy_status",
    "launch1_decision",
    "post_recording_verdict",
    "data_quality_status",
    "executable_order_findings",
    "non_executable_order_references",
    "secret_findings",
    "warnings",
    "blockers",
    "report_path",
]


@dataclass
class TextFinding:
    path: str
    line: int
    pattern: str
    classification: str
    reason: str


@dataclass
class SecretFinding:
    path: str
    line: int
    key: str
    classification: str = "SECRET_LEAK"
    masked_preview: str = "****"


@dataclass
class FinalSafetyAuditResult:
    timestamp: datetime
    project_path: Path
    execution_allowed: str
    live_trading_disabled: bool
    env_live_trading_disabled: bool
    env_risk_ack_disabled: bool
    broker_orders_disabled: bool
    automatic_execution_disabled: bool
    production_whatsapp_status: str
    strategy_status: str
    launch1_decision: str
    post_recording_verdict: str
    forward_validation_decision: str
    data_quality_status: str
    feature_mode: str
    contract_consistency_status: str
    reconciliation_status: str
    authoritative_feature_source: str
    pipeline_report_status: str
    data_collection_report_status: str
    pipeline_report_stale_or_failed: bool
    manual_feature_rebuild_reconciled_day: bool
    latest_verifier_date: str
    target_validation_date: str
    order_findings: list[TextFinding] = field(default_factory=list)
    executable_order_findings: list[TextFinding] = field(default_factory=list)
    non_executable_order_references: list[TextFinding] = field(default_factory=list)
    secret_findings: list[SecretFinding] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)
    verdict: str = FINAL_SAFETY_BLOCKED
    report_path: Path | None = None
    history_path: Path | None = None


def run_final_safety_audit(
    base_dir: Path | str = ".",
    *,
    configs: dict[str, Any] | None = None,
    now_fn: Callable[[], datetime] | None = None,
) -> FinalSafetyAuditResult:
    """Run a local, read-only final safety audit.

    The audit does not call Kite, TrueData, broker clients, WhatsApp, or any live
    service. It scans local files/reports and writes a local report.
    """

    base = Path(base_dir)
    timestamp = (now_fn or (lambda: datetime.now().astimezone()))()
    configs = configs or _load_configs_safely(base)
    report_texts = _read_latest_reports(base)
    combined_reports = "\n".join(report_texts.values())

    execution_allowed = _execution_allowed_status(combined_reports)
    live_disabled, env_live_disabled, env_ack_disabled = _live_safety_status(configs)
    broker_orders_disabled = _broker_orders_disabled(combined_reports)
    automatic_execution_disabled = _automatic_execution_disabled(configs, combined_reports)
    production_whatsapp_status = _production_whatsapp_status(configs, combined_reports)
    strategy_status = _first_non_empty(
        _extract_value(report_texts["forward_validation"], "Approval Decision:"),
        _extract_value(report_texts["launch1"], "strategy_approval_status:"),
        "RESEARCH_ONLY",
    )
    launch1_decision = _extract_value(report_texts["launch1"], "decision:") or "NOT_AVAILABLE"
    post_recording_verdict = _extract_value(report_texts["post_recording"], "VERDICT:") or "NOT_AVAILABLE"
    forward_validation_decision = _extract_value(report_texts["forward_validation"], "Approval Decision:") or "NOT_AVAILABLE"
    data_quality_status = _authoritative_status_value(
        report_texts,
        launch1_prefix="data_quality_status:",
        verifier_reconciled_prefixes=["Data collection market data status:"],
        data_collection_prefix="Market data status:",
        pipeline_prefix="status:",
        pipeline_section="DATA QUALITY GATE",
        stale_values={"MARKET_CLOSED_OR_NO_LIVE_DATA"},
    )
    feature_mode = _authoritative_status_value(
        report_texts,
        launch1_prefix="feature_mode:",
        verifier_reconciled_prefixes=[],
        data_collection_prefix="Feature mode:",
        pipeline_prefix="Feature mode:",
        stale_values={"NO_FEATURES"},
    )
    contract_consistency_status = _authoritative_status_value(
        report_texts,
        launch1_prefix="contract_consistency_status:",
        verifier_reconciled_prefixes=["Data collection contract status:"],
        data_collection_prefix="Contract consistency status:",
        pipeline_prefix="status:",
        pipeline_section="CONTRACT CONSISTENCY",
        stale_values={"NOT_CHECKED"},
    )
    reconciliation_status = _first_non_empty(
        _extract_value(report_texts["launch1"], "feature_rebuild_reconciliation_status:"),
        _extract_value(report_texts["post_recording"], "Feature rebuild reconciliation status:"),
        "NOT_AVAILABLE",
    )
    authoritative_feature_source = _first_non_empty(
        _extract_value(report_texts["launch1"], "authoritative_feature_source:"),
        _extract_value(report_texts["post_recording"], "Authoritative feature source used:"),
        "NOT_AVAILABLE",
    )
    pipeline_report_status = _first_non_empty(
        _extract_value(report_texts["launch1"], "pipeline_report_status:"),
        _extract_value(report_texts["post_recording"], "Pipeline report status:"),
        "NOT_AVAILABLE",
    )
    data_collection_report_status = _first_non_empty(
        _extract_value(report_texts["launch1"], "data_collection_report_status:"),
        _extract_value(report_texts["post_recording"], "Data collection report status:"),
        "NOT_AVAILABLE",
    )
    pipeline_report_stale_or_failed = _extract_bool_from_reports(
        report_texts,
        "pipeline_report_stale_or_failed:",
        "Pipeline report stale/failed:",
    )
    manual_feature_rebuild_reconciled_day = _extract_bool_from_reports(
        report_texts,
        "manual_feature_rebuild_reconciled_day:",
        "Manual feature rebuild reconciled day:",
    )
    latest_verifier_date = _first_non_empty(
        _extract_value(report_texts["launch1"], "latest_verifier_date:"),
        _extract_value(report_texts["post_recording"], "Date:"),
        "NOT_AVAILABLE",
    )
    target_validation_date = _extract_value(report_texts["launch1"], "target_validation_date:") or "NOT_AVAILABLE"

    order_findings = _scan_order_references(base)
    executable_order_findings = [item for item in order_findings if item.classification == "EXECUTABLE_ORDER_PATH"]
    non_exec_order_refs = [item for item in order_findings if item.classification != "EXECUTABLE_ORDER_PATH"]
    secret_findings = _scan_secret_like_values(base)
    blocking_secret_findings = [item for item in secret_findings if item.classification == "SECRET_LEAK"]

    warnings: list[str] = []
    blockers: list[str] = []
    if execution_allowed != "false":
        blockers.append("execution_allowed=false was not confirmed or execution_allowed=true was found.")
    if not live_disabled or not env_live_disabled or not env_ack_disabled:
        blockers.append("Live trading safety flags are not all false.")
    if not broker_orders_disabled:
        blockers.append("Broker orders are not confirmed disabled in latest reports.")
    if not automatic_execution_disabled:
        blockers.append("Automatic execution is not confirmed disabled.")
    if production_whatsapp_status != "BLOCKED":
        blockers.append("Production WhatsApp alerts are not blocked.")
    if executable_order_findings:
        blockers.append("Executable broker/order-placement path found.")
    if blocking_secret_findings:
        blockers.append("Secret-like token or credential value found outside the local .env file.")
    if _is_real_trading_approved(strategy_status, report_texts):
        blockers.append("Strategy appears approved for real trading unexpectedly.")

    if non_exec_order_refs:
        warnings.append("Non-executable/safety-guarded order-placement references exist in tests/docs/comments/paper broker/blocked guards.")
    if any(item.classification == "LOCAL_ENV_SECRET_PRESENT" for item in secret_findings):
        warnings.append("Local .env contains Kite credentials; values were masked and are not treated as report/code leaks.")
    if "WAITING_FOR_MONDAY" in launch1_decision or "WAITING_FOR_MONDAY_DATA" in launch1_decision:
        warnings.append("Monday target validation is still pending.")
    if strategy_status == "RESEARCH_ONLY":
        warnings.append("Strategy remains RESEARCH_ONLY; this is expected and blocks production trading/alerts.")
    if _contains_small_sample_warning(report_texts):
        warnings.append("Small sample or insufficient forward evidence warning exists.")
    if pipeline_report_stale_or_failed and manual_feature_rebuild_reconciled_day:
        warnings.append("Daily pipeline report was stale/failed, but final safety uses reconciled verifier/feature-builder status.")

    verdict = _decide_verdict(blockers, warnings)
    result = FinalSafetyAuditResult(
        timestamp=timestamp,
        project_path=base.resolve(),
        execution_allowed=execution_allowed,
        live_trading_disabled=live_disabled,
        env_live_trading_disabled=env_live_disabled,
        env_risk_ack_disabled=env_ack_disabled,
        broker_orders_disabled=broker_orders_disabled,
        automatic_execution_disabled=automatic_execution_disabled,
        production_whatsapp_status=production_whatsapp_status,
        strategy_status=strategy_status,
        launch1_decision=launch1_decision,
        post_recording_verdict=post_recording_verdict,
        forward_validation_decision=forward_validation_decision,
        data_quality_status=data_quality_status,
        feature_mode=feature_mode,
        contract_consistency_status=contract_consistency_status,
        reconciliation_status=reconciliation_status,
        authoritative_feature_source=authoritative_feature_source,
        pipeline_report_status=pipeline_report_status,
        data_collection_report_status=data_collection_report_status,
        pipeline_report_stale_or_failed=pipeline_report_stale_or_failed,
        manual_feature_rebuild_reconciled_day=manual_feature_rebuild_reconciled_day,
        latest_verifier_date=latest_verifier_date,
        target_validation_date=target_validation_date,
        order_findings=order_findings,
        executable_order_findings=executable_order_findings,
        non_executable_order_references=non_exec_order_refs,
        secret_findings=secret_findings,
        warnings=warnings,
        blockers=blockers,
        verdict=verdict,
    )
    _write_report(base, result)
    _append_history(base, result)
    _print_summary(result)
    return result


def _scan_order_references(base: Path) -> list[TextFinding]:
    findings: list[TextFinding] = []
    for path in _iter_scan_files(base):
        rel = _rel_path(base, path)
        if rel.replace("\\", "/").startswith("reports/final_safety/"):
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        for number, line in enumerate(lines, start=1):
            for pattern in ORDER_PATTERNS:
                if pattern in line:
                    classification, reason = _classify_order_reference(rel, line)
                    findings.append(TextFinding(rel, number, pattern, classification, reason))
    return findings


def _classify_order_reference(rel_path: str, line: str) -> tuple[str, str]:
    path = rel_path.replace("\\", "/").lower()
    stripped = line.strip()
    if path.startswith(("tests/", "docs/", "reports/", "src/reports/")):
        return "NON_EXECUTABLE_REFERENCE", "Test/docs/report reference only."
    if stripped.startswith("#") or stripped.startswith('"""') or stripped.startswith("'''"):
        return "NON_EXECUTABLE_REFERENCE", "Comment/docstring reference only."
    if "kite_live order placement is intentionally not implemented" in line.lower():
        return "SAFETY_BLOCKING_REFERENCE", "Kite live order placement intentionally not implemented."
    if "refused live order" in line.lower() or "evaluate_live_order_guard" in line:
        return "SAFETY_BLOCKING_REFERENCE", "Kite broker guard/refusal path."
    if path.endswith("src/brokers/kite_broker.py"):
        return "SAFETY_BLOCKING_REFERENCE", "KiteBroker order method is hard-blocked by guard and RuntimeError."
    if path.endswith("src/brokers/base_broker.py"):
        return "NON_EXECUTABLE_REFERENCE", "Abstract broker interface."
    if path.endswith("src/brokers/paper_broker.py") or "PaperBroker" in line or "paper" in line.lower():
        return "PAPER_SIMULATION_REFERENCE", "Paper broker simulation only."
    if path.endswith("src/main.py") and "broker.place_order" in line:
        return "PAPER_SIMULATION_REFERENCE", "Main run uses PaperBroker only in PAPER sample path."
    return "EXECUTABLE_ORDER_PATH", "Potential executable order-placement reference."


def _scan_secret_like_values(base: Path) -> list[SecretFinding]:
    findings: list[SecretFinding] = []
    for path in _iter_scan_files(base, include_env=True):
        rel = _rel_path(base, path)
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        for number, line in enumerate(lines, start=1):
            for key in SECRET_KEYS:
                value = _extract_secret_value(line, key)
                if value and _looks_like_real_secret(value):
                    classification = "LOCAL_ENV_SECRET_PRESENT" if rel.replace("\\", "/") == ".env" else "SECRET_LEAK"
                    findings.append(SecretFinding(rel, number, key, classification, "****"))
    return findings


def _extract_secret_value(line: str, key: str) -> str:
    pattern = re.compile(rf"(?i)\b{re.escape(key)}\b\s*[:=]\s*[\"']?([^\"'\s,#]+)")
    match = pattern.search(line)
    return match.group(1).strip() if match else ""


def _looks_like_real_secret(value: str) -> bool:
    cleaned = value.strip().strip("\"'")
    lowered = cleaned.lower()
    if not cleaned or lowered in {"present", "missing", "not_checked", "none", "null", "false", "true"}:
        return False
    if any(token in lowered for token in ["placeholder", "your_", "xxxx", "example", "masked", "****", "..."]):
        return False
    if len(cleaned) < 12:
        return False
    return bool(re.search(r"[A-Za-z]", cleaned) and re.search(r"\d", cleaned))


def _iter_scan_files(base: Path, *, include_env: bool = False) -> list[Path]:
    files: list[Path] = []
    for dirname in SCAN_DIRS:
        root = base / dirname
        if root.exists():
            files.extend(path for path in root.rglob("*") if _is_text_file(path))
    if include_env:
        for name in [".env", ".env.example"]:
            path = base / name
            if path.exists():
                files.append(path)
    return sorted(set(files))


def _is_text_file(path: Path) -> bool:
    if not path.is_file():
        return False
    if any(part in {".pytest_cache", "__pycache__"} for part in path.parts):
        return False
    return path.suffix.lower() in TEXT_EXTENSIONS or path.name.lower().startswith(".env")


def _read_latest_reports(base: Path) -> dict[str, str]:
    return {
        "post_recording": _read_text(base / "reports" / "kite_daily_pipeline" / "latest_post_recording_verifier_report.txt"),
        "launch1": _read_text(base / "reports" / "launch1" / "latest_launch1_readiness_report.txt"),
        "forward_validation": _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt"),
        "pipeline": _read_text(base / "reports" / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"),
        "data_collection": _read_text(base / "reports" / "kite_data_collection" / "latest_kite_data_collection_report.txt"),
    }


def _load_configs_safely(base: Path) -> dict[str, Any]:
    try:
        return load_configs(base)
    except (FileNotFoundError, OSError):
        return {
            "settings": {"mode": "PAPER", "enable_live_trading": False},
            "forward_validation": {"production_alerts_allowed": False},
            "alerts": {"whatsapp": {"enabled": False}},
            "approved_strategies": {},
        }


def _execution_allowed_status(text: str) -> str:
    lowered = text.lower()
    if "execution_allowed=true" in lowered:
        return "true"
    return "false" if "execution_allowed=false" in lowered or "execution_allowed: false" in lowered else "UNKNOWN"


def _live_safety_status(configs: dict[str, Any]) -> tuple[bool, bool, bool]:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    config_disabled = str(settings.get("mode", "PAPER")).upper() == "PAPER" and not bool(settings.get("enable_live_trading", False))
    env_live_disabled = not _truthy(os.environ.get("ENABLE_LIVE_TRADING"))
    env_ack_disabled = not _truthy(os.environ.get("I_UNDERSTAND_LIVE_TRADING_RISK"))
    return config_disabled, env_live_disabled, env_ack_disabled


def _broker_orders_disabled(text: str) -> bool:
    uppered = text.upper()
    return "BROKER ORDERS: ENABLED" not in uppered and "BROKER ORDERS: DISABLED" in uppered


def _automatic_execution_disabled(configs: dict[str, Any], text: str) -> bool:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    risk = configs.get("risk", {}) if isinstance(configs, dict) else {}
    return (
        str(settings.get("mode", "PAPER")).upper() == "PAPER"
        and not bool(settings.get("enable_live_trading", False))
        and not bool(risk.get("allow_live_trading", False))
        and "automatic_strategy_approval: DISABLED" in text
    )


def _production_whatsapp_status(configs: dict[str, Any], text: str) -> str:
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    alerts = configs.get("alerts", {}) if isinstance(configs, dict) else {}
    whatsapp = alerts.get("whatsapp", {}) if isinstance(alerts, dict) else {}
    if bool(forward.get("production_alerts_allowed", False)) or bool(whatsapp.get("enabled", False) and not whatsapp.get("dry_run", True)):
        return "ENABLED"
    if "Production WhatsApp Alerts: BLOCKED" in text or "production_whatsapp_status: BLOCKED" in text:
        return "BLOCKED"
    return "BLOCKED"


def _is_real_trading_approved(strategy_status: str, reports: dict[str, str]) -> bool:
    combined = "\n".join(reports.values()).upper()
    if "REAL-MONEY" in combined and "APPROVED" in combined and "NOT_APPROVED" not in combined:
        return True
    return strategy_status not in {"RESEARCH_ONLY", "WATCHLIST", "NOT_AVAILABLE", ""}


def _contains_small_sample_warning(reports: dict[str, str]) -> bool:
    text = "\n".join(reports.values()).lower()
    return "sample" in text and ("small" in text or "too few" in text or "minimum" in text)


def _decide_verdict(blockers: list[str], warnings: list[str]) -> str:
    if blockers:
        return FINAL_SAFETY_BLOCKED
    if warnings:
        return FINAL_SAFETY_PASS_WITH_WARNINGS
    return FINAL_SAFETY_PASS


def _write_report(base: Path, result: FinalSafetyAuditResult) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "FINAL SAFETY AUDIT",
        f"Generated timestamp: {result.timestamp.isoformat()}",
        f"Project path: {result.project_path}",
        "",
        "EXECUTION SAFETY",
        f"execution_allowed: {result.execution_allowed}",
        f"live_trading_disabled: {_bool_text(result.live_trading_disabled)}",
        f"ENABLE_LIVE_TRADING=false: {_bool_text(result.env_live_trading_disabled)}",
        f"I_UNDERSTAND_LIVE_TRADING_RISK=false: {_bool_text(result.env_risk_ack_disabled)}",
        f"broker_orders_disabled: {_bool_text(result.broker_orders_disabled)}",
        f"automatic_execution_disabled: {_bool_text(result.automatic_execution_disabled)}",
        "",
        "CODEBASE ORDER-PLACEMENT SCAN",
        f"executable_order_paths: {len(result.executable_order_findings)}",
        f"non_executable_or_guarded_references: {len(result.non_executable_order_references)}",
        "Executable findings:",
        *(_format_findings(result.executable_order_findings) if result.executable_order_findings else ["NONE"]),
        "Non-executable / safety-guarded references:",
        *(_format_findings(result.non_executable_order_references) if result.non_executable_order_references else ["NONE"]),
        "",
        "KITE CREDENTIAL / SECURITY AUDIT",
        "Kite modules: READ_ONLY_DATA / guarded login helpers only",
        "Credential values printed: NO",
        "Credential report format: PRESENT/MISSING/NOT_CHECKED only",
        "Real Kite credentials required for tests: NO",
        "",
        "WHATSAPP / ALERT SAFETY",
        f"production_whatsapp_status: {result.production_whatsapp_status}",
        "research_previews: disabled by default or research-only",
        "production trade alerts for RESEARCH_ONLY strategy: BLOCKED",
        "",
        "STRATEGY APPROVAL SAFETY",
        "strategy: GOLD-I VWAP Rejection Short",
        f"strategy_status: {result.strategy_status}",
        "automatic_strategy_approval: DISABLED",
        "Launch 1 readiness does not imply strategy approval.",
        "approved_for_real_money_trading: false",
        "",
        "DATA / RESEARCH STATUS",
        f"post_recording_verdict: {result.post_recording_verdict}",
        f"launch1_decision: {result.launch1_decision}",
        f"forward_validation_decision: {result.forward_validation_decision}",
        f"data_quality_status: {result.data_quality_status}",
        f"feature_mode: {result.feature_mode}",
        f"contract_consistency_status: {result.contract_consistency_status}",
        f"reconciliation_status: {result.reconciliation_status}",
        f"authoritative_feature_source: {result.authoritative_feature_source}",
        f"pipeline_report_status: {result.pipeline_report_status}",
        f"data_collection_report_status: {result.data_collection_report_status}",
        f"pipeline_report_stale_or_failed: {_bool_text(result.pipeline_report_stale_or_failed)}",
        f"manual_feature_rebuild_reconciled_day: {_bool_text(result.manual_feature_rebuild_reconciled_day)}",
        f"latest_verifier_date: {result.latest_verifier_date}",
        f"target_validation_date: {result.target_validation_date}",
        "",
        "SECRET SCAN",
        f"secret_like_findings: {len(result.secret_findings)}",
        *(_format_secret_findings(result.secret_findings) if result.secret_findings else ["NONE"]),
        "",
        "WARNINGS",
        *([f"- {item}" for item in result.warnings] if result.warnings else ["NONE"]),
        "",
        "BLOCKERS",
        *([f"- {item}" for item in result.blockers] if result.blockers else ["NONE"]),
        "",
        "FINAL VERDICT",
        result.verdict,
        "",
        "ALLOWED NEXT USE",
        "- Monday real-market validation",
        "- Read-only Kite data collection",
        "- Post-recording verification",
        "- Paper/research/manual signal observation",
        "",
        "PROHIBITED USE",
        "- Real-money trading",
        "- Broker orders",
        "- Kite place_order",
        "- Automatic execution",
        "- Production WhatsApp trade alerts",
        "- Treating RESEARCH_ONLY strategy as approved",
        "",
        "MONDAY COMMAND CHECKLIST",
        "- python -m src.data_collection.kite_monday_preflight --symbols \"GOLD-I\" --dry-run false",
        "- python -m src.data_collection.kite_daily_pipeline --symbols \"GOLD-I\" --duration-seconds 25200 --record-depth true --dry-run false",
        "- python -m src.data_collection.kite_post_recording_verifier --symbols \"GOLD-I\" --date YYYY-MM-DD",
        "- python -m src.reports.launch1_readiness_report --target-validation-date YYYY-MM-DD",
        "",
        "TUESDAY LAUNCH 1 LIMITS",
        "Launch 1 remains PAPER / RESEARCH / MANUAL SIGNAL ONLY.",
        "No broker orders. No live trading. No production WhatsApp trade alerts.",
        "execution_allowed=false",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _append_history(base: Path, result: FinalSafetyAuditResult) -> None:
    path = base / HISTORY_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    row = {
        "timestamp": result.timestamp.isoformat(),
        "verdict": result.verdict,
        "execution_allowed": result.execution_allowed,
        "live_trading_disabled": _bool_text(result.live_trading_disabled),
        "broker_orders_disabled": _bool_text(result.broker_orders_disabled),
        "production_whatsapp_status": result.production_whatsapp_status,
        "strategy_status": result.strategy_status,
        "launch1_decision": result.launch1_decision,
        "post_recording_verdict": result.post_recording_verdict,
        "data_quality_status": result.data_quality_status,
        "executable_order_findings": len(result.executable_order_findings),
        "non_executable_order_references": len(result.non_executable_order_references),
        "secret_findings": len(result.secret_findings),
        "warnings": "; ".join(result.warnings) if result.warnings else "NONE",
        "blockers": "; ".join(result.blockers) if result.blockers else "NONE",
        "report_path": str(result.report_path or REPORT_PATH),
    }
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=HISTORY_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    result.history_path = path


def _print_summary(result: FinalSafetyAuditResult) -> None:
    print("FINAL SAFETY AUDIT")
    print(f"Verdict: {result.verdict}")
    print(f"Warnings: {len(result.warnings)}")
    print(f"Blockers: {len(result.blockers)}")
    print(f"execution_allowed={result.execution_allowed}")
    print(f"Production WhatsApp: {result.production_whatsapp_status}")
    print(f"Strategy: {result.strategy_status}")
    print(f"Launch 1 decision: {result.launch1_decision}")
    print(f"Data Quality: {result.data_quality_status}")
    print(f"Feature Mode: {result.feature_mode}")
    print(f"Contract Consistency: {result.contract_consistency_status}")
    print(f"Reconciliation: {result.reconciliation_status}")
    print(f"Authoritative Feature Source: {result.authoritative_feature_source}")
    print(f"Executable order paths: {len(result.executable_order_findings)}")
    print(f"Secret findings: {len(result.secret_findings)}")
    print(f"Report: {result.report_path}")
    print("PAPER MODE ONLY. No broker orders were placed.")


def _format_findings(findings: list[TextFinding]) -> list[str]:
    return [
        f"- {item.classification}: {item.path}:{item.line} pattern={item.pattern} reason={item.reason}"
        for item in findings[:50]
    ] + ([f"- ... {len(findings) - 50} more"] if len(findings) > 50 else [])


def _format_secret_findings(findings: list[SecretFinding]) -> list[str]:
    return [
        f"- {item.classification}: {item.path}:{item.line} key={item.key} value={item.masked_preview}"
        for item in findings[:50]
    ] + ([f"- ... {len(findings) - 50} more"] if len(findings) > 50 else [])


def _authoritative_status_value(
    reports: dict[str, str],
    *,
    launch1_prefix: str,
    verifier_reconciled_prefixes: list[str],
    data_collection_prefix: str,
    pipeline_prefix: str,
    pipeline_section: str | None = None,
    stale_values: set[str] | None = None,
) -> str:
    stale_values = stale_values or set()
    pipeline_stale = _extract_bool_from_reports(
        reports,
        "pipeline_report_stale_or_failed:",
        "Pipeline report stale/failed:",
    ) or _first_non_empty(
        _extract_value(reports.get("launch1", ""), "pipeline_report_status:"),
        _extract_value(reports.get("post_recording", ""), "Pipeline report status:"),
    ) == "STALE_OR_FAILED"
    launch1_value = _extract_value(reports.get("launch1", ""), launch1_prefix)
    if launch1_value and launch1_value not in stale_values:
        return launch1_value
    for prefix in verifier_reconciled_prefixes:
        value = _extract_value(reports.get("post_recording", ""), prefix)
        if value and value not in stale_values:
            return value
    data_collection_value = _extract_value(reports.get("data_collection", ""), data_collection_prefix)
    if data_collection_value and data_collection_value not in stale_values:
        return data_collection_value
    pipeline_value = _extract_value(reports.get("pipeline", ""), pipeline_prefix, section=pipeline_section)
    if pipeline_value and not pipeline_stale:
        return pipeline_value
    return launch1_value or pipeline_value or "NOT_AVAILABLE"


def _extract_bool_from_reports(reports: dict[str, str], *prefixes: str) -> bool:
    for text in reports.values():
        for prefix in prefixes:
            value = _extract_value(text, prefix).strip().lower()
            if value == "true":
                return True
    return False


def _extract_value(text: str, prefix: str, *, section: str | None = None) -> str:
    source = text
    if section:
        marker = section + "\n"
        if marker not in text:
            return ""
        source = text.split(marker, 1)[1].split("\n\n", 1)[0]
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            return stripped.split(prefix, 1)[1].strip()
    return ""


def _first_non_empty(*values: str) -> str:
    for value in values:
        if str(value or "").strip():
            return str(value).strip()
    return ""


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""


def _rel_path(base: Path, path: Path) -> str:
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _bool_text(value: bool) -> str:
    return "true" if bool(value) else "false"


def build_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(description="Final local safety audit. No live services or broker orders.")


def main(argv: list[str] | None = None) -> int:
    build_parser().parse_args(argv)
    run_final_safety_audit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())



