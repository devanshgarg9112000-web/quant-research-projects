from __future__ import annotations

import argparse
import csv
import os
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable

from src.config_loader import load_configs


LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA = (
    "LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA"
)
LAUNCH1_READY_FOR_PAPER_RESEARCH = "LAUNCH1_READY_FOR_PAPER_RESEARCH"
LAUNCH1_BLOCKED_DATA_QUALITY = "LAUNCH1_BLOCKED_DATA_QUALITY"
LAUNCH1_BLOCKED_SAFETY = "LAUNCH1_BLOCKED_SAFETY"
LAUNCH1_BLOCKED_STRATEGY_VALIDATION = "LAUNCH1_BLOCKED_STRATEGY_VALIDATION"
LAUNCH1_NOT_READY = "LAUNCH1_NOT_READY"
STAGE0_READY = "READY"
STAGE0_NOT_READY = "NOT_READY"
TRADEABLE_LAUNCH1_NOT_READY = "NOT_READY"

REPORT_PATH = Path("reports") / "launch1" / "latest_launch1_readiness_report.txt"
HISTORY_PATH = Path("reports") / "launch1" / "launch1_readiness_history.csv"
MONDAY_CHECKLIST_PATH = Path("reports") / "kite_daily_pipeline" / "latest_monday_checklist.txt"
MONDAY_PREFLIGHT_PATH = Path("reports") / "kite_daily_pipeline" / "latest_monday_preflight_report.txt"
KITE_DAILY_PIPELINE_PATH = Path("reports") / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt"
POST_RECORDING_VERIFIER_PATH = (
    Path("reports") / "kite_daily_pipeline" / "latest_post_recording_verifier_report.txt"
)
KITE_DATA_COLLECTION_REPORT_PATH = (
    Path("reports") / "kite_data_collection" / "latest_kite_data_collection_report.txt"
)
FORWARD_VALIDATION_SUMMARY_PATH = (
    Path("reports") / "forward_validation" / "latest_forward_validation_summary.txt"
)
APPROVED_STRATEGIES_PATH = Path("config") / "approved_strategies.yaml"

REQUIRED_COMPONENTS = [
    Path("src") / "data_collection" / "kite_monday_checklist.py",
    Path("src") / "data_collection" / "kite_monday_preflight.py",
    Path("src") / "data_collection" / "kite_daily_pipeline.py",
    Path("src") / "data_collection" / "kite_data_quality_gate.py",
    Path("src") / "data_collection" / "kite_contract_consistency.py",
    Path("src") / "data_collection" / "kite_post_recording_verifier.py",
    Path("src") / "research" / "forward_validation.py",
]

HISTORY_COLUMNS = [
    "timestamp",
    "stage0_infrastructure_data_readiness",
    "tradeable_launch1_readiness",
    "target_validation_date",
    "latest_verifier_date",
    "target_validation_passed",
    "decision",
    "reason",
    "engineering_ready",
    "safety_ok",
    "monday_verifier_verdict",
    "data_quality_status",
    "contract_consistency_status",
    "tick_rows",
    "depth_rows",
    "feature_rows",
    "forward_validation_decision",
    "strategy_approval_status",
    "production_whatsapp_status",
    "execution_allowed",
    "report_path",
]


@dataclass
class Launch1ReadinessResult:
    timestamp: datetime
    engineering_ready: bool
    required_components_present: dict[str, bool]
    monday_checklist_exists: bool
    monday_preflight_exists: bool
    kite_daily_pipeline_exists: bool
    post_recording_verifier_exists: bool
    forward_validation_summary_exists: bool
    approved_strategies_config_exists: bool
    target_validation_date: date | None = None
    target_validation_date_explicit: bool = False
    latest_verifier_date: date | None = None
    target_validation_passed: bool = False
    readiness_data_basis: str = "NO_TARGET_VALIDATION_DATA"
    verifier_verdict: str = "NOT_AVAILABLE"
    tick_rows: int = 0
    depth_rows: int = 0
    feature_rows: int = 0
    selected_contract: str = "NOT_AVAILABLE"
    synthetic_rows: int = 0
    mixed_contracts: bool = False
    data_quality_status: str = "NOT_AVAILABLE"
    contract_consistency_status: str = "NOT_AVAILABLE"
    feature_mode: str = "NOT_AVAILABLE"
    pipeline_report_status: str = "NOT_AVAILABLE"
    data_collection_report_status: str = "NOT_AVAILABLE"
    feature_rebuild_reconciliation_status: str = "NOT_AVAILABLE"
    authoritative_feature_source: str = "NOT_AVAILABLE"
    pipeline_report_stale_or_failed: bool = False
    manual_feature_rebuild_reconciled_day: bool = False
    forward_validation_decision: str = "NOT_AVAILABLE"
    strategy_approval_status: str = "NOT_AVAILABLE"
    approved_strategy_policy: dict[str, Any] = field(default_factory=dict)
    production_whatsapp_status: str = "BLOCKED"
    execution_allowed: str = "false"
    safety_ok: bool = True
    safety_issues: list[str] = field(default_factory=list)
    monday_dependency_items: dict[str, bool] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    stage0_infrastructure_data_readiness: str = STAGE0_NOT_READY
    tradeable_launch1_readiness: str = TRADEABLE_LAUNCH1_NOT_READY
    decision: str = LAUNCH1_NOT_READY
    decision_reason: str = ""
    next_action: str = ""
    report_path: Path | None = None
    history_path: Path | None = None


def generate_launch1_readiness_report(
    base_dir: Path | str = ".",
    *,
    target_validation_date: str | date | None = None,
    require_approved_strategy: bool = False,
    configs: dict[str, Any] | None = None,
    now_fn: Callable[[], datetime] | None = None,
) -> Launch1ReadinessResult:
    """Create the Launch 1 readiness report from existing local artifacts only.

    This function performs no network calls and no broker actions. It only reads local
    reports/configuration and writes a readiness report/history row.
    """

    base = Path(base_dir)
    timestamp = (now_fn or (lambda: datetime.now().astimezone()))()
    target_date, target_explicit = _resolve_target_validation_date(
        target_validation_date,
        today=timestamp.date(),
    )
    texts = _read_artifacts(base)
    configs = configs or _load_configs_safely(base)
    required_components = {
        str(path): (base / path).exists()
        for path in REQUIRED_COMPONENTS
    }
    engineering_ready = all(required_components.values())

    verifier_text = texts["post_recording_verifier"]
    pipeline_text = texts["kite_daily_pipeline"]
    data_collection_text = texts["kite_data_collection"]
    forward_text = texts["forward_validation_summary"]
    combined_text = "\n".join(texts.values())

    latest_verifier_date = _extract_date_value(verifier_text, "Date:")
    verifier_verdict = _extract_value(verifier_text, "VERDICT:") or "NOT_AVAILABLE"
    tick_rows = _sum_file_rows(verifier_text, "Tick file:")
    depth_rows = _sum_file_rows(verifier_text, "Depth file:")
    feature_rows = _sum_file_rows(verifier_text, "Feature file:")
    selected_contract = _first_non_empty(
        _extract_value(verifier_text, "Selected contract:"),
        _extract_value(pipeline_text, "selected_contract:", section="CONTRACT CONSISTENCY"),
        "NOT_AVAILABLE",
    )
    synthetic_rows = _sum_int_lines(verifier_text, "Synthetic rows found:")
    mixed_contracts = _any_bool_lines(verifier_text, "Mixed contracts found:")
    pipeline_report_status = _extract_value(verifier_text, "Pipeline report status:") or "NOT_AVAILABLE"
    data_collection_report_status = _extract_value(verifier_text, "Data collection report status:") or "NOT_AVAILABLE"
    feature_rebuild_reconciliation_status = (
        _extract_value(verifier_text, "Feature rebuild reconciliation status:") or "NOT_AVAILABLE"
    )
    authoritative_feature_source = (
        _extract_value(verifier_text, "Authoritative feature source used:") or "NOT_AVAILABLE"
    )
    pipeline_report_stale_or_failed = _extract_bool_value(verifier_text, "Pipeline report stale/failed:")
    manual_feature_rebuild_reconciled_day = _extract_bool_value(
        verifier_text,
        "Manual feature rebuild reconciled day:",
    )
    reconciled_target_data = (
        latest_verifier_date == target_date
        and verifier_verdict == "DAY_ACCEPTED_FOR_RESEARCH"
        and manual_feature_rebuild_reconciled_day
        and authoritative_feature_source == "DATA_COLLECTION_FEATURE_BUILDER_REPORT"
    )
    data_quality_status = _reconciled_value(
        use_reconciled=reconciled_target_data,
        reconciled_values=[
            _extract_value(verifier_text, "Data collection market data status:"),
            _extract_value(data_collection_text, "Market data status:"),
        ],
        fallback_values=[
            _extract_value(verifier_text, "Data Quality Gate status:"),
            _extract_value(pipeline_text, "status:", section="DATA QUALITY GATE"),
            "NOT_AVAILABLE",
        ],
    )
    contract_consistency_status = _reconciled_value(
        use_reconciled=reconciled_target_data,
        reconciled_values=[
            _extract_value(verifier_text, "Data collection contract status:"),
            _extract_value(data_collection_text, "Contract consistency status:"),
        ],
        fallback_values=[
            _extract_value(verifier_text, "Pipeline contract status:"),
            _extract_value(pipeline_text, "status:", section="CONTRACT CONSISTENCY"),
            "NOT_AVAILABLE",
        ],
    )
    feature_mode = _reconciled_value(
        use_reconciled=reconciled_target_data,
        reconciled_values=[
            _extract_value(data_collection_text, "Feature mode:"),
        ],
        fallback_values=[
            _extract_value(pipeline_text, "Feature mode:"),
            "NOT_AVAILABLE",
        ],
    )
    forward_decision = _first_non_empty(
        _extract_value(forward_text, "Approval Decision:"),
        _extract_value(pipeline_text, "Forward-validation decision:"),
        "NOT_AVAILABLE",
    )
    strategy_status = forward_decision if forward_decision != "NOT_AVAILABLE" else "RESEARCH_ONLY"
    production_whatsapp = _production_whatsapp_status(combined_text, configs)
    execution_allowed = _execution_allowed_status(combined_text)
    safety_ok, safety_issues = _evaluate_safety(configs, combined_text, production_whatsapp, execution_allowed)
    approved_policy = configs.get("approved_strategies", {}) if isinstance(configs, dict) else {}

    target_validation_passed = (
        latest_verifier_date == target_date
        and verifier_verdict == "DAY_ACCEPTED_FOR_RESEARCH"
        and tick_rows > 0
        and depth_rows > 0
        and feature_rows > 0
        and synthetic_rows == 0
        and not mixed_contracts
        and forward_decision == "RESEARCH_ONLY"
    )
    readiness_data_basis = _readiness_data_basis(latest_verifier_date, target_date, target_validation_passed)
    warnings = _target_date_warnings(
        explicit=target_explicit,
        target_date=target_date,
        latest_verifier_date=latest_verifier_date,
        verifier_verdict=verifier_verdict,
    )
    if (
        latest_verifier_date == target_date
        and verifier_verdict == "DAY_ACCEPTED_FOR_RESEARCH"
        and pipeline_report_stale_or_failed
        and manual_feature_rebuild_reconciled_day
    ):
        warnings.append(
            "Long daily pipeline report was stale/failed due MemoryError; accepted day is based on "
            "reconciled post-recording verifier and feature-builder report."
        )

    monday_dependency_items = {
        "monday_checklist_report": (base / MONDAY_CHECKLIST_PATH).exists(),
        "monday_preflight_report": (base / MONDAY_PREFLIGHT_PATH).exists(),
        "kite_daily_pipeline_report": (base / KITE_DAILY_PIPELINE_PATH).exists(),
        "post_recording_verifier_report": (base / POST_RECORDING_VERIFIER_PATH).exists(),
        "forward_validation_summary": (base / FORWARD_VALIDATION_SUMMARY_PATH).exists(),
        "approved_strategies_config": (base / APPROVED_STRATEGIES_PATH).exists(),
        "engineering_components": engineering_ready,
    }

    decision, reason, next_action = _decide_launch1_status(
        engineering_ready=engineering_ready,
        safety_ok=safety_ok,
        target_validation_passed=target_validation_passed,
        target_validation_date=target_date,
        latest_verifier_date=latest_verifier_date,
        verifier_verdict=verifier_verdict,
        data_quality_status=data_quality_status,
        mixed_contracts=mixed_contracts,
        synthetic_rows=synthetic_rows,
        tick_rows=tick_rows,
        depth_rows=depth_rows,
        feature_rows=feature_rows,
        require_approved_strategy=require_approved_strategy,
        strategy_approval_status=strategy_status,
        forward_validation_decision=forward_decision,
    )
    stage0_readiness = (
        STAGE0_READY
        if engineering_ready and safety_ok and target_validation_passed
        else STAGE0_NOT_READY
    )

    result = Launch1ReadinessResult(
        timestamp=timestamp,
        engineering_ready=engineering_ready,
        required_components_present=required_components,
        monday_checklist_exists=monday_dependency_items["monday_checklist_report"],
        monday_preflight_exists=monday_dependency_items["monday_preflight_report"],
        kite_daily_pipeline_exists=monday_dependency_items["kite_daily_pipeline_report"],
        post_recording_verifier_exists=monday_dependency_items["post_recording_verifier_report"],
        forward_validation_summary_exists=monday_dependency_items["forward_validation_summary"],
        approved_strategies_config_exists=monday_dependency_items["approved_strategies_config"],
        target_validation_date=target_date,
        target_validation_date_explicit=target_explicit,
        latest_verifier_date=latest_verifier_date,
        target_validation_passed=target_validation_passed,
        readiness_data_basis=readiness_data_basis,
        verifier_verdict=verifier_verdict,
        tick_rows=tick_rows,
        depth_rows=depth_rows,
        feature_rows=feature_rows,
        selected_contract=selected_contract,
        synthetic_rows=synthetic_rows,
        mixed_contracts=mixed_contracts,
        data_quality_status=data_quality_status,
        contract_consistency_status=contract_consistency_status,
        feature_mode=feature_mode,
        pipeline_report_status=pipeline_report_status,
        data_collection_report_status=data_collection_report_status,
        feature_rebuild_reconciliation_status=feature_rebuild_reconciliation_status,
        authoritative_feature_source=authoritative_feature_source,
        pipeline_report_stale_or_failed=pipeline_report_stale_or_failed,
        manual_feature_rebuild_reconciled_day=manual_feature_rebuild_reconciled_day,
        forward_validation_decision=forward_decision,
        strategy_approval_status=strategy_status,
        approved_strategy_policy=approved_policy,
        production_whatsapp_status=production_whatsapp,
        execution_allowed=execution_allowed,
        safety_ok=safety_ok,
        safety_issues=safety_issues,
        monday_dependency_items=monday_dependency_items,
        warnings=warnings,
        stage0_infrastructure_data_readiness=stage0_readiness,
        tradeable_launch1_readiness=TRADEABLE_LAUNCH1_NOT_READY,
        decision=decision,
        decision_reason=reason,
        next_action=next_action,
    )
    _write_report(base, result, require_approved_strategy=require_approved_strategy)
    _append_history(base, result)
    _print_summary(result)
    return result


def _decide_launch1_status(
    *,
    engineering_ready: bool,
    safety_ok: bool,
    target_validation_passed: bool,
    target_validation_date: date | None,
    latest_verifier_date: date | None,
    verifier_verdict: str,
    data_quality_status: str,
    mixed_contracts: bool,
    synthetic_rows: int,
    tick_rows: int,
    depth_rows: int,
    feature_rows: int,
    require_approved_strategy: bool,
    strategy_approval_status: str,
    forward_validation_decision: str,
) -> tuple[str, str, str]:
    if not safety_ok:
        return (
            LAUNCH1_BLOCKED_SAFETY,
            "Safety flags or report text indicate live/order risk.",
            "Restore PAPER/no-order safety flags and regenerate trusted reports before Launch 1.",
        )
    if require_approved_strategy and strategy_approval_status != "APPROVED":
        return (
            LAUNCH1_BLOCKED_STRATEGY_VALIDATION,
            "An approved strategy was required, but the candidate strategy is not approved.",
            "Keep the strategy in research/manual review until approval rules and manual review pass.",
        )

    target_date_has_verifier = latest_verifier_date is not None and latest_verifier_date == target_validation_date
    if not target_date_has_verifier:
        if engineering_ready:
            return (
                LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA,
                "Engineering components and safety checks are ready, but target Monday real-market validation has not been completed yet.",
                "Run the Monday recording pipeline, run the post-recording verifier for the target date, then regenerate this report.",
            )
        return (
            LAUNCH1_NOT_READY,
            "Required Launch 1 engineering components are missing and target Monday validation is not complete.",
            "Complete missing components/reports and rerun tests before Launch 1.",
        )

    if verifier_verdict in {"DAY_REJECTED_BAD_DATA", "DAY_REQUIRES_INVESTIGATION"}:
        return (
            LAUNCH1_BLOCKED_DATA_QUALITY,
            f"Target-date post-recording verifier verdict is {verifier_verdict}.",
            "Investigate/rebuild target-date files and rerun the post-recording verifier.",
        )
    if data_quality_status in {
        "FEATURE_GENERATION_PROBLEM",
        "INVESTIGATE_BEFORE_NEXT_RUN",
        "SYMBOL_RESOLUTION_PROBLEM",
        "TOKEN_OR_CREDENTIAL_PROBLEM",
    }:
        return (
            LAUNCH1_BLOCKED_DATA_QUALITY,
            f"Target-date Data Quality Gate status is {data_quality_status}.",
            "Fix the reported data-quality issue before Tuesday Launch 1 research monitoring.",
        )
    if mixed_contracts or synthetic_rows > 0:
        return (
            LAUNCH1_BLOCKED_DATA_QUALITY,
            "Target-date feature/verifier output contains mixed contracts or synthetic rows.",
            "Rebuild real-only feature files and verify single-contract consistency.",
        )
    if tick_rows <= 0 or depth_rows <= 0 or feature_rows <= 0:
        return (
            LAUNCH1_BLOCKED_DATA_QUALITY,
            "Target-date verifier exists, but tick/depth/feature rows are not all positive.",
            "Keep recorded data, rebuild features if needed, and rerun the verifier.",
        )
    if forward_validation_decision != "RESEARCH_ONLY":
        return (
            LAUNCH1_BLOCKED_STRATEGY_VALIDATION,
            f"Forward-validation decision is {forward_validation_decision}; Launch 1 paper/research gate expects RESEARCH_ONLY.",
            "Manually review strategy status before changing production alert or trading posture.",
        )
    if target_validation_passed:
        return (
            LAUNCH1_READY_FOR_PAPER_RESEARCH,
            "Target Monday real-market validation data was accepted for research and safety checks are clean.",
            "Run Tuesday Launch 1 in PAPER/research/manual-signal mode only; continue forward validation.",
        )
    if engineering_ready:
        return (
            LAUNCH1_ENGINEERING_READY_WAITING_FOR_MONDAY_DATA,
            "Engineering components are present, but target Monday accepted real-market verification is not available yet.",
            "Run Monday recording, feature build, post-recording verifier, then regenerate this report.",
        )
    return (
        LAUNCH1_NOT_READY,
        "Required Launch 1 engineering components or reports are missing.",
        "Complete missing components/reports and rerun tests before Launch 1.",
    )


def _write_report(
    base: Path,
    result: Launch1ReadinessResult,
    *,
    require_approved_strategy: bool,
) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "STAGE 0 / LEGACY LAUNCH 1 READINESS REPORT",
        f"Generated: {result.timestamp.isoformat()}",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "",
        "READINESS INTERPRETATION",
        f"Stage 0 Infrastructure/Data Readiness: {result.stage0_infrastructure_data_readiness}",
        f"Tradeable Launch 1: {result.tradeable_launch1_readiness}",
        (
            f"Legacy decision code: {result.decision} means only PAPER/research/data "
            "infrastructure readiness."
        ),
        "It does not mean signal generation is reliable.",
        "It does not mean any strategy is approved.",
        "It does not mean real-money manual trading is approved.",
        "Use python -m src.reports.tradeable_launch1_readiness_report for the tradeable-system gate.",
        "",
        "TARGET VALIDATION DATE",
        f"target_validation_date: {_date_text(result.target_validation_date)}",
        f"target_validation_date_explicit: {_bool_text(result.target_validation_date_explicit)}",
        f"latest_verifier_date: {_date_text(result.latest_verifier_date)}",
        f"target_validation_passed: {_bool_text(result.target_validation_passed)}",
        f"readiness_data_basis: {result.readiness_data_basis}",
        "date_warnings:",
        *([f"- {warning}" for warning in result.warnings] if result.warnings else ["NONE"]),
        "",
        "ENGINEERING READINESS",
        f"engineering_ready: {_bool_text(result.engineering_ready)}",
        "Required components:",
    ]
    lines.extend(
        f"- {component}: {'PRESENT' if present else 'MISSING'}"
        for component, present in result.required_components_present.items()
    )
    lines.extend(
        [
            "",
            "KITE DATA READINESS",
            f"monday_checklist_report_exists: {_bool_text(result.monday_checklist_exists)}",
            f"monday_preflight_report_exists: {_bool_text(result.monday_preflight_exists)}",
            f"kite_daily_pipeline_report_exists: {_bool_text(result.kite_daily_pipeline_exists)}",
            f"post_recording_verifier_report_exists: {_bool_text(result.post_recording_verifier_exists)}",
            f"latest_verifier_date: {_date_text(result.latest_verifier_date)}",
            f"target_validation_date: {_date_text(result.target_validation_date)}",
            f"target_validation_date_has_passed_verifier: {_bool_text(result.target_validation_passed)}",
            f"readiness_basis: {result.readiness_data_basis}",
            f"tick_rows: {result.tick_rows}",
            f"depth_rows: {result.depth_rows}",
            f"feature_rows: {result.feature_rows}",
            f"post_recording_verifier_verdict: {result.verifier_verdict}",
            "",
            "CONTRACT CONSISTENCY READINESS",
            f"contract_consistency_status: {result.contract_consistency_status}",
            f"selected_contract: {result.selected_contract}",
            f"synthetic_rows: {result.synthetic_rows}",
            f"mixed_contracts: {_bool_text(result.mixed_contracts)}",
            "",
            "FEATURE GENERATION READINESS",
            f"feature_mode: {result.feature_mode}",
            f"feature_rows: {result.feature_rows}",
            f"feature_generation_ready: {_bool_text(result.feature_rows > 0 and result.target_validation_passed)}",
            "",
            "RECONCILIATION STATUS",
            f"pipeline_report_status: {result.pipeline_report_status}",
            f"data_collection_report_status: {result.data_collection_report_status}",
            f"feature_rebuild_reconciliation_status: {result.feature_rebuild_reconciliation_status}",
            f"authoritative_feature_source: {result.authoritative_feature_source}",
            f"pipeline_report_stale_or_failed: {_bool_text(result.pipeline_report_stale_or_failed)}",
            f"manual_feature_rebuild_reconciled_day: {_bool_text(result.manual_feature_rebuild_reconciled_day)}",
            "",
            "DATA QUALITY READINESS",
            f"data_quality_status: {result.data_quality_status}",
            f"post_recording_verifier_verdict: {result.verifier_verdict}",
            f"target_validation_passed: {_bool_text(result.target_validation_passed)}",
            "",
            "FORWARD VALIDATION READINESS",
            f"forward_validation_summary_exists: {_bool_text(result.forward_validation_summary_exists)}",
            f"forward_validation_decision: {result.forward_validation_decision}",
            "automatic_strategy_approval: DISABLED",
            "",
            "STRATEGY APPROVAL STATUS",
            "strategy: GOLD-I VWAP Rejection Short",
            f"strategy_approval_status: {result.strategy_approval_status}",
            f"approved_strategies_config_exists: {_bool_text(result.approved_strategies_config_exists)}",
            f"approved_strategy_policy: {result.approved_strategy_policy or 'NOT_AVAILABLE'}",
            f"approved_strategy_required_for_this_report: {_bool_text(require_approved_strategy)}",
            "Launch 1 readiness does not mean real-money strategy approval.",
            "Current production trading/production alert approval: NOT_APPROVED",
            "",
            "WHATSAPP / ALERT STATUS",
            f"production_whatsapp_status: {result.production_whatsapp_status}",
            "research_whatsapp_preview: DISABLED_BY_DEFAULT",
            "Production WhatsApp remains blocked unless a strategy is manually approved later.",
            "",
            "SAFETY STATUS",
            f"safety_ok: {_bool_text(result.safety_ok)}",
            f"execution_allowed: {result.execution_allowed}",
            "ENABLE_LIVE_TRADING=false",
            "I_UNDERSTAND_LIVE_TRADING_RISK=false",
            "No broker orders. No real trading. No Kite order placement.",
            "safety_issues:",
            *([f"- {issue}" for issue in result.safety_issues] if result.safety_issues else ["NONE"]),
            "",
            "MONDAY DEPENDENCY CHECKLIST",
        ]
    )
    lines.extend(
        f"- {name}: {'OK' if ok else 'MISSING'}"
        for name, ok in result.monday_dependency_items.items()
    )
    lines.extend(
        [
            "",
            "TUESDAY LAUNCH 1 DECISION (LEGACY STAGE 0)",
            f"decision: {result.decision}",
            f"decision_reason: {result.decision_reason}",
            f"next_action: {result.next_action}",
            "",
            "IMPORTANT LIMITS",
            "This report evaluates Stage 0 infrastructure/data readiness, not tradeable Launch 1.",
            "Launch 1 is paper/research/manual signal only.",
            "Readiness for Launch 1 does NOT mean real-money trading.",
            "GOLD-I VWAP Rejection Short remains RESEARCH_ONLY unless approval rules and manual review pass.",
            "Production WhatsApp alerts remain blocked.",
            "PAPER MODE ONLY. No broker orders were placed.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _append_history(base: Path, result: Launch1ReadinessResult) -> None:
    path = base / HISTORY_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    _upgrade_history_header(path)
    write_header = not path.exists() or path.stat().st_size == 0
    row = {
        "timestamp": result.timestamp.isoformat(),
        "stage0_infrastructure_data_readiness": result.stage0_infrastructure_data_readiness,
        "tradeable_launch1_readiness": result.tradeable_launch1_readiness,
        "target_validation_date": _date_text(result.target_validation_date),
        "latest_verifier_date": _date_text(result.latest_verifier_date),
        "target_validation_passed": _bool_text(result.target_validation_passed),
        "decision": result.decision,
        "reason": result.decision_reason,
        "engineering_ready": _bool_text(result.engineering_ready),
        "safety_ok": _bool_text(result.safety_ok),
        "monday_verifier_verdict": result.verifier_verdict,
        "data_quality_status": result.data_quality_status,
        "contract_consistency_status": result.contract_consistency_status,
        "tick_rows": result.tick_rows,
        "depth_rows": result.depth_rows,
        "feature_rows": result.feature_rows,
        "forward_validation_decision": result.forward_validation_decision,
        "strategy_approval_status": result.strategy_approval_status,
        "production_whatsapp_status": result.production_whatsapp_status,
        "execution_allowed": result.execution_allowed,
        "report_path": str(result.report_path or REPORT_PATH),
    }
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=HISTORY_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    result.history_path = path


def _upgrade_history_header(path: Path) -> None:
    if not path.exists() or path.stat().st_size == 0:
        return
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        existing_columns = list(reader.fieldnames or [])
        rows = list(reader)
    if existing_columns == HISTORY_COLUMNS:
        return
    normalized = [{column: row.get(column, "") for column in HISTORY_COLUMNS} for row in rows]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=HISTORY_COLUMNS)
        writer.writeheader()
        writer.writerows(normalized)


def _print_summary(result: Launch1ReadinessResult) -> None:
    print("STAGE 0 / LEGACY LAUNCH 1 READINESS REPORT")
    print(f"Stage 0 Infrastructure/Data Readiness: {result.stage0_infrastructure_data_readiness}")
    print(f"Tradeable Launch 1: {result.tradeable_launch1_readiness}")
    print(f"Legacy Decision: {result.decision}")
    print(f"Reason: {result.decision_reason}")
    print(f"Target validation date: {_date_text(result.target_validation_date)}")
    print(f"Latest verifier date: {_date_text(result.latest_verifier_date)}")
    print(f"Target validation passed: {_bool_text(result.target_validation_passed)}")
    print(f"Readiness data basis: {result.readiness_data_basis}")
    print(f"Engineering ready: {_bool_text(result.engineering_ready)}")
    print(f"Post-recording verifier: {result.verifier_verdict}")
    print(f"Tick rows: {result.tick_rows}")
    print(f"Depth rows: {result.depth_rows}")
    print(f"Feature rows: {result.feature_rows}")
    print(f"Data Quality: {result.data_quality_status}")
    print(f"Feature Mode: {result.feature_mode}")
    print(f"Contract Consistency: {result.contract_consistency_status}")
    print(f"Reconciliation: {result.feature_rebuild_reconciliation_status}")
    print(f"Authoritative Feature Source: {result.authoritative_feature_source}")
    print(f"Contract: {result.selected_contract}")
    print(f"Forward Validation: {result.forward_validation_decision}")
    print(f"Strategy Approval: {result.strategy_approval_status}")
    print(f"Production WhatsApp: {result.production_whatsapp_status}")
    print("execution_allowed=false")
    print(f"Report: {result.report_path}")
    print(f"History: {result.history_path}")
    print("This is not strategy approval or real-money manual-trading approval.")
    print("PAPER MODE ONLY. No broker orders were placed.")


def _read_artifacts(base: Path) -> dict[str, str]:
    return {
        "monday_checklist": _read_text(base / MONDAY_CHECKLIST_PATH),
        "monday_preflight": _read_text(base / MONDAY_PREFLIGHT_PATH),
        "kite_daily_pipeline": _read_text(base / KITE_DAILY_PIPELINE_PATH),
        "post_recording_verifier": _read_text(base / POST_RECORDING_VERIFIER_PATH),
        "kite_data_collection": _read_text(base / KITE_DATA_COLLECTION_REPORT_PATH),
        "forward_validation_summary": _read_text(base / FORWARD_VALIDATION_SUMMARY_PATH),
        "approved_strategies": _read_text(base / APPROVED_STRATEGIES_PATH),
    }


def _load_configs_safely(base: Path) -> dict[str, Any]:
    try:
        return load_configs(base)
    except (FileNotFoundError, OSError):
        return {
            "settings": {"mode": "PAPER", "enable_live_trading": False},
            "forward_validation": {
                "production_alerts_allowed": False,
                "send_research_whatsapp_preview": False,
            },
            "approved_strategies": {},
        }


def _evaluate_safety(
    configs: dict[str, Any],
    text: str,
    production_whatsapp: str,
    execution_allowed: str,
) -> tuple[bool, list[str]]:
    settings = configs.get("settings", {}) if isinstance(configs, dict) else {}
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    issues: list[str] = []
    if str(settings.get("mode", "PAPER")).upper() != "PAPER":
        issues.append("config settings.mode is not PAPER")
    if bool(settings.get("enable_live_trading", False)):
        issues.append("config settings.enable_live_trading is true")
    if bool(forward.get("production_alerts_allowed", False)):
        issues.append("forward_validation.production_alerts_allowed is true")
    if _truthy(os.environ.get("ENABLE_LIVE_TRADING")):
        issues.append("environment ENABLE_LIVE_TRADING is truthy")
    if _truthy(os.environ.get("I_UNDERSTAND_LIVE_TRADING_RISK")):
        issues.append("environment I_UNDERSTAND_LIVE_TRADING_RISK is truthy")
    lowered = text.lower()
    uppered = text.upper()
    if "execution_allowed=true" in lowered:
        issues.append("a report contains execution_allowed=true")
    if "LIVE TRADING: ENABLED" in uppered:
        issues.append("a report says live trading is enabled")
    if "BROKER ORDERS: ENABLED" in uppered:
        issues.append("a report says broker orders are enabled")
    if execution_allowed != "false":
        issues.append("execution_allowed=false was not confirmed")
    if production_whatsapp != "BLOCKED":
        issues.append("production WhatsApp is not confirmed blocked")
    return not issues, issues


def _production_whatsapp_status(text: str, configs: dict[str, Any]) -> str:
    forward = configs.get("forward_validation", {}) if isinstance(configs, dict) else {}
    if bool(forward.get("production_alerts_allowed", False)):
        return "ALLOWED"
    uppered = text.upper()
    if "PRODUCTION WHATSAPP" in uppered and "ALLOWED" in uppered and "BLOCKED" not in uppered:
        return "UNKNOWN_OR_ALLOWED"
    return "BLOCKED"


def _execution_allowed_status(text: str) -> str:
    lowered = text.lower()
    if "execution_allowed=true" in lowered:
        return "true"
    return "false"


def _extract_value(text: str, prefix: str, *, section: str | None = None) -> str:
    source = text
    if section:
        marker = section + "\n"
        if marker not in text:
            return ""
        source = text.split(marker, 1)[1].split("\n\n", 1)[0]
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            return stripped.split(prefix, 1)[1].strip()
    return ""


def _extract_date_value(text: str, prefix: str) -> date | None:
    value = _extract_value(text, prefix)
    if not value:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None


def _resolve_target_validation_date(value: str | date | None, *, today: date) -> tuple[date, bool]:
    if isinstance(value, date):
        return value, True
    if value:
        return date.fromisoformat(str(value)), True
    return _next_monday_on_or_after(today), False


def _next_monday_on_or_after(day: date) -> date:
    days_ahead = (0 - day.weekday()) % 7
    return day + timedelta(days=days_ahead)


def _target_date_warnings(
    *,
    explicit: bool,
    target_date: date,
    latest_verifier_date: date | None,
    verifier_verdict: str,
) -> list[str]:
    warnings: list[str] = []
    if not explicit:
        warnings.append(
            "Target validation date was inferred as the next Monday; pass --target-validation-date YYYY-MM-DD to confirm it explicitly."
        )
    if latest_verifier_date is None:
        warnings.append("No latest post-recording verifier date was found.")
    elif latest_verifier_date != target_date:
        warnings.append(
            f"Latest verifier date {latest_verifier_date.isoformat()} is not the target validation date {target_date.isoformat()}; treating it as historical/test data only."
        )
    elif verifier_verdict != "DAY_ACCEPTED_FOR_RESEARCH":
        warnings.append(
            f"Target validation date verifier exists, but verdict is {verifier_verdict}."
        )
    return warnings


def _readiness_data_basis(
    latest_verifier_date: date | None,
    target_date: date,
    target_validation_passed: bool,
) -> str:
    if target_validation_passed:
        return "ACTUAL_TARGET_MONDAY_VALIDATION_DATA"
    if latest_verifier_date is None:
        return "NO_VERIFIER_DATA"
    if latest_verifier_date == target_date:
        return "TARGET_DATE_DATA_NOT_ACCEPTED"
    return "HISTORICAL_OR_TEST_DATA_ONLY"


def _sum_file_rows(text: str, line_prefix: str) -> int:
    total = 0
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(line_prefix):
            match = re.search(r"rows=(\d+)", stripped)
            if match:
                total += int(match.group(1))
    return total


def _sum_int_lines(text: str, prefix: str) -> int:
    total = 0
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            value = stripped.split(prefix, 1)[1].strip()
            try:
                total += int(value)
            except ValueError:
                continue
    return total


def _any_bool_lines(text: str, prefix: str) -> bool:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix) and stripped.split(prefix, 1)[1].strip().lower() == "true":
            return True
    return False


def _extract_bool_value(text: str, prefix: str) -> bool:
    value = _extract_value(text, prefix).strip().lower()
    return value == "true"


def _reconciled_value(
    *,
    use_reconciled: bool,
    reconciled_values: list[str],
    fallback_values: list[str],
) -> str:
    if use_reconciled:
        value = _first_non_empty(*reconciled_values)
        if value:
            return value
    return _first_non_empty(*fallback_values)


def _first_non_empty(*values: str) -> str:
    for value in values:
        if str(value or "").strip():
            return str(value).strip()
    return ""


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _bool_text(value: bool) -> str:
    return "true" if bool(value) else "false"


def _date_text(value: date | None) -> str:
    return value.isoformat() if value else "NOT_AVAILABLE"


def _parse_bool(value: str | bool | None) -> bool:
    return value is True or str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create a Launch 1 PAPER/research readiness report from local reports only."
    )
    parser.add_argument(
        "--target-validation-date",
        help="Required Monday validation date in YYYY-MM-DD form. If omitted, next Monday is inferred with a warning.",
    )
    parser.add_argument(
        "--require-approved-strategy",
        default="false",
        help="Set true only when evaluating a production-approved strategy requirement.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    generate_launch1_readiness_report(
        target_validation_date=args.target_validation_date,
        require_approved_strategy=_parse_bool(args.require_approved_strategy),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
