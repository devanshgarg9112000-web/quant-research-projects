﻿from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from src.research.forward_validation import analyze_independent_evidence, load_ledger


REPORT_PATH = Path("reports") / "forward_validation" / "latest_forward_validation_independence_report.txt"
SUPPORTED_FAMILY = "gold_vwap_rejection_reclaim_family"
CANONICAL_SETUP = "gold_vwap_rejection_short"
RECOMMENDED_NEXT_ENGINEERING_TASK = (
    "Create/extend a forward validation ledger schema for post-lock VWAP signals with "
    "lock_version, signal_id, session_id, provider, entry/SL/target/result, and post_lock=true/false."
)


@dataclass(frozen=True)
class ForwardValidationIndependenceResult:
    report_path: Path
    family: str
    forward_validation_independence_status: str
    current_forward_trades: int
    required_forward_trades: int
    forward_sample_sufficient: bool
    real_money_approval_allowed: bool
    production_alerts_allowed: bool


def generate_forward_validation_independence_report(
    base_dir: Path | str = ".",
    *,
    family: str = SUPPORTED_FAMILY,
    now: datetime | None = None,
) -> ForwardValidationIndependenceResult:
    """Create a local-file-only report defining independent forward validation for the VWAP family."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    evidence = _collect_evidence(base)
    gates = _evaluate_independence_gates(evidence, family)
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(_format_report(timestamp, family, evidence, gates) + "\n", encoding="utf-8")
    return ForwardValidationIndependenceResult(
        report_path=report_path,
        family=family,
        forward_validation_independence_status="NOT_PASSED",
        current_forward_trades=int(evidence["current_forward_trades"]),
        required_forward_trades=int(evidence["required_forward_trades"]),
        forward_sample_sufficient=bool(evidence["forward_sample_sufficient"]),
        real_money_approval_allowed=False,
        production_alerts_allowed=False,
    )


def _collect_evidence(base: Path) -> dict[str, Any]:
    identity_config_text = _read_text(base / "config" / "strategy_identity.yaml")
    identity_report = _read_text(base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt")
    spec_report = _read_text(base / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt")
    execution_gate = _read_text(base / "reports" / "strategy_audits" / "latest_backtest_execution_quality_gate.txt")
    bias_audit = _read_text(base / "reports" / "strategy_audits" / "latest_vwap_family_backtest_bias_audit.txt")
    forward_summary = _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt")
    forward_config = _read_text(base / "config" / "forward_validation.yaml")
    approved_config = _read_text(base / "config" / "approved_strategies.yaml")

    ledger_rows = load_ledger(base)
    ledger_evidence = analyze_independent_evidence(base, ledger_rows)
    current_forward_trades = ledger_evidence.completed_independent_post_lock_trades
    required_forward_trades = ledger_evidence.required_forward_trades
    required_forward_sessions = ledger_evidence.required_forward_sessions
    forward_sample_sufficient = (
        current_forward_trades >= required_forward_trades
        and ledger_evidence.distinct_post_lock_sessions >= required_forward_sessions
    )
    conservative_execution_available = (
        "CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK" in execution_gate
        or "Conservative execution model available: true" in execution_gate
    )
    identity_locked = (
        "Canonical strategy identity config: FOUND" in identity_report
        or "Approval identity consistency | PASS" in execution_gate
        or "gold_vwap_rejection_reclaim_family" in identity_config_text
    )
    production_alerts_allowed = "production_alerts_allowed: true" in identity_config_text or (
        "production_alerts_allowed: true" in forward_config.lower()
    )
    real_money_allowed = "real_money_approved: true" in identity_config_text or "APPROVED" in approved_config
    active_lock = _extract_yaml_block(identity_config_text, "active_research_lock")
    forward_lock_version = _extract_yaml_value(forward_config, "active_lock_version")
    forward_lock_timestamp = _extract_yaml_value(forward_config, "active_lock_timestamp")
    strategy_lock_status = active_lock.get("lock_status") or ("LOCKED_FOR_FORWARD_RESEARCH" if forward_lock_version else ("PARTIAL" if conservative_execution_available else "NOT_LOCKED"))
    return {
        "identity_config_text": identity_config_text,
        "identity_report": identity_report,
        "spec_report": spec_report,
        "execution_gate": execution_gate,
        "bias_audit": bias_audit,
        "forward_summary": forward_summary,
        "forward_config": forward_config,
        "approved_config": approved_config,
        "canonical_family": SUPPORTED_FAMILY,
        "canonical_setup": CANONICAL_SETUP,
        "strategy_status": _extract_prefixed_value(spec_report, "Current family approval status:") or "RESEARCH_ONLY",
        "execution_model": "CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK" if conservative_execution_available else "NOT_CONFIRMED",
        "identity_locked": identity_locked,
        "execution_model_locked": conservative_execution_available,
        "strategy_lock_status": strategy_lock_status,
        "lock_version": active_lock.get("lock_version") or forward_lock_version or "UNKNOWN",
        "lock_timestamp": active_lock.get("lock_timestamp") or forward_lock_timestamp or "UNKNOWN",
        "total_ledger_rows": ledger_evidence.total_ledger_rows,
        "legacy_pre_lock_rows": ledger_evidence.legacy_pre_lock_rows,
        "pending_post_lock_rows": ledger_evidence.pending_post_lock_rows,
        "current_forward_trades": current_forward_trades,
        "completed_independent_post_lock_trades": ledger_evidence.completed_independent_post_lock_trades,
        "distinct_post_lock_sessions": ledger_evidence.distinct_post_lock_sessions,
        "required_forward_trades": required_forward_trades,
        "required_forward_sessions": required_forward_sessions,
        "forward_sample_sufficient": forward_sample_sufficient,
        "provider_breakdown": ledger_evidence.provider_breakdown,
        "independent_provider_breakdown": ledger_evidence.independent_provider_breakdown,
        "ineligible_reasons": _format_reason_counts(ledger_evidence.ineligible_reasons),
        "production_alerts_allowed": production_alerts_allowed,
        "real_money_allowed": real_money_allowed,
        "execution_allowed_false": "execution_allowed=false" in execution_gate
        and "execution_allowed=false" in spec_report,
    }
def _evaluate_independence_gates(evidence: dict[str, Any], family: str) -> list[dict[str, str]]:
    execution_model_status = "PASS" if evidence["execution_model_locked"] else "PARTIAL"
    post_lock_status = "PARTIAL" if evidence["current_forward_trades"] > 0 else "FAIL"
    return [
        _gate(
            "canonical_identity_locked",
            "PASS" if family == SUPPORTED_FAMILY and evidence["identity_locked"] else "FAIL",
            f"canonical_family={SUPPORTED_FAMILY}; canonical_setup={CANONICAL_SETUP}; identity_locked={evidence['identity_locked']}.",
            "Keep canonical identity frozen in config/strategy_identity.yaml before counting new trades.",
        ),
        _gate(
            "execution_model_locked",
            execution_model_status,
            f"execution_model={evidence['execution_model']}; recent execution gate remains FAIL until forward evidence is independent.",
            "Do not count old samples as fully independent until post-lock ledger rows prove the same execution rules were used.",
        ),
        _gate(
            "post_lock_forward_sample_exists",
            post_lock_status,
            f"current_forward_trades={evidence['current_forward_trades']}; existing rows are treated as PRE_LOCK_RESEARCH_SAMPLE unless post_lock metadata proves otherwise.",
            "Add lock_version and post_lock=true/false to the forward validation ledger.",
        ),
        _gate(
            "forward_sample_sufficient",
            "PASS" if evidence["forward_sample_sufficient"] else "FAIL",
            f"current_forward_trades={evidence['current_forward_trades']}; required_forward_trades={evidence['required_forward_trades']}; forward_sample_sufficient={str(evidence['forward_sample_sufficient']).lower()}.",
            "Collect at least 30 post-lock independent forward trades across at least 5 sessions.",
        ),
        _gate(
            "forward_data_not_used_for_tuning",
            "UNKNOWN",
            "Current files do not prove that existing forward/replay rows were excluded from parameter tuning.",
            "Freeze parameters and separate future validation ledger from research/optimization evidence.",
        ),
        _gate(
            "production_alerts_blocked",
            "PASS" if not evidence["production_alerts_allowed"] else "FAIL",
            f"production_alerts_allowed={str(evidence['production_alerts_allowed']).lower()}.",
            "Keep production WhatsApp/social alerts blocked until manual approval.",
        ),
        _gate(
            "real_money_approval_false",
            "PASS" if not evidence["real_money_allowed"] else "FAIL",
            f"real_money_approval_allowed={str(evidence['real_money_allowed']).lower()}.",
            "Do not approve real-money trading until all approval gates and manual review pass.",
        ),
    ]


def _gate(gate: str, status: str, evidence: str, required_fix: str) -> dict[str, str]:
    return {"gate": gate, "status": status, "evidence": evidence, "required_fix": required_fix}


def _format_report(timestamp: datetime, family: str, evidence: dict[str, Any], gates: list[dict[str, str]]) -> str:
    lines = [
        "FORWARD VALIDATION INDEPENDENCE PROTOCOL REPORT",
        f"Generated At: {timestamp.isoformat()}",
        "Recommended Codex Level Used: Medium",
        f"Strategy Family: {family}",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "Real Money Approval: false",
        "",
        "EXECUTIVE DECISION",
        "forward_validation_independence_status: NOT_PASSED",
        "real_money_approval_allowed: false",
        "production_alerts_allowed: false",
        "execution_allowed=false",
        "Decision reason: Current evidence is research-only/pre-lock or not proven post-lock; collect new independent forward trades after strategy identity and conservative execution rules are locked.",
        "",
        "STRATEGY LOCK INFORMATION",
        f"canonical family: {SUPPORTED_FAMILY}",
        f"canonical setup: {CANONICAL_SETUP}",
        f"strategy status: {evidence['strategy_status']}",
        f"execution model: {evidence['execution_model']}",
        f"strategy_lock_status: {evidence['strategy_lock_status']}",
        f"lock_version: {evidence['lock_version']}",
        f"lock_timestamp: {evidence['lock_timestamp']}",
        "reason: execution model was recently formalized, so the independent sample must be collected after lock and marked explicitly in the ledger.",
        "",
        "INDEPENDENCE RULES",
        "A forward trade counts as independent only if:",
        "- it occurs after canonical strategy identity is locked",
        "- it occurs after conservative execution model is locked",
        "- it is not used to tune parameters",
        "- it uses the same rules as backtest",
        "- it has provider/date/session metadata",
        "- it has entry, stop, target, result, and MFE/MAE where available",
        "- it is paper/manual observation only until approval",
        "",
        "CURRENT EVIDENCE",
        f"total_ledger_rows: {evidence['total_ledger_rows']}",
        f"legacy_pre_lock_rows: {evidence['legacy_pre_lock_rows']}",
        "legacy_rows_counted_for_approval: 0",
        f"pending_post_lock_rows: {evidence['pending_post_lock_rows']}",
        f"completed_independent_post_lock_trades: {evidence['completed_independent_post_lock_trades']}",
        f"distinct_post_lock_sessions: {evidence['distinct_post_lock_sessions']}",
        f"current_forward_trades: {evidence['current_forward_trades']}",
        f"required_forward_trades: {evidence['required_forward_trades']}",
        f"required_forward_sessions: {evidence['required_forward_sessions']}",
        f"forward_sample_sufficient: {str(evidence['forward_sample_sufficient']).lower()}",
        f"provider_breakdown: {evidence['provider_breakdown']}",
        f"independent_provider_breakdown: {evidence['independent_provider_breakdown']}",
        f"ineligible_reasons: {evidence['ineligible_reasons']}",
        "current_sample_classification: PRE_LOCK_RESEARCH_SAMPLE unless post_lock=true and lock_version metadata proves otherwise",
        "current trades are research-only and not enough for approval.",
        "",
        "REQUIRED NEXT VALIDATION PLAN",
        "- collect at least 30 post-lock forward trades",
        "- collect across at least 5 distinct sessions",
        "- keep production alerts blocked",
        "- no real-money trading",
        "- no auto execution",
        "- use conservative execution model",
        "- maintain forward validation ledger",
        "",
        "INDEPENDENCE GATE TABLE",
        "gate | status | evidence | required_fix",
    ]
    for gate in gates:
        lines.append(" | ".join([gate["gate"], gate["status"], gate["evidence"], gate["required_fix"]]))
    lines.extend(
        [
            "",
            "RECOMMENDED NEXT ENGINEERING TASK",
            RECOMMENDED_NEXT_ENGINEERING_TASK,
            "",
            "SAFETY CONFIRMATION",
            "No live data used.",
            "No broker orders.",
            "No production WhatsApp.",
            "execution_allowed=false.",
            "Real-money trading remains 0% approved.",
            "No strategy approval was changed.",
            "No strategy, backtest execution, forward-validation rules, alert behavior, or order behavior was changed.",
        ]
    )
    return "\n".join(lines)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _extract_prefixed_value(text: str, prefix: str) -> str:
    prefix_lower = prefix.lower()
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith(prefix_lower):
            return stripped.split(":", 1)[1].strip() if ":" in stripped else ""
    return ""


def _extract_yaml_block(text: str, block_name: str) -> dict[str, str]:
    values: dict[str, str] = {}
    in_block = False
    for raw in text.splitlines():
        if raw.strip() == f"{block_name}:":
            in_block = True
            continue
        if in_block and raw and not raw.startswith(" "):
            break
        if not in_block or ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        values[key.strip()] = value.strip().strip("\"").strip("'")
    return values


def _extract_yaml_value(text: str, key: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{key}:"):
            return stripped.split(":", 1)[1].strip()
    return ""


def _first_int(*values: str) -> int:
    for value in values:
        try:
            if value not in (None, ""):
                return int(float(str(value).strip()))
        except ValueError:
            continue
    return 0


def _format_reason_counts(reasons: tuple[tuple[str, int], ...]) -> str:
    if not reasons:
        return "NONE"
    return ", ".join(f"{reason}={count}" for reason, count in reasons)

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create a local-file-only forward-validation independence protocol report."
    )
    parser.add_argument("--family", default=SUPPORTED_FAMILY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = generate_forward_validation_independence_report(family=args.family)
    print("FORWARD VALIDATION INDEPENDENCE PROTOCOL REPORT")
    print(f"Report path: {result.report_path}")
    print(f"Strategy Family: {result.family}")
    print(f"forward_validation_independence_status: {result.forward_validation_independence_status}")
    print(f"current_forward_trades: {result.current_forward_trades}")
    print(f"required_forward_trades: {result.required_forward_trades}")
    print(f"forward_sample_sufficient: {str(result.forward_sample_sufficient).lower()}")
    print("real_money_approval_allowed: false")
    print("production_alerts_allowed: false")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())




