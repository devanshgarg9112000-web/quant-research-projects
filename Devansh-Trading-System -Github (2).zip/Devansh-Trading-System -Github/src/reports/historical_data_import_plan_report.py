from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


REPORT_PATH = Path("reports") / "strategy_audits" / "latest_historical_data_import_plan_report.txt"
FOCUS_FAMILY = "gold_vwap_rejection_reclaim_family"
LOCK_VERSION = "GOLD_VWAP_RESEARCH_LOCK_V1"
REQUIRED_COLUMNS = [
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "symbol",
    "provider",
    "timeframe",
    "contract",
    "expiry",
    "is_continuous",
    "source_file",
]
VALIDATION_CHECKLIST = [
    "row count",
    "date range",
    "duplicate timestamps",
    "missing sessions",
    "missing OHLC",
    "high < low invalid bars",
    "zero/negative prices",
    "volume sanity",
    "timezone normalization",
    "continuous contract metadata",
    "no lookahead roll adjustment",
    "stable file hash or import manifest",
]
REGIME_LABELS = [
    "trend_up",
    "trend_down",
    "range",
    "high_volatility",
    "low_volatility",
    "gap_day",
    "trend_day",
    "range_day",
    "low_liquidity",
    "high_liquidity",
    "event_day_optional_manual_tag",
]


@dataclass(frozen=True)
class HistoricalDataImportPlanResult:
    report_path: Path
    historical_import_required: bool
    multi_year_backtest_currently_reliable: bool
    regime_labeling_required: bool
    next_best_task: str
    real_money_approval_allowed: bool
    execution_allowed: bool


def generate_historical_data_import_plan_report(
    base_dir: Path | str = ".",
    *,
    now: datetime | None = None,
) -> HistoricalDataImportPlanResult:
    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(_format_report(timestamp) + "\n", encoding="utf-8")
    return HistoricalDataImportPlanResult(
        report_path=report_path,
        historical_import_required=True,
        multi_year_backtest_currently_reliable=False,
        regime_labeling_required=True,
        next_best_task="create importer/validator after choosing data source",
        real_money_approval_allowed=False,
        execution_allowed=False,
    )


def _format_report(timestamp: datetime) -> str:
    lines = [
        "HISTORICAL OHLCV IMPORT PLAN + REGIME LABELING READINESS REPORT",
        f"generated_at: {timestamp.isoformat()}",
        "Mode: REPORT + PLAN ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Production WhatsApp: BLOCKED",
        "execution_allowed=false",
        "",
        "CURRENT DATA LIMITATION SUMMARY",
        "available_providers: TRUEDATA; KITE; LOCAL",
        "available_symbols: GOLD-I; SILVER-I; latest_truedata samples",
        "TrueData OHLCV bars: 2026-06-04 to 2026-06-19 only",
        "TrueData ticks: 2026-06-15 to 2026-06-19 only",
        "Kite recorded GOLD-I ticks/depth/features: 2026-06-19 to 2026-06-23 only",
        "REGIME_LABELS_MISSING: true",
        "why_insufficient: current data is too short, mostly June 2026, and cannot prove multi-year, multi-regime robustness.",
        "why_still_useful: useful for engineering validation, schema checks, forward validation plumbing, and PAPER observation workflows.",
        f"strategy_family_in_focus: {FOCUS_FAMILY}",
        f"lock_version: {LOCK_VERSION}",
        "strategy_status: RESEARCH_ONLY",
        "",
        "RECOMMENDED HISTORICAL DATA TARGET",
        "minimum_history: at least 2 years OHLCV bars",
        "preferred_history: 3-5 years if available",
        "priority_symbols: GOLD-I; SILVER-I first",
        "preferred_timeframe: 1-minute bars",
        "optional_timeframes: derive 5-minute and 15-minute bars from validated 1-minute bars",
        "continuous_futures_handling_required: true",
        "contract_rollover_expiry_handling_required: true",
        "timezone_consistency_required: Asia/Kolkata normalized timestamps preferred",
        "duplicate_missing_bar_checks_required: true",
        "session_calendar_handling_required: true",
        "no_lookahead_roll_adjustment_required: true",
        "",
        "DATA SCHEMA RECOMMENDATION",
        r"target_folder: data\historical\ohlcv\provider\symbol\timeframe\YYYY.csv",
        "required_columns:",
    ]
    lines.extend(f"- {column}" for column in REQUIRED_COLUMNS)
    lines.extend(
        [
            "",
            "IMPORT VALIDATION CHECKLIST",
        ]
    )
    lines.extend(f"- {item}" for item in VALIDATION_CHECKLIST)
    lines.extend(
        [
            "",
            "REGIME LABELING READINESS",
            "regime_labeling_required: true",
            "Regime labels must be generated after clean data import and before trusting multi-year conclusions.",
            "future_regime_labels:",
        ]
    )
    lines.extend(f"- {label}" for label in REGIME_LABELS)
    lines.extend(
        [
            "",
            "STAGED PLAN",
            "Stage 1: import long OHLCV data",
            "Stage 2: validate and create import manifest",
            "Stage 3: create regime labeling report",
            "Stage 4: run bar-level backtests for READY_FOR_BAR_BACKTEST strategies",
            "Stage 5: VWAP family bar replay",
            "Stage 6: walk-forward/month-by-month/OOS analysis",
            "Stage 7: combine with post-lock forward validation",
            "",
            "FINAL VERDICT",
            "historical_import_required: true",
            "multi_year_backtest_currently_reliable: false",
            "regime_labeling_required: true",
            "next_best_task: create importer/validator after choosing data source",
            "real_money_approval_allowed: false",
            "production_whatsapp_allowed: false",
            "broker_orders_enabled: false",
            "execution_allowed=false",
            "",
            "SAFETY CONFIRMATION",
            "No live data used.",
            "No historical data downloaded automatically.",
            "No broker orders.",
            "No production WhatsApp.",
            "No strategy logic changed.",
            "No signal-generation rules changed.",
            "Real-money trading remains 0% approved.",
            "execution_allowed=false.",
        ]
    )
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate historical OHLCV import and regime labeling plan report.")
    parser.parse_args(argv)
    result = generate_historical_data_import_plan_report()
    print("HISTORICAL OHLCV IMPORT PLAN + REGIME LABELING READINESS REPORT")
    print(f"Report path: {result.report_path}")
    print(f"historical_import_required: {str(result.historical_import_required).lower()}")
    print(f"multi_year_backtest_currently_reliable: {str(result.multi_year_backtest_currently_reliable).lower()}")
    print(f"regime_labeling_required: {str(result.regime_labeling_required).lower()}")
    print(f"next_best_task: {result.next_best_task}")
    print("real_money_approval_allowed: false")
    print("execution_allowed=false")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
