from __future__ import annotations

import argparse
import csv
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable


TRADEABLE_LAUNCH1_NOT_READY = "TRADEABLE_LAUNCH1_NOT_READY"
TRADEABLE_LAUNCH1_READY_FOR_MANUAL_APPROVAL = "TRADEABLE_LAUNCH1_READY_FOR_MANUAL_APPROVAL"

REPORT_PATH = Path("reports") / "launch1" / "latest_tradeable_launch1_readiness_report.txt"
HISTORY_PATH = Path("reports") / "launch1" / "tradeable_launch1_readiness_history.csv"
LAUNCH1_REPORT_PATH = Path("reports") / "launch1" / "latest_launch1_readiness_report.txt"
FINAL_SAFETY_PATH = Path("reports") / "final_safety" / "latest_final_safety_audit_report.txt"
FORWARD_VALIDATION_PATH = Path("reports") / "forward_validation" / "latest_forward_validation_summary.txt"
DEEP_DIVE_PATH = Path("reports") / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.txt"
DEEP_DIVE_CSV_PATH = Path("reports") / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.csv"
STRATEGY_RESEARCH_PATH = Path("reports") / "strategy_research" / "latest_strategy_research_report.txt"
APPROVED_STRATEGIES_PATH = Path("config") / "approved_strategies.yaml"

HISTORY_COLUMNS = [
    "timestamp",
    "decision",
    "stage0_status",
    "recorder_stability_status",
    "strategy_inventory_status",
    "professional_backtesting_status",
    "cost_slippage_status",
    "out_of_sample_status",
    "robustness_status",
    "forward_validation_status",
    "strategy_approval_status",
    "signal_generation_status",
    "alert_delivery_status",
    "manual_risk_plan_status",
    "final_safety_status",
    "real_money_approval",
    "execution_allowed",
    "production_whatsapp_status",
    "report_path",
]


@dataclass(frozen=True)
class ReadinessGate:
    number: int
    key: str
    label: str
    status: str
    blocking: bool
    evidence: str


@dataclass
class TradeableLaunch1ReadinessResult:
    timestamp: datetime
    decision: str
    decision_reason: str
    gates: list[ReadinessGate]
    stage0_status: str
    final_safety_verdict: str
    strategy_approval_status: str
    forward_validation_status: str
    production_whatsapp_status: str = "BLOCKED"
    execution_allowed: str = "false"
    real_money_approval: bool = False
    warnings: list[str] = field(default_factory=list)
    report_path: Path | None = None
    history_path: Path | None = None


def generate_tradeable_launch1_readiness_report(
    base_dir: Path | str = ".",
    *,
    now_fn: Callable[[], datetime] | None = None,
) -> TradeableLaunch1ReadinessResult:
    """Evaluate readiness for manual real-money Launch 1 using local evidence only.

    This report never grants real-money approval automatically. It performs no network,
    broker, recorder, alert, or order action.
    """

    base = Path(base_dir)
    timestamp = (now_fn or (lambda: datetime.now().astimezone()))()
    launch_text = _read_text(base / LAUNCH1_REPORT_PATH)
    safety_text = _read_text(base / FINAL_SAFETY_PATH)
    forward_text = _read_text(base / FORWARD_VALIDATION_PATH)
    deep_text = _read_text(base / DEEP_DIVE_PATH)
    research_text = _read_text(base / STRATEGY_RESEARCH_PATH)
    deep_csv_text = _read_text(base / DEEP_DIVE_CSV_PATH)
    approved_text = _read_text(base / APPROVED_STRATEGIES_PATH)

    legacy_decision = _extract_value(launch_text, "decision:") or "NOT_AVAILABLE"
    target_validation_passed = _extract_value(launch_text, "target_validation_passed:").lower() == "true"
    stage0_status = _extract_value(launch_text, "Stage 0 Infrastructure/Data Readiness:")
    if not stage0_status:
        stage0_status = (
            "READY"
            if legacy_decision == "LAUNCH1_READY_FOR_PAPER_RESEARCH" and target_validation_passed
            else "NOT_READY"
        )

    final_safety_verdict = _extract_after_heading(safety_text, "FINAL VERDICT") or "NOT_AVAILABLE"
    recorder_code = _read_text(base / "src" / "data_collection" / "kite_live_recorder.py")
    pipeline_code = _read_text(base / "src" / "data_collection" / "kite_daily_pipeline.py")
    recorder_memory_safe = (
        "_StreamingCsvAppender" in recorder_code
        and "memory_safe_streaming" in recorder_code
        and "chunk_seconds" in pipeline_code
    )

    forward_decision = _extract_value(forward_text, "Approval Decision:") or "RESEARCH_ONLY"
    forward_trades = _extract_metric_int(forward_text, "Forward/replay-recorded trades:", "trades")
    strategy_status = _first_non_empty(
        _extract_value(launch_text, "strategy_approval_status:"),
        forward_decision,
        "RESEARCH_ONLY",
    )
    production_whatsapp = "BLOCKED" if "BLOCKED" in (launch_text + safety_text + forward_text).upper() else "NOT_CONFIRMED"
    execution_allowed = "true" if "execution_allowed=true" in (launch_text + safety_text + forward_text).lower() else "false"

    low_sample = any(
        marker in (deep_text + research_text + forward_text).upper()
        for marker in ["LOW_SAMPLE", "LOW_TRADE_COUNT", "TOO FEW", "AT LEAST 10"]
    )
    overfit_warning = "OVERFIT_RISK" in (deep_text + research_text).upper()
    validation_present = "Validation:" in deep_text or "validation=" in research_text
    robustness_label = _extract_value(deep_text, "Robustness:") or "NOT_AVAILABLE"
    cost_model_present = all(
        marker in deep_csv_text
        for marker in ["adjusted_entry", "adjusted_exit", "gross_pnl", "trade_net_pnl"]
    )
    inventory_evidence = "tested 72 variants" in research_text.lower()
    approved_config_is_policy_only = "allow_approved" in approved_text and strategy_status != "APPROVED"

    gates = [
        ReadinessGate(
            1,
            "stage0_infrastructure_data",
            "Stage 0 infrastructure/data readiness",
            stage0_status,
            stage0_status != "READY",
            f"legacy_decision={legacy_decision}; target_validation_passed={_bool_text(target_validation_passed)}",
        ),
        ReadinessGate(
            2,
            "recorder_stability",
            "Recorder stability readiness",
            "CODE_READY / NEEDS_NEXT_LIVE_CHUNK_VALIDATION" if recorder_memory_safe else "NOT_READY",
            True,
            "Memory-safe streaming/chunk support exists, but a fresh market-hours chunked live validation is still required."
            if recorder_memory_safe
            else "Memory-safe streaming/chunk implementation was not confirmed.",
        ),
        ReadinessGate(
            3,
            "strategy_inventory",
            "Strategy inventory complete",
            "NOT_CONFIRMED",
            True,
            "Research variants exist, but no signed-off complete strategy inventory/audit was found."
            + (" Research lab evidence was found." if inventory_evidence else ""),
        ),
        ReadinessGate(
            4,
            "professional_backtesting",
            "Professional backtesting complete",
            "NOT_READY",
            True,
            "Current candidate evidence remains low-sample and is not approval-grade."
            if low_sample
            else "No approval-grade professional backtest evidence was found.",
        ),
        ReadinessGate(
            5,
            "cost_slippage_model",
            "Cost/slippage model complete",
            "IMPLEMENTED / NEEDS_APPROVAL_VALIDATION" if cost_model_present else "NOT_READY",
            True,
            "Adjusted entry/exit, gross PnL, and net PnL fields are present, but the model is not validated for an approved strategy."
            if cost_model_present
            else "A complete cost/slippage evidence trail was not found.",
        ),
        ReadinessGate(
            6,
            "out_of_sample_walk_forward",
            "Out-of-sample or walk-forward validation complete",
            "NOT_READY",
            True,
            "A train/validation split exists, but the validation sample is too small for approval."
            if validation_present and low_sample
            else "Approval-grade out-of-sample/walk-forward evidence was not found.",
        ),
        ReadinessGate(
            7,
            "robustness_sensitivity",
            "Robustness/sensitivity tests complete",
            "NOT_READY",
            True,
            f"Reported robustness={robustness_label}, but low-sample/overfit warnings prevent approval."
            if robustness_label != "NOT_AVAILABLE" and (low_sample or overfit_warning)
            else "Approval-grade robustness evidence was not found.",
        ),
        ReadinessGate(
            8,
            "forward_validation_sample",
            "Forward validation sample size sufficient",
            "RESEARCH_ONLY / INSUFFICIENT_FOR_APPROVAL",
            True,
            f"forward_trades={forward_trades}; decision={forward_decision}",
        ),
        ReadinessGate(
            9,
            "strategy_approval",
            "Strategy approval status",
            strategy_status,
            strategy_status != "APPROVED",
            "No manual APPROVED strategy is present; approved_strategies.yaml is policy only."
            if approved_config_is_policy_only
            else "Strategy approval evidence is not sufficient for manual real-money use.",
        ),
        ReadinessGate(
            10,
            "signal_generation_engine",
            "Signal generation engine ready",
            "NOT_READY",
            True,
            "Signal/monitor code exists, but reliable approved-strategy signal generation is not validated.",
        ),
        ReadinessGate(
            11,
            "alert_delivery",
            "Telegram/WhatsApp/alert delivery ready",
            production_whatsapp,
            True,
            "Production alerts are intentionally blocked; research previews do not constitute tradeable delivery readiness.",
        ),
        ReadinessGate(
            12,
            "manual_risk_plan",
            "Manual risk plan ready",
            "NOT_READY",
            True,
            "No approved-strategy, signed-off small-size manual risk plan was found.",
        ),
        ReadinessGate(
            13,
            "final_safety_audit",
            "Final safety audit clean",
            "PASS_WITH_WARNINGS_ACCEPTED"
            if final_safety_verdict == "FINAL_SAFETY_PASS_WITH_WARNINGS"
            else ("PASS" if final_safety_verdict == "FINAL_SAFETY_PASS" else "NOT_READY"),
            final_safety_verdict not in {"FINAL_SAFETY_PASS", "FINAL_SAFETY_PASS_WITH_WARNINGS"},
            f"final_safety_verdict={final_safety_verdict}",
        ),
        ReadinessGate(
            14,
            "real_money_small_size_approval",
            "Real-money small-size manual approval",
            "false",
            True,
            "Real-money trading is 0% approved and cannot be granted automatically by this report.",
        ),
    ]

    warnings = [
        "Stage 0 readiness is infrastructure/data readiness only.",
        "The current strategy sample is too small for manual real-money approval.",
        "Recorder code needs the next short market-hours chunk validation before stability can be promoted.",
    ]
    if execution_allowed != "false":
        warnings.append("execution_allowed=false was not confirmed; safety review is required.")
    if production_whatsapp != "BLOCKED":
        warnings.append("Production alert blocking was not confirmed.")

    result = TradeableLaunch1ReadinessResult(
        timestamp=timestamp,
        decision=TRADEABLE_LAUNCH1_NOT_READY,
        decision_reason=(
            "Stage 0 infrastructure/data readiness is available, but no strategy has approval-grade "
            "backtesting, robustness, forward-validation, signal, alert, manual-risk, and explicit "
            "small-size real-money approval evidence."
        ),
        gates=gates,
        stage0_status=stage0_status,
        final_safety_verdict=final_safety_verdict,
        strategy_approval_status=strategy_status,
        forward_validation_status=f"{forward_decision} / forward_trades={forward_trades}",
        production_whatsapp_status=production_whatsapp,
        execution_allowed=execution_allowed,
        real_money_approval=False,
        warnings=warnings,
    )
    _write_report(base, result)
    _append_history(base, result)
    _print_summary(result)
    return result


def _write_report(base: Path, result: TradeableLaunch1ReadinessResult) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "TRADEABLE LAUNCH 1 READINESS REPORT",
        f"Generated: {result.timestamp.isoformat()}",
        "Scope: Manual real-market tradeability without algorithmic order execution",
        "",
        "OVERALL DECISION",
        f"decision: {result.decision}",
        f"reason: {result.decision_reason}",
        f"Stage 0 Infrastructure/Data Readiness: {result.stage0_status}",
        "Tradeable Launch 1: NOT_READY",
        "Real-money approval: false",
        "Real-money trading approved: 0%",
        "",
        "READINESS GATES",
    ]
    for gate in result.gates:
        lines.extend(
            [
                f"{gate.number}. {gate.label}",
                f"   key: {gate.key}",
                f"   status: {gate.status}",
                f"   blocking: {_bool_text(gate.blocking)}",
                f"   evidence: {gate.evidence}",
            ]
        )
    lines.extend(
        [
            "",
            "PROJECT ROADMAP",
            "Stage 0: Data + infrastructure readiness - READY",
            "Stage 1: Stable recorder and clean data archive - IN_PROGRESS",
            "Stage 2: Professional strategy inventory and audit - NOT_READY",
            "Stage 3: Professional backtesting and robustness testing - NOT_READY",
            "Stage 4: Forward validation and paper/manual signal tracking - RESEARCH_ONLY",
            "Stage 5: Signal generation and Telegram/WhatsApp research alerts - NOT_READY",
            "Stage 6: Small-size manual real-money approval - NOT_APPROVED",
            "Stage 7: Scaling only after stable live results - LOCKED",
            "",
            "CURRENT EVIDENCE LIMITS",
            f"Strategy approval status: {result.strategy_approval_status}",
            f"Forward validation: {result.forward_validation_status}",
            f"Final safety audit: {result.final_safety_verdict}",
            "A positive five-trade result is not sufficient evidence of a repeatable edge.",
            "No automatic or report-generated real-money approval is permitted.",
            "",
            "SAFETY STATUS",
            "No auto trading",
            "No broker orders",
            "No Kite place_order",
            f"execution_allowed={result.execution_allowed}",
            f"Production WhatsApp alerts: {result.production_whatsapp_status}",
            f"Strategy remains: {result.strategy_approval_status}",
            "Real-money trading: 0% approved",
            "PAPER / RESEARCH / MANUAL SIGNAL DEVELOPMENT ONLY",
            "",
            "WARNINGS",
            *[f"- {warning}" for warning in result.warnings],
            "",
            "NEXT PROFESSIONAL MILESTONE",
            "Validate the memory-safe recorder in a short market-hours chunk, archive clean data, then complete a signed-off strategy inventory before expanding backtests.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.report_path = path


def _append_history(base: Path, result: TradeableLaunch1ReadinessResult) -> None:
    path = base / HISTORY_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    gates = {gate.key: gate.status for gate in result.gates}
    row = {
        "timestamp": result.timestamp.isoformat(),
        "decision": result.decision,
        "stage0_status": result.stage0_status,
        "recorder_stability_status": gates["recorder_stability"],
        "strategy_inventory_status": gates["strategy_inventory"],
        "professional_backtesting_status": gates["professional_backtesting"],
        "cost_slippage_status": gates["cost_slippage_model"],
        "out_of_sample_status": gates["out_of_sample_walk_forward"],
        "robustness_status": gates["robustness_sensitivity"],
        "forward_validation_status": gates["forward_validation_sample"],
        "strategy_approval_status": gates["strategy_approval"],
        "signal_generation_status": gates["signal_generation_engine"],
        "alert_delivery_status": gates["alert_delivery"],
        "manual_risk_plan_status": gates["manual_risk_plan"],
        "final_safety_status": gates["final_safety_audit"],
        "real_money_approval": "false",
        "execution_allowed": result.execution_allowed,
        "production_whatsapp_status": result.production_whatsapp_status,
        "report_path": str(result.report_path or REPORT_PATH),
    }
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=HISTORY_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    result.history_path = path


def _print_summary(result: TradeableLaunch1ReadinessResult) -> None:
    print("TRADEABLE LAUNCH 1 READINESS REPORT")
    print(f"Decision: {result.decision}")
    print(f"Stage 0 Infrastructure/Data Readiness: {result.stage0_status}")
    for gate in result.gates:
        print(f"Gate {gate.number} - {gate.label}: {gate.status}")
    print(f"Final Safety: {result.final_safety_verdict}")
    print(f"Strategy: {result.strategy_approval_status}")
    print(f"Production WhatsApp: {result.production_whatsapp_status}")
    print(f"execution_allowed={result.execution_allowed}")
    print(f"Report: {result.report_path}")
    print(f"History: {result.history_path}")
    print("Real-money trading: 0% approved. No broker orders were placed.")


def _extract_value(text: str, prefix: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            return stripped.split(prefix, 1)[1].strip()
    return ""


def _extract_after_heading(text: str, heading: str) -> str:
    lines = text.splitlines()
    for index, line in enumerate(lines):
        if line.strip() == heading:
            for following in lines[index + 1 :]:
                value = following.strip()
                if value:
                    return value
    return ""


def _extract_metric_int(text: str, prefix: str, metric: str) -> int:
    line = next((line for line in text.splitlines() if line.strip().startswith(prefix)), "")
    match = re.search(rf"\b{re.escape(metric)}=(\d+)", line)
    return int(match.group(1)) if match else 0


def _first_non_empty(*values: str) -> str:
    for value in values:
        if str(value or "").strip():
            return str(value).strip()
    return ""


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""


def _bool_text(value: bool) -> str:
    return "true" if value else "false"


def build_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(
        description="Evaluate tradeable manual Launch 1 readiness from local research/safety evidence only."
    )


def main(argv: list[str] | None = None) -> int:
    build_parser().parse_args(argv)
    generate_tradeable_launch1_readiness_report()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
