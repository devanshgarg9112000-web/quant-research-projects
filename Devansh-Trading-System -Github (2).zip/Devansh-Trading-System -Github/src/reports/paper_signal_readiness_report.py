﻿from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from src.research.forward_validation import analyze_independent_evidence, load_ledger


REPORT_PATH = Path("reports") / "paper_signal_readiness" / "latest_paper_signal_readiness_report.txt"
SUPPORTED_FAMILY = "gold_vwap_rejection_reclaim_family"
CANONICAL_SETUP = "gold_vwap_rejection_short"
LOCK_VERSION = "GOLD_VWAP_RESEARCH_LOCK_V1"
PAPER_VERDICT = "PAPER_SIGNAL_OBSERVATION_READY_WITH_RESTRICTIONS"
MANUAL_PAPER_VERDICT = "LIMITED_RESEARCH_ONLY"
TRADEABLE_LAUNCH_VERDICT = "TRADEABLE_LAUNCH1_NOT_READY"
REAL_MONEY_VERDICT = "REAL_MONEY_NOT_ALLOWED"


@dataclass(frozen=True)
class PaperSignalReadinessResult:
    report_path: Path
    family: str
    paper_signal_readiness_verdict: str
    manual_paper_trading_readiness: str
    tradeable_launch_verdict: str
    real_money_approval_status: str
    current_forward_trades: int
    required_forward_trades: int
    forward_validation_independence_status: str
    final_safety_status: str
    execution_allowed: bool
    production_alerts_allowed: bool
    real_money_approval_allowed: bool
    broker_orders_enabled: bool


def generate_paper_signal_readiness_report(
    base_dir: Path | str = ".",
    *,
    family: str = SUPPORTED_FAMILY,
    now: datetime | None = None,
) -> PaperSignalReadinessResult:
    """Generate a local research-only readiness report for manual paper signal observation."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    evidence = _collect_evidence(base, family)
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(_format_report(timestamp, family, evidence) + "\n", encoding="utf-8")
    return PaperSignalReadinessResult(
        report_path=report_path,
        family=family,
        paper_signal_readiness_verdict=evidence["paper_signal_readiness_verdict"],
        manual_paper_trading_readiness=evidence["manual_paper_trading_readiness"],
        tradeable_launch_verdict=TRADEABLE_LAUNCH_VERDICT,
        real_money_approval_status=REAL_MONEY_VERDICT,
        current_forward_trades=int(evidence["current_forward_trades"]),
        required_forward_trades=int(evidence["required_forward_trades"]),
        forward_validation_independence_status=evidence["forward_validation_independence_status"],
        final_safety_status=evidence["final_safety_status"],
        execution_allowed=False,
        production_alerts_allowed=False,
        real_money_approval_allowed=False,
        broker_orders_enabled=False,
    )


def _collect_evidence(base: Path, family: str) -> dict[str, Any]:
    ledger_rows = load_ledger(base)
    independent = analyze_independent_evidence(base, ledger_rows)
    current_forward_trades = independent.completed_independent_post_lock_trades
    required_forward_trades = independent.required_forward_trades
    forward_status = "PASSED" if current_forward_trades >= required_forward_trades else "NOT_PASSED"
    final_safety_text = _read_text(base / "reports" / "final_safety" / "latest_final_safety_audit_report.txt")
    independence_text = _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_independence_report.txt")
    forward_summary_text = _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt")
    pipeline_text = _read_text(base / "reports" / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt")
    final_safety_status = _extract_final_safety_status(final_safety_text)
    completed_chain = _completed_signal_chain(base, ledger_rows, final_safety_text, pipeline_text, forward_summary_text)
    chain_working = all(completed_chain.values())
    paper_verdict = PAPER_VERDICT if chain_working else "PAPER_SIGNAL_OBSERVATION_NOT_READY"
    return {
        "family": family,
        "canonical_setup": CANONICAL_SETUP,
        "lock_version": _extract_lock_version(ledger_rows) or LOCK_VERSION,
        "paper_signal_readiness_verdict": paper_verdict,
        "manual_paper_trading_readiness": MANUAL_PAPER_VERDICT,
        "tradeable_launch_verdict": TRADEABLE_LAUNCH_VERDICT,
        "real_money_approval_status": REAL_MONEY_VERDICT,
        "current_forward_trades": current_forward_trades,
        "required_forward_trades": required_forward_trades,
        "forward_validation_independence_status": _extract_value(independence_text, "forward_validation_independence_status:") or forward_status,
        "final_safety_status": final_safety_status,
        "execution_allowed": False,
        "production_alerts_allowed": False,
        "real_money_approval_allowed": False,
        "broker_orders_enabled": False,
        "completed_signal_chain": completed_chain,
        "main_remaining_blocker": "forward validation independence sample size",
    }


def _completed_signal_chain(
    base: Path,
    ledger_rows: list[dict[str, Any]],
    final_safety_text: str,
    pipeline_text: str,
    forward_summary_text: str,
) -> dict[str, bool]:
    kite_ticks_exist = any((base / "data" / "kite_recorded" / "ticks").glob("*/*_ticks.csv"))
    features_exist = any((base / "data" / "kite_recorded" / "features").glob("*/*_orderflow_lite.csv"))
    post_lock_kite_rows = [
        row for row in ledger_rows
        if str(row.get("provider") or "").upper() == "KITE" and _is_true(row.get("post_lock"))
    ]
    resolved_kite_rows = [
        row for row in post_lock_kite_rows
        if str(row.get("result") or row.get("status") or "").upper() in {"WIN", "LOSS", "END_EXIT"}
    ]
    return {
        "Kite data recorded": kite_ticks_exist or "Recorder tick rows:" in pipeline_text,
        "features generated": features_exist or "Feature rows generated:" in pipeline_text,
        "VWAP bridge signal created": bool(post_lock_kite_rows),
        "KITE tick outcome resolver working": bool(resolved_kite_rows),
        "ledger updated": bool(resolved_kite_rows) or "Completed Independent Post-lock Trades:" in forward_summary_text,
    }


def _format_report(timestamp: datetime, family: str, evidence: dict[str, Any]) -> str:
    chain = evidence["completed_signal_chain"]
    lines = [
        "PAPER SIGNAL READINESS REPORT + MANUAL PAPER TRADING CHECKLIST",
        f"Generated At: {timestamp.isoformat()}",
        "Recommended Codex Level Used: Medium",
        "Mode: PAPER / RESEARCH / MANUAL OBSERVATION ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "Real Money Approval: false",
        "",
        "VERDICT",
        f"paper_signal_observation: {evidence['paper_signal_readiness_verdict']}",
        f"manual_paper_trading_readiness: {evidence['manual_paper_trading_readiness']}",
        f"tradeable_launch1: {evidence['tradeable_launch_verdict']}",
        f"real_money: {evidence['real_money_approval_status']}",
        "production_alerts: BLOCKED",
        "",
        "STRATEGY CONTEXT",
        f"strategy_family: {family}",
        f"strategy_setup: {evidence['canonical_setup']}",
        f"lock_version: {evidence['lock_version']}",
        "strategy_status: RESEARCH_ONLY",
        f"current_forward_trades: {evidence['current_forward_trades']}",
        f"required_forward_trades: {evidence['required_forward_trades']}",
        f"forward_validation_independence_status: {evidence['forward_validation_independence_status']}",
        f"final_safety_status: {evidence['final_safety_status']}",
        "execution_allowed: false",
        "production_alerts_allowed: false",
        "real_money_approval_allowed: false",
        "broker_orders_enabled: false",
        f"main_remaining_blocker: {evidence['main_remaining_blocker']}",
        "approval_progress: " + f"{evidence['current_forward_trades']}/{evidence['required_forward_trades']} does not pass approval",
        "",
        "COMPLETED SIGNAL CHAIN STATUS",
    ]
    lines.extend(f"- {name}: {'PASS' if status else 'NOT_CONFIRMED'}" for name, status in chain.items())
    lines.extend(
        [
            "",
            "WHAT IS ALLOWED",
            "- observe signals",
            "- manually record paper decisions",
            "- review signal after close",
            "- collect more post-lock evidence",
            "",
            "WHAT IS FORBIDDEN",
            "- real money",
            "- auto orders",
            "- broker orders",
            "- production WhatsApp alerts",
            "- averaging losers",
            "- changing parameters based on one trade",
            f"- treating {evidence['current_forward_trades']}/{evidence['required_forward_trades']} as approval",
            "",
            "REQUIRED DISPLAY FIELDS FOR A PAPER SIGNAL",
            "- symbol",
            "- strategy/setup",
            "- side",
            "- signal_time",
            "- entry",
            "- stop_loss",
            "- target",
            "- risk_per_unit",
            "- reward_per_unit",
            "- expected_R",
            "- signal_score",
            "- market_regime",
            "- lock_version",
            "- status RESEARCH_ONLY",
            "- execution_allowed=false",
            "",
            "MANUAL ACTION CHECKLIST",
            "- screenshot chart",
            "- note VWAP context",
            "- note support/resistance context",
            "- note market condition",
            "- mark paper entry only",
            "- never average",
            "- record whether stop/target/end-exit happened",
            "- review after outcome",
            "",
            "FINAL DECISION",
            f"{PAPER_VERDICT}",
            f"{TRADEABLE_LAUNCH_VERDICT}",
            f"{REAL_MONEY_VERDICT}",
            "",
            "SAFETY CONFIRMATION",
            "No live data used by this report.",
            "No broker orders.",
            "No production WhatsApp.",
            "No strategy approval was changed.",
            "execution_allowed=false.",
        ]
    )
    return "\n".join(lines)


def _extract_final_safety_status(text: str) -> str:
    for value in ("FINAL_SAFETY_BLOCKED", "FINAL_SAFETY_PASS_WITH_WARNINGS", "FINAL_SAFETY_PASS"):
        if value in text:
            return value
    return "NOT_AVAILABLE"


def _extract_lock_version(rows: list[dict[str, Any]]) -> str:
    for row in rows:
        if _is_true(row.get("post_lock")) and row.get("lock_version"):
            return str(row["lock_version"])
    return ""


def _extract_value(text: str, prefix: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            return stripped.split(prefix, 1)[1].strip()
    return ""


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""


def _is_true(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate paper signal readiness report without live data or broker orders.")
    parser.add_argument("--family", default=SUPPORTED_FAMILY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = generate_paper_signal_readiness_report(family=args.family)
    print("PAPER SIGNAL READINESS REPORT")
    print(f"Report path: {result.report_path}")
    print(f"paper_signal_observation: {result.paper_signal_readiness_verdict}")
    print(f"manual_paper_trading_readiness: {result.manual_paper_trading_readiness}")
    print(f"tradeable_launch1: {result.tradeable_launch_verdict}")
    print(f"real_money: {result.real_money_approval_status}")
    print(f"current_forward_trades: {result.current_forward_trades}")
    print(f"required_forward_trades: {result.required_forward_trades}")
    print(f"final_safety_status: {result.final_safety_status}")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
