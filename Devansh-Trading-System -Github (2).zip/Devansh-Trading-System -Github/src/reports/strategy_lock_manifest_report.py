﻿from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from src.research.forward_validation import analyze_independent_evidence, load_ledger


SUPPORTED_FAMILY = "gold_vwap_rejection_reclaim_family"
CANONICAL_SETUP = "gold_vwap_rejection_short"
REPORT_PATH = Path("reports") / "strategy_locks" / "latest_strategy_lock_manifest_report.txt"
DEFAULT_LOCK = {
    "lock_version": "GOLD_VWAP_RESEARCH_LOCK_V1",
    "lock_status": "LOCKED_FOR_FORWARD_RESEARCH",
    "family": SUPPORTED_FAMILY,
    "canonical_setup": CANONICAL_SETUP,
    "strategy_status": "RESEARCH_ONLY",
    "real_money_approved": "false",
    "production_alerts_allowed": "false",
    "execution_allowed": "false",
    "execution_model": "CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK",
    "approval_grade_backtest_ready": "false",
    "forward_validation_required": "true",
    "required_forward_trades": "30",
    "required_forward_sessions": "5",
}


@dataclass(frozen=True)
class StrategyLockManifestResult:
    report_path: Path
    family: str
    lock_version: str
    lock_status: str
    current_independent_forward_trades: int
    required_forward_trades: int
    real_money_approved: bool
    production_alerts_allowed: bool
    execution_allowed: bool


def generate_strategy_lock_manifest_report(
    base_dir: Path | str = ".",
    *,
    family: str = SUPPORTED_FAMILY,
    now: datetime | None = None,
) -> StrategyLockManifestResult:
    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    lock = _load_active_research_lock(base)
    evidence = analyze_independent_evidence(base, load_ledger(base))
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    text = _format_report(timestamp, family, lock, evidence)
    report_path.write_text(text + "\n", encoding="utf-8")
    return StrategyLockManifestResult(
        report_path=report_path,
        family=family,
        lock_version=lock["lock_version"],
        lock_status=lock["lock_status"],
        current_independent_forward_trades=evidence.completed_independent_post_lock_trades,
        required_forward_trades=int(lock.get("required_forward_trades") or evidence.required_forward_trades),
        real_money_approved=_is_true(lock.get("real_money_approved")),
        production_alerts_allowed=_is_true(lock.get("production_alerts_allowed")),
        execution_allowed=_is_true(lock.get("execution_allowed")),
    )


def _load_active_research_lock(base: Path) -> dict[str, str]:
    identity_text = _read_text(base / "config" / "strategy_identity.yaml")
    forward_text = _read_text(base / "config" / "forward_validation.yaml")
    lock = dict(DEFAULT_LOCK)
    lock.update(_extract_yaml_block(identity_text, "active_research_lock"))
    forward_lock_version = _extract_yaml_value(forward_text, "active_lock_version")
    forward_lock_timestamp = _extract_yaml_value(forward_text, "active_lock_timestamp")
    if forward_lock_version:
        lock["lock_version"] = forward_lock_version
    if forward_lock_timestamp and not lock.get("lock_timestamp"):
        lock["lock_timestamp"] = forward_lock_timestamp
    lock.setdefault("lock_timestamp", "UNKNOWN")
    return {key: str(value) for key, value in lock.items()}


def _format_report(timestamp: datetime, family: str, lock: dict[str, str], evidence: Any) -> str:
    future_post_lock = (
        lock.get("lock_status") == "LOCKED_FOR_FORWARD_RESEARCH"
        and lock.get("family") == family
        and lock.get("canonical_setup") == CANONICAL_SETUP
        and not _is_true(lock.get("real_money_approved"))
        and not _is_true(lock.get("production_alerts_allowed"))
        and not _is_true(lock.get("execution_allowed"))
    )
    lines = [
        "STRATEGY LOCK MANIFEST REPORT",
        f"Generated At: {timestamp.isoformat()}",
        "Recommended Codex Level Used: High",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Production WhatsApp Alerts: BLOCKED",
        "execution_allowed=false",
        "Real Money Approval: false",
        "",
        "EXECUTIVE DECISION",
        "This is NOT strategy approval.",
        "This is NOT real-money approval.",
        "This is NOT production alert approval.",
        "This only locks the current research definition for future paper/research forward validation.",
        "",
        "LOCK MANIFEST",
        f"lock_version: {lock.get('lock_version')}",
        f"lock_status: {lock.get('lock_status')}",
        f"lock_timestamp: {lock.get('lock_timestamp')}",
        f"family: {lock.get('family')}",
        f"canonical_setup: {lock.get('canonical_setup')}",
        f"strategy_status: {lock.get('strategy_status')}",
        f"execution_model: {lock.get('execution_model')}",
        f"real_money_approved: {str(_is_true(lock.get('real_money_approved'))).lower()}",
        f"production_alerts_allowed: {str(_is_true(lock.get('production_alerts_allowed'))).lower()}",
        f"execution_allowed=false" if not _is_true(lock.get("execution_allowed")) else "execution_allowed=true",
        f"approval_grade_backtest_ready: {str(_is_true(lock.get('approval_grade_backtest_ready'))).lower()}",
        f"forward_validation_required: {str(_is_true(lock.get('forward_validation_required'))).lower()}",
        f"required_forward_trades: {lock.get('required_forward_trades') or evidence.required_forward_trades}",
        f"required_forward_sessions: {lock.get('required_forward_sessions') or evidence.required_forward_sessions}",
        f"notes: {lock.get('notes', 'Research lock only.')}",
        "",
        "CURRENT FORWARD VALIDATION EVIDENCE",
        f"current_independent_forward_trades: {evidence.completed_independent_post_lock_trades}",
        f"current_distinct_forward_sessions: {evidence.distinct_post_lock_sessions}",
        f"legacy_pre_lock_rows: {evidence.legacy_pre_lock_rows}",
        "legacy_rows_counted_for_approval: 0",
        f"provider_breakdown: {evidence.provider_breakdown}",
        f"independent_provider_breakdown: {evidence.independent_provider_breakdown}",
        f"ineligible_reasons: {_format_reason_counts(evidence.ineligible_reasons)}",
        "",
        "POST-LOCK CLASSIFICATION RULE",
        f"future_rows_can_be_marked_post_lock_true_if_they_match_this_lock: {str(future_post_lock).lower()}",
        "Future rows still must satisfy provider, session_id, schema, execution_allowed=false, data_role=FORWARD_VALIDATION, and no-parameter-tuning rules before they count as independent evidence.",
        "",
        "SAFETY CONFIRMATION",
        "No live data used.",
        "No broker orders.",
        "No production WhatsApp.",
        "execution_allowed=false.",
        "Real-money trading remains 0% approved.",
        "Strategy approval unchanged: RESEARCH_ONLY.",
    ]
    return "\n".join(lines)


def _extract_yaml_block(text: str, block_name: str) -> dict[str, str]:
    values: dict[str, str] = {}
    in_block = False
    for raw in text.splitlines():
        if raw.strip() == f"{block_name}:":
            in_block = True
            continue
        if in_block and raw and not raw.startswith(" "):
            break
        if not in_block or ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        values[key.strip()] = value.strip().strip('"\'')
    return values


def _extract_yaml_value(text: str, key: str) -> str:
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped.startswith(f"{key}:"):
            return stripped.split(":", 1)[1].strip().strip('"\'')
    return ""


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _is_true(value: Any) -> bool:
    return value is True or str(value).strip().lower() == "true"


def _format_reason_counts(reasons: tuple[tuple[str, int], ...]) -> str:
    if not reasons:
        return "NONE"
    return ", ".join(f"{reason}={count}" for reason, count in reasons)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create a research-only strategy lock manifest report.")
    parser.add_argument("--family", default=SUPPORTED_FAMILY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = generate_strategy_lock_manifest_report(family=args.family)
    print("STRATEGY LOCK MANIFEST REPORT")
    print(f"Report path: {result.report_path}")
    print(f"family: {result.family}")
    print(f"lock_version: {result.lock_version}")
    print(f"lock_status: {result.lock_status}")
    print(f"current_independent_forward_trades: {result.current_independent_forward_trades}")
    print(f"required_forward_trades: {result.required_forward_trades}")
    print("real_money_approved: false")
    print("production_alerts_allowed: false")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
