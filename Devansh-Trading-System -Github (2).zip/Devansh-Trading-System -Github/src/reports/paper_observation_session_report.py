from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any

from src.research.forward_validation import analyze_independent_evidence, load_ledger


REPORT_PATH = Path("reports") / "paper_observation" / "latest_paper_observation_session_report.txt"
SUPPORTED_FAMILY = "gold_vwap_rejection_reclaim_family"
CANONICAL_SETUP = "gold_vwap_rejection_short"
LOCK_VERSION = "GOLD_VWAP_RESEARCH_LOCK_V1"
REAL_MONEY_STATUS = "REAL_MONEY_NOT_ALLOWED"


@dataclass(frozen=True)
class PaperObservationSessionResult:
    report_path: Path
    family: str
    paper_observation_status: str
    session_valid_for_research: bool
    current_forward_trades: int
    required_forward_trades: int
    remaining_forward_trades: int
    latest_post_lock_signal_status: str
    latest_post_lock_signal_result: str
    final_safety_verdict: str
    next_action: str
    execution_allowed: bool
    production_alerts_allowed: bool
    real_money_approval_allowed: bool
    broker_orders_enabled: bool


def generate_paper_observation_session_report(
    base_dir: Path | str = ".",
    *,
    family: str = SUPPORTED_FAMILY,
    now: datetime | None = None,
) -> PaperObservationSessionResult:
    """Create a local-file-only report for one read-only paper observation session."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    evidence = _collect_evidence(base, family, timestamp.date())
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(_format_report(timestamp, family, evidence) + "\n", encoding="utf-8")
    return PaperObservationSessionResult(
        report_path=report_path,
        family=family,
        paper_observation_status=evidence["paper_observation_status"],
        session_valid_for_research=bool(evidence["session_valid_for_research"]),
        current_forward_trades=int(evidence["current_forward_trades"]),
        required_forward_trades=int(evidence["required_forward_trades"]),
        remaining_forward_trades=int(evidence["remaining_forward_trades"]),
        latest_post_lock_signal_status=evidence["latest_post_lock_signal_status"],
        latest_post_lock_signal_result=evidence["latest_post_lock_signal_result"],
        final_safety_verdict=evidence["final_safety_verdict"],
        next_action=evidence["next_action"],
        execution_allowed=False,
        production_alerts_allowed=False,
        real_money_approval_allowed=False,
        broker_orders_enabled=False,
    )


def _collect_evidence(base: Path, family: str, session_date: date) -> dict[str, Any]:
    ledger_rows = load_ledger(base)
    independent = analyze_independent_evidence(base, ledger_rows)
    final_safety_text = _read_text(base / "reports" / "final_safety" / "latest_final_safety_audit_report.txt")
    independence_text = _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_independence_report.txt")
    readiness_text = _read_text(base / "reports" / "paper_signal_readiness" / "latest_paper_signal_readiness_report.txt")
    pipeline_text = _read_text(base / "reports" / "kite_daily_pipeline" / "latest_kite_daily_pipeline_report.txt")
    verifier_text = _read_text(base / "reports" / "kite_daily_pipeline" / "latest_post_recording_verifier_report.txt")
    combined_text = "\n".join([final_safety_text, independence_text, readiness_text, pipeline_text, verifier_text])

    post_lock_rows = [row for row in ledger_rows if _is_true(row.get("post_lock"))]
    today_post_lock_rows = [row for row in post_lock_rows if _row_date(row) == session_date.isoformat()]
    latest_post_lock = _latest_row(post_lock_rows)
    latest_today = _latest_row(today_post_lock_rows)
    latest_for_status = latest_today or latest_post_lock or {}

    current = independent.completed_independent_post_lock_trades
    required = independent.required_forward_trades
    remaining = max(0, required - current)
    final_safety_verdict = _extract_final_safety_verdict(final_safety_text)
    blockers = _extract_int(combined_text, "Blockers:")
    execution_allowed = _execution_allowed(combined_text)
    production_alerts_allowed = _production_alerts_allowed(combined_text)
    data_quality = _extract_data_quality(pipeline_text, verifier_text, final_safety_text)
    feature_mode = _extract_feature_mode(pipeline_text, verifier_text, final_safety_text)
    contract_consistency = _extract_contract_consistency(pipeline_text, verifier_text, final_safety_text)
    reconciliation = _extract_reconciliation(verifier_text, final_safety_text)

    status, session_valid = _decide_session_status(
        blockers=blockers,
        execution_allowed=execution_allowed,
        production_alerts_allowed=production_alerts_allowed,
        data_quality=data_quality,
        today_post_lock_rows=today_post_lock_rows,
    )
    next_action = _next_action(status, current, required)

    return {
        "strategy_family": family,
        "lock_version": _extract_lock_version(post_lock_rows) or LOCK_VERSION,
        "paper_observation_status": status,
        "session_valid_for_research": session_valid,
        "current_forward_trades": current,
        "required_forward_trades": required,
        "remaining_forward_trades": remaining,
        "completed_post_lock_trades": independent.completed_independent_post_lock_trades,
        "pending_post_lock_trades": independent.pending_post_lock_rows,
        "legacy_pre_lock_rows": independent.legacy_pre_lock_rows,
        "latest_post_lock_signal_id": str(latest_for_status.get("signal_id") or "NONE"),
        "latest_post_lock_signal_status": str(latest_for_status.get("status") or "NONE"),
        "latest_post_lock_signal_result": str(latest_for_status.get("result") or latest_for_status.get("status") or "NONE"),
        "latest_post_lock_signal_exit_time": str(latest_for_status.get("exit_time") or "N/A"),
        "latest_post_lock_signal_exit_price": str(latest_for_status.get("exit_price") or "N/A"),
        "forward_validation_independence_status": _extract_value(independence_text, "forward_validation_independence_status:") or ("PASSED" if current >= required else "NOT_PASSED"),
        "forward_validation_progress_status": "FORWARD_VALIDATION_COMPLETE" if current >= required else "FORWARD_VALIDATION_IN_PROGRESS",
        "data_quality": data_quality,
        "feature_mode": feature_mode,
        "contract_consistency": contract_consistency,
        "reconciliation": reconciliation,
        "final_safety_verdict": final_safety_verdict,
        "blockers": blockers,
        "execution_allowed": execution_allowed,
        "production_alerts_allowed": production_alerts_allowed,
        "real_money_approval_allowed": False,
        "broker_orders_enabled": False,
        "real_money_status": REAL_MONEY_STATUS,
        "next_action": next_action,
    }


def _decide_session_status(
    *,
    blockers: int,
    execution_allowed: bool,
    production_alerts_allowed: bool,
    data_quality: str,
    today_post_lock_rows: list[dict[str, Any]],
) -> tuple[str, bool]:
    if blockers > 0 or execution_allowed or production_alerts_allowed:
        return "SESSION_NOT_VALID_SAFETY_BLOCKER", False
    if not _data_quality_ready(data_quality):
        return "SESSION_LIMITED_DATA", True
    if not today_post_lock_rows:
        return "SESSION_VALID_NO_SIGNAL", True
    if any(str(row.get("result") or row.get("status") or "").upper() == "PENDING" for row in today_post_lock_rows):
        return "SESSION_VALID_PENDING_OUTCOME", True
    return "SESSION_VALID_SIGNAL_RESOLVED", True


def _format_report(timestamp: datetime, family: str, evidence: dict[str, Any]) -> str:
    lines = [
        "PAPER OBSERVATION SESSION REPORT",
        f"generated_at: {timestamp.isoformat()}",
        "Recommended Codex Level Used: Medium",
        "Mode: PAPER / RESEARCH / READ-ONLY OBSERVATION",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "",
        "SESSION DECISION",
        f"strategy_family: {family}",
        f"lock_version: {evidence['lock_version']}",
        f"paper_observation_status: {evidence['paper_observation_status']}",
        f"session_valid_for_research: {str(evidence['session_valid_for_research']).lower()}",
        f"next_action: {evidence['next_action']}",
        "",
        "FORWARD VALIDATION PROGRESS",
        f"current_forward_trades: {evidence['current_forward_trades']}",
        f"required_forward_trades: {evidence['required_forward_trades']}",
        f"remaining_forward_trades: {evidence['remaining_forward_trades']}",
        f"approval_progress: {evidence['current_forward_trades']}/{evidence['required_forward_trades']} does not pass approval",
        f"forward_validation_progress_status: {evidence['forward_validation_progress_status']}",
        f"completed_post_lock_trades: {evidence['completed_post_lock_trades']}",
        f"pending_post_lock_trades: {evidence['pending_post_lock_trades']}",
        f"legacy_pre_lock_rows: {evidence['legacy_pre_lock_rows']}",
        f"forward_validation_independence_status: {evidence['forward_validation_independence_status']}",
        "",
        "LATEST POST-LOCK SIGNAL",
        f"latest_post_lock_signal_id: {evidence['latest_post_lock_signal_id']}",
        f"latest_post_lock_signal_status: {evidence['latest_post_lock_signal_status']}",
        f"latest_post_lock_signal_result: {evidence['latest_post_lock_signal_result']}",
        f"latest_post_lock_signal_exit_time: {evidence['latest_post_lock_signal_exit_time']}",
        f"latest_post_lock_signal_exit_price: {evidence['latest_post_lock_signal_exit_price']}",
        "",
        "SESSION DATA AND SAFETY",
        f"data_quality: {evidence['data_quality']}",
        f"feature_mode: {evidence['feature_mode']}",
        f"contract_consistency: {evidence['contract_consistency']}",
        f"reconciliation: {evidence['reconciliation']}",
        f"final_safety_verdict: {evidence['final_safety_verdict']}",
        f"blockers: {evidence['blockers']}",
        f"execution_allowed: {str(evidence['execution_allowed']).lower()}",
        f"production_alerts_allowed: {str(evidence['production_alerts_allowed']).lower()}",
        f"production_whatsapp_status: BLOCKED",
        f"real_money_approval_allowed: {str(evidence['real_money_approval_allowed']).lower()}",
        f"real_money: {evidence['real_money_status']}",
        f"broker_orders_enabled: {str(evidence['broker_orders_enabled']).lower()}",
        "",
        "WHAT TO DO NEXT",
        "- If market is open: run next read-only observation session",
        "- If signal pending: wait for more data / rerun updater/report",
        "- If no signal: keep collecting",
        "- If safety blocker: stop and fix",
        "- If current_forward_trades < 30: continue research",
        "",
        "WHAT IS FORBIDDEN",
        "- real money",
        "- broker orders",
        "- auto orders",
        "- production WhatsApp alerts",
        "- averaging losers",
        "- changing parameters from small sample",
        "- treating less than 30 trades as approval",
        "",
        "FINAL DECISION",
        f"{evidence['paper_observation_status']}",
        f"{evidence['forward_validation_progress_status']}",
        REAL_MONEY_STATUS,
        "",
        "SAFETY CONFIRMATION",
        "No live data used by this report.",
        "No broker orders.",
        "No production WhatsApp.",
        "No strategy logic changed.",
        "No signal-generation rules changed.",
        "execution_allowed=false.",
    ]
    return "\n".join(lines)


def _latest_row(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {}
    return max(rows, key=lambda row: str(row.get("entry_time") or row.get("signal_time") or row.get("date") or ""))


def _row_date(row: dict[str, Any]) -> str:
    value = str(row.get("date") or "")
    if value:
        return value[:10]
    for key in ("entry_time", "signal_time"):
        timestamp = str(row.get(key) or "")
        if len(timestamp) >= 10:
            return timestamp[:10]
    return ""


def _extract_final_safety_verdict(text: str) -> str:
    for value in ("FINAL_SAFETY_BLOCKED", "FINAL_SAFETY_PASS_WITH_WARNINGS", "FINAL_SAFETY_PASS"):
        if value in text:
            return value
    return "NOT_AVAILABLE"


def _extract_lock_version(rows: list[dict[str, Any]]) -> str:
    for row in reversed(rows):
        value = str(row.get("lock_version") or "")
        if value:
            return value
    return ""


def _extract_data_quality(pipeline_text: str, verifier_text: str, final_safety_text: str) -> str:
    return (
        _extract_value(verifier_text, "Data Quality Gate status:")
        or _extract_value(pipeline_text, "- data_quality_gate:")
        or _extract_value(pipeline_text, "Feature market data status:")
        or _extract_value(final_safety_text, "data_quality_status:")
        or "MISSING"
    )


def _extract_feature_mode(pipeline_text: str, verifier_text: str, final_safety_text: str) -> str:
    return (
        _extract_value(verifier_text, "Feature modes:")
        or _extract_value(pipeline_text, "Feature mode:")
        or _extract_value(final_safety_text, "feature_mode:")
        or "MISSING"
    )


def _extract_contract_consistency(pipeline_text: str, verifier_text: str, final_safety_text: str) -> str:
    return (
        _extract_value(verifier_text, "Pipeline contract status:")
        or _extract_value(pipeline_text, "status:")
        or _extract_value(final_safety_text, "contract_consistency_status:")
        or "MISSING"
    )


def _extract_reconciliation(verifier_text: str, final_safety_text: str) -> str:
    return (
        _extract_value(verifier_text, "Feature rebuild reconciliation status:")
        or _extract_value(final_safety_text, "reconciliation_status:")
        or "MISSING"
    )


def _data_quality_ready(value: str) -> bool:
    normalized = value.strip().upper()
    return normalized in {"FULL_DEPTH", "READY", "READY_FOR_FORWARD_VALIDATION", "DAY_ACCEPTED_FOR_RESEARCH"}


def _execution_allowed(text: str) -> bool:
    lowered = text.lower()
    if "execution_allowed=true" in lowered or "execution_allowed: true" in lowered:
        return True
    return False


def _production_alerts_allowed(text: str) -> bool:
    lowered = text.lower()
    if "production_alerts_allowed: true" in lowered:
        return True
    if "production whatsapp alerts: allowed" in lowered:
        return True
    return False


def _next_action(status: str, current: int, required: int) -> str:
    if status == "SESSION_NOT_VALID_SAFETY_BLOCKER":
        return "stop and fix safety blocker"
    if status == "SESSION_VALID_PENDING_OUTCOME":
        return "wait for more data / rerun updater/report"
    if status == "SESSION_VALID_NO_SIGNAL":
        return "keep collecting read-only sessions"
    if current < required:
        return "continue research until 30 independent post-lock trades"
    return "review forward validation evidence manually; real money remains blocked"


def _extract_int(text: str, prefix: str) -> int:
    value = _extract_value(text, prefix)
    try:
        return int(float(value))
    except ValueError:
        return 0


def _extract_value(text: str, prefix: str) -> str:
    prefix_lower = prefix.lower()
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith(prefix_lower):
            return stripped.split(":", 1)[1].strip() if ":" in stripped else ""
    return ""


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""


def _is_true(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate a read-only paper observation session report.")
    parser.add_argument("--family", default=SUPPORTED_FAMILY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = generate_paper_observation_session_report(family=args.family)
    print("PAPER OBSERVATION SESSION REPORT")
    print(f"Report path: {result.report_path}")
    print(f"paper_observation_status: {result.paper_observation_status}")
    print(f"session_valid_for_research: {str(result.session_valid_for_research).lower()}")
    print(f"current_forward_trades: {result.current_forward_trades}")
    print(f"required_forward_trades: {result.required_forward_trades}")
    print(f"remaining_forward_trades: {result.remaining_forward_trades}")
    print(f"latest_post_lock_signal_status: {result.latest_post_lock_signal_status}")
    print(f"latest_post_lock_signal_result: {result.latest_post_lock_signal_result}")
    print(f"final_safety_verdict: {result.final_safety_verdict}")
    print(f"next_action: {result.next_action}")
    print("real_money: REAL_MONEY_NOT_ALLOWED")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
