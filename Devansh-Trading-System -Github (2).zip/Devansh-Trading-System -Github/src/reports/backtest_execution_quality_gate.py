from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


REPORT_PATH = Path("reports") / "strategy_audits" / "latest_backtest_execution_quality_gate.txt"
SUPPORTED_FAMILY = "gold_vwap_rejection_reclaim_family"
RECOMMENDED_NEXT_ENGINEERING_TASK = (
    "Implement conservative execution model for VWAP family backtests: next-bar entry, "
    "cost/slippage config, same-bar stop-first rule."
)


@dataclass(frozen=True)
class BacktestExecutionQualityGateResult:
    report_path: Path
    family: str
    overall_gate: str
    approval_grade_backtest_ready: bool
    real_money_approval_allowed: bool
    failed_gates_count: int
    unknown_gates_count: int
    top_blockers: tuple[str, ...]


def generate_backtest_execution_quality_gate(
    base_dir: Path | str = ".",
    *,
    family: str = SUPPORTED_FAMILY,
    now: datetime | None = None,
) -> BacktestExecutionQualityGateResult:
    """Create a local-file-only approval-grade backtest/execution quality gate report."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    evidence = _collect_evidence(base)
    gates = _evaluate_gates(evidence, family)
    failed = [gate for gate in gates if gate["status"] == "FAIL"]
    unknown = [gate for gate in gates if gate["status"] == "UNKNOWN"]
    overall_gate = "PASS" if not failed and not unknown else "FAIL"
    top_blockers = tuple(gate["gate_name"] for gate in failed[:5])
    report_path = base / REPORT_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        _format_report(timestamp, family, evidence, gates, overall_gate, top_blockers) + "\n",
        encoding="utf-8",
    )
    return BacktestExecutionQualityGateResult(
        report_path=report_path,
        family=family,
        overall_gate=overall_gate,
        approval_grade_backtest_ready=False,
        real_money_approval_allowed=False,
        failed_gates_count=len(failed),
        unknown_gates_count=len(unknown),
        top_blockers=top_blockers,
    )


def _collect_evidence(base: Path) -> dict[str, Any]:
    bias_audit = _read_text(base / "reports" / "strategy_audits" / "latest_vwap_family_backtest_bias_audit.txt")
    spec_report = _read_text(base / "reports" / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt")
    identity_report = _read_text(base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt")
    approved_config = _read_text(base / "config" / "approved_strategies.yaml")
    strategies_config = _read_text(base / "config" / "strategies.yaml")
    backtest_code = _read_text(base / "src" / "backtesting" / "strategy_backtest_runner.py")
    deep_dive_code = _read_text(base / "src" / "research" / "vwap_rejection_deep_dive.py")
    identity_config = _load_strategy_identity_config(base / "config" / "strategy_identity.yaml")
    return {
        "bias_audit": bias_audit,
        "spec_report": spec_report,
        "identity_report": identity_report,
        "approved_config": approved_config,
        "strategies_config": strategies_config,
        "backtest_code": backtest_code,
        "deep_dive_code": deep_dive_code,
        "bias_risk": _extract_prefixed_value(bias_audit, "Bias risk:") or "UNKNOWN",
        "fill_realism_risk": _extract_prefixed_value(bias_audit, "Fill realism risk:") or "UNKNOWN",
        "cost_slippage_completeness": _extract_prefixed_value(bias_audit, "Cost/slippage completeness:") or "UNKNOWN",
        "evidence_trust_level": _extract_prefixed_value(bias_audit, "Evidence trust level:") or "UNKNOWN",
        "forward_trades": _extract_prefixed_value(spec_report, "Forward trades count:") or "0",
        "forward_approval_decision": _extract_prefixed_value(spec_report, "Forward approval decision:") or "RESEARCH_ONLY",
        "family_approval_status": _extract_prefixed_value(spec_report, "Current family approval status:") or "RESEARCH_ONLY",
        "approved_strategy_count": _extract_prefixed_value(spec_report, "Approved strategy count:") or "0",
        "production_alerts_blocked": "Production WhatsApp Alerts: BLOCKED" in spec_report
        or "Production WhatsApp Alerts: BLOCKED" in bias_audit,
        "execution_allowed_false": "execution_allowed=false" in spec_report
        and "execution_allowed=false" in bias_audit,
        "has_conservative_execution_model": "CONSERVATIVE_NEXT_BAR_OR_NEXT_TICK" in backtest_code,
        "has_approval_grade_ready_flag": "approval_grade_execution_ready" in backtest_code,
        "has_spread_points": "spread_points" in backtest_code,
        "has_tick_size": "tick_size" in backtest_code,
        "has_same_bar_stop_first_helper": "_approval_grade_same_bar_exit" in backtest_code and "STOP_FIRST" in backtest_code,
        "has_entry_delay_enforcement": "entry_delay_ticks=max(1" in backtest_code or "entry_delay_ticks=max(1," in backtest_code,
        "has_cost_requirement": "cost_per_trade) > 0.0" in backtest_code,
        "has_slippage_requirement": "slippage_points) > 0.0" in backtest_code,
        "identity_config": identity_config,
        "identity_consistency_configured": identity_config.get("gold_vwap_family_configured", False),
        "identity_config_status": identity_config.get("status", "UNKNOWN"),
        "identity_config_real_money_approved": identity_config.get("real_money_approved", True),
        "identity_config_production_alerts_allowed": identity_config.get("production_alerts_allowed", True),
        "sample_size_threshold_defined": identity_config.get("sample_size_threshold_defined", False),
        "required_forward_trades": identity_config.get("minimum_forward_trades", 0),
        "required_backtest_trades": identity_config.get("minimum_backtest_trades", 0),
        "current_forward_trades": _to_int(_extract_prefixed_value(spec_report, "Forward trades count:") or "0"),
        "current_backtest_trades": _extract_current_backtest_trades(spec_report, identity_report),
        "approval_review_requirements_source": "config/strategy_identity.yaml" if identity_config.get("sample_size_threshold_defined", False) else "NOT_CONFIGURED",
    }


def _evaluate_gates(evidence: dict[str, Any], family: str) -> list[dict[str, str]]:
    return [
        _gate(
            "GATE-01",
            "Signal timing defined",
            "PASS" if "signal candle close" in evidence["bias_audit"] else "UNKNOWN",
            "Bias audit says signal candle close is decision time.",
            "Define exact signal-time cutoff for every setup.",
        ),
        _gate(
            "GATE-02",
            "No future data before signal",
            "UNKNOWN" if evidence["bias_risk"] in {"MEDIUM", "HIGH", "UNKNOWN"} else "PASS",
            f"Bias risk: {evidence['bias_risk']}.",
            "Add tests proving entry conditions use only data available before/at signal time.",
        ),
        _gate(
            "GATE-03",
            "Entry fill model defined",
            "PASS" if evidence["has_conservative_execution_model"] and evidence["has_entry_delay_enforcement"] else "FAIL",
            f"Conservative model present: {evidence['has_conservative_execution_model']}; entry delay enforced: {evidence['has_entry_delay_enforcement']}; old fill realism risk: {evidence['fill_realism_risk']}.",
            "Use next candle open or next available quote/tick entry for approval-grade backtests.",
        ),
        _gate(
            "GATE-04",
            "Stop-loss model defined",
            "PASS" if "Stop-loss/invalidation availability: available" in evidence["spec_report"] else "UNKNOWN",
            "Spec report says stop-loss/invalidation is available.",
            "Formalize stop placement and invalidation per setup.",
        ),
        _gate(
            "GATE-05",
            "Target model defined",
            "PASS" if "Target/risk-reward availability: available" in evidence["spec_report"] else "UNKNOWN",
            "Spec report says 2R target/risk-reward is available.",
            "Formalize target logic per setup.",
        ),
        _gate(
            "GATE-06",
            "Same-bar stop-first ambiguity rule defined",
            "PASS" if evidence["has_same_bar_stop_first_helper"] else "UNKNOWN",
            f"Same-bar stop-first helper present: {evidence['has_same_bar_stop_first_helper']}.",
            "Define and enforce same-bar stop-first rule for OHLC backtests.",
        ),
        _gate(
            "GATE-07",
            "Cost model defined",
            "PASS" if evidence["has_cost_requirement"] else "FAIL",
            f"Cost requirement present: {evidence['has_cost_requirement']}; old cost/slippage completeness: {evidence['cost_slippage_completeness']}.",
            "Require non-zero cost model for all approval-grade strategy runs.",
        ),
        _gate(
            "GATE-08",
            "Slippage/spread model defined",
            "PASS" if evidence["has_slippage_requirement"] and evidence["has_spread_points"] else "FAIL",
            f"Slippage requirement present: {evidence['has_slippage_requirement']}; spread points present: {evidence['has_spread_points']}.",
            "Require slippage plus spread assumptions in config/report for this family.",
        ),
        _gate(
            "GATE-09",
            "Instrument/tick-size/liquidity model defined",
            "PASS" if evidence["has_tick_size"] else "UNKNOWN",
            f"Tick-size field present: {evidence['has_tick_size']}; liquidity assumptions still require live research evidence.",
            "Add instrument tick-size, lot, spread, and liquidity assumptions to approval reports.",
        ),
        _gate(
            "GATE-10",
            "Sample-size threshold defined",
            "PASS" if evidence["sample_size_threshold_defined"] else "FAIL",
            f"Sample thresholds defined: {evidence['sample_size_threshold_defined']}; current_forward_trades: {evidence['current_forward_trades']}; required_forward_trades: {evidence['required_forward_trades']}; forward_sample_sufficient: {evidence['current_forward_trades'] >= evidence['required_forward_trades'] if evidence['required_forward_trades'] else False}.",
            "Keep thresholds defined in config/strategy_identity.yaml and collect enough independent trades before approval review.",
        ),
        _gate(
            "GATE-11",
            "Forward validation independence",
            "FAIL",
            "Bias audit says forward validation independence is PARTIAL/LOW confidence because sample is small and related to replay/research evidence.",
            "Use clean provider-tagged real-market forward signals independent of optimization data.",
        ),
        _gate(
            "GATE-12",
            "Approval identity consistency",
            "PASS" if _identity_consistency_passes(evidence, family) else "FAIL",
            f"Family requested: {family}; identity config present: {evidence['identity_consistency_configured']}; status: {evidence['identity_config_status']}; real_money_approved: {evidence['identity_config_real_money_approved']}; production_alerts_allowed: {evidence['identity_config_production_alerts_allowed']}.",
            "Maintain config/strategy_identity.yaml with conservative canonical aliases and approval IDs.",
        ),
    ]


def _gate(gate_id: str, gate_name: str, status: str, evidence: str, required_fix: str) -> dict[str, str]:
    return {
        "gate_id": gate_id,
        "gate_name": gate_name,
        "status": status,
        "evidence": evidence,
        "required_fix": required_fix,
    }


def _format_report(
    timestamp: datetime,
    family: str,
    evidence: dict[str, Any],
    gates: list[dict[str, str]],
    overall_gate: str,
    top_blockers: tuple[str, ...],
) -> str:
    failed_count = sum(1 for gate in gates if gate["status"] == "FAIL")
    unknown_count = sum(1 for gate in gates if gate["status"] == "UNKNOWN")
    lines = [
        "BACKTEST / EXECUTION QUALITY GATE REPORT",
        f"Generated At: {timestamp.isoformat()}",
        "Recommended Codex Level Used: High",
        f"Strategy Family: {family}",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Production WhatsApp Alerts: BLOCKED",
        "Real Money Approval: false",
        "",
        "EXECUTIVE DECISION",
        f"Overall gate: {overall_gate}",
        "Approval-grade backtest ready: false",
        "Real-money approval allowed: false",
        f"Failed gates count: {failed_count}",
        f"Unknown gates count: {unknown_count}",
        f"Bias risk: {evidence['bias_risk']}",
        f"Fill realism risk: {evidence['fill_realism_risk']}",
        f"Cost/slippage completeness: {evidence['cost_slippage_completeness']}",
        f"Evidence trust level: {evidence['evidence_trust_level']}",
        f"Approval identity consistency configured: {str(evidence['identity_consistency_configured']).lower()}",
        f"Identity config status: {evidence['identity_config_status']}",
        f"Identity config real-money approved: {str(bool(evidence['identity_config_real_money_approved'])).lower()}",
        f"Identity config production alerts allowed: {str(bool(evidence['identity_config_production_alerts_allowed'])).lower()}",
        f"sample_size_threshold_defined: {str(bool(evidence['sample_size_threshold_defined'])).lower()}",
        f"approval_review_requirements_source: {evidence['approval_review_requirements_source']}",
        f"current_forward_trades: {evidence['current_forward_trades']}",
        f"required_forward_trades: {evidence['required_forward_trades']}",
        f"forward_sample_sufficient: {str(bool(evidence['current_forward_trades'] >= evidence['required_forward_trades'] if evidence['required_forward_trades'] else False)).lower()}",
        f"current_backtest_trades: {evidence['current_backtest_trades']}",
        f"required_backtest_trades: {evidence['required_backtest_trades']}",
        f"backtest_sample_sufficient: {str(bool(evidence['current_backtest_trades'] >= evidence['required_backtest_trades'] if evidence['required_backtest_trades'] else False)).lower()}",
        f"Conservative execution model available: {str(evidence['has_conservative_execution_model']).lower()}",
        f"Spread points supported: {str(evidence['has_spread_points']).lower()}",
        f"Tick size supported: {str(evidence['has_tick_size']).lower()}",
        f"Same-bar STOP_FIRST helper available: {str(evidence['has_same_bar_stop_first_helper']).lower()}",
        "",
        "GATE TABLE",
        "gate_id | gate_name | status | evidence | required_fix",
    ]
    for gate in gates:
        lines.append(
            " | ".join(
                [
                    gate["gate_id"],
                    gate["gate_name"],
                    gate["status"],
                    gate["evidence"],
                    gate["required_fix"],
                ]
            )
        )
    lines.extend(
        [
            "",
            "APPROVAL BLOCKER SUMMARY",
            f"Top blockers: {', '.join(top_blockers) if top_blockers else 'NONE'}",
            "Likely blockers: Current forward/backtest samples remain below configured conservative review thresholds; Forward validation independence unresolved; Approval status RESEARCH_ONLY; Production alerts blocked.",
            "",
            "MINIMUM STANDARD REQUIRED BEFORE NEXT APPROVAL REVIEW",
            "1. One canonical strategy family and setup ID must be locked.",
            "2. Signal-time cutoff must be test-proven with no future data before signal.",
            "3. Entry must use next-bar/next-quote conservative fill assumptions.",
            "4. Same-bar stop-first ambiguity rule must be defined and enforced.",
            "5. Cost, slippage, spread, tick-size, and liquidity assumptions must be non-zero/explicit.",
            "6. Forward validation must reach the configured independent sample threshold.",
            "7. Production alerts must remain blocked until manual approval is granted.",
            "",
            "RECOMMENDED NEXT ENGINEERING TASK",
            RECOMMENDED_NEXT_ENGINEERING_TASK,
            "",
            "SAFETY CONFIRMATION",
            "No live data used.",
            "No broker orders.",
            "No production WhatsApp.",
            "execution_allowed=false.",
            "Real-money trading remains 0% approved.",
            "No strategy, backtest, forward-validation, approval, alert, or order behavior was changed.",
        ]
    )
    return "\n".join(lines)


def _load_strategy_identity_config(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    family = "gold_vwap_rejection_reclaim_family"
    required_tokens = [
        family,
        "gold_vwap_rejection_short",
        "vwap_rejection",
        "vwap_rejection_short",
        "gold_vwap_rejection_short",
        "forward_validation_id: gold_vwap_rejection_short",
        "approval_id: gold_vwap_rejection_short",
        "gold_vwap_reclaim_long",
        "vwap_reclaim",
        "vwap_reclaim_long",
        "trend_day_vwap_pullback",
        "status: RESEARCH_ONLY",
        "real_money_approved: false",
        "production_alerts_allowed: false",
    ]
    configured = bool(text) and all(token in text for token in required_tokens)
    minimum_forward_trades = _extract_yaml_int(text, "minimum_forward_trades")
    minimum_backtest_trades = _extract_yaml_int(text, "minimum_backtest_trades")
    threshold_tokens = [
        "approval_review_requirements:",
        "minimum_backtest_trades:",
        "minimum_backtest_days:",
        "minimum_forward_trades:",
        "minimum_forward_days:",
        "minimum_distinct_sessions:",
        "minimum_profit_factor:",
        "requires_cost_slippage_spread: true",
        "requires_oos_or_walk_forward: true",
        "requires_forward_independence: true",
        "requires_manual_risk_plan: true",
    ]
    thresholds_defined = bool(text) and all(token in text for token in threshold_tokens)
    return {
        "gold_vwap_family_configured": configured,
        "status": "RESEARCH_ONLY" if "status: RESEARCH_ONLY" in text else "UNKNOWN",
        "real_money_approved": "real_money_approved: true" in text,
        "production_alerts_allowed": "production_alerts_allowed: true" in text,
        "sample_size_threshold_defined": thresholds_defined,
        "minimum_forward_trades": minimum_forward_trades,
        "minimum_backtest_trades": minimum_backtest_trades,
    }


def _identity_consistency_passes(evidence: dict[str, Any], family: str) -> bool:
    return (
        family == SUPPORTED_FAMILY
        and bool(evidence.get("identity_consistency_configured"))
        and evidence.get("identity_config_status") == "RESEARCH_ONLY"
        and not bool(evidence.get("identity_config_real_money_approved"))
        and not bool(evidence.get("identity_config_production_alerts_allowed"))
    )

def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _extract_prefixed_value(text: str, prefix: str) -> str:
    for line in text.splitlines():
        if line.lower().startswith(prefix.lower()):
            return line.split(":", 1)[1].strip()
    return ""


def _to_int(value: Any) -> int:
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return 0


def _extract_yaml_int(text: str, key: str) -> int:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{key}:"):
            return _to_int(stripped.split(":", 1)[1].strip())
    return 0


def _extract_current_backtest_trades(spec_report: str, identity_report: str) -> int:
    for prefix in (
        "Backtest trades count:",
        "Combined backtest trades:",
        "Current backtest trades:",
        "Total backtest trades:",
    ):
        value = _extract_prefixed_value(spec_report, prefix) or _extract_prefixed_value(identity_report, prefix)
        if value:
            return _to_int(value)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create a local-file-only approval-grade backtest/execution quality gate report."
    )
    parser.add_argument("--family", default=SUPPORTED_FAMILY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = generate_backtest_execution_quality_gate(family=args.family)
    print("BACKTEST / EXECUTION QUALITY GATE REPORT")
    print(f"Report path: {result.report_path}")
    print(f"Strategy Family: {result.family}")
    print(f"Overall gate: {result.overall_gate}")
    print(f"Approval-grade backtest ready: {str(result.approval_grade_backtest_ready).lower()}")
    print(f"Real-money approval allowed: {str(result.real_money_approval_allowed).lower()}")
    print(f"Failed gates count: {result.failed_gates_count}")
    print(f"Top blockers: {', '.join(result.top_blockers) if result.top_blockers else 'NONE'}")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    print("Production WhatsApp Alerts: BLOCKED | Real-money trading approval: false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
