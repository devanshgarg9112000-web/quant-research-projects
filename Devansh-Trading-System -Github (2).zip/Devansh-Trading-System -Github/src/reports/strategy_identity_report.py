from __future__ import annotations

import argparse
import ast
import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


REPORT_PATH = Path("reports") / "strategy_identity" / "latest_strategy_identity_report.txt"
CSV_PATH = Path("reports") / "strategy_identity" / "strategy_identity_map.csv"

REPORT_COLUMNS = [
    "canonical_strategy_id",
    "strategy_family",
    "module_name",
    "config_key",
    "backtest_key",
    "research_id_or_aliases",
    "forward_validation_id",
    "approval_id",
    "enabled_in_config",
    "registered_in_engine",
    "included_in_backtest",
    "included_in_forward_validation",
    "has_direct_signal_generator",
    "role",
    "current_status",
    "anti_retail_relevance",
    "uses_vwap",
    "uses_order_flow",
    "uses_imbalance",
    "uses_volume_profile",
    "uses_support_resistance",
    "uses_opening_range",
    "uses_mcx_metals",
    "known_gaps",
    "recommended_action",
]


@dataclass(frozen=True)
class StrategyIdentity:
    canonical_strategy_id: str
    strategy_family: str
    module_name: str
    config_key: str
    backtest_key: str
    research_aliases: tuple[str, ...]
    forward_validation_id: str
    approval_id: str
    role: str
    anti_retail_relevance: str
    uses_vwap: bool = False
    uses_order_flow: bool = False
    uses_imbalance: bool = False
    uses_volume_profile: bool = False
    uses_support_resistance: bool = False
    uses_opening_range: bool = False
    uses_mcx_metals: bool = False
    known_gaps: str = ""
    recommended_action: str = "KEEP_RESEARCH"


@dataclass(frozen=True)
class StrategyIdentityReportResult:
    report_path: Path
    csv_path: Path
    total_strategy_modules: int
    total_config_keys: int
    total_canonical_families: int
    approved_strategy_count: int
    rows: list[dict[str, Any]]


CANONICAL_STRATEGIES = [
    StrategyIdentity(
        canonical_strategy_id="trend_following",
        strategy_family="trend_following",
        module_name="trend_following",
        config_key="trend_following",
        backtest_key="trend_following",
        research_aliases=("trend_following", "trend_pullback"),
        forward_validation_id="",
        approval_id="trend_following",
        role="missing_module",
        anti_retail_relevance="LOW",
        known_gaps="Enabled/backtested but no registered strategy module or direct signal generator was found.",
        recommended_action="IMPLEMENT_MISSING",
    ),
    StrategyIdentity(
        canonical_strategy_id="breakout_acceptance",
        strategy_family="opening_range_acceptance",
        module_name="breakout_acceptance",
        config_key="breakout_acceptance",
        backtest_key="breakout_acceptance",
        research_aliases=("opening_range_breakout",),
        forward_validation_id="",
        approval_id="breakout_acceptance",
        role="standalone_strategy",
        anti_retail_relevance="MEDIUM",
        uses_opening_range=True,
        known_gaps="Needs stronger out-of-sample evidence before approval.",
        recommended_action="KEEP_RESEARCH",
    ),
    StrategyIdentity(
        canonical_strategy_id="breakdown_acceptance",
        strategy_family="opening_range_acceptance",
        module_name="breakdown_acceptance",
        config_key="breakdown_acceptance",
        backtest_key="breakdown_acceptance",
        research_aliases=("opening_range_breakdown",),
        forward_validation_id="",
        approval_id="breakdown_acceptance",
        role="standalone_strategy",
        anti_retail_relevance="MEDIUM",
        uses_opening_range=True,
        known_gaps="Needs stronger out-of-sample evidence before approval.",
        recommended_action="KEEP_RESEARCH",
    ),
    StrategyIdentity(
        canonical_strategy_id="failed_breakout_trap",
        strategy_family="opening_range_failure_trap",
        module_name="failed_breakout",
        config_key="failed_breakout",
        backtest_key="failed_breakout",
        research_aliases=("failed_breakout", "failed_breakout_trap"),
        forward_validation_id="",
        approval_id="failed_breakout",
        role="standalone_strategy",
        anti_retail_relevance="HIGH",
        uses_imbalance=True,
        uses_opening_range=True,
        known_gaps="Overlaps with opening-range and trap logic; should be consolidated into one family.",
        recommended_action="CONSOLIDATE",
    ),
    StrategyIdentity(
        canonical_strategy_id="failed_breakdown_trap",
        strategy_family="opening_range_failure_trap",
        module_name="failed_breakdown",
        config_key="failed_breakdown",
        backtest_key="failed_breakdown",
        research_aliases=("failed_breakdown", "failed_breakdown_trap"),
        forward_validation_id="",
        approval_id="failed_breakdown",
        role="standalone_strategy",
        anti_retail_relevance="HIGH",
        uses_imbalance=True,
        uses_opening_range=True,
        known_gaps="Overlaps with opening-range and trap logic; should be consolidated into one family.",
        recommended_action="CONSOLIDATE",
    ),
    StrategyIdentity(
        canonical_strategy_id="vwap_reclaim_family",
        strategy_family="vwap_reclaim",
        module_name="vwap_reclaim",
        config_key="vwap_reclaim",
        backtest_key="vwap_reclaim",
        research_aliases=("vwap_reclaim", "vwap_reclaim_long", "research_lab__gold_i__vrl"),
        forward_validation_id="",
        approval_id="vwap_reclaim",
        role="standalone_strategy",
        anti_retail_relevance="MEDIUM",
        uses_vwap=True,
        known_gaps="Research alias and production module need one canonical identity and more forward data.",
        recommended_action="CONSOLIDATE",
    ),
    StrategyIdentity(
        canonical_strategy_id="gold_vwap_rejection_short",
        strategy_family="vwap_rejection",
        module_name="vwap_rejection",
        config_key="vwap_rejection",
        backtest_key="vwap_rejection",
        research_aliases=("vwap_rejection", "vwap_rejection_short", "research_lab__gold_i__vrs"),
        forward_validation_id="gold_vwap_rejection_short",
        approval_id="vwap_rejection",
        role="standalone_strategy",
        anti_retail_relevance="MEDIUM",
        uses_vwap=True,
        known_gaps="Aliases are fragmented across module, research, forward-validation, and approval reports.",
        recommended_action="CONSOLIDATE",
    ),
    StrategyIdentity(
        canonical_strategy_id="value_area_rejection",
        strategy_family="volume_profile_rejection",
        module_name="value_area_rejection",
        config_key="value_area_rejection",
        backtest_key="value_area_rejection",
        research_aliases=("value_area_rejection", "range_reversal_poc_retest"),
        forward_validation_id="",
        approval_id="value_area_rejection",
        role="standalone_strategy",
        anti_retail_relevance="MEDIUM",
        uses_volume_profile=True,
        known_gaps="Needs cleaner separation from POC/value-area mean-reversion variants.",
        recommended_action="CONSOLIDATE",
    ),
    StrategyIdentity(
        canonical_strategy_id="poc_magnet",
        strategy_family="volume_profile_poc",
        module_name="poc_magnet",
        config_key="poc_magnet",
        backtest_key="poc_magnet",
        research_aliases=("poc_magnet",),
        forward_validation_id="",
        approval_id="poc_magnet",
        role="standalone_strategy",
        anti_retail_relevance="LOW",
        uses_volume_profile=True,
        known_gaps="High raw signal frequency and overfit risk; not approval-grade.",
        recommended_action="DO_NOT_PRIORITIZE",
    ),
    StrategyIdentity(
        canonical_strategy_id="trend_day_vwap_pullback",
        strategy_family="vwap_trend_pullback",
        module_name="trend_day_vwap_pullback",
        config_key="trend_day_vwap_pullback",
        backtest_key="trend_day_vwap_pullback",
        research_aliases=("trend_day_vwap_pullback", "trend_pullback"),
        forward_validation_id="",
        approval_id="trend_day_vwap_pullback",
        role="standalone_strategy",
        anti_retail_relevance="LOW",
        uses_vwap=True,
        known_gaps="Overlaps with VWAP reclaim/rejection family and needs stronger independent validation.",
        recommended_action="CONSOLIDATE",
    ),
    StrategyIdentity(
        canonical_strategy_id="mcx_cluster_orderflow_trap",
        strategy_family="mcx_cluster_orderflow_trap",
        module_name="cluster_imbalance_trap",
        config_key="cluster_imbalance_trap",
        backtest_key="cluster_imbalance_trap",
        research_aliases=("cluster_imbalance_trap", "estimated_buyer_trap", "estimated_seller_trap"),
        forward_validation_id="",
        approval_id="cluster_imbalance_trap",
        role="standalone_strategy",
        anti_retail_relevance="HIGH",
        uses_order_flow=True,
        uses_imbalance=True,
        uses_mcx_metals=True,
        known_gaps="Needs more clean tick/depth forward validation; candle-only path is not sufficient.",
        recommended_action="NEEDS_MORE_DATA",
    ),
    StrategyIdentity(
        canonical_strategy_id="abnormal_flow_filter",
        strategy_family="order_flow_filter",
        module_name="abnormal_flow",
        config_key="abnormal_flow",
        backtest_key="abnormal_flow",
        research_aliases=("abnormal_flow",),
        forward_validation_id="",
        approval_id="abnormal_flow",
        role="filter_or_confirmation",
        anti_retail_relevance="MEDIUM",
        uses_order_flow=True,
        uses_imbalance=True,
        known_gaps="Enabled/backtested, but module is confirmation-only and returns no standalone signal.",
        recommended_action="CONVERT_TO_FILTER",
    ),
    StrategyIdentity(
        canonical_strategy_id="opening_option_mispricing_scanner",
        strategy_family="options_opening_mispricing",
        module_name="opening_option_mispricing",
        config_key="opening_option_mispricing",
        backtest_key="",
        research_aliases=("opening_option_mispricing", "nifty_option_scanner"),
        forward_validation_id="",
        approval_id="opening_option_mispricing",
        role="scanner_only",
        anti_retail_relevance="LOW",
        uses_opening_range=True,
        known_gaps="Scanner-only and disabled in strategy config; not part of main backtest approval path.",
        recommended_action="KEEP_RESEARCH",
    ),
    StrategyIdentity(
        canonical_strategy_id="mcx_metals_placeholder",
        strategy_family="mcx_metals",
        module_name="mcx_metals",
        config_key="mcx_metals",
        backtest_key="",
        research_aliases=("mcx_metals",),
        forward_validation_id="",
        approval_id="mcx_metals",
        role="placeholder",
        anti_retail_relevance="LOW",
        uses_mcx_metals=True,
        known_gaps="Disabled placeholder; no direct production-grade strategy implementation.",
        recommended_action="DISABLE_OR_DEMOTE",
    ),
]


def generate_strategy_identity_report(
    base_dir: Path | str = ".",
    *,
    now: datetime | None = None,
) -> StrategyIdentityReportResult:
    """Build a read-only strategy identity map from local project files."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    strategy_modules = _strategy_module_files(base)
    config_enabled = _load_strategy_config(base / "config" / "strategies.yaml")
    registered = _load_registered_strategies(base / "src" / "strategies" / "strategy_engine.py")
    backtest = _load_backtest_strategies(base / "src" / "backtesting" / "strategy_backtest_runner.py")
    forward_config = _load_simple_yaml(base / "config" / "forward_validation.yaml")
    identity_config = _load_strategy_identity_config(base / "config" / "strategy_identity.yaml")
    forward_id = str(forward_config.get("strategy") or "").strip()
    production_whatsapp_allowed = str(forward_config.get("production_alerts_allowed") or "false").lower() == "true"
    approval_rows = _load_csv(base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv")
    approved_count = sum(1 for row in approval_rows if str(row.get("status", "")).upper() == "APPROVED")
    approval_status = _status_by_key(approval_rows, "strategy")
    research_status = _research_status_by_alias(base / "reports" / "strategy_research" / "latest_strategy_research_report.csv")
    forward_status = _extract_prefixed_value(
        base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt",
        "Approval Decision:",
    ).upper()

    rows = [
        _identity_to_row(
            identity,
            config_enabled=config_enabled,
            registered=registered,
            backtest=backtest,
            forward_id=forward_id,
            approval_status=approval_status,
            research_status=research_status,
            forward_status=forward_status,
        )
        for identity in CANONICAL_STRATEGIES
    ]

    report_path = base / REPORT_PATH
    csv_path = base / CSV_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    _write_csv(csv_path, rows)
    report_path.write_text(
        _format_report(
            timestamp,
            rows,
            strategy_modules=strategy_modules,
            config_enabled=config_enabled,
            registered=registered,
            backtest=backtest,
            approved_count=approved_count,
            production_whatsapp_allowed=production_whatsapp_allowed,
            identity_config=identity_config,
            report_path=REPORT_PATH,
            csv_path=CSV_PATH,
        )
        + "\n",
        encoding="utf-8",
    )
    return StrategyIdentityReportResult(
        report_path=report_path,
        csv_path=csv_path,
        total_strategy_modules=len(strategy_modules),
        total_config_keys=len(config_enabled),
        total_canonical_families=len({row["strategy_family"] for row in rows}),
        approved_strategy_count=approved_count,
        rows=rows,
    )


def _strategy_module_files(base: Path) -> list[str]:
    strategies_dir = base / "src" / "strategies"
    if not strategies_dir.exists():
        return []
    return sorted(path.stem for path in strategies_dir.glob("*.py") if path.name != "__init__.py")


def _load_strategy_config(path: Path) -> dict[str, bool]:
    if not path.exists():
        return {}
    output: dict[str, bool] = {}
    in_strategies = False
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if line.startswith("strategies:"):
            in_strategies = True
            continue
        if in_strategies and not line.startswith((" ", "\t")):
            break
        if in_strategies and ":" in stripped:
            key, value = stripped.split(":", 1)
            normalized = value.strip().lower()
            if normalized in {"true", "false"}:
                output[key.strip()] = normalized == "true"
    return output


def _load_registered_strategies(path: Path) -> set[str]:
    return set(_extract_ast_dict_keys(path, "STRATEGY_MODULES"))


def _load_backtest_strategies(path: Path) -> set[str]:
    return set(_extract_ast_string_list(path, "BACKTEST_STRATEGIES"))


def _extract_ast_dict_keys(path: Path, variable_name: str) -> list[str]:
    if not path.exists():
        return []
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return []
    for node in tree.body:
        if _is_assignment_to(node, variable_name) and isinstance(node.value, ast.Dict):
            return [
                key.value
                for key in node.value.keys
                if isinstance(key, ast.Constant) and isinstance(key.value, str)
            ]
    return []


def _extract_ast_string_list(path: Path, variable_name: str) -> list[str]:
    if not path.exists():
        return []
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return []
    for node in tree.body:
        if _is_assignment_to(node, variable_name) and isinstance(node.value, (ast.List, ast.Tuple)):
            return [
                item.value
                for item in node.value.elts
                if isinstance(item, ast.Constant) and isinstance(item.value, str)
            ]
    return []


def _is_assignment_to(node: ast.AST, variable_name: str) -> bool:
    return isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id == variable_name for target in node.targets
    )


def _load_strategy_identity_config(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    family = "gold_vwap_rejection_reclaim_family"
    required_tokens = [
        family,
        "gold_vwap_rejection_short",
        "vwap_rejection",
        "vwap_rejection_short",
        "gold_vwap_rejection_short",
        "forward_validation_id: gold_vwap_rejection_short",
        "approval_id: gold_vwap_rejection_short",
        "gold_vwap_reclaim_long",
        "vwap_reclaim",
        "vwap_reclaim_long",
        "trend_day_vwap_pullback",
        "status: RESEARCH_ONLY",
        "real_money_approved: false",
        "production_alerts_allowed: false",
    ]
    configured = bool(text) and all(token in text for token in required_tokens)
    threshold_tokens = [
        "approval_review_requirements:",
        "minimum_backtest_trades:",
        "minimum_forward_trades:",
        "requires_cost_slippage_spread: true",
        "requires_forward_independence: true",
        "requires_manual_risk_plan: true",
    ]
    thresholds_configured = bool(text) and all(token in text for token in threshold_tokens)
    return {
        "path": str(path),
        "text": text,
        "gold_vwap_family_configured": configured,
        "gold_vwap_family": family,
        "real_money_approved": "real_money_approved: true" in text,
        "production_alerts_allowed": "production_alerts_allowed: true" in text,
        "status": "RESEARCH_ONLY" if "status: RESEARCH_ONLY" in text else "UNKNOWN",
        "approval_thresholds_configured": thresholds_configured,
        "minimum_forward_trades": _extract_yaml_int_from_text(text, "minimum_forward_trades"),
        "minimum_backtest_trades": _extract_yaml_int_from_text(text, "minimum_backtest_trades"),
    }


def _extract_yaml_int_from_text(text: str, key: str) -> int:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{key}:"):
            value = stripped.split(":", 1)[1].strip()
            try:
                return int(float(value))
            except ValueError:
                return 0
    return 0


def _load_simple_yaml(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    output: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or ":" not in stripped:
            continue
        key, value = stripped.split(":", 1)
        output[key.strip()] = value.strip().strip("\"'")
    return output


def _load_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def _status_by_key(rows: list[dict[str, str]], key_name: str) -> dict[str, str]:
    output: dict[str, str] = {}
    for row in rows:
        key = str(row.get(key_name) or "").strip()
        status = str(row.get("status") or "").strip().upper()
        if key and status:
            output[key] = status
    return output


def _research_status_by_alias(path: Path) -> dict[str, str]:
    output: dict[str, str] = {}
    for row in _load_csv(path):
        status = str(row.get("status") or "").strip().upper()
        strategy = str(row.get("strategy") or "").strip()
        recommendation = str(row.get("final_recommendation") or "")
        aliases = {strategy}
        if ":" in recommendation:
            aliases.add(recommendation.split(":", 1)[0].strip())
        for alias in aliases:
            if alias and status:
                output[alias] = status
    return output


def _extract_prefixed_value(path: Path, prefix: str) -> str:
    if not path.exists():
        return ""
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.lower().startswith(prefix.lower()):
            return line.split(":", 1)[1].strip()
    return ""


def _identity_to_row(
    identity: StrategyIdentity,
    *,
    config_enabled: dict[str, bool],
    registered: set[str],
    backtest: set[str],
    forward_id: str,
    approval_status: dict[str, str],
    research_status: dict[str, str],
    forward_status: str,
) -> dict[str, Any]:
    enabled = config_enabled.get(identity.config_key)
    registered_in_engine = identity.module_name in registered
    included_in_backtest = bool(identity.backtest_key and identity.backtest_key in backtest)
    included_in_forward = bool(identity.forward_validation_id and identity.forward_validation_id == forward_id)
    has_generator = identity.role == "standalone_strategy" and registered_in_engine
    if identity.role in {"filter_or_confirmation", "scanner_only", "placeholder", "missing_module"}:
        has_generator = False
    current_status = _current_status(
        identity,
        approval_status=approval_status,
        research_status=research_status,
        forward_status=forward_status,
        included_in_forward=included_in_forward,
    )
    return {
        "canonical_strategy_id": identity.canonical_strategy_id,
        "strategy_family": identity.strategy_family,
        "module_name": identity.module_name,
        "config_key": identity.config_key,
        "backtest_key": identity.backtest_key,
        "research_id_or_aliases": ";".join(identity.research_aliases),
        "forward_validation_id": identity.forward_validation_id,
        "approval_id": identity.approval_id,
        "enabled_in_config": _bool_or_missing(enabled),
        "registered_in_engine": _bool_text(registered_in_engine),
        "included_in_backtest": _bool_text(included_in_backtest),
        "included_in_forward_validation": _bool_text(included_in_forward),
        "has_direct_signal_generator": _bool_text(has_generator),
        "role": identity.role,
        "current_status": current_status,
        "anti_retail_relevance": identity.anti_retail_relevance,
        "uses_vwap": _bool_text(identity.uses_vwap),
        "uses_order_flow": _bool_text(identity.uses_order_flow),
        "uses_imbalance": _bool_text(identity.uses_imbalance),
        "uses_volume_profile": _bool_text(identity.uses_volume_profile),
        "uses_support_resistance": _bool_text(identity.uses_support_resistance),
        "uses_opening_range": _bool_text(identity.uses_opening_range),
        "uses_mcx_metals": _bool_text(identity.uses_mcx_metals),
        "known_gaps": identity.known_gaps,
        "recommended_action": identity.recommended_action,
    }


def _current_status(
    identity: StrategyIdentity,
    *,
    approval_status: dict[str, str],
    research_status: dict[str, str],
    forward_status: str,
    included_in_forward: bool,
) -> str:
    if included_in_forward and forward_status:
        return forward_status
    approval = approval_status.get(identity.approval_id)
    if approval:
        return approval
    alias_statuses = [research_status[alias] for alias in identity.research_aliases if alias in research_status]
    for status in ("APPROVED", "WATCHLIST", "RESEARCH_ONLY", "REJECTED"):
        if status in alias_statuses:
            return status
    if identity.role in {"missing_module", "scanner_only", "placeholder"}:
        return "NOT_CONNECTED"
    return "UNKNOWN"


def _bool_text(value: bool) -> str:
    return str(bool(value)).lower()


def _bool_or_missing(value: bool | None) -> str:
    if value is None:
        return "missing"
    return _bool_text(value)


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=REPORT_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _format_report(
    timestamp: datetime,
    rows: list[dict[str, Any]],
    *,
    strategy_modules: list[str],
    config_enabled: dict[str, bool],
    registered: set[str],
    backtest: set[str],
    approved_count: int,
    production_whatsapp_allowed: bool,
    identity_config: dict[str, Any],
    report_path: Path,
    csv_path: Path,
) -> str:
    config_or_backtest = set(config_enabled) | backtest
    missing_mismatches = sorted(key for key in config_or_backtest if key not in registered)
    duplicate_text = (
        "vwap_rejection/vwap_rejection_short/gold_vwap_rejection_short; "
        "vwap_reclaim/vwap_reclaim_long; "
        "opening-range acceptance/failure/trap; "
        "poc_magnet/value_area_rejection/range_reversal_poc_retest"
    )
    filters = [row["canonical_strategy_id"] for row in rows if row["role"] == "filter_or_confirmation"]
    scanner_or_placeholder = [
        row["canonical_strategy_id"] for row in rows if row["role"] in {"scanner_only", "placeholder"}
    ]
    not_eligible = [row["canonical_strategy_id"] for row in rows if row["current_status"] != "APPROVED"]
    lines = [
        "CANONICAL STRATEGY IDENTITY REPORT",
        f"Generated At: {timestamp.isoformat()}",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Real Money Approval: false",
        f"Production WhatsApp Alerts: {'ALLOWED' if production_whatsapp_allowed else 'BLOCKED'}",
        "",
        "SUMMARY",
        f"Total strategy modules: {len(strategy_modules)}",
        f"Total config keys: {len(config_enabled)}",
        f"Total canonical strategy families: {len({row['strategy_family'] for row in rows})}",
        f"Registered engine strategies: {len(registered)}",
        f"Backtest strategies: {len(backtest)}",
        f"Approved strategy count: {approved_count}",
        f"Missing module/config mismatches: {'; '.join(missing_mismatches) if missing_mismatches else 'NONE'}",
        f"Canonical strategy identity config: {'FOUND' if identity_config.get('gold_vwap_family_configured') else 'MISSING_OR_INCOMPLETE'}",
        f"GOLD VWAP identity consistency: {'CONSISTENT' if identity_config.get('gold_vwap_family_configured') else 'PARTIAL'}",
        f"GOLD VWAP family status: {identity_config.get('status', 'UNKNOWN')}",
        f"GOLD VWAP real-money approved: {str(bool(identity_config.get('real_money_approved'))).lower()}",
        f"GOLD VWAP production alerts allowed: {str(bool(identity_config.get('production_alerts_allowed'))).lower()}",
        f"GOLD VWAP approval thresholds configured: {str(bool(identity_config.get('approval_thresholds_configured'))).lower()}",
        f"GOLD VWAP required forward trades: {identity_config.get('minimum_forward_trades', 0)}",
        f"GOLD VWAP required backtest trades: {identity_config.get('minimum_backtest_trades', 0)}",
        f"Duplicate/overlapping strategy identities: {duplicate_text if not identity_config.get('gold_vwap_family_configured') else 'Resolved for GOLD-I VWAP family by config/strategy_identity.yaml; remaining families still need canonical mapping'}",
        f"Strategies that should be filters, not standalone strategies: {', '.join(filters) if filters else 'NONE'}",
        f"Strategies that are placeholders/scanners only: {', '.join(scanner_or_placeholder) if scanner_or_placeholder else 'NONE'}",
        "Strategies eligible for next research focus: gold_vwap_rejection_short; failed_breakout_trap/failed_breakdown_trap; mcx_cluster_orderflow_trap",
        f"Strategies not eligible for approval: {len(not_eligible)}",
        "",
        "TOP 3 FOCUS FAMILIES",
        "1. GOLD-I VWAP rejection/reclaim family",
        "2. Opening-range failure/trap family",
        "3. MCX cluster/order-flow trap family",
        "",
        "STRATEGY IDENTITY MAP",
        "canonical_strategy_id | module_name | config_key | backtest_key | role | current_status | recommended_action | known_gaps",
    ]
    for row in rows:
        lines.append(
            " | ".join(
                [
                    row["canonical_strategy_id"],
                    row["module_name"],
                    row["config_key"],
                    row["backtest_key"] or "-",
                    row["role"],
                    row["current_status"],
                    row["recommended_action"],
                    row["known_gaps"],
                ]
            )
        )
    lines.extend(
        [
            "",
            "OUTPUTS",
            f"Report Path: {report_path}",
            f"CSV Path: {csv_path}",
            "",
            "SAFETY CONFIRMATION",
            "No live data was requested by this report.",
            "No broker orders were placed.",
            "No production WhatsApp alerts were enabled.",
            "No strategy approval was changed.",
            "PAPER MODE ONLY. Real-money trading remains 0% approved.",
        ]
    )
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(
        description="Create a read-only canonical strategy identity map. No live data, broker, or order actions."
    )


def main(argv: list[str] | None = None) -> int:
    build_parser().parse_args(argv)
    result = generate_strategy_identity_report()
    print("CANONICAL STRATEGY IDENTITY REPORT")
    print(f"Report path: {result.report_path}")
    print(f"CSV path: {result.csv_path}")
    print(f"Total strategy modules: {result.total_strategy_modules}")
    print(f"Total canonical strategy families: {result.total_canonical_families}")
    print(f"Approved strategy count: {result.approved_strategy_count}")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    print("Production WhatsApp Alerts: BLOCKED | Real-money trading approval: false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
