from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


CANONICAL_FAMILY_ID = "gold_vwap_rejection_reclaim_family"
REPORT_PATH = Path("reports") / "strategy_specs" / "latest_gold_vwap_family_spec_report.txt"
CSV_PATH = Path("reports") / "strategy_specs" / "gold_vwap_family_spec_map.csv"

SPEC_COLUMNS = [
    "setup_id",
    "display_name",
    "module_name",
    "direction",
    "current_status",
    "approval_status",
    "research_status",
    "forward_validation_id",
    "data_requirements",
    "known_weak_points",
]


@dataclass(frozen=True)
class VwapFamilySpecResult:
    report_path: Path
    csv_path: Path
    canonical_family_id: str
    approved_strategy_count: int
    setup_count: int
    current_approval_status: str


def generate_gold_vwap_family_spec_report(
    base_dir: Path | str = ".",
    *,
    now: datetime | None = None,
) -> VwapFamilySpecResult:
    """Create a local-file-only spec report for the GOLD-I VWAP family.

    This function reads existing strategy/config/report files and writes a report.
    It performs no live data, broker, alert, or order action.
    """

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    evidence = _collect_evidence(base)
    setup_rows = _build_setup_rows(evidence)
    approved_count = evidence["approved_strategy_count"]
    report_path = base / REPORT_PATH
    csv_path = base / CSV_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    _write_csv(csv_path, setup_rows)
    report_path.write_text(_format_report(timestamp, setup_rows, evidence) + "\n", encoding="utf-8")
    return VwapFamilySpecResult(
        report_path=report_path,
        csv_path=csv_path,
        canonical_family_id=CANONICAL_FAMILY_ID,
        approved_strategy_count=approved_count,
        setup_count=len(setup_rows),
        current_approval_status="RESEARCH_ONLY",
    )


def _collect_evidence(base: Path) -> dict[str, Any]:
    approval_rows = _load_csv(base / "reports" / "strategy_verification" / "latest_strategy_approval_report.csv")
    research_rows = _load_csv(base / "reports" / "strategy_research" / "latest_strategy_research_report.csv")
    forward_text = _read_text(base / "reports" / "forward_validation" / "latest_forward_validation_summary.txt")
    deep_dive_text = _read_text(base / "reports" / "strategy_research" / "latest_gold_vwap_rejection_deep_dive.txt")
    identity_text = _read_text(base / "reports" / "strategy_identity" / "latest_strategy_identity_report.txt")
    strategies_config = _read_text(base / "config" / "strategies.yaml")
    forward_config = _read_text(base / "config" / "forward_validation.yaml")
    return {
        "approval_rows": approval_rows,
        "research_rows": research_rows,
        "forward_text": forward_text,
        "deep_dive_text": deep_dive_text,
        "identity_text": identity_text,
        "strategies_config": strategies_config,
        "forward_config": forward_config,
        "vwap_rejection_code": _read_text(base / "src" / "strategies" / "vwap_rejection.py"),
        "vwap_reclaim_code": _read_text(base / "src" / "strategies" / "vwap_reclaim.py"),
        "trend_day_vwap_pullback_code": _read_text(base / "src" / "strategies" / "trend_day_vwap_pullback.py"),
        "approved_strategy_count": sum(1 for row in approval_rows if str(row.get("status", "")).upper() == "APPROVED"),
        "approval_status": _status_by_strategy(approval_rows),
        "research_status": _research_status_by_alias(research_rows),
        "forward_decision": _extract_prefixed_value(forward_text, "Approval Decision:") or "RESEARCH_ONLY",
        "forward_trades": _extract_metric(forward_text, "Forward/replay-recorded trades:", "trades") or "0",
        "forward_pf": _extract_metric(forward_text, "Forward/replay-recorded trades:", "PF") or "UNKNOWN",
        "deep_dive_status": _extract_prefixed_value(deep_dive_text, "Current approval status:") or "UNKNOWN",
        "deep_dive_robustness": _extract_prefixed_value(deep_dive_text, "Robustness:") or "UNKNOWN",
        "production_alerts_allowed": "production_alerts_allowed: true" in forward_config.lower(),
    }


def _build_setup_rows(evidence: dict[str, Any]) -> list[dict[str, str]]:
    approval = evidence["approval_status"]
    research = evidence["research_status"]
    forward_decision = str(evidence["forward_decision"]).upper()
    return [
        {
            "setup_id": "vwap_rejection_short",
            "display_name": "VWAP Rejection Short",
            "module_name": "vwap_rejection",
            "direction": "short",
            "current_status": forward_decision,
            "approval_status": approval.get("vwap_rejection", "UNKNOWN"),
            "research_status": research.get("vwap_rejection_short", evidence["deep_dive_status"]),
            "forward_validation_id": "gold_vwap_rejection_short",
            "data_requirements": "OHLCV bars with VWAP, ATR/volume context for research variant, market regime.",
            "known_weak_points": "Only 5 forward/replay trades; sample size is below WATCHLIST review threshold.",
        },
        {
            "setup_id": "vwap_reclaim_long",
            "display_name": "VWAP Reclaim Long",
            "module_name": "vwap_reclaim",
            "direction": "long",
            "current_status": research.get("vwap_reclaim_long", approval.get("vwap_reclaim", "UNKNOWN")),
            "approval_status": approval.get("vwap_reclaim", "UNKNOWN"),
            "research_status": research.get("vwap_reclaim_long", "UNKNOWN"),
            "forward_validation_id": "",
            "data_requirements": "OHLCV bars with VWAP cross/reclaim context and market regime.",
            "known_weak_points": "Research/watchlist-like evidence exists, but no dedicated forward-validation ID is active.",
        },
        {
            "setup_id": "trend_day_vwap_pullback",
            "display_name": "Trend-day VWAP Pullback",
            "module_name": "trend_day_vwap_pullback",
            "direction": "long_or_short",
            "current_status": approval.get("trend_day_vwap_pullback", "REJECTED"),
            "approval_status": approval.get("trend_day_vwap_pullback", "UNKNOWN"),
            "research_status": research.get("trend_pullback", "UNKNOWN"),
            "forward_validation_id": "",
            "data_requirements": "OHLCV bars with VWAP slope/structure and market regime.",
            "known_weak_points": "Overlaps with VWAP reclaim/rejection; identity should be consolidated or separated clearly.",
        },
    ]


def _format_report(timestamp: datetime, setup_rows: list[dict[str, str]], evidence: dict[str, Any]) -> str:
    production_whatsapp = "ALLOWED" if evidence["production_alerts_allowed"] else "BLOCKED"
    lines = [
        "GOLD-I VWAP REJECTION / RECLAIM FAMILY SPEC REPORT",
        f"Generated At: {timestamp.isoformat()}",
        "Recommended Codex Level Used: High",
        "Mode: PAPER / RESEARCH / MANUAL SIGNAL ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "Real Money Approval: false",
        f"Production WhatsApp Alerts: {production_whatsapp}",
        "",
        "CANONICAL FAMILY",
        f"canonical_family_id: {CANONICAL_FAMILY_ID}",
        "Canonical parent family should be: gold_vwap_rejection_reclaim_family",
        "Family members: vwap_rejection; vwap_rejection_short; gold_vwap_rejection_short; vwap_reclaim; vwap_reclaim_long; trend_day_vwap_pullback",
        "",
        "CURRENT STATUS SUMMARY",
        f"Approved strategy count: {evidence['approved_strategy_count']}",
        "Current family approval status: RESEARCH_ONLY",
        "GOLD-I VWAP Rejection Short: RESEARCH_ONLY, not approval-ready.",
        "VWAP Reclaim Long: WATCHLIST-like research evidence exists, not approval-ready.",
        "Trend-day VWAP Pullback: overlapping/rejected production identity, not approval-ready.",
        "Real-money manual trading approved: false",
        "",
        "EVIDENCE SUMMARY",
        "Forward validation ID: gold_vwap_rejection_short",
        f"Forward trades count: {evidence['forward_trades']}",
        f"Forward profit factor: {evidence['forward_pf']}",
        f"Forward approval decision: {evidence['forward_decision']}",
        f"Deep-dive status: {evidence['deep_dive_status']}",
        f"Deep-dive robustness: {evidence['deep_dive_robustness']}",
        "Minimum sample required before WATCHLIST review: at least 10 forward trades.",
        "Evidence sufficient for manual trading approval: false",
        "",
        "SETUP SPECIFICATIONS",
    ]
    lines.extend(_setup_spec_vwap_rejection_short())
    lines.extend(_setup_spec_vwap_reclaim_long())
    lines.extend(_setup_spec_trend_day_vwap_pullback())
    lines.extend(
        [
            "",
            "STATUS BY SETUP",
            "setup_id | display_name | direction | current_status | approval_status | research_status | forward_validation_id",
        ]
    )
    for row in setup_rows:
        lines.append(
            " | ".join(
                [
                    row["setup_id"],
                    row["display_name"],
                    row["direction"],
                    row["current_status"],
                    row["approval_status"],
                    row["research_status"],
                    row["forward_validation_id"] or "-",
                ]
            )
        )
    lines.extend(_approval_gap_checklist(production_whatsapp))
    lines.extend(_recommended_next_steps())
    lines.extend(
        [
            "",
            "OUTPUTS",
            f"Report Path: {REPORT_PATH}",
            f"CSV Path: {CSV_PATH}",
            "",
            "SAFETY CONFIRMATION",
            "No live data used.",
            "No broker orders.",
            "No production WhatsApp.",
            "execution_allowed=false.",
            "Real-money trading remains 0% approved.",
            "No strategy approval, alert permission, or order setting was changed.",
        ]
    )
    return "\n".join(lines)


def _setup_spec_vwap_rejection_short() -> list[str]:
    return [
        "",
        "VWAP Rejection Short",
        "Direction: short",
        "Setup condition: price trades into/above VWAP, then closes back below VWAP with bearish candle control.",
        "Entry trigger: current implementation enters at the rejecting candle close; research version uses delayed/future bar assumptions.",
        "Invalid setup / avoid condition: insufficient bars; no bearish close below VWAP; weak or incomplete sample; no approval-grade evidence.",
        "Stop-loss/invalidation availability: available; module uses high + 5 points, research version uses ATR/invalidation logic.",
        "Target/risk-reward availability: available; module uses 2R target.",
        "VWAP role: primary rejection/resistance reference.",
        "Order-flow role: not required in current module; can be added later as confirmation only.",
        "Imbalance role: not required in current module.",
        "Volume-profile role: not used directly.",
        "Support/resistance role: not used directly.",
        "Opening-range role: research report includes opening-range parameterization; module itself does not require it.",
        "Market regime filter availability: market_mode is attached; short module branch does not strictly require TREND_DOWN.",
        "Data requirements: OHLCV bars, VWAP, enough history for regime/ATR/volume research checks.",
        "Known weak points: low forward sample, alias fragmentation, not approval-ready.",
    ]


def _setup_spec_vwap_reclaim_long() -> list[str]:
    return [
        "",
        "VWAP Reclaim Long",
        "Direction: long",
        "Setup condition: previous candle closes below VWAP and latest candle closes back above VWAP with bullish candle control.",
        "Entry trigger: latest candle close after reclaim.",
        "Invalid setup / avoid condition: insufficient bars; no clean reclaim; bearish continuation; no dedicated forward-validation ID.",
        "Stop-loss/invalidation availability: available; module uses latest low - 5 points.",
        "Target/risk-reward availability: available; module uses 2R target.",
        "VWAP role: primary reclaim/fair-value acceptance reference.",
        "Order-flow role: not required in current module.",
        "Imbalance role: not required in current module.",
        "Volume-profile role: not used directly.",
        "Support/resistance role: not used directly.",
        "Opening-range role: research lab variants include opening-range parameters; module itself does not require it.",
        "Market regime filter availability: market_mode is attached but module trigger is VWAP reclaim driven.",
        "Data requirements: OHLCV bars and VWAP.",
        "Known weak points: production approval row is rejected; research alias is not enough for manual trading approval.",
    ]


def _setup_spec_trend_day_vwap_pullback() -> list[str]:
    return [
        "",
        "Trend-day VWAP Pullback",
        "Direction: long or short",
        "Setup condition: VWAP slope/local structure supports trend, then pullback holds/rejects VWAP.",
        "Entry trigger: candle close after VWAP hold/rejection.",
        "Invalid setup / avoid condition: insufficient bars; weak trend structure; market mode not aligned and local structure absent.",
        "Stop-loss/invalidation availability: available; long uses low - 5, short uses high + 5.",
        "Target/risk-reward availability: available; module uses 2R target.",
        "VWAP role: primary pullback support/resistance reference.",
        "Order-flow role: not required in current module.",
        "Imbalance role: not required in current module.",
        "Volume-profile role: not used directly.",
        "Support/resistance role: not used directly.",
        "Opening-range role: not used directly.",
        "Market regime filter availability: yes; TREND_UP/TREND_DOWN or local VWAP structure.",
        "Data requirements: OHLCV bars, VWAP history, market regime.",
        "Known weak points: overlaps with VWAP rejection/reclaim family and is not approval-ready.",
    ]


def _approval_gap_checklist(production_whatsapp: str) -> list[str]:
    return [
        "",
        "APPROVAL GAP CHECKLIST",
        "canonical identity complete: partial",
        "backtest quality complete: false",
        "cost/slippage model complete: false/unknown",
        "out-of-sample/walk-forward complete: false",
        "robustness testing complete: false",
        "forward validation sample sufficient: false",
        "manual risk plan complete: false",
        "signal delivery ready: false",
        f"production alerts allowed: {str(production_whatsapp == 'ALLOWED').lower()}",
        "real-money manual trading approved: false",
    ]


def _recommended_next_steps() -> list[str]:
    return [
        "",
        "RECOMMENDED NEXT IMPROVEMENT SEQUENCE",
        "1. Consolidate IDs under one canonical family.",
        "2. Define exact entry, invalidation, stop-loss, and target rules for VWAP Rejection Short and VWAP Reclaim Long.",
        "3. Add/verify realistic cost, slippage, spread, and fill assumptions in backtests for this family.",
        "4. Expand forward validation sample size with clean, provider-tagged real-market days.",
        "5. Only after proof, create a research-only signal template for manual review.",
    ]


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _load_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def _status_by_strategy(rows: list[dict[str, str]]) -> dict[str, str]:
    output: dict[str, str] = {}
    for row in rows:
        strategy = str(row.get("strategy") or "").strip()
        status = str(row.get("status") or "").strip().upper()
        if strategy and status:
            output[strategy] = status
    return output


def _research_status_by_alias(rows: list[dict[str, str]]) -> dict[str, str]:
    output: dict[str, str] = {}
    for row in rows:
        status = str(row.get("status") or "").strip().upper()
        strategy = str(row.get("strategy") or "").strip()
        recommendation = str(row.get("final_recommendation") or "")
        aliases = {strategy}
        if ":" in recommendation:
            aliases.add(recommendation.split(":", 1)[0].strip())
        for alias in aliases:
            if alias and status:
                output[alias] = status
    return output


def _extract_prefixed_value(text: str, prefix: str) -> str:
    for line in text.splitlines():
        if line.lower().startswith(prefix.lower()):
            return line.split(":", 1)[1].strip()
    return ""


def _extract_metric(text: str, line_prefix: str, metric_name: str) -> str:
    for line in text.splitlines():
        if not line.startswith(line_prefix):
            continue
        parts = line.replace(",", " ").split()
        prefix = metric_name + "="
        for part in parts:
            if part.startswith(prefix):
                return part.split("=", 1)[1]
    return ""


def _write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=SPEC_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(
        description="Create a local-file-only GOLD-I VWAP family spec report. No live data, brokers, alerts, or orders."
    )


def main(argv: list[str] | None = None) -> int:
    build_parser().parse_args(argv)
    result = generate_gold_vwap_family_spec_report()
    print("GOLD-I VWAP FAMILY SPEC REPORT")
    print(f"Report path: {result.report_path}")
    print(f"CSV path: {result.csv_path}")
    print(f"Canonical family: {result.canonical_family_id}")
    print(f"Setup count: {result.setup_count}")
    print(f"Approved strategy count: {result.approved_strategy_count}")
    print(f"Current approval status: {result.current_approval_status}")
    print("execution_allowed=false | Live Trading: DISABLED | Broker Orders: DISABLED")
    print("Production WhatsApp Alerts: BLOCKED | Real-money trading approval: false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
