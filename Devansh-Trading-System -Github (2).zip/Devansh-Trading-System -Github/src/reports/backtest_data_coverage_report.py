from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from src.config_loader import load_yaml


REPORT_PATH = Path("reports") / "strategy_audits" / "latest_backtest_data_coverage_report.txt"
CSV_PATH = Path("reports") / "strategy_audits" / "backtest_data_coverage_matrix.csv"
STRATEGY_FOCUS_FAMILY = "gold_vwap_rejection_reclaim_family"
LOCK_VERSION = "GOLD_VWAP_RESEARCH_LOCK_V1"

DATA_ROOTS = [
    Path("data"),
    Path("data") / "historical",
    Path("data") / "historical" / "truedata",
    Path("data") / "historical" / "truedata" / "bars",
    Path("data") / "historical" / "truedata" / "ticks",
    Path("data") / "kite_recorded" / "ticks",
    Path("data") / "kite_recorded" / "depth",
    Path("data") / "kite_recorded" / "features",
    Path("data") / "ticks",
]

CSV_COLUMNS = [
    "record_type",
    "symbol",
    "provider",
    "data_type",
    "date_range",
    "file_count",
    "row_count",
    "timeframes",
    "usable_for_multi_year_backtest",
    "usable_for_orderflow_depth_backtest",
    "strategy_name",
    "family",
    "readiness_bucket",
    "required_data_type",
    "can_backtest_now",
    "reason",
]


@dataclass(frozen=True)
class BacktestDataCoverageResult:
    report_path: Path
    csv_path: Path
    data_coverage_status: str
    multi_year_backtest_ready: str
    total_data_groups: int
    total_strategy_rows: int
    ready_for_bar_backtest: int
    needs_tick_or_depth: int
    filter_only: int
    next_best_task: str


def generate_backtest_data_coverage_report(
    base_dir: Path | str = ".",
    *,
    now: datetime | None = None,
) -> BacktestDataCoverageResult:
    """Create a local-file-only audit of backtest data coverage and strategy readiness."""

    base = Path(base_dir)
    timestamp = now or datetime.now().astimezone()
    data_groups = _scan_data_coverage(base)
    strategies = _scan_strategy_readiness(base, data_groups)
    status = _coverage_status(data_groups)
    multi_year_ready = _multi_year_ready(data_groups)
    next_task = _next_best_task(data_groups, strategies)

    report_path = base / REPORT_PATH
    csv_path = base / CSV_PATH
    report_path.parent.mkdir(parents=True, exist_ok=True)
    _write_csv(csv_path, data_groups, strategies)
    report_path.write_text(
        _format_report(timestamp, data_groups, strategies, status, multi_year_ready, next_task) + "\n",
        encoding="utf-8",
    )

    return BacktestDataCoverageResult(
        report_path=report_path,
        csv_path=csv_path,
        data_coverage_status=status,
        multi_year_backtest_ready=multi_year_ready,
        total_data_groups=len(data_groups),
        total_strategy_rows=len(strategies),
        ready_for_bar_backtest=sum(1 for row in strategies if row["readiness_bucket"] == "READY_FOR_BAR_BACKTEST"),
        needs_tick_or_depth=sum(1 for row in strategies if row["readiness_bucket"] == "NEEDS_TICK_OR_DEPTH_DATA"),
        filter_only=sum(1 for row in strategies if row["readiness_bucket"] == "FILTER_ONLY_NOT_STANDALONE"),
        next_best_task=next_task,
    )


def _scan_data_coverage(base: Path) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str, str], dict[str, Any]] = {}
    for root in DATA_ROOTS:
        full_root = base / root
        if not full_root.exists():
            continue
        for path in full_root.rglob("*.csv"):
            if any(part == "__pycache__" for part in path.parts):
                continue
            provider = _provider_for_path(path)
            data_type = _data_type_for_path(path)
            symbol = _symbol_for_file(path)
            key = (provider, data_type, symbol)
            group = groups.setdefault(
                key,
                {
                    "record_type": "DATA",
                    "symbol": symbol,
                    "provider": provider,
                    "data_type": data_type,
                    "files": [],
                    "dates": set(),
                    "row_count": 0,
                    "timeframes": set(),
                    "columns": set(),
                },
            )
            group["files"].append(path)
            group["dates"].update(_dates_from_path(path))
            count, columns, intervals = _csv_stats(path)
            group["row_count"] += count
            group["columns"].update(columns)
            group["timeframes"].update(intervals)
    rows: list[dict[str, Any]] = []
    for group in groups.values():
        dates = sorted(group["dates"])
        date_range = f"{dates[0]} to {dates[-1]}" if dates else "UNKNOWN"
        timeframes = sorted(group["timeframes"])
        row = {
            "record_type": "DATA",
            "symbol": group["symbol"],
            "provider": group["provider"],
            "data_type": group["data_type"],
            "date_range": date_range,
            "file_count": len(group["files"]),
            "row_count": group["row_count"],
            "timeframes": ";".join(timeframes) if timeframes else _default_timeframe(group["data_type"]),
            "usable_for_multi_year_backtest": _usable_multi_year(group, dates),
            "usable_for_orderflow_depth_backtest": _usable_orderflow(group),
            "columns": group["columns"],
        }
        rows.append(row)
    return sorted(rows, key=lambda item: (item["provider"], item["data_type"], item["symbol"]))


def _scan_strategy_readiness(base: Path, data_groups: list[dict[str, Any]]) -> list[dict[str, Any]]:
    strategies_dir = base / "src" / "strategies"
    module_names = []
    if strategies_dir.exists():
        module_names = sorted(
            path.stem
            for path in strategies_dir.glob("*.py")
            if path.stem not in {"__init__", "base_strategy", "strategy_engine", "cluster_signal_quality", "mcx_metals"}
        )
    config_enabled = _strategy_config(base)
    identity_map = _identity_map(base)
    rows = []
    for name in module_names:
        enabled = bool(config_enabled.get(name, True))
        identity = identity_map.get(name, {})
        family = identity.get("canonical_strategy_id") or _family_for_strategy(name)
        role = identity.get("role") or _role_for_strategy(name)
        current_status = identity.get("current_status") or ("RESEARCH_ONLY" if name == "vwap_rejection" else "REJECTED")
        required = _required_data_type(name)
        bucket, can_backtest, reason = _readiness_bucket(name, role, enabled, required, data_groups, current_status)
        rows.append(
            {
                "record_type": "STRATEGY",
                "strategy_name": name,
                "family": family,
                "config_enabled": str(enabled).lower(),
                "standalone_signal_strategy": str(role == "standalone_strategy").lower(),
                "filter_confirmation_only": str(role == "filter_or_confirmation").lower(),
                "required_data_type": required,
                "readiness_bucket": bucket,
                "can_backtest_now": can_backtest,
                "reason": reason,
                "current_status": current_status,
            }
        )
    for config_name, enabled in sorted(config_enabled.items()):
        if config_name not in {row["strategy_name"] for row in rows}:
            required = _required_data_type(config_name)
            bucket = "UNKNOWN_NEEDS_INSPECTION" if enabled else "DISABLED_OR_RESEARCH_ONLY"
            rows.append(
                {
                    "record_type": "STRATEGY",
                    "strategy_name": config_name,
                    "family": _family_for_strategy(config_name),
                    "config_enabled": str(bool(enabled)).lower(),
                    "standalone_signal_strategy": "unknown",
                    "filter_confirmation_only": "unknown",
                    "required_data_type": required,
                    "readiness_bucket": bucket,
                    "can_backtest_now": "partial" if enabled else "no",
                    "reason": "Configured strategy does not have a directly matched inspected module or needs manual mapping.",
                    "current_status": "UNKNOWN" if enabled else "DISABLED",
                }
            )
    return rows


def _identity_map(base: Path) -> dict[str, dict[str, str]]:
    path = base / "reports" / "strategy_identity" / "strategy_identity_map.csv"
    output: dict[str, dict[str, str]] = {}
    if not path.exists():
        return output
    try:
        with path.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                module = str(row.get("module_name") or "").strip()
                if module:
                    output[module] = row
    except OSError:
        return output
    return output


def _strategy_config(base: Path) -> dict[str, bool]:
    path = base / "config" / "strategies.yaml"
    if not path.exists():
        return {}
    try:
        raw = load_yaml(path) or {}
    except Exception:
        return {}
    strategies = raw.get("strategies", raw) if isinstance(raw, dict) else {}
    return {str(key): bool(value) for key, value in strategies.items()} if isinstance(strategies, dict) else {}


def _readiness_bucket(
    name: str,
    role: str,
    enabled: bool,
    required: str,
    data_groups: list[dict[str, Any]],
    current_status: str,
) -> tuple[str, str, str]:
    if role == "filter_or_confirmation" or name == "abnormal_flow":
        return "FILTER_ONLY_NOT_STANDALONE", "no", "Strategy appears to be a filter/confirmation, not a standalone approval-grade signal."
    if not enabled or current_status in {"NOT_CONNECTED"}:
        return "DISABLED_OR_RESEARCH_ONLY", "no", "Strategy is disabled, scanner-only, placeholder, or not connected for approval."
    if required in {"OHLCV bars", "intraday bars", "OHLCV bars + VWAP"}:
        if _has_bars(data_groups):
            if current_status == "RESEARCH_ONLY" or "vwap" in name:
                return "DISABLED_OR_RESEARCH_ONLY", "partial", "Bar data exists, but strategy remains research-only and approval/forward independence is incomplete."
            return "READY_FOR_BAR_BACKTEST", "yes", "Local intraday OHLCV bars exist; still require conservative execution settings."
        return "PARTIAL_NEEDS_DATA_ADAPTER", "partial", "Strategy is bar-based, but no suitable local OHLCV bar coverage was found."
    if required in {"tick data", "depth/order book", "order-flow features", "tick/depth/order-flow features"}:
        if _has_tick_or_depth(data_groups):
            return "PARTIAL_NEEDS_DATA_ADAPTER", "partial", "Tick/depth/features exist only for short recent periods; adapter/replay and larger sample are needed."
        return "NEEDS_TICK_OR_DEPTH_DATA", "no", "Requires tick/depth/order-flow data that is not sufficiently available."
    return "UNKNOWN_NEEDS_INSPECTION", "partial", "Data requirements or standalone behavior need inspection."


def _required_data_type(name: str) -> str:
    if "cluster" in name:
        return "tick/depth/order-flow features"
    if "abnormal_flow" in name:
        return "order-flow features"
    if "opening_option" in name:
        return "option chain + intraday bars"
    if "vwap" in name:
        return "OHLCV bars + VWAP"
    if "poc" in name or "value_area" in name:
        return "intraday bars + volume profile"
    if "breakout" in name or "breakdown" in name or "trend" in name:
        return "intraday bars"
    return "OHLCV bars"


def _role_for_strategy(name: str) -> str:
    if name == "abnormal_flow":
        return "filter_or_confirmation"
    if "opening_option" in name:
        return "scanner_only"
    return "standalone_strategy"


def _family_for_strategy(name: str) -> str:
    if "vwap" in name:
        return STRATEGY_FOCUS_FAMILY
    if "cluster" in name:
        return "mcx_cluster_orderflow_trap"
    if "breakout" in name or "breakdown" in name:
        return "opening_range_failure_trap_family"
    return name


def _provider_for_path(path: Path) -> str:
    text = str(path).replace("\\", "/").lower()
    if "/kite_recorded/" in text or "/kite_instruments/" in text:
        return "KITE"
    if "/truedata/" in text or "truedata" in path.name.lower():
        return "TRUEDATA"
    return "LOCAL"


def _data_type_for_path(path: Path) -> str:
    text = str(path).replace("\\", "/").lower()
    name = path.name.lower()
    if "/depth/" in text or "depth" in name:
        return "depth/order book"
    if "/features/" in text or "feature" in name or "orderflow" in name:
        return "order-flow features"
    if "/ticks/" in text or "tick" in name:
        return "ticks"
    if "/bars/" in text or "bar" in name or "candle" in name:
        return "OHLCV bars"
    return "csv/unknown"


def _symbol_for_file(path: Path) -> str:
    stem = path.stem
    for suffix in ("_1minute_bars", "_minute_candles", "_orderflow_lite", "_ticks", "_depth", "_bars"):
        if stem.endswith(suffix):
            stem = stem[: -len(suffix)]
    return stem or "UNKNOWN"


def _dates_from_path(path: Path) -> set[str]:
    dates = {part for part in path.parts if _looks_like_date(part)}
    return dates


def _looks_like_date(text: str) -> bool:
    parts = text.split("-")
    return len(parts) == 3 and all(part.isdigit() for part in parts) and len(parts[0]) == 4


def _csv_stats(path: Path) -> tuple[int, set[str], set[str]]:
    count = 0
    columns: set[str] = set()
    intervals: set[str] = set()
    try:
        with path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            columns = set(reader.fieldnames or [])
            for row in reader:
                count += 1
                interval = str(row.get("interval") or "").strip()
                if interval:
                    intervals.add(interval)
    except (OSError, UnicodeDecodeError, csv.Error):
        return 0, set(), set()
    return count, columns, intervals


def _default_timeframe(data_type: str) -> str:
    if data_type == "OHLCV bars":
        return "1minute/unknown"
    if data_type in {"ticks", "depth/order book", "order-flow features"}:
        return "tick/intraday"
    return "unknown"


def _usable_multi_year(group: dict[str, Any], dates: list[str]) -> str:
    if group["data_type"] != "OHLCV bars":
        return "false"
    if len(dates) >= 252:
        return "true"
    if len(dates) >= 10:
        return "partial_short_sample"
    return "false_short_sample"


def _usable_orderflow(group: dict[str, Any]) -> str:
    if group["data_type"] in {"ticks", "depth/order book", "order-flow features"}:
        return "partial_recent_only" if int(group["row_count"] or 0) > 0 else "false"
    return "false"


def _has_bars(groups: list[dict[str, Any]]) -> bool:
    return any(row["data_type"] == "OHLCV bars" and int(row["row_count"] or 0) > 0 for row in groups)


def _has_tick_or_depth(groups: list[dict[str, Any]]) -> bool:
    return any(row["data_type"] in {"ticks", "depth/order book", "order-flow features"} and int(row["row_count"] or 0) > 0 for row in groups)


def _coverage_status(groups: list[dict[str, Any]]) -> str:
    if not groups:
        return "NO_LOCAL_BACKTEST_DATA_FOUND"
    has_bars = _has_bars(groups)
    has_orderflow = _has_tick_or_depth(groups)
    if has_bars and has_orderflow:
        return "PARTIAL_RECENT_BAR_TICK_DEPTH_COVERAGE"
    if has_bars:
        return "PARTIAL_BAR_COVERAGE_ONLY"
    if has_orderflow:
        return "PARTIAL_TICK_DEPTH_COVERAGE_ONLY"
    return "DATA_PRESENT_BUT_NOT_CLASSIFIED"


def _multi_year_ready(groups: list[dict[str, Any]]) -> str:
    if any(row["usable_for_multi_year_backtest"] == "true" for row in groups):
        return "true"
    if any(str(row["usable_for_multi_year_backtest"]).startswith("partial") for row in groups):
        return "partial"
    return "false"


def _next_best_task(groups: list[dict[str, Any]], strategies: list[dict[str, Any]]) -> str:
    if _multi_year_ready(groups) != "true":
        return "Build/import longer OHLCV history and run staged bar-level audits before large optimization."
    if any(row["readiness_bucket"] == "PARTIAL_NEEDS_DATA_ADAPTER" for row in strategies):
        return "Add strategy-specific data adapters and run small walk-forward pilots."
    return "Run staged walk-forward/OOS robustness by month, then continue post-lock forward validation."


def _write_csv(path: Path, data_groups: list[dict[str, Any]], strategies: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in data_groups:
            writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})
        for row in strategies:
            writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})


def _format_report(
    timestamp: datetime,
    data_groups: list[dict[str, Any]],
    strategies: list[dict[str, Any]],
    status: str,
    multi_year_ready: str,
    next_task: str,
) -> str:
    buckets = _bucket_counts(strategies)
    lines = [
        "BACKTEST DATA COVERAGE + STRATEGY BACKTEST READINESS AUDIT",
        f"generated_at: {timestamp.isoformat()}",
        "Mode: INSPECT + REPORT ONLY",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "Production WhatsApp: BLOCKED",
        "execution_allowed=false",
        "",
        "EXECUTIVE VERDICT",
        f"backtest_data_coverage_status: {status}",
        f"multi_year_backtest_ready: {multi_year_ready}",
        "all_strategies_reliable: false",
        "real_money_approval_allowed: false",
        "paper_observation_allowed: true with restrictions",
        f"strategy_family_in_focus: {STRATEGY_FOCUS_FAMILY}",
        f"lock_version: {LOCK_VERSION}",
        f"next_best_task: {next_task}",
        "",
        "HISTORICAL DATA COVERAGE",
    ]
    if not data_groups:
        lines.append("No local historical/recorded CSV data folders were found.")
    for row in data_groups:
        lines.append(
            f"- {row['provider']} | {row['symbol']} | {row['data_type']} | dates={row['date_range']} | "
            f"files={row['file_count']} | rows={row['row_count']} | timeframes={row['timeframes']} | "
            f"multi_year={row['usable_for_multi_year_backtest']} | orderflow_depth={row['usable_for_orderflow_depth_backtest']}"
        )
    lines.extend(
        [
            "",
            "STRATEGY READINESS BUCKETS",
            f"READY_FOR_BAR_BACKTEST: {buckets.get('READY_FOR_BAR_BACKTEST', 0)}",
            f"PARTIAL_NEEDS_DATA_ADAPTER: {buckets.get('PARTIAL_NEEDS_DATA_ADAPTER', 0)}",
            f"NEEDS_TICK_OR_DEPTH_DATA: {buckets.get('NEEDS_TICK_OR_DEPTH_DATA', 0)}",
            f"FILTER_ONLY_NOT_STANDALONE: {buckets.get('FILTER_ONLY_NOT_STANDALONE', 0)}",
            f"DISABLED_OR_RESEARCH_ONLY: {buckets.get('DISABLED_OR_RESEARCH_ONLY', 0)}",
            f"UNKNOWN_NEEDS_INSPECTION: {buckets.get('UNKNOWN_NEEDS_INSPECTION', 0)}",
            "",
            "STRATEGY READINESS DETAIL",
        ]
    )
    if not strategies:
        lines.append("No strategy modules/config entries were found.")
    for row in strategies:
        lines.append(
            f"- {row['strategy_name']} | family={row['family']} | enabled={row['config_enabled']} | "
            f"required={row['required_data_type']} | bucket={row['readiness_bucket']} | "
            f"can_backtest_now={row['can_backtest_now']} | reason={row['reason']}"
        )
    lines.extend(
        [
            "",
            "REGIME COVERAGE READINESS",
            "regime_label_status: REGIME_LABELS_MISSING",
            "bull/trending up: unknown_without_regime_labels",
            "bear/trending down: unknown_without_regime_labels",
            "sideways/range: unknown_without_regime_labels",
            "high volatility: unknown_without_regime_labels",
            "low volatility: unknown_without_regime_labels",
            "trend day: unknown_without_regime_labels",
            "range day: unknown_without_regime_labels",
            "gap/news/event day: unknown_without_regime_labels",
            "low liquidity: unknown_without_regime_labels",
            "high liquidity: unknown_without_regime_labels",
            "recommendation: create a future regime-labeling report before trusting multi-year conclusions.",
            "",
            "SAFE STAGED MULTI-YEAR BACKTEST PLAN",
            "Stage A: bar-based strategies using clean OHLCV bars and conservative execution.",
            "Stage B: VWAP family bar-level historical replay with locked identity and no parameter changes from tiny forward samples.",
            "Stage C: Kite-recorded tick/depth forward replay for already-recorded sessions only.",
            "Stage D: order-flow/depth strategies only when enough tick/depth history exists.",
            "Stage E: walk-forward/OOS/month-by-month robustness; avoid single-day and single-regime dependency.",
            "",
            "APPROVAL REQUIREMENTS BEFORE RELIABLE PAPER LAUNCH",
            "- no lookahead bias",
            "- conservative next-bar/next-tick entry",
            "- stop-first or tick-sequential outcome",
            "- costs/slippage/spread",
            "- at least 100 backtest trades where applicable",
            "- at least 30 out-of-sample trades where applicable",
            "- at least 30 independent post-lock forward trades",
            "- no single-day dependency",
            "- no single-regime dependency",
            "- max drawdown/loss streak acceptable",
            "",
            "FINAL VERDICT",
            f"backtest_data_coverage_status: {status}",
            f"multi_year_backtest_ready: {multi_year_ready}",
            "all_strategies_reliable: false",
            "real_money_approval_allowed: false",
            "paper_observation_allowed: true with restrictions",
            f"next_best_task: {next_task}",
            "",
            "SAFETY CONFIRMATION",
            "No live data used.",
            "No broker orders.",
            "No production WhatsApp.",
            "No strategy logic changed.",
            "No backtest logic changed.",
            "Real-money trading remains 0% approved.",
            "execution_allowed=false.",
        ]
    )
    return "\n".join(lines)


def _bucket_counts(strategies: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in strategies:
        bucket = row["readiness_bucket"]
        counts[bucket] = counts.get(bucket, 0) + 1
    return counts


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate backtest data coverage readiness audit.")
    parser.parse_args(argv)
    result = generate_backtest_data_coverage_report()
    print("BACKTEST DATA COVERAGE + STRATEGY BACKTEST READINESS AUDIT")
    print(f"Report path: {result.report_path}")
    print(f"CSV path: {result.csv_path}")
    print(f"backtest_data_coverage_status: {result.data_coverage_status}")
    print(f"multi_year_backtest_ready: {result.multi_year_backtest_ready}")
    print(f"data_groups: {result.total_data_groups}")
    print(f"strategies: {result.total_strategy_rows}")
    print(f"ready_for_bar_backtest: {result.ready_for_bar_backtest}")
    print(f"needs_tick_or_depth: {result.needs_tick_or_depth}")
    print(f"filter_only: {result.filter_only}")
    print(f"next_best_task: {result.next_best_task}")
    print("real_money_approval_allowed: false")
    print("execution_allowed=false")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
