from __future__ import annotations

from src.indicators.opening_range import calculate_opening_range
from src.indicators.vwap import calculate_vwap


def classify_market_mode(candles: list[dict], settings: dict | None = None) -> str:
    settings = settings or {}
    if settings.get("event_day") or settings.get("high_impact_event"):
        return "HIGH_VOLATILITY_NEWS"
    if len(candles) < 4:
        return "UNCLEAR"
    opening = calculate_opening_range(candles)
    recent = candles[-5:]
    if any(c["high"] > opening["opening_range_high"] and c["close"] < opening["opening_range_high"] for c in recent):
        return "TRAP_REVERSAL"
    if any(c["low"] < opening["opening_range_low"] and c["close"] > opening["opening_range_low"] for c in recent):
        return "TRAP_REVERSAL"
    vwap_rows = calculate_vwap(candles)
    closes = [c["close"] for c in candles[-8:]]
    above = sum(1 for c, v in zip(candles[-8:], vwap_rows[-8:]) if c["close"] > v["vwap"])
    below = sum(1 for c, v in zip(candles[-8:], vwap_rows[-8:]) if c["close"] < v["vwap"])
    slope = vwap_rows[-1]["vwap"] - vwap_rows[max(0, len(vwap_rows) - 5)]["vwap"]
    price_change = closes[-1] - closes[0]
    range_points = max(c["high"] for c in candles[-8:]) - min(c["low"] for c in candles[-8:])
    if above >= 6 and slope > 0 and price_change > 0:
        return "TREND_UP"
    if below >= 6 and slope < 0 and price_change < 0:
        return "TREND_DOWN"
    if range_points <= max(8, abs(closes[-1]) * 0.08):
        return "RANGE"
    crosses = sum(1 for c, v in zip(candles[-8:], vwap_rows[-8:]) if abs(c["close"] - v["vwap"]) < max(5, abs(v["vwap"]) * 0.01))
    if crosses >= 3:
        return "RANGE"
    return "UNCLEAR"
