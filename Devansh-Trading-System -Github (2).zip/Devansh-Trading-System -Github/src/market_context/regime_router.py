from __future__ import annotations

from .market_mode import classify_market_mode


def route_regime(candles: list[dict], settings: dict | None = None) -> dict:
    mode = classify_market_mode(candles, settings)
    mapping = {
        "TREND_UP": ["trend_day_vwap_pullback", "breakout_acceptance", "cluster_imbalance_trap"],
        "TREND_DOWN": ["trend_day_vwap_pullback", "breakdown_acceptance", "cluster_imbalance_trap"],
        "RANGE": ["value_area_rejection", "poc_magnet", "failed_breakout", "failed_breakdown"],
        "TRAP_REVERSAL": ["failed_breakout", "failed_breakdown", "vwap_reclaim", "vwap_rejection", "cluster_imbalance_trap"],
        "HIGH_VOLATILITY_NEWS": [],
        "UNCLEAR": [],
    }
    return {"market_mode": mode, "preferred_strategies": mapping.get(mode, [])}
