from __future__ import annotations


def classify_continuation_or_trap(signal_side: str, market_mode: str, order_flow_event: str = "UNCLEAR") -> str:
    if "TRAP" in order_flow_event or market_mode == "TRAP_REVERSAL":
        return "trap_failure_confirmed"
    if market_mode in {"TREND_UP", "TREND_DOWN"}:
        return "trend_continuation"
    return "unclear"
