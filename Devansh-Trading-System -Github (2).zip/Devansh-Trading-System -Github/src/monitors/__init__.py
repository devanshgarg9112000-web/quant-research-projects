"""Long-running PAPER-only monitoring helpers."""
