from __future__ import annotations

import argparse
import csv
import io
import os
import sys
import time
from contextlib import redirect_stdout
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, TextIO

from src.alerts.whatsapp_alerts import WhatsAppAlertProvider
from src.config_loader import load_configs
from src.data_feeds.tick_storage import (
    TickCsvError,
    append_daily_ticks,
    default_tick_file,
    load_normalized_ticks,
    resolve_tick_file,
    save_normalized_ticks,
)
from src.data_feeds.truedata_feed import TrueDataFeed
from src.main import _build_paper_dashboard_rows, _evaluate_paper_ticks, _new_paper_report
from src.research.forward_validation import record_watchlist_signal_from_row
from src.replay.replay_engine import filter_replay_ticks, parse_replay_symbols
from src.scoring.strategy_verification import StrategyApprovalGate


DUPLICATE_WINDOW_SECONDS = 300
SIGNAL_LOG_COLUMNS = [
    "scan_time",
    "data_feed",
    "symbol",
    "status",
    "direction",
    "strategy",
    "entry",
    "stop",
    "target",
    "rr",
    "score",
    "qty",
    "risk_budget",
    "estimated_risk_amount",
    "key_reason",
    "rejection_reason",
    "cluster_status",
    "cluster_gate_status",
    "market_mode",
    "strategy_verification_status",
    "strategy_verification_reason",
    "alert_allowed",
    "candidate_strategy_check",
    "candidate_status",
    "forward_validation_ledger_updated",
    "approval_status",
    "execution_allowed",
]
ERROR_LOG_COLUMNS = ["timestamp", "error_type", "error_message", "scan_number", "data_feed"]


@dataclass
class MonitorRuntimeState:
    started_at: datetime
    last_scan_time: datetime | None = None
    total_scans: int = 0
    accepted_alerts: int = 0
    rejected_alerts: int = 0
    duplicate_skipped: int = 0
    scan_errors: int = 0
    shutdown_reason: str = "COMPLETED"


class LiveSignalMonitor:
    """Runs the existing PAPER strategy/risk path and persists compact scans."""

    def __init__(
        self,
        base_dir: Path | str,
        configs: dict,
        symbols: list[str],
        data_feed: str,
        scan_interval: int,
        window_seconds: int,
        alert_channel: str = "none",
        record_ticks: bool = False,
        now_fn: Callable[[], datetime] | None = None,
        whatsapp_provider: WhatsAppAlertProvider | None = None,
        strategy_gate: StrategyApprovalGate | None = None,
    ):
        self.base = Path(base_dir)
        self.settings = dict(configs["settings"])
        self.settings["mode"] = "PAPER"
        self.settings["enable_live_trading"] = False
        self.risk_config = configs["risk"]
        self.strategies = configs["strategies"]
        self.instruments = configs.get("instruments", {})
        self.symbols = symbols
        self.data_feed = data_feed.upper()
        self.scan_interval = max(1, int(scan_interval))
        self.window_seconds = max(1, int(window_seconds))
        self.alert_channel = alert_channel
        self.record_ticks = bool(record_ticks)
        self.now_fn = now_fn or (lambda: datetime.now().astimezone())
        self.recent_signals: dict[tuple, datetime] = {}
        self.report_dir = self.base / "reports" / "signals"
        self.signal_log_path = self.report_dir / "live_signal_log.csv"
        self.dashboard_path = self.report_dir / "latest_live_signal_dashboard.txt"
        self.heartbeat_path = self.report_dir / "latest_monitor_heartbeat.txt"
        self.error_log_path = self.report_dir / "monitor_error_log.csv"
        self.forward_validation_config = configs.get("forward_validation", {})
        self.last_scan_stats = {
            "accepted_alerts": 0,
            "rejected_alerts": 0,
            "duplicate_skipped": 0,
            "whatsapp_alerts": 0,
            "forward_validation_recorded": 0,
        }
        whatsapp_config = (configs.get("alerts") or {}).get("whatsapp", {})
        self.whatsapp_provider = whatsapp_provider or WhatsAppAlertProvider(
            self.base,
            config=whatsapp_config,
        )
        self.strategy_gate = strategy_gate or StrategyApprovalGate(
            self.base,
            config=configs.get("approved_strategies", {}),
        )

    def ensure_runtime_files(self) -> None:
        self.report_dir.mkdir(parents=True, exist_ok=True)
        if not self.error_log_path.exists() or self.error_log_path.stat().st_size == 0:
            with self.error_log_path.open("w", newline="", encoding="utf-8") as f:
                csv.DictWriter(f, fieldnames=ERROR_LOG_COLUMNS).writeheader()

    def scan_ticks(self, ticks: list[dict]) -> list[dict]:
        scan_time = self.now_fn()
        report = _new_paper_report(
            self.symbols,
            self.data_feed,
            "LIVE PAPER SIGNAL MONITOR",
            "PAPER MODE ONLY. No broker orders were placed.",
        )
        report["total_ticks"] = len(ticks)
        with redirect_stdout(io.StringIO()):
            _evaluate_paper_ticks(
                self.base,
                self.settings,
                self.risk_config,
                self.strategies,
                self.symbols,
                ticks,
                report,
                candle_label="monitor",
                instruments=self.instruments,
                journal_signals=False,
            )
        rows = _build_paper_dashboard_rows(report)
        _prepare_forward_validation_visibility(rows, self.data_feed)
        (
            duplicate_count,
            new_candidates,
            alert_candidates,
            blocked_count,
            forward_validation_recorded,
        ) = self._append_new_candidates(rows, scan_time)
        alert_count = self.whatsapp_provider.alert_rows(alert_candidates, self.alert_channel)
        self.last_scan_stats = {
            "accepted_alerts": sum(1 for row in new_candidates if row["status"] == "ACCEPTED_PAPER_SIGNAL"),
            "rejected_alerts": sum(1 for row in new_candidates if row["status"] == "RISK_REJECTED"),
            "duplicate_skipped": duplicate_count,
            "whatsapp_alerts": alert_count,
            "strategy_blocked": blocked_count,
            "forward_validation_recorded": forward_validation_recorded,
        }
        dashboard = format_monitor_dashboard(
            rows,
            scan_time,
            self.symbols,
            self.data_feed,
            duplicate_count,
            self.alert_channel,
            alert_count,
            blocked_count,
        )
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.dashboard_path.write_text(dashboard + "\n", encoding="utf-8")
        print(dashboard)
        return rows

    def write_heartbeat(self, state: MonitorRuntimeState) -> None:
        current_time = self.now_fn()
        text = format_monitor_heartbeat(current_time, self, state)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.heartbeat_path.write_text(text + "\n", encoding="utf-8")
        self.whatsapp_provider.preview_monitor_event("HEARTBEAT", text, self.alert_channel)

    def log_scan_error(self, exc: Exception, scan_number: int) -> None:
        timestamp = self.now_fn()
        error_type = type(exc).__name__
        error_message = _sanitize_error_message(str(exc))
        self.report_dir.mkdir(parents=True, exist_ok=True)
        write_header = not self.error_log_path.exists() or self.error_log_path.stat().st_size == 0
        with self.error_log_path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=ERROR_LOG_COLUMNS)
            if write_header:
                writer.writeheader()
            writer.writerow({
                "timestamp": timestamp.isoformat(),
                "error_type": error_type,
                "error_message": error_message,
                "scan_number": scan_number,
                "data_feed": self.data_feed,
            })
        alert_text = "\n".join([
            f"Current Time: {timestamp.isoformat()}",
            f"Error Type: {error_type}",
            f"Error Message: {error_message}",
            f"Scan Number: {scan_number}",
            f"Data Feed: {self.data_feed}",
        ])
        self.whatsapp_provider.preview_monitor_event("ERROR", alert_text, self.alert_channel)

    def _append_new_candidates(
        self,
        rows: list[dict],
        scan_time: datetime,
    ) -> tuple[int, list[dict], list[dict], int, int]:
        self._expire_duplicates(scan_time)
        new_log_rows: list[dict] = []
        new_candidates: list[dict] = []
        alert_candidates: list[dict] = []
        duplicate_count = 0
        blocked_count = 0
        forward_validation_recorded = 0
        for row in rows:
            if row["status"] not in {"ACCEPTED_PAPER_SIGNAL", "RISK_REJECTED"}:
                continue
            key = _signal_key(row)
            last_seen = self.recent_signals.get(key)
            if last_seen and scan_time - last_seen < timedelta(seconds=DUPLICATE_WINDOW_SECONDS):
                duplicate_count += 1
                continue
            self.recent_signals[key] = scan_time
            verification = self.strategy_gate.evaluate(row)
            row["strategy_verification_status"] = verification.status
            row["strategy_verification_reason"] = verification.reason
            row["alert_allowed"] = verification.allowed
            forward_candidate = _is_vwap_rejection_forward_candidate(row)
            approval_status = _forward_approval_status(verification.status)
            if forward_candidate:
                row.setdefault("provider", _provider_from_data_feed(self.data_feed))
                row.setdefault("candidate_strategy_check", "GOLD-I VWAP Rejection Short")
                row.setdefault("forward_validation_ledger_updated", "NO")
                row["approval_status"] = approval_status
                row["approval_status_at_signal"] = approval_status
                row["candidate_status"] = "BLOCKED_BY_APPROVAL"
                row["alert_mode"] = (
                    "research_only"
                    if bool(self.forward_validation_config.get("send_research_whatsapp_preview", False))
                    else "blocked"
                )
            if verification.allowed and not forward_candidate:
                alert_candidates.append(row)
            else:
                blocked_count += 1
                if forward_candidate:
                    recorded = record_watchlist_signal_from_row(
                        self.base,
                        row,
                        scan_time=scan_time,
                        alert_mode=row.get("alert_mode", "blocked"),
                        config=self.forward_validation_config,
                    )
                    row["forward_validation_ledger_updated"] = "YES" if recorded else "NO"
                    row["candidate_status"] = "SETUP_RECORDED" if recorded else "BLOCKED_BY_APPROVAL"
                    forward_validation_recorded += int(recorded)
                    if (
                        recorded
                        and bool(self.forward_validation_config.get("send_research_whatsapp_preview", False))
                    ):
                        self.whatsapp_provider.preview_research_watchlist(row)
            new_candidates.append(row)
            new_log_rows.append(_signal_log_row(row, scan_time, self.data_feed))
        _append_signal_log(self.signal_log_path, new_log_rows)
        return duplicate_count, new_candidates, alert_candidates, blocked_count, forward_validation_recorded

    def _expire_duplicates(self, scan_time: datetime) -> None:
        cutoff = scan_time - timedelta(seconds=DUPLICATE_WINDOW_SECONDS)
        self.recent_signals = {
            key: seen_at
            for key, seen_at in self.recent_signals.items()
            if seen_at > cutoff
        }


def run_monitor(
    base_dir: Path | str = ".",
    data_feed: str = "replay",
    tick_file: str | None = None,
    symbols_text: str | None = None,
    scan_interval: int = 60,
    window_seconds: int = 300,
    max_scans: int | None = None,
    alert_channel: str = "none",
    max_runtime_seconds: int | None = None,
    heartbeat_interval_seconds: int = 300,
    log_file: str | None = None,
    record_ticks: bool = False,
    configs: dict | None = None,
    monotonic_fn: Callable[[], float] | None = None,
    sleep_fn: Callable[[float], None] | None = None,
) -> int:
    if log_file:
        log_path = Path(log_file)
        if not log_path.is_absolute():
            log_path = Path(base_dir) / log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as output:
            with redirect_stdout(_TeeWriter(sys.stdout, output)):
                return run_monitor(
                    base_dir=base_dir,
                    data_feed=data_feed,
                    tick_file=tick_file,
                    symbols_text=symbols_text,
                    scan_interval=scan_interval,
                    window_seconds=window_seconds,
                    max_scans=max_scans,
                    alert_channel=alert_channel,
                    max_runtime_seconds=max_runtime_seconds,
                    heartbeat_interval_seconds=heartbeat_interval_seconds,
                    log_file=None,
                    record_ticks=record_ticks,
                    configs=configs,
                    monotonic_fn=monotonic_fn,
                    sleep_fn=sleep_fn,
                )
    base = Path(base_dir)
    configs = configs or load_configs(base)
    symbols = parse_replay_symbols(symbols_text)
    if not symbols:
        print("PAPER monitor skipped: no symbols supplied.")
        return 1

    print("LAUNCH 1 ALL-DAY PAPER SIGNAL MONITOR")
    print("Launch: 1")
    print("Mode: PAPER")
    print(f"Data Feed: {data_feed.upper()}")
    print(f"Symbols: {', '.join(symbols)}")
    print(f"Scan Interval Seconds: {max(1, scan_interval)}")
    print(f"Window Seconds: {max(1, window_seconds)}")
    print(f"Max Runtime Seconds: {max_runtime_seconds if max_runtime_seconds is not None else 'CONTINUOUS'}")
    print(f"Heartbeat Interval Seconds: {max(0, heartbeat_interval_seconds)}")
    print(f"Alert Channel: {alert_channel}")
    print(f"Record Ticks: {'ENABLED' if record_ticks else 'DISABLED'}")
    print("Live Trading: DISABLED")
    print("Broker Orders: DISABLED")
    print("execution_allowed=false")
    print("PAPER MODE ONLY")
    print("Manual Execution Only")

    monitor = LiveSignalMonitor(
        base,
        configs,
        symbols,
        data_feed,
        scan_interval,
        window_seconds,
        alert_channel=alert_channel,
        record_ticks=record_ticks,
    )
    monitor.ensure_runtime_files()
    if data_feed == "replay":
        return _run_replay_monitor(
            monitor,
            base,
            tick_file,
            max_runtime_seconds=max_runtime_seconds,
            heartbeat_interval_seconds=heartbeat_interval_seconds,
            monotonic_fn=monotonic_fn,
            sleep_fn=sleep_fn,
        )
    if data_feed == "truedata":
        return _run_truedata_monitor(
            monitor,
            max_scans,
            max_runtime_seconds=max_runtime_seconds,
            heartbeat_interval_seconds=heartbeat_interval_seconds,
            monotonic_fn=monotonic_fn,
            sleep_fn=sleep_fn,
        )
    print(f"Unsupported data feed: {data_feed}")
    return 1


def _run_replay_monitor(
    monitor: LiveSignalMonitor,
    base: Path,
    tick_file: str | None,
    max_runtime_seconds: int | None = None,
    heartbeat_interval_seconds: int = 300,
    monotonic_fn: Callable[[], float] | None = None,
    sleep_fn: Callable[[float], None] | None = None,
) -> int:
    path = resolve_tick_file(base, tick_file)
    try:
        source_ticks = load_normalized_ticks(path)
    except FileNotFoundError:
        print(f"Replay monitor tick file missing: {path}")
        return 1
    except TickCsvError as exc:
        print(f"Replay monitor tick CSV invalid: {exc}")
        return 1
    ticks = filter_replay_ticks(source_ticks, monitor.symbols)
    print(f"Tick File: {path}")
    print(f"Replay Monitor Ticks: {len(ticks)} matching ticks from {len(source_ticks)} file ticks.")
    if not ticks:
        print("Replay monitor found no matching ticks.")
    if max_runtime_seconds is None:
        state = _run_scan_loop(
            monitor,
            lambda remaining: ticks,
            max_runtime_seconds=None,
            heartbeat_interval_seconds=heartbeat_interval_seconds,
            max_scans=1,
            monotonic_fn=monotonic_fn,
            sleep_fn=sleep_fn,
        )
        state.shutdown_reason = "REPLAY_SINGLE_SCAN_COMPLETE"
    else:
        state = _run_scan_loop(
            monitor,
            lambda remaining: ticks,
            max_runtime_seconds=max_runtime_seconds,
            heartbeat_interval_seconds=heartbeat_interval_seconds,
            monotonic_fn=monotonic_fn,
            sleep_fn=sleep_fn,
        )
    _print_final_summary(monitor, state)
    return 0


def _run_truedata_monitor(
    monitor: LiveSignalMonitor,
    max_scans: int | None,
    max_runtime_seconds: int | None = None,
    heartbeat_interval_seconds: int = 300,
    monotonic_fn: Callable[[], float] | None = None,
    sleep_fn: Callable[[float], None] | None = None,
) -> int:
    settings = dict(monitor.settings)
    settings["enable_true_data"] = True
    rolling_ticks: list[dict] = []
    def supply_ticks(remaining_seconds: float | None) -> list[dict]:
        feed = TrueDataFeed(settings, monitor.base, allow_network=True)
        collection_seconds = monitor.scan_interval
        if remaining_seconds is not None:
            collection_seconds = max(1, min(collection_seconds, int(remaining_seconds)))
        fresh_ticks = feed.collect_live_ticks(monitor.symbols, collection_seconds, echo=False)
        rolling_ticks.extend(fresh_ticks)
        clean = _trim_rolling_window(rolling_ticks, monitor.window_seconds)
        rolling_ticks[:] = clean
        if monitor.record_ticks:
            save_normalized_ticks(clean, default_tick_file(monitor.base))
            daily_result = append_daily_ticks(fresh_ticks, monitor.base, source="TRUEDATA_MONITOR")
            print(
                "Tick Recorder: "
                f"{daily_result['rows_written']} new daily rows across {daily_result['files_touched']} files"
            )
        return clean

    state = _run_scan_loop(
        monitor,
        supply_ticks,
        max_runtime_seconds=max_runtime_seconds,
        heartbeat_interval_seconds=heartbeat_interval_seconds,
        max_scans=max_scans,
        monotonic_fn=monotonic_fn,
        sleep_fn=sleep_fn,
    )
    _print_final_summary(monitor, state)
    return 0


def _run_scan_loop(
    monitor: LiveSignalMonitor,
    tick_supplier: Callable[[float | None], list[dict]],
    max_runtime_seconds: int | None,
    heartbeat_interval_seconds: int,
    max_scans: int | None = None,
    monotonic_fn: Callable[[], float] | None = None,
    sleep_fn: Callable[[float], None] | None = None,
) -> MonitorRuntimeState:
    monotonic = monotonic_fn or time.monotonic
    sleeper = sleep_fn or time.sleep
    started_monotonic = monotonic()
    state = MonitorRuntimeState(started_at=monitor.now_fn())
    next_scan_due = started_monotonic
    heartbeat_enabled = heartbeat_interval_seconds > 0
    next_heartbeat_due = started_monotonic
    try:
        while True:
            now = monotonic()
            elapsed = now - started_monotonic
            if max_runtime_seconds is not None and elapsed >= max(0, max_runtime_seconds):
                state.shutdown_reason = "MAX_RUNTIME_REACHED"
                break
            if max_scans is not None and state.total_scans >= max_scans:
                state.shutdown_reason = "MAX_SCANS_REACHED"
                break
            if now < next_scan_due:
                wake_at = next_scan_due
                if heartbeat_enabled:
                    wake_at = min(wake_at, next_heartbeat_due)
                if max_runtime_seconds is not None:
                    wake_at = min(wake_at, started_monotonic + max_runtime_seconds)
                sleeper(max(0.0, wake_at - now))
                continue

            scan_number = state.total_scans + 1
            state.total_scans = scan_number
            try:
                remaining_seconds = None
                if max_runtime_seconds is not None:
                    remaining_seconds = max(0.0, max_runtime_seconds - (monotonic() - started_monotonic))
                rows = monitor.scan_ticks(tick_supplier(remaining_seconds))
                state.last_scan_time = monitor.now_fn()
                stats = monitor.last_scan_stats
                state.accepted_alerts += int(stats.get("accepted_alerts", 0))
                state.rejected_alerts += int(stats.get("rejected_alerts", 0))
                state.duplicate_skipped += int(stats.get("duplicate_skipped", 0))
                if not rows:
                    print(f"Scan {scan_number}: no symbol rows produced.")
            except KeyboardInterrupt:
                state.shutdown_reason = "CTRL_C"
                break
            except Exception as exc:
                state.scan_errors += 1
                monitor.log_scan_error(exc, scan_number)
                print(f"Scan {scan_number} failed safely: {type(exc).__name__}. Continuing.")

            next_scan_due = max(next_scan_due + monitor.scan_interval, monotonic())
            now = monotonic()
            if heartbeat_enabled and now >= next_heartbeat_due:
                monitor.write_heartbeat(state)
                while next_heartbeat_due <= now:
                    next_heartbeat_due += heartbeat_interval_seconds
    except KeyboardInterrupt:
        state.shutdown_reason = "CTRL_C"
    if heartbeat_enabled:
        monitor.write_heartbeat(state)
    return state


def _trim_rolling_window(ticks: list[dict], window_seconds: int) -> list[dict]:
    if not ticks:
        return []
    clean = sorted(ticks, key=lambda tick: tick["timestamp"])
    cutoff = clean[-1]["timestamp"] - timedelta(seconds=window_seconds)
    return [tick for tick in clean if tick["timestamp"] >= cutoff]


def format_monitor_dashboard(
    rows: list[dict],
    scan_time: datetime,
    symbols: list[str],
    data_feed: str,
    duplicate_count: int = 0,
    alert_channel: str = "none",
    alert_count: int = 0,
    strategy_blocked_count: int = 0,
) -> str:
    accepted = [row["symbol"] for row in rows if row["status"] == "ACCEPTED_PAPER_SIGNAL"]
    rejected = [row["symbol"] for row in rows if row["status"] == "RISK_REJECTED"]
    no_signal = [row["symbol"] for row in rows if row["status"] == "NO_SIGNAL"]
    lines = [
        "LAUNCH 1 LIVE PAPER SIGNAL DASHBOARD",
        "Launch: 1",
        f"Current Time: {scan_time.isoformat()}",
        f"Symbols Scanned: {', '.join(symbols)}",
        f"Data Feed: {data_feed}",
        f"Alert Channel: {alert_channel}",
        f"New WhatsApp Alerts: {alert_count}",
        f"Strategy Verification Blocks: {strategy_blocked_count}",
        f"Accepted PAPER Signals: {', '.join(accepted) if accepted else 'NONE'}",
        f"Risk Rejected Signals: {', '.join(rejected) if rejected else 'NONE'}",
        f"No-Signal Symbols: {', '.join(no_signal) if no_signal else 'NONE'}",
        f"Duplicate Signals Skipped: {duplicate_count}",
    ]
    for row in rows:
        lines.extend([
            "",
            f"Symbol: {row['symbol']}",
            f"Status: {row['status']}",
            f"Market Mode: {row['market_mode']}",
            f"Cluster Diagnostic: {row['cluster_status']}",
            f"Cluster Gate Status: {row['cluster_gate_status']}",
            f"Direction: {_display(row.get('direction'))}",
            f"Strategy: {_display(row.get('strategy'))}",
            f"Qty: {_display(row.get('qty'))}",
            f"Key Reason: {_display(row.get('key_reason'))}",
            f"Rejection Reason: {_display(row.get('rejection_reason'))}",
            f"Strategy Verification: {_display(row.get('strategy_verification_status'))}",
            f"Strategy Alert Gate: {_display(row.get('strategy_verification_reason'))}",
            f"Candidate Strategy Check: {_display(row.get('candidate_strategy_check'))}",
            f"Candidate Status: {_display(row.get('candidate_status'))}",
            f"Forward Validation Ledger Updated: {_display(row.get('forward_validation_ledger_updated'))}",
            f"Approval Status: {_display(row.get('approval_status'))}",
            "execution_allowed=false",
            "broker_orders=disabled",
            "Manual Execution Only",
        ])
    lines.extend([
        "",
        "execution_allowed=false",
        "broker_orders=disabled",
        "PAPER MODE ONLY",
        "Manual Execution Only",
    ])
    return "\n".join(lines)


def format_monitor_heartbeat(
    current_time: datetime,
    monitor: LiveSignalMonitor,
    state: MonitorRuntimeState,
) -> str:
    return "\n".join([
        "LAUNCH 1 MONITOR HEARTBEAT",
        f"Current Time: {current_time.isoformat()}",
        f"Data Feed: {monitor.data_feed}",
        f"Symbols: {', '.join(monitor.symbols)}",
        f"Last Scan Time: {state.last_scan_time.isoformat() if state.last_scan_time else 'N/A'}",
        f"Total Scans: {state.total_scans}",
        f"Accepted Alerts Count: {state.accepted_alerts}",
        f"Rejected Alerts Count: {state.rejected_alerts}",
        f"Duplicate Skipped Count: {state.duplicate_skipped}",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "PAPER MODE ONLY",
        "Manual Execution Only",
        "execution_allowed=false",
    ])


def _print_final_summary(monitor: LiveSignalMonitor, state: MonitorRuntimeState) -> None:
    print("FINAL MONITOR SUMMARY")
    print(f"Shutdown Reason: {state.shutdown_reason}")
    print(f"Total Scans: {state.total_scans}")
    print(f"Accepted Alerts: {state.accepted_alerts}")
    print(f"Rejected Alerts: {state.rejected_alerts}")
    print(f"Duplicate Signals Skipped: {state.duplicate_skipped}")
    print(f"Scan Errors: {state.scan_errors}")
    print(f"Heartbeat File: {monitor.heartbeat_path}")
    print(f"Error Log: {monitor.error_log_path}")
    print(f"Tick Recording: {'ENABLED' if monitor.record_ticks else 'DISABLED'}")
    print("Live Trading: DISABLED")
    print("Broker Orders: DISABLED")
    print("execution_allowed=false")
    print("PAPER MODE ONLY")
    print("Manual Execution Only")



def _prepare_forward_validation_visibility(rows: list[dict], data_feed: str) -> None:
    provider = _provider_from_data_feed(data_feed)
    for row in rows:
        row["provider"] = provider
        if row.get("symbol") == "GOLD-I":
            row["candidate_strategy_check"] = "GOLD-I VWAP Rejection Short"
            row["approval_status"] = "RESEARCH_ONLY"
            if _is_vwap_rejection_forward_candidate(row):
                row["candidate_status"] = "BLOCKED_BY_APPROVAL"
            else:
                row["candidate_status"] = "NO_SETUP"
        else:
            row["candidate_strategy_check"] = "NOT_APPLICABLE"
            row["candidate_status"] = "NO_SETUP"
            row["approval_status"] = "N/A"
        row["forward_validation_ledger_updated"] = "NO"


def _is_vwap_rejection_forward_candidate(row: dict) -> bool:
    if row.get("symbol") != "GOLD-I":
        return False
    if row.get("status") != "ACCEPTED_PAPER_SIGNAL":
        return False
    strategy = str(row.get("strategy") or "").strip().lower().replace("-", "_").replace(" ", "_")
    return strategy in {"vwap_rejection_short", "gold_i_vwap_rejection_short", "gold_vwap_rejection_short"}


def _forward_approval_status(status: str) -> str:
    value = str(status or "").strip().upper()
    if value in {"WATCHLIST", "APPROVED", "REJECTED"}:
        return value
    return "RESEARCH_ONLY"


def _provider_from_data_feed(data_feed: str) -> str:
    value = str(data_feed or "").strip().upper()
    if value == "KITE":
        return "KITE"
    if value in {"TRUEDATA", "REPLAY"}:
        return "TRUEDATA"
    return value or "UNKNOWN"

def _signal_key(row: dict) -> tuple:
    return (
        row.get("symbol"),
        row.get("status"),
        row.get("direction"),
        row.get("strategy"),
        row.get("entry"),
        row.get("stop"),
        row.get("target"),
    )


def _signal_log_row(row: dict, scan_time: datetime, data_feed: str) -> dict:
    output = {
        "scan_time": scan_time.isoformat(),
        "data_feed": data_feed,
        **{column: row.get(column) for column in SIGNAL_LOG_COLUMNS if column not in {"scan_time", "data_feed"}},
    }
    output["execution_allowed"] = "false"
    return output


def _append_signal_log(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=SIGNAL_LOG_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerows(rows)


def _sanitize_error_message(message: str) -> str:
    safe = str(message or "No error message.").replace("\r", " ").replace("\n", " ")
    for key, value in os.environ.items():
        upper = key.upper()
        if any(marker in upper for marker in ("TOKEN", "PASSWORD", "SECRET", "API_KEY")) and value:
            safe = safe.replace(value, "[REDACTED]")
    return safe[:500]


class _TeeWriter:
    def __init__(self, primary: TextIO, secondary: TextIO):
        self.primary = primary
        self.secondary = secondary

    def write(self, text: str) -> int:
        self.primary.write(text)
        self.secondary.write(text)
        self.secondary.flush()
        return len(text)

    def flush(self) -> None:
        self.primary.flush()
        self.secondary.flush()


def _display(value) -> str:
    return "N/A" if value is None or value == "" else str(value)


def main() -> int:
    parser = argparse.ArgumentParser(description="Launch 1 all-day PAPER monitor. Manual execution only; never places broker orders.")
    parser.add_argument("--data-feed", choices=["replay", "truedata"], required=True)
    parser.add_argument("--tick-file", default=None, help="Normalized replay tick CSV.")
    parser.add_argument("--symbols", required=True, help="Comma-separated symbols.")
    parser.add_argument("--scan-interval", type=int, default=60)
    parser.add_argument("--window-seconds", type=int, default=300)
    parser.add_argument(
        "--alert-channel",
        choices=["none", "whatsapp-dry-run", "whatsapp-live"],
        default="none",
    )
    parser.add_argument("--max-scans", type=int, default=None, help="Optional controlled TrueData scan limit.")
    parser.add_argument("--max-runtime-seconds", type=int, default=None)
    parser.add_argument("--heartbeat-interval-seconds", type=int, default=300)
    parser.add_argument("--log-file", default=None, help="Optional console output log file.")
    parser.add_argument("--record-ticks", action="store_true", help="Record TrueData monitor ticks to latest and daily tick files.")
    args = parser.parse_args()
    return run_monitor(
        data_feed=args.data_feed,
        tick_file=args.tick_file,
        symbols_text=args.symbols,
        scan_interval=args.scan_interval,
        window_seconds=args.window_seconds,
        max_scans=args.max_scans,
        alert_channel=args.alert_channel,
        max_runtime_seconds=args.max_runtime_seconds,
        heartbeat_interval_seconds=args.heartbeat_interval_seconds,
        log_file=args.log_file,
        record_ticks=args.record_ticks,
    )


def _safe_cli_entrypoint() -> int:
    try:
        return main()
    except KeyboardInterrupt:
        print("Monitor stopped safely by Ctrl+C. No broker orders were placed.")
        return 0
    except Exception as exc:
        print(
            "Monitor stopped safely due to startup error: "
            f"{type(exc).__name__}: {_sanitize_error_message(str(exc))}"
        )
        print("Broker Orders: DISABLED")
        print("execution_allowed=false")
        print("PAPER MODE ONLY")
        print("Manual Execution Only")
        return 1


if __name__ == "__main__":
    raise SystemExit(_safe_cli_entrypoint())
