from __future__ import annotations


class KiteFeed:
    def connect(self) -> bool:
        print("Kite data feed disabled by default.")
        return False
