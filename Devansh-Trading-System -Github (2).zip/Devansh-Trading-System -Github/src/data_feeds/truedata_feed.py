from __future__ import annotations

import argparse
import csv
import json
import os
import time
from dataclasses import dataclass
from datetime import datetime
from io import StringIO
from pathlib import Path
from typing import Any, Callable
from urllib import parse, request

from src.config_loader import load_configs, load_dotenv_file


AUTH_URL = "https://auth.truedata.in/token"
HISTORY_BASE_URL = "https://history.truedata.in"
WEBSOCKET_HOST = "push.truedata.in"


TickCallback = Callable[[dict[str, Any]], None]


@dataclass(slots=True)
class TrueDataCredentials:
    username: str | None
    password: str | None
    realtime_port: str | None

    @property
    def missing(self) -> list[str]:
        missing = []
        if not self.username:
            missing.append("TRUEDATA_USERNAME")
        if not self.password:
            missing.append("TRUEDATA_PASSWORD")
        return missing


def _to_float(value: Any) -> float | None:
    if value in {None, ""}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_number(value: Any) -> int | float | None:
    number = _to_float(value)
    if number is None:
        return None
    return int(number) if number.is_integer() else number


def _parse_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    text = str(value or "").strip()
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%m/%d/%Y %I:%M:%S %p"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    return datetime.fromisoformat(text)


def _format_truedata_datetime(value: datetime | str) -> str:
    if isinstance(value, datetime):
        return value.strftime("%y%m%dT%H:%M:%S")
    return str(value)


def _normalize_truedata_bar_interval(interval: str) -> str:
    value = str(interval or "").strip().lower()
    aliases = {
        "minute": "1min",
        "1minute": "1min",
        "1-minute": "1min",
    }
    if value in aliases:
        return aliases[value]
    if value.endswith("minutes") and value[:-7].isdigit():
        return f"{value[:-7]}min"
    if value.endswith("minute") and value[:-6].isdigit():
        return f"{value[:-6]}min"
    return value


def normalize_live_tick(raw_tick: dict[str, Any] | list[Any], symbol_map: dict[str, str] | None = None) -> dict[str, Any]:
    """Normalize documented TrueData trade/touchline payloads.

    WebSocket trade fields from the docs:
    symbol_id, timestamp, ltp, ltq, atp, ttq, open, high, low, prev_close,
    oi, prev_oi, turnover, special_tag, tick_sequence_no, bid, bid_qty, ask, ask_qty.

    Touchline/symbol-added rows include the symbol at index 0 and symbol_id at index 1.
    """

    symbol_map = symbol_map or {}
    original = raw_tick
    if isinstance(raw_tick, dict):
        if "trade" in raw_tick:
            row = raw_tick["trade"]
            symbol_id = str(row[0])
            symbol = symbol_map.get(symbol_id, symbol_id)
            offset = 0
        elif "symbol_row" in raw_tick:
            row = raw_tick["symbol_row"]
            symbol = str(row[0])
            symbol_id = str(row[1])
            offset = 1
        else:
            row = raw_tick
            symbol = str(row.get("symbol") or row.get("symbol_id") or "")
            symbol_id = str(row.get("symbol_id") or symbol)
            return {
                "symbol": symbol,
                "timestamp": _parse_datetime(row.get("timestamp")),
                "ltp": float(row.get("ltp")),
                "ltq": _to_number(row.get("ltq") or row.get("volume")) or 0,
                "volume": _to_number(row.get("volume") or row.get("ltq")) or 0,
                "oi": _to_number(row.get("oi")),
                "bid": _to_float(row.get("bid")),
                "ask": _to_float(row.get("ask")),
                "bid_qty": _to_number(row.get("bid_qty") or row.get("bidqty")),
                "ask_qty": _to_number(row.get("ask_qty") or row.get("askqty")),
                "raw": original,
            }
    else:
        row = raw_tick
        symbol_id = str(row[0])
        symbol = symbol_map.get(symbol_id, symbol_id)
        offset = 0

    timestamp_index = 1 + offset
    ltp_index = 2 + offset
    ltq_index = 3 + offset
    volume_index = 5 + offset
    oi_index = 10 + offset
    bid_index = 15 + offset
    bid_qty_index = 16 + offset
    ask_index = 17 + offset
    ask_qty_index = 18 + offset

    return {
        "symbol": symbol,
        "timestamp": _parse_datetime(row[timestamp_index]),
        "ltp": float(row[ltp_index]),
        "ltq": _to_number(row[ltq_index]) or 0,
        "volume": _to_number(row[volume_index]) or 0,
        "oi": _to_number(row[oi_index]) if len(row) > oi_index else None,
        "bid": _to_float(row[bid_index]) if len(row) > bid_index else None,
        "ask": _to_float(row[ask_index]) if len(row) > ask_index else None,
        "bid_qty": _to_number(row[bid_qty_index]) if len(row) > bid_qty_index else None,
        "ask_qty": _to_number(row[ask_qty_index]) if len(row) > ask_qty_index else None,
        "raw": original,
    }


def normalize_bidask_update(raw: dict[str, Any] | list[Any], symbol_map: dict[str, str] | None = None) -> dict[str, Any]:
    row = raw.get("bidask", raw) if isinstance(raw, dict) else raw
    symbol_map = symbol_map or {}
    symbol_id = str(row[0])
    return {
        "symbol": symbol_map.get(symbol_id, symbol_id),
        "symbol_id": symbol_id,
        "timestamp": _parse_datetime(row[1]),
        "bid": _to_float(row[2]),
        "bid_qty": _to_number(row[3]),
        "ask": _to_float(row[4]),
        "ask_qty": _to_number(row[5]),
        "raw": raw,
    }


def normalize_historical_tick_response(response_text: str, symbol: str) -> list[dict[str, Any]]:
    text = response_text.strip()
    if not text or text.lower().startswith("no data"):
        return []
    if text.startswith("{") or text.startswith("["):
        payload = json.loads(text)
        rows = payload.get("Records", payload.get("data", payload)) if isinstance(payload, dict) else payload
        return [normalize_live_tick({**row, "symbol": symbol}) for row in rows]
    output: list[dict[str, Any]] = []
    for row in csv.DictReader(StringIO(text)):
        volume = _to_number(row.get("volume") or row.get("tickvol")) or 0
        output.append({
            "symbol": symbol,
            "timestamp": _parse_datetime(row.get("timestamp") or row.get("time")),
            "ltp": float(row["ltp"]),
            "ltq": volume,
            "volume": volume,
            "oi": _to_number(row.get("oi") or row.get("openinterest")),
            "bid": _to_float(row.get("bid")),
            "ask": _to_float(row.get("ask")),
            "bid_qty": _to_number(row.get("bidqty") or row.get("bid_qty")),
            "ask_qty": _to_number(row.get("askqty") or row.get("ask_qty")),
            "raw": dict(row),
        })
    return output


def normalize_historical_bar_response(response_text: str, symbol: str) -> list[dict[str, Any]]:
    text = response_text.strip()
    if not text or text.lower().startswith("no data"):
        return []
    output: list[dict[str, Any]] = []
    for row in csv.DictReader(StringIO(text)):
        output.append({
            "symbol": symbol,
            "timestamp": _parse_datetime(row.get("timestamp") or row.get("time")),
            "open": float(row["open"]),
            "high": float(row["high"]),
            "low": float(row["low"]),
            "close": float(row["close"]),
            "volume": _to_number(row.get("volume")) or 0,
            "oi": _to_number(row.get("oi") or row.get("openinterest")),
            "raw": dict(row),
        })
    return output


class TrueDataFeed:
    """TrueData market-data integration using only the uploaded docs.

    Defaults are deliberately safe: sample-data PAPER mode remains the runtime
    default, and TrueData does not connect unless explicitly enabled and the
    documented credentials/port are present.
    """

    def __init__(self, settings: dict | None = None, base_dir: Path | str = ".", allow_network: bool = False):
        self.base_dir = Path(base_dir)
        load_dotenv_file(self.base_dir)
        self.settings = settings or {}
        self.enabled = bool(self.settings.get("enable_true_data", False))
        self.allow_network = allow_network
        self.credentials = TrueDataCredentials(
            username=os.getenv("TRUEDATA_USERNAME"),
            password=os.getenv("TRUEDATA_PASSWORD"),
            realtime_port=os.getenv("TRUEDATA_REALTIME_PORT"),
        )
        self.connected = False
        self.websocket = None
        self.callbacks: list[TickCallback] = []
        self.latest_ticks: list[dict[str, Any]] = []
        self.symbol_id_to_symbol: dict[str, str] = {}
        self.depth_by_symbol: dict[str, dict[str, Any]] = {}
        self._access_token: str | None = None

    def realtime_url(self) -> str | None:
        if not self.credentials.realtime_port:
            return None
        quoted_user = parse.quote(self.credentials.username or "")
        quoted_password = parse.quote(self.credentials.password or "")
        return f"wss://{WEBSOCKET_HOST}:{self.credentials.realtime_port}?user={quoted_user}&password={quoted_password}"

    def connect(self) -> bool:
        if not self.enabled:
            print("TrueData feed skipped: enable_true_data is false.")
            return False
        if self.credentials.missing:
            print("TrueData feed skipped: credentials missing.")
            return False
        if not self.credentials.realtime_port:
            print("TrueData feed skipped: TRUEDATA_REALTIME_PORT missing.")
            return False
        if not self.allow_network:
            print("TrueData feed skipped: real network access is disabled outside manual test commands.")
            return False
        try:
            import websocket
        except Exception:
            print("TrueData feed skipped: websocket-client package missing.")
            return False

        url = self.realtime_url()
        try:
            self.websocket = websocket.create_connection(url, timeout=15)
        except Exception as exc:
            print(f"TrueData WebSocket connection failed safely: {exc}")
            return False
        self.connected = True
        print("TrueData WebSocket connected. Credentials are not printed.")
        return True

    def disconnect(self) -> None:
        if self.websocket:
            try:
                self.websocket.send(json.dumps({"method": "logout"}))
                self.websocket.close()
            except Exception:
                pass
        self.connected = False

    def subscribe(self, symbols: list[str]) -> bool:
        if not self.connected or not self.websocket:
            print("TrueData subscribe skipped: feed not connected.")
            return False
        self.websocket.send(json.dumps({"method": "addsymbol", "symbols": symbols}))
        return True

    def unsubscribe(self, symbols: list[str]) -> bool:
        if not self.connected or not self.websocket:
            print("TrueData unsubscribe skipped: feed not connected.")
            return False
        self.websocket.send(json.dumps({"method": "removesymbol", "symbols": symbols}))
        return True

    def on_tick(self, callback: TickCallback) -> None:
        self.callbacks.append(callback)

    def handle_message(self, message: str | dict[str, Any]) -> list[dict[str, Any]]:
        payload = json.loads(message) if isinstance(message, str) else message
        normalized: list[dict[str, Any]] = []
        if "symbollist" in payload:
            for row in payload.get("symbollist", []):
                symbol = str(row[0])
                symbol_id = str(row[1])
                self.symbol_id_to_symbol[symbol_id] = symbol
                tick = normalize_live_tick({"symbol_row": row}, self.symbol_id_to_symbol)
                normalized.append(tick)
        if "trade" in payload:
            normalized.append(normalize_live_tick(payload, self.symbol_id_to_symbol))
        if "bidask" in payload:
            depth = normalize_bidask_update(payload, self.symbol_id_to_symbol)
            self.depth_by_symbol[depth["symbol"]] = depth
        if "bidaskL2" in payload:
            symbol_id = str(payload["bidaskL2"][0])
            symbol = self.symbol_id_to_symbol.get(symbol_id, symbol_id)
            self.depth_by_symbol[symbol] = {"symbol": symbol, "symbol_id": symbol_id, "levels": payload["bidaskL2"][2:], "raw": payload}
        for tick in normalized:
            self.latest_ticks.append(tick)
            for callback in self.callbacks:
                callback(tick)
        return normalized

    def get_latest_ticks(self) -> list[dict[str, Any]]:
        return self.latest_ticks

    def collect_live_ticks(self, symbols: list[str], seconds: int, echo: bool = False) -> list[dict[str, Any]]:
        if not symbols:
            print("TrueData live collection skipped: no symbols supplied.")
            return []
        if not self.connect():
            return []
        self.subscribe(symbols)
        deadline = time.time() + max(1, seconds)
        try:
            if self.websocket and hasattr(self.websocket, "settimeout"):
                self.websocket.settimeout(1)
            while time.time() < deadline:
                try:
                    message = self.websocket.recv()
                except Exception:
                    continue
                try:
                    ticks = self.handle_message(message)
                except Exception as exc:
                    if echo:
                        print(f"TrueData message skipped safely: {exc}")
                    continue
                if echo:
                    for tick in ticks[:3]:
                        print(f"tick {tick['symbol']} {tick['timestamp']} ltp={tick['ltp']}")
        finally:
            self.unsubscribe(symbols)
            self.disconnect()
        return self.latest_ticks

    def _authenticate_rest(self) -> str | None:
        if self.credentials.missing:
            print("TrueData REST skipped: credentials missing.")
            return None
        body = parse.urlencode({
            "username": self.credentials.username,
            "password": self.credentials.password,
            "grant_type": "password",
        }).encode("utf-8")
        req = request.Request(AUTH_URL, data=body, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        try:
            with request.urlopen(req, timeout=15) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except Exception as exc:
            print(f"TrueData REST auth failed safely: {exc}")
            return None
        token = payload.get("access_token")
        self._access_token = token
        return token

    def _rest_get(self, path: str, params: dict[str, Any]) -> str | None:
        token = self._access_token or self._authenticate_rest()
        if not token:
            return None
        url = f"{HISTORY_BASE_URL}/{path}?{parse.urlencode(params)}"
        req = request.Request(url, method="GET")
        req.add_header("Authorization", f"bearer {token}")
        try:
            with request.urlopen(req, timeout=20) as response:
                return response.read().decode("utf-8")
        except Exception as exc:
            print(f"TrueData REST request failed safely: {exc}")
            return None

    def get_historical(self, symbol: str, start: datetime | str, end: datetime | str, interval: str) -> list[dict[str, Any]]:
        interval_value = interval.lower()
        if interval_value in {"tick", "ticks"}:
            response_text = self._rest_get("getticks", {
                "symbol": symbol,
                "bidask": 1,
                "from": _format_truedata_datetime(start),
                "to": _format_truedata_datetime(end),
                "response": "csv",
            })
            return normalize_historical_tick_response(response_text or "", symbol)
        response_text = self._rest_get("getbars", {
            "symbol": symbol,
            "from": _format_truedata_datetime(start),
            "to": _format_truedata_datetime(end),
            "response": "csv",
            "interval": _normalize_truedata_bar_interval(interval),
        })
        return normalize_historical_bar_response(response_text or "", symbol)

    def get_option_chain(self, symbol: str, expiry: str | None = None) -> list[dict[str, Any]]:
        if not expiry:
            print("TrueData option chain skipped: expiry is required by uploaded docs.")
            return []
        response_text = self._rest_get("getSymbolOptionChain", {"symbol": symbol, "expiry": expiry, "response": "csv"})
        if not response_text:
            return []
        return list(csv.DictReader(StringIO(response_text.strip())))

    def get_market_depth(self, symbol: str) -> dict[str, Any] | None:
        return self.depth_by_symbol.get(symbol)

    def build_candles(self) -> list[dict[str, Any]]:
        return []


def _test_connection() -> int:
    configs = load_configs(".")
    feed = TrueDataFeed(configs["settings"], allow_network=True)
    if not feed.enabled:
        print("TrueData connection test skipped: enable_true_data is false.")
        return 0
    connected = feed.connect()
    if not connected:
        return 0
    print("TrueData connection object prepared. Run a controlled live-data test only after subscription is confirmed.")
    feed.disconnect()
    return 0


def _test_stream(symbols_text: str, seconds: int) -> int:
    configs = load_configs(".")
    feed = TrueDataFeed(configs["settings"], allow_network=True)
    if not feed.enabled:
        print("TrueData stream test skipped: enable_true_data is false.")
        return 0
    symbols = [symbol.strip() for symbol in symbols_text.split(",") if symbol.strip()]
    if not symbols:
        print("TrueData stream test skipped: no symbols supplied.")
        return 1
    print(f"TrueData stream test started for {len(symbols)} symbols and {seconds} seconds. Secrets are not printed.")
    ticks = feed.collect_live_ticks(symbols, seconds, echo=True)
    print(f"TrueData stream test completed. Normalized ticks received: {len(ticks)}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Safe TrueData feed helper.")
    parser.add_argument("--test-connection", action="store_true", help="Safely test TrueData setup without printing secrets.")
    parser.add_argument("--test-stream", action="store_true", help="Manual TrueData stream test. Requires enable_true_data and credentials.")
    parser.add_argument("--symbols", default="", help="Comma-separated TrueData symbols, e.g. NIFTY-I,RELIANCE.")
    parser.add_argument("--seconds", type=int, default=30, help="Manual stream test duration.")
    args = parser.parse_args()
    if args.test_connection:
        return _test_connection()
    if args.test_stream:
        return _test_stream(args.symbols, args.seconds)
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
