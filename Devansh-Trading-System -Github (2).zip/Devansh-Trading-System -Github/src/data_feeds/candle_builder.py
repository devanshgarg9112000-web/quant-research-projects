from __future__ import annotations

from datetime import timedelta


def build_candles_from_ticks(ticks: list[dict], timeframe_minutes: int = 5) -> list[dict]:
    return build_candles_from_ticks_seconds(ticks, timeframe_minutes * 60)


def build_candles_from_ticks_seconds(ticks: list[dict], timeframe_seconds: int = 300) -> list[dict]:
    if not ticks:
        return []
    clean = sorted(ticks, key=lambda t: t["timestamp"])
    candles: list[dict] = []
    bucket_start = clean[0]["timestamp"]
    bucket: list[dict] = []
    for tick in clean:
        if tick["timestamp"] >= bucket_start + timedelta(seconds=timeframe_seconds):
            candles.append(_bucket_to_candle(bucket, bucket_start))
            bucket_start = tick["timestamp"]
            bucket = []
        bucket.append(tick)
    if bucket:
        candles.append(_bucket_to_candle(bucket, bucket_start))
    return candles


def _bucket_to_candle(bucket: list[dict], start):
    prices = [t["ltp"] for t in bucket]
    return {
        "timestamp": start,
        "open": prices[0],
        "high": max(prices),
        "low": min(prices),
        "close": prices[-1],
        "volume": sum(t["ltq"] for t in bucket),
        "symbol": bucket[0]["symbol"],
    }
