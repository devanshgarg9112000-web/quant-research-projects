from __future__ import annotations

import csv
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any


TICK_COLUMNS = ["timestamp", "symbol", "ltp", "ltq", "volume", "oi", "bid", "bid_qty", "ask", "ask_qty"]
DAILY_TICK_COLUMNS = ["timestamp", "symbol", "ltp", "ltq", "bid", "ask", "bid_qty", "ask_qty", "source", "received_at"]
DEFAULT_TICK_FILE = Path("data") / "ticks" / "latest_truedata_ticks.csv"
DEFAULT_DAILY_TICK_DIR = Path("data") / "ticks" / "daily"


class TickCsvError(ValueError):
    """Raised when a replay tick CSV cannot be parsed safely."""


def default_tick_file(base: Path | str = ".") -> Path:
    return Path(base) / DEFAULT_TICK_FILE


def default_daily_tick_dir(base: Path | str = ".") -> Path:
    return Path(base) / DEFAULT_DAILY_TICK_DIR


def save_normalized_ticks(ticks: list[dict[str, Any]], path: Path | str) -> Path:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TICK_COLUMNS)
        writer.writeheader()
        for tick in ticks:
            writer.writerow({column: _serialize_value(tick.get(column)) for column in TICK_COLUMNS})
    return output_path


def append_daily_ticks(
    ticks: list[dict[str, Any]],
    base: Path | str = ".",
    source: str = "TRUEDATA",
    received_at: datetime | None = None,
) -> dict[str, Any]:
    """Append normalized ticks to per-symbol daily CSVs with simple duplicate protection.

    Duplicate key: timestamp + symbol + ltp + ltq. This keeps repeated monitor
    scans from inflating the future backtest sample while still allowing real
    price/quantity changes at the same timestamp.
    """

    daily_root = default_daily_tick_dir(base)
    received = received_at or datetime.now().astimezone()
    grouped: defaultdict[Path, list[dict[str, Any]]] = defaultdict(list)
    for tick in ticks:
        timestamp = tick.get("timestamp")
        if not isinstance(timestamp, datetime):
            timestamp = _parse_timestamp(str(timestamp))
        symbol = str(tick.get("symbol") or "").strip()
        if not symbol:
            continue
        day = timestamp.date().isoformat()
        path = daily_root / day / f"{_safe_symbol_filename(symbol)}_ticks.csv"
        grouped[path].append(_daily_tick_row(tick, timestamp, symbol, source, received))

    rows_written = 0
    files_touched: list[Path] = []
    for path, rows in grouped.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        existing = _read_daily_tick_keys(path)
        write_header = not path.exists() or path.stat().st_size == 0
        new_rows: list[dict[str, Any]] = []
        for row in rows:
            key = _daily_tick_key(row)
            if key in existing:
                continue
            existing.add(key)
            new_rows.append(row)
        if not new_rows:
            continue
        with path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=DAILY_TICK_COLUMNS)
            if write_header:
                writer.writeheader()
            writer.writerows(new_rows)
        rows_written += len(new_rows)
        files_touched.append(path)
    return {
        "files": files_touched,
        "files_touched": len(files_touched),
        "rows_written": rows_written,
    }


def load_normalized_ticks(path: Path | str) -> list[dict[str, Any]]:
    input_path = Path(path)
    if not input_path.exists():
        raise FileNotFoundError(f"Replay tick file missing: {input_path}")
    with input_path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        missing = [column for column in TICK_COLUMNS if column not in fieldnames]
        if missing:
            raise TickCsvError(f"Replay tick CSV missing columns: {', '.join(missing)}")
        return [_parse_tick_row(row, row_number=index + 2) for index, row in enumerate(reader)]


def load_tick_csv(path: Path | str) -> list[dict[str, Any]]:
    """Load either legacy normalized ticks or Launch 1 daily tick files."""

    input_path = Path(path)
    if not input_path.exists():
        raise FileNotFoundError(f"Tick file missing: {input_path}")
    with input_path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        if all(column in fieldnames for column in TICK_COLUMNS):
            return [_parse_tick_row(row, row_number=index + 2) for index, row in enumerate(reader)]
        missing_daily = [column for column in DAILY_TICK_COLUMNS if column not in fieldnames]
        if missing_daily:
            raise TickCsvError(f"Tick CSV missing columns: {', '.join(missing_daily)}")
        return [_parse_daily_tick_row(row, row_number=index + 2) for index, row in enumerate(reader)]


def resolve_tick_file(base: Path | str, tick_file: Path | str | None) -> Path:
    if tick_file is None or str(tick_file).strip() == "":
        return default_tick_file(base)
    path = Path(tick_file)
    return path if path.is_absolute() else Path(base) / path


def _parse_tick_row(row: dict[str, str], row_number: int) -> dict[str, Any]:
    try:
        timestamp = _parse_timestamp(row["timestamp"])
        symbol = row["symbol"].strip()
        if not symbol:
            raise TickCsvError(f"Replay tick CSV row {row_number} has empty symbol.")
        return {
            "timestamp": timestamp,
            "symbol": symbol,
            "ltp": _parse_required_float(row["ltp"], "ltp", row_number),
            "ltq": _parse_optional_float(row["ltq"], default=0.0),
            "volume": _parse_optional_float(row["volume"], default=0.0),
            "oi": _parse_optional_float(row["oi"]),
            "bid": _parse_optional_float(row["bid"]),
            "bid_qty": _parse_optional_float(row["bid_qty"]),
            "ask": _parse_optional_float(row["ask"]),
            "ask_qty": _parse_optional_float(row["ask_qty"]),
        }
    except TickCsvError:
        raise
    except Exception as exc:
        raise TickCsvError(f"Replay tick CSV row {row_number} could not be parsed safely: {exc}") from exc


def _parse_daily_tick_row(row: dict[str, str], row_number: int) -> dict[str, Any]:
    try:
        timestamp = _parse_timestamp(row["timestamp"])
        symbol = row["symbol"].strip()
        if not symbol:
            raise TickCsvError(f"Daily tick CSV row {row_number} has empty symbol.")
        return {
            "timestamp": timestamp,
            "symbol": symbol,
            "ltp": _parse_required_float(row["ltp"], "ltp", row_number),
            "ltq": _parse_optional_float(row["ltq"], default=0.0),
            "volume": 0.0,
            "oi": None,
            "bid": _parse_optional_float(row["bid"]),
            "bid_qty": _parse_optional_float(row["bid_qty"]),
            "ask": _parse_optional_float(row["ask"]),
            "ask_qty": _parse_optional_float(row["ask_qty"]),
            "source": row.get("source", "").strip(),
            "received_at": row.get("received_at", "").strip(),
        }
    except TickCsvError:
        raise
    except Exception as exc:
        raise TickCsvError(f"Daily tick CSV row {row_number} could not be parsed safely: {exc}") from exc


def _parse_timestamp(value: str) -> datetime:
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(text)
    except ValueError as exc:
        raise TickCsvError(f"invalid timestamp '{value}'") from exc


def _parse_required_float(value: str, column: str, row_number: int) -> float:
    if value is None or value.strip() == "":
        raise TickCsvError(f"Replay tick CSV row {row_number} has empty {column}.")
    return float(value)


def _parse_optional_float(value: str | None, default: float | None = None) -> float | None:
    if value is None or value.strip() == "":
        return default
    return float(value)


def _serialize_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    return value


def _daily_tick_row(tick: dict[str, Any], timestamp: datetime, symbol: str, source: str, received_at: datetime) -> dict[str, Any]:
    return {
        "timestamp": _serialize_value(timestamp),
        "symbol": symbol,
        "ltp": _serialize_value(tick.get("ltp")),
        "ltq": _serialize_value(tick.get("ltq")),
        "bid": _serialize_value(tick.get("bid")),
        "ask": _serialize_value(tick.get("ask")),
        "bid_qty": _serialize_value(tick.get("bid_qty")),
        "ask_qty": _serialize_value(tick.get("ask_qty")),
        "source": source,
        "received_at": _serialize_value(received_at),
    }


def _read_daily_tick_keys(path: Path) -> set[tuple[str, str, str, str]]:
    if not path.exists() or path.stat().st_size == 0:
        return set()
    with path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return {_daily_tick_key(row) for row in reader}


def _daily_tick_key(row: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(row.get("timestamp") or "").strip(),
        str(row.get("symbol") or "").strip(),
        _normalized_float_text(row.get("ltp")),
        _normalized_float_text(row.get("ltq")),
    )


def _normalized_float_text(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text == "":
        return ""
    try:
        return str(float(text))
    except ValueError:
        return text


def _safe_symbol_filename(symbol: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in symbol)
