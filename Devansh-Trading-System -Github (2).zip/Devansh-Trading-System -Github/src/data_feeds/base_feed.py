from __future__ import annotations

from abc import ABC, abstractmethod


class BaseFeed(ABC):
    @abstractmethod
    def connect(self) -> bool:
        raise NotImplementedError
