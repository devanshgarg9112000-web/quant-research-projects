from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class Signal:
    """A trade idea after strategy, context, and scoring checks."""

    symbol: str
    timestamp: datetime
    strategy_name: str
    side: str
    entry_price: float
    stop_loss: float
    target_price: float
    reward_risk: float
    score: float
    reason: str
    market_mode: str
    key_level: float | None = None
    setup_type: str = ""
    regime_alignment: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
