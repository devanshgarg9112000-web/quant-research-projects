from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class Order:
    """Broker order request/result. Paper orders are default and safe."""

    order_id: str
    symbol: str
    side: str
    quantity: int
    order_type: str
    price: float
    status: str
    broker: str
    timestamp: datetime
    metadata: dict[str, Any] = field(default_factory=dict)
