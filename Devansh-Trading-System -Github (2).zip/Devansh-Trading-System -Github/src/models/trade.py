from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class Trade:
    """A completed or open trade record used by paper execution and reports."""

    trade_id: str
    symbol: str
    strategy_name: str
    side: str
    entry_time: datetime
    entry_price: float
    stop_loss: float
    target_price: float
    exit_time: datetime | None
    exit_price: float | None
    quantity: int
    pnl: float
    r_multiple: float
    status: str
    reason: str
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
