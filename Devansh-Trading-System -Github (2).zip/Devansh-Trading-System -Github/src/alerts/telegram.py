from __future__ import annotations

import os

from src.models.signal import Signal


def format_console_trade_alert(signal: Signal, mode: str, live_trading: bool, risk_amount: float | None = None) -> str:
    return "\n".join([
        "Trade Signal Generated",
        f"Mode: {mode}",
        f"Symbol: {signal.symbol}",
        f"Strategy: {signal.strategy_name}",
        f"Side: {signal.side}",
        f"Entry: {signal.entry_price}",
        f"Stop Loss: {signal.stop_loss}",
        f"Target: {signal.target_price}",
        f"Reward Risk: 1:{signal.reward_risk:g}",
        f"Score: {signal.score:g}/10",
        f"Market Mode: {signal.market_mode}",
        f"Reason: {signal.reason}",
        f"Risk Amount: {risk_amount if risk_amount is not None else 'N/A'}",
        f"Live Trading: {'ENABLED' if live_trading else 'DISABLED'}",
    ])


def send_trade_alert(signal: Signal, mode: str, live_trading: bool, enabled: bool = False, risk_amount: float | None = None) -> bool:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    message = format_console_trade_alert(signal, mode, live_trading, risk_amount)
    if not enabled or not token or not chat_id:
        print(message)
        return False
    print("Telegram alert ready, but network send is skipped in safe MVP.")
    return False
