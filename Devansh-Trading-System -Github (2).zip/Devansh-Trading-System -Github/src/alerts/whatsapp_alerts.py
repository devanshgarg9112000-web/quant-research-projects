from __future__ import annotations

import csv
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Callable
from urllib import request


REQUIRED_LIVE_ENV = (
    "WHATSAPP_PHONE_NUMBER_ID",
    "WHATSAPP_ACCESS_TOKEN",
    "WHATSAPP_TO_NUMBER",
)
ALERT_LOG_COLUMNS = [
    "timestamp",
    "channel",
    "delivery_status",
    "symbol",
    "signal_status",
    "message",
    "execution_allowed",
    "manual_execution_only",
]


class WhatsAppAlertProvider:
    """Launch 1 PAPER alerts only; never performs any trading action."""

    def __init__(
        self,
        base_dir: Path | str = ".",
        config: dict | None = None,
        environ: dict[str, str] | None = None,
        opener: Callable | None = None,
        now_fn: Callable[[], datetime] | None = None,
    ):
        self.base = Path(base_dir)
        self.config = config or {}
        self.environ = environ if environ is not None else os.environ
        self.opener = opener or request.urlopen
        self.now_fn = now_fn or (lambda: datetime.now().astimezone())
        self.report_dir = self.base / "reports" / "alerts"
        self.preview_path = self.report_dir / "latest_whatsapp_alert_preview.txt"
        self.log_path = self.report_dir / "whatsapp_alert_log.csv"
        self.heartbeat_preview_path = self.report_dir / "latest_whatsapp_heartbeat_preview.txt"
        self.error_preview_path = self.report_dir / "latest_whatsapp_error_preview.txt"
        self.research_watchlist_preview_path = (
            self.report_dir / "latest_whatsapp_research_watchlist_preview.txt"
        )

    def alert_rows(self, rows: list[dict], channel: str) -> int:
        candidates = [
            row for row in rows
            if row.get("status") in {"ACCEPTED_PAPER_SIGNAL", "RISK_REJECTED"}
        ]
        if channel == "none" or not candidates:
            return 0
        if channel == "whatsapp-dry-run":
            return self._dry_run(candidates)
        if channel == "whatsapp-live":
            return self._live(candidates)
        print(f"WhatsApp alert skipped: unsupported channel {channel}.")
        return 0

    def _dry_run(self, rows: list[dict]) -> int:
        messages: list[str] = []
        log_rows: list[dict] = []
        for row in rows:
            if not _safe_launch_one_row(row):
                print(f"WhatsApp dry-run skipped unsafe row for {row.get('symbol', 'UNKNOWN')}.")
                continue
            message = format_launch_one_whatsapp_alert(row)
            messages.append(message)
            log_rows.append(self._log_row(row, message, "whatsapp-dry-run", "PREVIEW"))
            print(message)
        if messages:
            self.report_dir.mkdir(parents=True, exist_ok=True)
            self.preview_path.write_text(
                ("\n\n" + "=" * 48 + "\n\n").join(messages) + "\n",
                encoding="utf-8",
            )
            _append_alert_log(self.log_path, log_rows)
        return len(messages)

    def _live(self, rows: list[dict]) -> int:
        if not bool(self.config.get("enabled", False)):
            print("WhatsApp live alert skipped: config alerts.whatsapp.enabled is false.")
            return 0
        if not _truthy(self.environ.get("ENABLE_WHATSAPP_ALERTS")):
            print("WhatsApp live alert skipped: ENABLE_WHATSAPP_ALERTS is not true.")
            return 0
        missing = [name for name in REQUIRED_LIVE_ENV if not self.environ.get(name)]
        if missing:
            print("WhatsApp live alert skipped: missing environment variables: " + ", ".join(missing))
            return 0

        sent_count = 0
        log_rows: list[dict] = []
        for row in rows:
            if not _safe_launch_one_row(row):
                print(f"WhatsApp live alert skipped unsafe row for {row.get('symbol', 'UNKNOWN')}.")
                continue
            message = format_launch_one_whatsapp_alert(row)
            sent = self._send_cloud_api_message(message)
            delivery_status = "SENT" if sent else "FAILED_SAFE"
            log_rows.append(self._log_row(row, message, "whatsapp-live", delivery_status))
            sent_count += int(sent)
        if log_rows:
            _append_alert_log(self.log_path, log_rows)
        return sent_count

    def _send_cloud_api_message(self, message: str) -> bool:
        phone_number_id = self.environ["WHATSAPP_PHONE_NUMBER_ID"]
        access_token = self.environ["WHATSAPP_ACCESS_TOKEN"]
        to_number = self.environ["WHATSAPP_TO_NUMBER"]
        url = f"https://graph.facebook.com/{phone_number_id}/messages"
        payload = json.dumps({
            "messaging_product": "whatsapp",
            "to": to_number,
            "type": "text",
            "text": {"body": message},
        }).encode("utf-8")
        req = request.Request(url, data=payload, method="POST")
        req.add_header("Authorization", f"Bearer {access_token}")
        req.add_header("Content-Type", "application/json")
        try:
            with self.opener(req, timeout=10) as response:
                return 200 <= int(getattr(response, "status", 0)) < 300
        except Exception as exc:
            print(f"WhatsApp live alert failed safely: {type(exc).__name__}.")
            return False

    def preview_monitor_event(self, event_type: str, message: str, channel: str) -> bool:
        """Write dry-run-only heartbeat/error previews for the PAPER monitor."""

        if channel != "whatsapp-dry-run":
            return False
        event = event_type.strip().upper()
        if event not in {"HEARTBEAT", "ERROR"}:
            return False
        text = "\n".join([
            f"LAUNCH 1 MONITOR {event} - PAPER ONLY",
            "",
            message,
            "",
            "execution_allowed=false",
            "Broker Orders: DISABLED",
            "Algo Trading: DISABLED",
            "Manual Execution Only",
        ])
        path = self.heartbeat_preview_path if event == "HEARTBEAT" else self.error_preview_path
        self.report_dir.mkdir(parents=True, exist_ok=True)
        path.write_text(text + "\n", encoding="utf-8")
        _append_alert_log(self.log_path, [{
            "timestamp": self.now_fn().isoformat(),
            "channel": "whatsapp-dry-run",
            "delivery_status": f"{event}_PREVIEW",
            "symbol": "MONITOR",
            "signal_status": event,
            "message": text,
            "execution_allowed": "false",
            "manual_execution_only": "true",
        }])
        return True

    def preview_research_watchlist(self, row: dict) -> bool:
        """Write an explicitly non-tradable research preview; never sends live."""

        if not bool(self.config.get("research_watchlist_enabled", False)):
            return False
        if str(row.get("strategy_verification_status") or "").upper() != "WATCHLIST":
            return False
        if str(row.get("status") or "").upper() in {"RISK_REJECTED", "REJECTED"}:
            return False
        if not _safe_launch_one_row(row):
            return False
        message = format_research_watchlist_alert(row)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.research_watchlist_preview_path.write_text(message + "\n", encoding="utf-8")
        _append_alert_log(self.log_path, [self._log_row(
            row,
            message,
            "whatsapp-research-watchlist-dry-run",
            "RESEARCH_PREVIEW",
        )])
        return True

    def _log_row(self, row: dict, message: str, channel: str, delivery_status: str) -> dict:
        return {
            "timestamp": self.now_fn().isoformat(),
            "channel": channel,
            "delivery_status": delivery_status,
            "symbol": row.get("symbol"),
            "signal_status": row.get("status"),
            "message": message,
            "execution_allowed": "false",
            "manual_execution_only": "true",
        }


def format_launch_one_whatsapp_alert(row: dict) -> str:
    if row.get("status") == "RISK_REJECTED":
        return "\n".join([
            "PAPER SIGNAL REJECTED",
            "",
            f"Symbol: {_display(row.get('symbol'))}",
            f"Status: RISK_REJECTED",
            f"Direction: {_display(row.get('direction'))}",
            f"Strategy: {_display(row.get('strategy'))}",
            f"Reason: {_display(row.get('rejection_reason'))}",
            "Manual execution not recommended.",
            "",
            "execution_allowed=false",
            "Broker Orders: DISABLED",
            "Algo Trading: DISABLED",
            "Manual review required.",
        ])
    return "\n".join([
        "PAPER SIGNAL ALERT - MANUAL EXECUTION ONLY",
        "",
        f"Symbol: {_display(row.get('symbol'))}",
        f"Status: {_display(row.get('status'))}",
        f"Direction: {_display(row.get('direction'))}",
        f"Strategy: {_display(row.get('strategy'))}",
        f"Entry: {_display(row.get('entry'))}",
        f"Stop: {_display(row.get('stop'))}",
        f"Target: {_display(row.get('target'))}",
        f"RR: {_display(row.get('rr'))}",
        f"Qty: {_display(row.get('qty'))}",
        f"Score: {_display(row.get('score'))}",
        f"Risk: {_display(row.get('estimated_risk_amount'))}",
        f"Market Mode: {_display(row.get('market_mode'))}",
        f"Cluster: {_display(row.get('cluster_status'))}",
        "",
        "execution_allowed=false",
        "Broker Orders: DISABLED",
        "Algo Trading: DISABLED",
        "Manual review required.",
    ])


def format_research_watchlist_alert(row: dict) -> str:
    return "\n".join([
        "RESEARCH ONLY - DO NOT TRADE",
        "",
        f"Symbol: {_display(row.get('symbol'))}",
        f"Strategy: {_display(row.get('strategy'))}",
        "Verification Status: WATCHLIST",
        f"Research Note: {_display(row.get('strategy_verification_reason'))}",
        "",
        "This is not a production signal.",
        "Manual execution is not recommended from this alert.",
        "execution_allowed=false",
        "Broker Orders: DISABLED",
        "Algo Trading: DISABLED",
    ])


def _safe_launch_one_row(row: dict) -> bool:
    execution_allowed = row.get("execution_allowed", False)
    return execution_allowed is False or str(execution_allowed).strip().lower() == "false"


def _append_alert_log(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=ALERT_LOG_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerows(rows)


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _display(value) -> str:
    return "N/A" if value is None or value == "" else str(value)
