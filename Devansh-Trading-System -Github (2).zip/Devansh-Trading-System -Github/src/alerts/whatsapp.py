from __future__ import annotations

import os
from urllib import parse, request

from src.models.signal import Signal


MISSING_MESSAGE = "WhatsApp alert skipped: credentials missing."


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def format_whatsapp_trade_message(signal: Signal, mode: str, live_trading: bool) -> str:
    time_text = signal.timestamp.strftime("%I:%M %p")
    return "\n".join([
        "🚨 Trade Signal Generated",
        "",
        f"Mode: {mode}",
        f"Symbol: {signal.symbol}",
        f"Strategy: {signal.strategy_name}",
        f"Side: {signal.side}",
        f"Entry: {signal.entry_price:g}",
        f"Stop Loss: {signal.stop_loss:g}",
        f"Target: {signal.target_price:g}",
        f"Reward Risk: 1:{signal.reward_risk:g}",
        f"Score: {signal.score:g}/10",
        f"Market Mode: {signal.market_mode}",
        f"Reason: {signal.reason}",
        f"Time: {time_text}",
        "",
        f"Live Trading: {'ENABLED' if live_trading else 'DISABLED'}",
    ])


def send_whatsapp_trade_alert(signal: Signal, mode: str, live_trading: bool, config_enabled: bool = False) -> bool:
    """Send a WhatsApp trade alert through Twilio only.

    This module never places trades and never uses unofficial WhatsApp Web
    automation. Credentials are read from .env/environment only.
    """

    if not config_enabled:
        return False
    if not _truthy(os.getenv("WHATSAPP_ALERTS_ENABLED")):
        print(MISSING_MESSAGE)
        return False
    provider = os.getenv("WHATSAPP_PROVIDER")
    to_number = os.getenv("WHATSAPP_TO_NUMBER")
    from_number = os.getenv("WHATSAPP_FROM_NUMBER")
    account_sid = os.getenv("TWILIO_ACCOUNT_SID")
    auth_token = os.getenv("TWILIO_AUTH_TOKEN")
    if provider != "TWILIO" or not all([to_number, from_number, account_sid, auth_token]):
        print(MISSING_MESSAGE)
        return False
    body = parse.urlencode({"From": from_number, "To": to_number, "Body": format_whatsapp_trade_message(signal, mode, live_trading)}).encode("utf-8")
    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
    req = request.Request(url, data=body, method="POST")
    credentials = f"{account_sid}:{auth_token}".encode("utf-8")
    import base64
    req.add_header("Authorization", "Basic " + base64.b64encode(credentials).decode("ascii"))
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with request.urlopen(req, timeout=10) as response:
            return 200 <= response.status < 300
    except Exception as exc:
        print(f"WhatsApp alert skipped: {exc}")
        return False
