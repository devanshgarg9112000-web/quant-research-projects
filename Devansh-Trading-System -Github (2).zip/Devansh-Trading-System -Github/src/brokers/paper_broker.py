from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from src.journal.trade_journal import TradeJournal
from src.models.order import Order
from src.models.signal import Signal
from src.models.trade import Trade


class PaperBroker:
    """Simulates orders locally and never touches a real broker."""

    name = "PaperBroker"

    def __init__(self, journal: TradeJournal | None = None):
        self.open_positions: list[Trade] = []
        self.journal = journal or TradeJournal()

    def place_order(self, signal: Signal, quantity: int) -> tuple[Order, Trade]:
        now = datetime.now()
        order = Order(str(uuid4()), signal.symbol, signal.side, quantity, "MARKET", signal.entry_price, "FILLED", self.name, now, {"paper": True})
        trade = Trade(
            trade_id=str(uuid4()),
            symbol=signal.symbol,
            strategy_name=signal.strategy_name,
            side=signal.side,
            entry_time=signal.timestamp,
            entry_price=signal.entry_price,
            stop_loss=signal.stop_loss,
            target_price=signal.target_price,
            exit_time=None,
            exit_price=None,
            quantity=quantity,
            pnl=0.0,
            r_multiple=0.0,
            status="OPEN",
            reason=signal.reason,
            tags=[signal.setup_type],
            metadata={"order_id": order.order_id, "paper": True},
        )
        self.open_positions.append(trade)
        self.journal.log_trade(trade)
        return order, trade
