from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qsl, parse_qs, urlencode, urlparse, urlunparse

from src.data_collection.kite_credentials import (
    kite_daily_token_path,
    kite_session_date,
    load_daily_access_token,
    load_kite_credentials,
)
from src.utils.logger import log_event


TOKEN_DIR = ".tokens"


@dataclass(slots=True)
class LiveOrderGuardResult:
    approved: bool
    reasons: list[str]


def extract_request_token(value: str) -> str:
    """Accept either a raw Kite request_token or the full redirect URL."""

    text = value.strip()
    if not text:
        return ""
    if "request_token=" not in text:
        return text
    parsed = urlparse(text)
    query = parsed.query or text.split("?", 1)[-1]
    token = parse_qs(query).get("request_token", [""])[0]
    return token.strip()


def mask_token(token: str | None) -> str:
    if not token:
        return "missing"
    if len(token) <= 8:
        return "****"
    return f"{token[:4]}...{token[-4:]}"


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _today_token_path(base_dir: Path | str = ".") -> Path:
    return kite_daily_token_path(base_dir)


def _today_login_url_path(base_dir: Path | str = ".") -> Path:
    return Path(base_dir) / TOKEN_DIR / f"kite_login_url_{kite_session_date().isoformat()}.txt"


def save_login_url(login_url: str, base_dir: Path | str = ".") -> Path:
    url_path = _today_login_url_path(base_dir)
    url_path.parent.mkdir(parents=True, exist_ok=True)
    url_path.write_text(login_url.strip(), encoding="utf-8")
    return url_path


def save_access_token(access_token: str, base_dir: Path | str = ".") -> Path:
    cleaned = str(access_token or "").strip()
    if not cleaned:
        raise ValueError("Cannot save an empty Kite access token")
    token_path = _today_token_path(base_dir)
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(cleaned, encoding="utf-8")
    return token_path


def load_saved_access_token(base_dir: Path | str = ".") -> str | None:
    return load_daily_access_token(base_dir)


def mask_login_url(login_url: str) -> str:
    parsed = urlparse(login_url)
    query = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        if key.lower() in {"api_key", "access_token", "request_token"}:
            query.append((key, mask_token(value)))
        else:
            query.append((key, value))
    return urlunparse(parsed._replace(query=urlencode(query)))


def evaluate_live_order_guard(mode: str, settings: dict, risk_config: dict, broker_name: str, env: dict | None = None) -> LiveOrderGuardResult:
    """Central hard gate for live broker order placement."""

    env = env or os.environ
    reasons: list[str] = []
    if mode != "LIVE":
        reasons.append("mode is not LIVE")
    if not bool(settings.get("enable_live_trading")):
        reasons.append("settings enable_live_trading is false")
    if not bool(risk_config.get("allow_live_trading")):
        reasons.append("risk allow_live_trading is false")
    if not _truthy(env.get("ENABLE_LIVE_TRADING")):
        reasons.append("environment ENABLE_LIVE_TRADING is not true")
    if not _truthy(env.get("I_UNDERSTAND_LIVE_TRADING_RISK")):
        reasons.append("environment I_UNDERSTAND_LIVE_TRADING_RISK is not true")
    if broker_name != "kite":
        reasons.append("broker is not explicitly selected as kite")
    return LiveOrderGuardResult(not reasons, reasons)


def _kite_connect_class():
    try:
        from kiteconnect import KiteConnect
    except Exception:
        return None
    return KiteConnect


class KiteBroker:
    """Manual Kite helper plus strict live-order blocker.

    No Selenium, no Zerodha login automation, and no live orders in this MVP.
    """

    def __init__(self, settings: dict | None = None, risk_config: dict | None = None, broker_name: str = "paper", base_dir: Path | str = "."):
        self.settings = settings or {}
        self.risk_config = risk_config or {}
        self.broker_name = broker_name
        self.base_dir = Path(base_dir)
        self.credential_state = load_kite_credentials(self.base_dir, require_daily_token=True)
        self.api_key = self.credential_state.api_key
        self.api_secret = self.credential_state.api_secret
        self.access_token = self.credential_state.access_token

    def _missing_credentials(self) -> list[str]:
        missing = []
        if not self.api_key:
            missing.append("KITE_API_KEY")
        if not self.api_secret:
            missing.append("KITE_API_SECRET")
        return missing

    def _missing_read_credentials(self) -> list[str]:
        missing = []
        if not self.api_key:
            missing.append("KITE_API_KEY")
        if not self.access_token:
            missing.append("KITE_ACCESS_TOKEN or today's saved token from --login")
        return missing

    def get_login_url(self) -> str:
        missing = self._missing_credentials()
        if missing:
            return "Kite credentials missing: " + ", ".join(missing)
        kite_class = _kite_connect_class()
        if kite_class is None:
            return "kiteconnect package missing. Run: pip install -r requirements.txt"
        return kite_class(api_key=self.api_key).login_url()

    def generate_session(self, request_token: str) -> dict:
        missing = self._missing_credentials()
        if missing:
            return {"status": "credentials_missing", "missing": missing}
        kite_class = _kite_connect_class()
        if kite_class is None:
            return {"status": "kiteconnect_missing"}
        kite = kite_class(api_key=self.api_key)
        return kite.generate_session(request_token, api_secret=self.api_secret)

    def set_access_token(self, token: str) -> None:
        self.access_token = token

    def _authenticated_client(self):
        missing = self._missing_read_credentials()
        if missing:
            return None, {"status": "credentials_missing", "missing": missing}
        kite_class = _kite_connect_class()
        if kite_class is None:
            return None, {"status": "kiteconnect_missing"}
        kite = kite_class(api_key=self.api_key)
        kite.set_access_token(self.access_token)
        return kite, None

    def get_profile(self) -> dict:
        kite, error = self._authenticated_client()
        if error:
            return error
        return kite.profile()

    def get_positions(self) -> dict:
        kite, error = self._authenticated_client()
        if error:
            return error
        return kite.positions()

    def get_margins(self) -> dict:
        kite, error = self._authenticated_client()
        if error:
            return error
        return kite.margins()

    def get_quote(self, symbols: list[str]) -> dict:
        if not symbols:
            return {"status": "symbols_missing", "message": "No symbols supplied."}
        kite, error = self._authenticated_client()
        if error:
            return error
        return kite.quote(symbols)

    def get_historical_data(self, instrument_token: int, from_date, to_date, interval: str, continuous: bool = False, oi: bool = True) -> list | dict:
        kite, error = self._authenticated_client()
        if error:
            return error
        return kite.historical_data(instrument_token, from_date, to_date, interval, continuous=continuous, oi=oi)

    def get_instruments_summary(self) -> dict:
        instruments = self.get_instruments()
        if isinstance(instruments, dict) and instruments.get("status"):
            return instruments
        if not isinstance(instruments, list):
            return {"status": "unexpected_instruments_response", "type": type(instruments).__name__}
        sample = []
        for item in instruments[:5]:
            sample.append({key: item.get(key) for key in ["exchange", "tradingsymbol", "instrument_type"] if key in item})
        return {"count": len(instruments), "sample": sample}

    def get_instruments(self, exchange: str | None = None) -> list | dict:
        kite, error = self._authenticated_client()
        if error:
            return error
        return kite.instruments(exchange) if exchange else kite.instruments()

    def get_read_only_snapshot(self) -> dict:
        snapshot: dict = {}
        for key, func in [
            ("profile", self.get_profile),
            ("margins", self.get_margins),
            ("positions", self.get_positions),
            ("instruments", self.get_instruments_summary),
        ]:
            try:
                snapshot[key] = func()
            except Exception as exc:
                snapshot[key] = {"status": "read_failed", "error_type": type(exc).__name__}
        return snapshot

    def place_order(self, *args, risk_approved: bool = False, explicit_order_flag: bool = False, confirm_live_order: bool = False, mode: str | None = None, **kwargs):
        mode = mode or self.settings.get("mode", "PAPER")
        result = evaluate_live_order_guard(mode, self.settings, self.risk_config, self.broker_name)
        reasons = list(result.reasons)
        quantity = kwargs.get("quantity")
        symbol = str(kwargs.get("symbol") or "").strip()
        allowed_symbols = {str(item).strip() for item in kwargs.get("allowed_symbols", []) if str(item).strip()}
        if not risk_approved:
            reasons.append("risk engine did not approve the order")
        if not explicit_order_flag and not confirm_live_order:
            reasons.append("explicit order flag was not passed")
        if quantity is None:
            reasons.append("quantity is missing")
        else:
            try:
                if int(quantity) <= 0:
                    reasons.append("quantity must be positive")
            except (TypeError, ValueError):
                reasons.append("quantity must be positive")
        if not allowed_symbols or symbol not in allowed_symbols:
            reasons.append("symbol is not in allowed list")
        if reasons:
            message = "KiteBroker refused live order: " + "; ".join(reasons)
            log_event(message, self.base_dir)
            raise RuntimeError(message)
        raise RuntimeError("Kite live order placement is intentionally not implemented in this safety-first MVP.")


def _login_cli(base_dir: Path | str = ".") -> int:
    broker = KiteBroker(base_dir=base_dir)
    missing = broker._missing_credentials()
    if missing:
        print("Kite login skipped: missing " + ", ".join(missing) + ". Add them to .env first.")
        return 1
    login_url = broker.get_login_url()
    if login_url.startswith("kiteconnect package missing") or login_url.startswith("Kite credentials missing"):
        print(login_url)
        return 1
    url_path = save_login_url(login_url, base_dir)
    print("Official Kite login URL generated.")
    print(f"Full URL saved locally at: {url_path}")
    print("Open the saved URL in your browser, complete login manually, then paste only the redirected URL or request_token here.")
    pasted = input("Paste request_token or full redirect URL here: ").strip()
    request_token = extract_request_token(pasted)
    if not request_token:
        print("Kite login skipped: request_token not found.")
        return 1
    try:
        session = broker.generate_session(request_token)
    except Exception as exc:
        print(f"Kite login failed safely: {type(exc).__name__}")
        return 1
    access_token = session.get("access_token") if isinstance(session, dict) else None
    if not access_token:
        print("Kite login failed safely: access_token not returned.")
        return 1
    token_path = save_access_token(access_token, base_dir)
    print(f"Kite access token saved for today at {token_path}.")
    return 0


def _auth_diagnose_cli(base_dir: Path | str = ".") -> int:
    state = load_kite_credentials(base_dir, require_daily_token=True)
    print("KITE AUTH DIAGNOSTIC (OFFLINE)")
    print(f"API key: {state.status_for('KITE_API_KEY')} | source={state.api_key_source}")
    print(f"API secret: {state.status_for('KITE_API_SECRET')} | source={state.api_secret_source}")
    print(f"Daily token file: {'PRESENT' if state.daily_token_file_present else 'MISSING'}")
    print(f"Daily token date: {state.daily_token_date}")
    print(f"Access token: {state.status_for('KITE_ACCESS_TOKEN')} | source={state.access_token_source}")
    print(f"Read-only session ready: {'YES' if state.read_ready else 'NO'}")
    print("No network call was made. No broker order was placed. execution_allowed=false")
    return 0 if state.read_ready else 1


def _profile_test_cli(base_dir: Path | str = ".") -> int:
    broker = KiteBroker(base_dir=base_dir)
    snapshot = broker.get_read_only_snapshot()
    profile = snapshot.get("profile", {})
    if profile.get("status"):
        print(_read_error_message("Kite profile test skipped", profile))
        return 1
    safe_profile = {key: profile.get(key) for key in ["user_id", "user_name", "email", "broker"] if key in profile}
    print("Kite profile test succeeded. Read-only calls only; no orders were placed.")
    _print_json("Profile", safe_profile)
    _print_json("Margins summary", _summarize_mapping(snapshot.get("margins")))
    _print_json("Positions summary", _summarize_positions(snapshot.get("positions")))
    _print_json("Instruments summary", snapshot.get("instruments"))
    return 0


def _quote_test_cli(symbols_text: str, base_dir: Path | str = ".") -> int:
    broker = KiteBroker(base_dir=base_dir)
    symbols = [symbol.strip() for symbol in symbols_text.split(",") if symbol.strip()]
    try:
        quote = broker.get_quote(symbols)
    except Exception as exc:
        quote = {"status": "read_failed", "error_type": type(exc).__name__}
    if quote.get("status"):
        print(_read_error_message("Kite quote test skipped", quote))
        return 1
    instruments = broker.get_instruments_summary()
    print("Kite quote test succeeded. Read-only calls only; no orders were placed.")
    _print_json("Quote", quote)
    _print_json("Instruments summary", instruments)
    return 0


def _read_error_message(prefix: str, payload: dict) -> str:
    if payload.get("status") == "credentials_missing":
        return f"{prefix}: missing " + ", ".join(payload.get("missing", [])) + ". Add them to .env or run --login first."
    if payload.get("status") == "kiteconnect_missing":
        return f"{prefix}: kiteconnect package missing. Run: pip install -r requirements.txt"
    if payload.get("status") == "read_failed":
        return f"{prefix}: read-only Kite API call failed safely ({payload.get('error_type', 'unknown error')})."
    return payload.get("message") or f"{prefix}: {payload.get('status', 'unknown error')}"


def _summarize_mapping(value) -> dict:
    if not isinstance(value, dict):
        return value if value is not None else {"status": "not_available"}
    return {"status": value.get("status", "ok"), "top_level_keys": sorted(str(key) for key in value.keys())}


def _summarize_positions(value) -> dict:
    if not isinstance(value, dict):
        return value if value is not None else {"status": "not_available"}
    day = value.get("day") if isinstance(value.get("day"), list) else []
    net = value.get("net") if isinstance(value.get("net"), list) else []
    return {"status": value.get("status", "ok"), "day_count": len(day), "net_count": len(net)}


def _print_json(title: str, payload) -> None:
    print(title + ":")
    print(json.dumps(payload, indent=2, default=str))


def main() -> int:
    parser = argparse.ArgumentParser(description="Safe manual Kite daily login helper.")
    parser.add_argument("--login", action="store_true", help="Generate official login URL and exchange manual request_token.")
    parser.add_argument("--test-profile", action="store_true", help="Read profile, margins, positions, and instruments summary without orders.")
    parser.add_argument("--profile-test", action="store_true", help="Deprecated alias for --test-profile.")
    parser.add_argument("--test-quote", action="store_true", help="Read quotes for supplied Kite symbols without orders.")
    parser.add_argument("--auth-diagnose", action="store_true", help="Show offline credential source/status metadata only.")
    parser.add_argument("--symbols", default="", help='Comma-separated Kite instruments, e.g. "NSE:RELIANCE,NSE:INFY".')
    args = parser.parse_args()
    if args.login:
        return _login_cli(".")
    if args.auth_diagnose:
        return _auth_diagnose_cli(".")
    if args.test_profile or args.profile_test:
        return _profile_test_cli(".")
    if args.test_quote:
        return _quote_test_cli(args.symbols, ".")
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
