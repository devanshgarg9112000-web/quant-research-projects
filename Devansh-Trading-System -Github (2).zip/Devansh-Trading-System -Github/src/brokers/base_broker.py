from __future__ import annotations

from abc import ABC, abstractmethod


class BaseBroker(ABC):
    @abstractmethod
    def place_order(self, *args, **kwargs):
        raise NotImplementedError
