from __future__ import annotations

from src.models.signal import Signal


def reward_risk(entry: float, stop: float, target: float) -> float:
    risk = abs(entry - stop)
    reward = abs(target - entry)
    return round(reward / risk, 2) if risk else 0.0


def make_signal(candles: list[dict], strategy_name: str, side: str, entry: float, stop: float, target: float, score: float, reason: str, market_mode: str, setup_type: str, key_level: float | None = None) -> Signal:
    return Signal(
        symbol=candles[-1]["symbol"],
        timestamp=candles[-1]["timestamp"],
        strategy_name=strategy_name,
        side=side,
        entry_price=round(entry, 2),
        stop_loss=round(stop, 2),
        target_price=round(target, 2),
        reward_risk=reward_risk(entry, stop, target),
        score=score,
        reason=reason,
        market_mode=market_mode,
        key_level=key_level,
        setup_type=setup_type,
        regime_alignment="aligned" if market_mode != "UNCLEAR" else "unclear",
        metadata={"source": "sample_safe_mvp"},
    )
