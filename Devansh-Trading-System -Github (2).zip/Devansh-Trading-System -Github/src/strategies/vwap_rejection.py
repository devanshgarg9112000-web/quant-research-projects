from __future__ import annotations

from src.indicators.vwap import calculate_vwap
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 4:
        return None
    last = candles[-1]
    vwap = calculate_vwap(candles)[-1]["vwap"]
    if last["high"] >= vwap and last["close"] < vwap and last["close"] < last["open"]:
        entry = last["close"]
        stop = last["high"] + 5
        risk = stop - entry
        return make_signal(candles, "VWAP Rejection Short", "SELL", entry, stop, entry - 2 * risk, 7.7, "Pullback into VWAP rejected while sellers kept control", context["market_mode"], "vwap_rejection", vwap)
    if last["low"] <= vwap and last["close"] > vwap and last["close"] > last["open"] and context["market_mode"] == "TREND_UP":
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        return make_signal(candles, "VWAP Pullback Long", "BUY", entry, stop, entry + 2 * risk, 7.6, "VWAP held as fair-value support in trend", context["market_mode"], "vwap_rejection", vwap)
    return None
