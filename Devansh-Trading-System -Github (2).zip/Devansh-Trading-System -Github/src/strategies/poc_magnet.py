from __future__ import annotations

from src.indicators.volume_profile import calculate_volume_profile
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 8 or context["market_mode"] not in {"RANGE", "TRAP_REVERSAL"}:
        return None
    last = candles[-1]
    profile = context.get("volume_profile") or calculate_volume_profile(candles[:-1])
    poc = profile["poc"]
    if last["close"] > poc and last["close"] < profile["vah"]:
        entry = last["close"]
        stop = last["high"] + 5
        risk = stop - entry
        if risk > 0 and abs(entry - poc) >= 1.5 * risk:
            return make_signal(candles, "POC Magnet Short", "SELL", entry, stop, poc, 7.2, "Range market rejected edge and POC is the magnet target", context["market_mode"], "poc_magnet", poc)
    if last["close"] < poc and last["close"] > profile["val"]:
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        if risk > 0 and abs(poc - entry) >= 1.5 * risk:
            return make_signal(candles, "POC Magnet Long", "BUY", entry, stop, poc, 7.2, "Range market rejected edge and POC is the magnet target", context["market_mode"], "poc_magnet", poc)
    return None
