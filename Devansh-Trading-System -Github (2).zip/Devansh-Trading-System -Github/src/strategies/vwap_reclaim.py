from __future__ import annotations

from src.indicators.vwap import calculate_vwap
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 4:
        return None
    rows = calculate_vwap(candles)
    prev_candle, last = candles[-2], candles[-1]
    prev_vwap, last_vwap = rows[-2]["vwap"], rows[-1]["vwap"]
    if prev_candle["close"] < prev_vwap and last["close"] > last_vwap and last["close"] > last["open"]:
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        return make_signal(candles, "VWAP Reclaim Long", "BUY", entry, stop, entry + 2 * risk, 8.0, "Price reclaimed VWAP after sellers failed to continue", context["market_mode"], "vwap_reclaim", last_vwap)
    return None
