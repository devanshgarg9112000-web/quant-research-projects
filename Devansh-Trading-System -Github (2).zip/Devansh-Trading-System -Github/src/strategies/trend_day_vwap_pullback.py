from __future__ import annotations

from src.indicators.vwap import calculate_vwap
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 8:
        return None
    last = candles[-1]
    rows = calculate_vwap(candles)
    vwap = rows[-1]["vwap"]
    reference = rows[max(0, len(rows) - 5)]["vwap"]
    local_up_structure = vwap > reference and last["close"] > rows[-4]["close"] and last["close"] > vwap
    local_down_structure = vwap < reference and last["close"] < rows[-4]["close"] and last["close"] < vwap
    long_allowed = context["market_mode"] == "TREND_UP" or local_up_structure
    short_allowed = context["market_mode"] == "TREND_DOWN" or local_down_structure
    if long_allowed and last["low"] <= vwap <= last["close"] and last["close"] > last["open"]:
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        return make_signal(candles, "Trend Day VWAP Pullback Long", "BUY", entry, stop, entry + 2 * risk, 7.9, "Trend day pullback held VWAP support", context["market_mode"], "trend_day_vwap_pullback", vwap)
    if short_allowed and last["high"] >= vwap >= last["close"] and last["close"] < last["open"]:
        entry = last["close"]
        stop = last["high"] + 5
        risk = stop - entry
        return make_signal(candles, "Trend Day VWAP Pullback Short", "SELL", entry, stop, entry - 2 * risk, 7.9, "Trend day pullback rejected VWAP resistance", context["market_mode"], "trend_day_vwap_pullback", vwap)
    return None
