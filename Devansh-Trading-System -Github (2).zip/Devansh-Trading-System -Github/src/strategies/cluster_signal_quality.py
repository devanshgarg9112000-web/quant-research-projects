from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from src.models.signal import Signal


@dataclass(frozen=True)
class ClusterSignalQualityConfig:
    enabled: bool = True
    min_score: float = 8.5
    min_trap_strength: float = 0.65
    min_volume_or_ltq: float = 1.0
    min_stop_distance: float = 5.0
    max_stop_distance: float = 600.0
    min_target_distance: float = 10.0
    require_market_mode_alignment: bool = True
    prevent_rapid_direction_flip: bool = True
    direction_flip_cooldown_seconds: int = 300
    same_zone_cooldown_seconds: int = 300
    max_raw_signals_per_day_warning: int = 100

    @classmethod
    def from_mapping(cls, values: dict[str, Any] | None = None, **overrides: Any) -> "ClusterSignalQualityConfig":
        data = dict(values or {})
        data.update({key: value for key, value in overrides.items() if value is not None})
        return cls(
            enabled=bool(data.get("enabled", True)),
            min_score=float(data.get("min_score", 8.5)),
            min_trap_strength=float(data.get("min_trap_strength", 0.65)),
            min_volume_or_ltq=float(data.get("min_volume_or_ltq", 1.0)),
            min_stop_distance=float(data.get("min_stop_distance", 5.0)),
            max_stop_distance=float(data.get("max_stop_distance", 600.0)),
            min_target_distance=float(data.get("min_target_distance", 10.0)),
            require_market_mode_alignment=bool(data.get("require_market_mode_alignment", True)),
            prevent_rapid_direction_flip=bool(data.get("prevent_rapid_direction_flip", True)),
            direction_flip_cooldown_seconds=max(0, int(data.get("direction_flip_cooldown_seconds", 300))),
            same_zone_cooldown_seconds=max(0, int(data.get("same_zone_cooldown_seconds", 300))),
            max_raw_signals_per_day_warning=max(1, int(data.get("max_raw_signals_per_day_warning", 100))),
        )


@dataclass(frozen=True)
class ClusterSignalQualityDecision:
    accepted: bool
    status: str
    reasons: tuple[str, ...] = ()
    reason_codes: tuple[str, ...] = ()
    trap_strength: float = 0.0

    @property
    def reason_text(self) -> str:
        return "; ".join(self.reasons)


@dataclass
class ClusterSignalQualityState:
    last_direction: dict[str, tuple[str, datetime]] = field(default_factory=dict)
    last_zone_signal: dict[tuple[str, str, float], datetime] = field(default_factory=dict)

    def evaluate(
        self,
        signal: Signal,
        signal_time: datetime,
        config: ClusterSignalQualityConfig,
    ) -> ClusterSignalQualityDecision:
        trap_strength = float(signal.metadata.get("trap_strength") or 0.0)
        if not config.enabled or signal.setup_type != "cluster_imbalance_trap":
            return ClusterSignalQualityDecision(True, "QUALITY_ACCEPTED", trap_strength=trap_strength)

        reasons: list[str] = []
        codes: list[str] = []
        stop_distance = abs(float(signal.entry_price) - float(signal.stop_loss))
        target_distance = abs(float(signal.target_price) - float(signal.entry_price))
        latest_volume = float(
            signal.metadata.get("latest_ltq")
            or signal.metadata.get("signal_volume")
            or signal.metadata.get("volume")
            or 0.0
        )

        if float(signal.score) < config.min_score:
            _reject(reasons, codes, "LOW_SCORE", f"score {signal.score} below minimum {config.min_score}")
        if trap_strength < config.min_trap_strength:
            _reject(
                reasons,
                codes,
                "WEAK_TRAP",
                f"trap strength {trap_strength:.3f} below minimum {config.min_trap_strength:.3f}",
            )
        if latest_volume < config.min_volume_or_ltq:
            _reject(
                reasons,
                codes,
                "LOW_VOLUME",
                f"LTQ/volume {latest_volume:g} below minimum {config.min_volume_or_ltq:g}",
            )
        if stop_distance < config.min_stop_distance:
            _reject(
                reasons,
                codes,
                "BAD_STOP_DISTANCE",
                f"stop distance {stop_distance:.2f} below minimum {config.min_stop_distance:.2f}",
            )
        elif stop_distance > config.max_stop_distance:
            _reject(
                reasons,
                codes,
                "BAD_STOP_DISTANCE",
                f"stop distance {stop_distance:.2f} above maximum {config.max_stop_distance:.2f}",
            )
        if target_distance < config.min_target_distance:
            _reject(
                reasons,
                codes,
                "BAD_TARGET_DISTANCE",
                f"target distance {target_distance:.2f} below minimum {config.min_target_distance:.2f}",
            )
        if config.require_market_mode_alignment and not _market_mode_aligned(signal.side, signal.market_mode):
            _reject(
                reasons,
                codes,
                "MARKET_MODE",
                f"{signal.side} signal is not aligned with market mode {signal.market_mode}",
            )

        previous_direction = self.last_direction.get(signal.symbol)
        if (
            config.prevent_rapid_direction_flip
            and previous_direction is not None
            and previous_direction[0] != signal.side
            and (signal_time - previous_direction[1]).total_seconds() < config.direction_flip_cooldown_seconds
        ):
            _reject(
                reasons,
                codes,
                "DIRECTION_FLIP",
                f"rapid direction flip from {previous_direction[0]} to {signal.side} inside "
                f"{config.direction_flip_cooldown_seconds}s",
            )

        zone = _signal_zone(signal)
        previous_zone_time = self.last_zone_signal.get((signal.symbol, signal.side, zone))
        if (
            previous_zone_time is not None
            and (signal_time - previous_zone_time).total_seconds() < config.same_zone_cooldown_seconds
        ):
            _reject(
                reasons,
                codes,
                "SAME_ZONE",
                f"same-zone {signal.side} signal repeated inside {config.same_zone_cooldown_seconds}s",
            )

        if reasons:
            return ClusterSignalQualityDecision(
                False,
                "QUALITY_REJECTED",
                tuple(reasons),
                tuple(codes),
                trap_strength,
            )

        self.last_direction[signal.symbol] = (signal.side, signal_time)
        self.last_zone_signal[(signal.symbol, signal.side, zone)] = signal_time
        return ClusterSignalQualityDecision(True, "QUALITY_ACCEPTED", trap_strength=trap_strength)


def _reject(reasons: list[str], codes: list[str], code: str, reason: str) -> None:
    if code not in codes:
        codes.append(code)
    reasons.append(reason)


def _signal_zone(signal: Signal) -> float:
    value = signal.metadata.get("cluster_zone")
    if value is None:
        value = signal.key_level if signal.key_level is not None else signal.entry_price
    return round(float(value), 2)


def _market_mode_aligned(side: str, market_mode: str) -> bool:
    mode = str(market_mode or "").upper()
    direction = str(side or "").upper()
    if direction == "BUY":
        return mode in {"TREND_UP", "TRAP_REVERSAL"}
    if direction == "SELL":
        return mode in {"TREND_DOWN", "TRAP_REVERSAL"}
    return False
