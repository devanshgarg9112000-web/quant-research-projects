from __future__ import annotations


def generate_signal(candles: list[dict], context: dict):
    """Disabled placeholder for future MCX metals and energy research."""

    return None
