from __future__ import annotations


class AbnormalFlowDetector:
    """Detects unusual order-flow events without calling them manipulation."""

    def classify(self, context: dict) -> str:
        return context.get("order_flow", {}).get("event", "UNCLEAR")


def generate_signal(candles: list[dict], context: dict):
    # Abnormal flow is a confirmation layer in this MVP. It does not force trades alone.
    return None
