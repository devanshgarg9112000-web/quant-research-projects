from __future__ import annotations

from src.indicators.opening_range import calculate_opening_range
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 4:
        return None
    last = candles[-1]
    opening = calculate_opening_range(candles)
    level = opening["opening_range_high"]
    if last["high"] > level and last["close"] < level and last["close"] < last["open"]:
        entry = last["close"]
        stop = last["high"] + 5
        risk = stop - entry
        return make_signal(candles, "Failed Breakout Short", "SELL", entry, stop, entry - 2 * risk, 8.5, "Buy imbalance failed above ORH, price closed back below level", context["market_mode"], "failed_breakout", level)
    return None
