from __future__ import annotations

from datetime import date, datetime, time
from typing import Any

from src.options.black_scholes import black_scholes_price
from src.options.option_chain import infer_option_type, infer_strike


MODEL_WARNING_MESSAGE = "MODEL WARNING: fair value reference appears miscalibrated. Do not treat scanner rows as trade signals."


def scan_opening_option_mispricing(
    underlying_symbol: str,
    spot_reference: float,
    previous_close: float,
    option_quote_snapshots: list[dict],
    expiry: str,
    risk_free_rate: float = 0.065,
    default_iv: float = 0.18,
    min_mispricing_pct: float = 15.0,
    min_depth_quantity: int = 50,
    min_bid_qty: int | None = None,
    min_ask_qty: int | None = None,
    max_spread_pct: float = 20.0,
    max_signals: int = 10,
    tick_size: float = 0.05,
    suggested_limit_offset_ticks: int = 1,
) -> list[dict]:
    min_bid_qty = int(min_depth_quantity if min_bid_qty is None else min_bid_qty)
    min_ask_qty = int(min_depth_quantity if min_ask_qty is None else min_ask_qty)
    diagnostics = build_option_mispricing_diagnostics(
        underlying_symbol=underlying_symbol,
        spot_reference=spot_reference,
        previous_close=previous_close,
        option_quote_snapshots=option_quote_snapshots,
        expiry=expiry,
        risk_free_rate=risk_free_rate,
        default_iv=default_iv,
        max_spread_pct=max_spread_pct,
    )
    rows: list[dict] = []
    for item in diagnostics:
        if not item["spread_ok"]:
            continue
        bid_mispricing_pct = item["bid_mispricing_pct"]
        ask_mispricing_pct = item["ask_mispricing_pct"]
        bid_qty = item["bid_qty"]
        ask_qty = item["ask_qty"]
        if bid_mispricing_pct >= min_mispricing_pct and bid_qty >= min_bid_qty:
            rows.append(_scanner_row(
                symbol=item["symbol"],
                underlying_symbol=underlying_symbol,
                option_type=item["option_type"],
                strike=item["strike"],
                expiry=expiry,
                fair_price=item["fair_price"],
                best_bid=item["best_bid"],
                best_ask=item["best_ask"],
                spread_pct=item["spread_pct"],
                bid_qty=bid_qty,
                ask_qty=ask_qty,
                mispricing_pct=bid_mispricing_pct,
                suggested_action="SELL",
                reason="visible bid is above model fair value",
                tick_size=tick_size,
                suggested_limit_offset_ticks=suggested_limit_offset_ticks,
            ))
        if ask_mispricing_pct <= -min_mispricing_pct and ask_qty >= min_ask_qty:
            rows.append(_scanner_row(
                symbol=item["symbol"],
                underlying_symbol=underlying_symbol,
                option_type=item["option_type"],
                strike=item["strike"],
                expiry=expiry,
                fair_price=item["fair_price"],
                best_bid=item["best_bid"],
                best_ask=item["best_ask"],
                spread_pct=item["spread_pct"],
                bid_qty=bid_qty,
                ask_qty=ask_qty,
                mispricing_pct=ask_mispricing_pct,
                suggested_action="BUY",
                reason="visible ask is below model fair value",
                tick_size=tick_size,
                suggested_limit_offset_ticks=suggested_limit_offset_ticks,
            ))

    rows.sort(key=lambda row: abs(row["mispricing_pct"]), reverse=True)
    return rows[:max(0, int(max_signals))]


def build_option_mispricing_diagnostics(
    underlying_symbol: str,
    spot_reference: float,
    previous_close: float,
    option_quote_snapshots: list[dict],
    expiry: str,
    risk_free_rate: float = 0.065,
    default_iv: float = 0.18,
    max_spread_pct: float = 20.0,
) -> list[dict]:
    diagnostics: list[dict] = []
    spot = _safe_positive_float(spot_reference) or _safe_positive_float(previous_close)
    time_to_expiry = calculate_time_to_expiry_years(expiry)
    if not spot or time_to_expiry <= 0:
        return []
    for snapshot in option_quote_snapshots or []:
        symbol = str(snapshot.get("symbol") or snapshot.get("tradingsymbol") or snapshot.get("instrument") or "").strip()
        option_type = infer_option_type(symbol)
        if option_type not in {"CALL", "PUT"}:
            option_type = _option_type_from_snapshot(snapshot)
        strike = _safe_positive_float(snapshot.get("strike")) or infer_strike(symbol)
        if option_type not in {"CALL", "PUT"} or not strike:
            continue
        fair_price = black_scholes_price(spot, strike, time_to_expiry, risk_free_rate, default_iv, option_type)
        if fair_price <= 0:
            continue
        best_bid, bid_qty = _best_depth(snapshot, "buy", "best_bid", "bid_qty")
        best_ask, ask_qty = _best_depth(snapshot, "sell", "best_ask", "ask_qty")
        if not best_bid or not best_ask or best_bid <= 0 or best_ask <= 0:
            continue
        spread_pct = (best_ask - best_bid) / fair_price * 100.0
        bid_mispricing_pct = (best_bid - fair_price) / fair_price * 100.0
        ask_mispricing_pct = (best_ask - fair_price) / fair_price * 100.0
        diagnostics.append({
            "symbol": symbol,
            "underlying_symbol": underlying_symbol,
            "option_type": option_type,
            "strike": float(strike),
            "expiry": expiry,
            "fair_price": round(float(fair_price), 2),
            "best_bid": round(float(best_bid), 2),
            "best_ask": round(float(best_ask), 2),
            "mid_price": round((float(best_bid) + float(best_ask)) / 2.0, 2),
            "spread_pct": round(float(spread_pct), 2),
            "bid_qty": int(bid_qty),
            "ask_qty": int(ask_qty),
            "bid_mispricing_pct": round(float(bid_mispricing_pct), 2),
            "ask_mispricing_pct": round(float(ask_mispricing_pct), 2),
            "abs_extreme_mispricing_pct": round(max(abs(bid_mispricing_pct), abs(ask_mispricing_pct)), 2),
            "spread_ok": spread_pct >= 0 and spread_pct <= max_spread_pct,
            "dry_run": True,
        })
    return diagnostics


def detect_model_reference_warning(
    rows_or_quotes: list[dict],
    fair_values: list[float] | None = None,
    option_quote_snapshots: list[dict] | None = None,
    max_model_warning_ratio: float = 0.35,
    min_mispricing_pct: float = 15.0,
    market_iv_available: bool = False,
) -> str | None:
    details = detect_model_reference_warning_details(
        rows_or_quotes=rows_or_quotes,
        max_model_warning_ratio=max_model_warning_ratio,
        min_mispricing_pct=min_mispricing_pct,
        market_iv_available=market_iv_available,
    )
    return MODEL_WARNING_MESSAGE if details["warning"] else None


def detect_model_reference_warning_details(
    rows_or_quotes: list[dict],
    max_model_warning_ratio: float = 0.35,
    min_mispricing_pct: float = 15.0,
    market_iv_available: bool = False,
) -> dict:
    rows = rows_or_quotes or []
    if not rows:
        return {"warning": False, "reasons": [], "reason_text": ""}
    calls = [row for row in rows if row.get("option_type") == "CALL"]
    puts = [row for row in rows if row.get("option_type") == "PUT"]
    reasons: list[str] = []
    if _ratio_above(calls, "bid_mispricing_pct", min_mispricing_pct) >= 0.70 and len(calls) >= 3:
        if not market_iv_available:
            reasons.append("broad-side mispricing")
    if _ratio_below(puts, "ask_mispricing_pct", -min_mispricing_pct) >= 0.70 and len(puts) >= 3:
        if not market_iv_available:
            reasons.append("broad-side mispricing")
    extreme = [row for row in rows if float(row.get("abs_extreme_mispricing_pct", abs(float(row.get("mispricing_pct", 0.0))))) >= 75.0]
    if len(rows) >= 3 and len(extreme) / len(rows) >= 0.60:
        reasons.append("extreme mispricing across most strikes")
    if _atm_straddle_ratio_exceeds(rows, max_model_warning_ratio):
        reasons.append("straddle premium mismatch")
    deduped = list(dict.fromkeys(reasons))
    return {"warning": bool(deduped), "reasons": deduped, "reason_text": ", ".join(deduped)}


def generate_signal(candles: list[dict], context: dict):
    """Strategy-engine compatibility hook.

    The opening option mispricing workflow is intentionally scanner-only for now,
    so this does not create executable trade signals.
    """

    if context.get("option_quote_snapshots"):
        context["opening_option_mispricing_rows"] = scan_opening_option_mispricing(
            underlying_symbol=context.get("underlying_symbol", "NIFTY"),
            spot_reference=context.get("spot_reference", 0),
            previous_close=context.get("previous_close", 0),
            option_quote_snapshots=context.get("option_quote_snapshots", []),
            expiry=context.get("expiry", ""),
            risk_free_rate=float(context.get("risk_free_rate", 0.065)),
            default_iv=float(context.get("default_iv", 0.18)),
            min_mispricing_pct=float(context.get("min_mispricing_pct", 15.0)),
            min_depth_quantity=int(context.get("min_depth_quantity", 50)),
            max_spread_pct=float(context.get("max_spread_pct", 20.0)),
            max_signals=int(context.get("max_signals", 10)),
            tick_size=float(context.get("tick_size", 0.05)),
            suggested_limit_offset_ticks=int(context.get("suggested_limit_offset_ticks", 1)),
        )
    return None


def _scanner_row(
    symbol: str,
    underlying_symbol: str,
    option_type: str,
    strike: float,
    expiry: str,
    fair_price: float,
    best_bid: float,
    best_ask: float,
    spread_pct: float,
    bid_qty: int,
    ask_qty: int,
    mispricing_pct: float,
    suggested_action: str,
    reason: str,
    tick_size: float = 0.05,
    suggested_limit_offset_ticks: int = 1,
) -> dict:
    return {
        "symbol": symbol,
        "underlying_symbol": underlying_symbol,
        "option_type": option_type,
        "strike": float(strike),
        "expiry": expiry,
        "fair_price": round(float(fair_price), 2),
        "best_bid": round(float(best_bid), 2),
        "best_ask": round(float(best_ask), 2),
        "spread_pct": round(float(spread_pct), 2),
        "bid_qty": int(bid_qty),
        "ask_qty": int(ask_qty),
        "mispricing_pct": round(float(mispricing_pct), 2),
        "suggested_action": suggested_action,
        "confidence": _confidence_score(mispricing_pct, spread_pct),
        "reason": reason,
        **_scanner_risk_metadata(suggested_action),
        **_opening_spike_planner_metadata(
            suggested_action=suggested_action,
            fair_price=fair_price,
            best_bid=best_bid,
            best_ask=best_ask,
            tick_size=tick_size,
            suggested_limit_offset_ticks=suggested_limit_offset_ticks,
        ),
        "dry_run": True,
    }


def _best_depth(snapshot: dict[str, Any], side: str, direct_price_key: str, direct_qty_key: str) -> tuple[float | None, int]:
    price = _safe_positive_float(snapshot.get(direct_price_key))
    quantity = _safe_int(snapshot.get(direct_qty_key))
    if price is not None:
        return price, quantity
    depth = snapshot.get("depth") or {}
    levels = depth.get(side) if isinstance(depth, dict) else None
    if isinstance(levels, list) and levels:
        first = levels[0] or {}
        return _safe_positive_float(first.get("price")), _safe_int(first.get("quantity"))
    return None, 0


def _option_type_from_snapshot(snapshot: dict[str, Any]) -> str:
    raw = str(snapshot.get("option_type") or snapshot.get("instrument_type") or "").strip().upper()
    if raw in {"CALL", "CE"}:
        return "CALL"
    if raw in {"PUT", "PE"}:
        return "PUT"
    return "UNKNOWN"


def _scanner_risk_metadata(suggested_action: str) -> dict:
    if str(suggested_action).strip().upper() == "SELL":
        return {
            "execution_allowed": False,
            "hedge_required": True,
            "risk_note": "Option selling is blocked in scanner mode. Hedge required. Dry-run only.",
        }
    return {
        "execution_allowed": False,
        "hedge_required": False,
        "risk_note": "Option buying is scanner-only. Manual review required. Dry-run only.",
    }


def _opening_spike_planner_metadata(
    suggested_action: str,
    fair_price: float,
    best_bid: float,
    best_ask: float,
    tick_size: float = 0.05,
    suggested_limit_offset_ticks: int = 1,
) -> dict:
    action = str(suggested_action).strip().upper()
    fair = round(float(fair_price), 2)
    tick = _safe_positive_float(tick_size) or 0.05
    offset = tick * max(0, int(suggested_limit_offset_ticks))
    if action == "SELL":
        suggested_limit = round(max(float(best_bid) - offset, fair), 2)
        edge_points = round(suggested_limit - fair, 2)
        edge_pct = round((edge_points / fair * 100.0) if fair > 0 else 0.0, 2)
        return {
            "visible_match_price": round(float(best_bid), 2),
            "visible_match_side": "BUYER_BID",
            "suggested_limit_price": suggested_limit,
            "suggested_limit_rule": "SELL near visible buyer bid minus one tick",
            "fair_exit_price": fair,
            "expected_gross_edge_points": edge_points,
            "expected_gross_edge_pct": edge_pct,
            "tick_size": round(float(tick), 4),
            "max_adverse_price_note": "If option spikes further above entry, naked short risk can be large. Hedge required.",
            "exit_plan": "Target exit near model fair value if price settles; manual review required.",
            "planner_note": "Opening spike planner only. Visible orders can disappear or not fill.",
        }
    suggested_limit = round(min(float(best_ask) + offset, fair), 2)
    edge_points = round(fair - suggested_limit, 2)
    edge_pct = round((edge_points / suggested_limit * 100.0) if suggested_limit > 0 else 0.0, 2)
    return {
        "visible_match_price": round(float(best_ask), 2),
        "visible_match_side": "SELLER_ASK",
        "suggested_limit_price": suggested_limit,
        "suggested_limit_rule": "BUY near visible seller ask plus one tick",
        "fair_exit_price": fair,
        "expected_gross_edge_points": edge_points,
        "expected_gross_edge_pct": edge_pct,
        "tick_size": round(float(tick), 4),
        "max_adverse_price_note": "If fair model is wrong or market falls further, option can lose value.",
        "exit_plan": "Target exit near model fair value if price settles; manual review required.",
        "planner_note": "Opening spike planner only. Visible orders can disappear or not fill.",
    }


def calculate_time_to_expiry_years(expiry: str, now: datetime | None = None) -> float:
    try:
        expiry_date = datetime.strptime(str(expiry), "%Y-%m-%d").date()
    except ValueError:
        return 0.0
    now = now or datetime.now()
    expiry_close = datetime.combine(expiry_date, time(15, 30))
    seconds = (expiry_close - now).total_seconds()
    if seconds <= 0 and expiry_date == now.date():
        seconds = 60.0
    if seconds <= 0:
        return 0.0
    return seconds / (365.0 * 24.0 * 60.0 * 60.0)


def _time_to_expiry_years(expiry: str) -> float:
    return calculate_time_to_expiry_years(expiry)


def _confidence_score(mispricing_pct: float, spread_pct: float) -> float:
    mispricing_component = min(abs(mispricing_pct) / 5.0, 8.0)
    spread_penalty = min(max(spread_pct, 0.0) / 10.0, 3.0)
    return round(max(1.0, min(10.0, 4.0 + mispricing_component - spread_penalty)), 1)


def _safe_positive_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _safe_int(value: Any) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def _ratio_above(rows: list[dict], key: str, threshold: float) -> float:
    if not rows:
        return 0.0
    return sum(1 for row in rows if float(row.get(key, 0.0)) >= threshold) / len(rows)


def _ratio_below(rows: list[dict], key: str, threshold: float) -> float:
    if not rows:
        return 0.0
    return sum(1 for row in rows if float(row.get(key, 0.0)) <= threshold) / len(rows)


def _atm_straddle_ratio_exceeds(rows: list[dict], max_model_warning_ratio: float) -> bool:
    by_strike: dict[float, dict[str, dict]] = {}
    for row in rows:
        by_strike.setdefault(float(row["strike"]), {})[row["option_type"]] = row
    paired = [(strike, pair) for strike, pair in by_strike.items() if "CALL" in pair and "PUT" in pair]
    if not paired:
        return False
    strike, pair = min(paired, key=lambda item: abs(item[1]["CALL"].get("best_bid", 0.0) - item[1]["PUT"].get("best_bid", 0.0)))
    model_premium = pair["CALL"]["fair_price"] + pair["PUT"]["fair_price"]
    market_premium = pair["CALL"]["mid_price"] + pair["PUT"]["mid_price"]
    if model_premium <= 0:
        return False
    return abs(market_premium - model_premium) / model_premium > max_model_warning_ratio
