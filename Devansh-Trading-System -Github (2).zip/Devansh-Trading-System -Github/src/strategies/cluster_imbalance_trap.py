from __future__ import annotations

from src.indicators.opening_range import calculate_opening_range
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 4:
        return None
    diagnostics = context.get("cluster_diagnostics") or {}
    if diagnostics.get("data_sufficient"):
        status = diagnostics.get("cluster_imbalance_trap_status")
        last = candles[-1]
        recent_ranges = [max(float(candle["high"]) - float(candle["low"]), 0.0) for candle in candles[-3:]]
        buffer = max(1.0, (sum(recent_ranges) / max(len(recent_ranges), 1)) * 0.10)
        if status == "ESTIMATED_BUYER_TRAP_POSSIBLE":
            entry = float(last["close"])
            reference = max(diagnostics.get("buy_imbalance_levels") or [float(last["high"])])
            stop = max(float(last["high"]), float(reference)) + buffer
            risk = stop - entry
            if risk > 0:
                return _attach_quality_metadata(make_signal(
                    candles,
                    "MCX Estimated Buyer Trap Short",
                    "SELL",
                    entry,
                    stop,
                    entry - 2 * risk,
                    8.8,
                    "Data-sufficient ESTIMATED buyer-trap cluster diagnostic confirmed a PAPER-only short setup",
                    context["market_mode"],
                    "cluster_imbalance_trap",
                    float(reference),
                ), diagnostics, reference)
        if status == "ESTIMATED_SELLER_TRAP_POSSIBLE":
            entry = float(last["close"])
            reference = min(diagnostics.get("sell_imbalance_levels") or [float(last["low"])])
            stop = min(float(last["low"]), float(reference)) - buffer
            risk = entry - stop
            if risk > 0:
                return _attach_quality_metadata(make_signal(
                    candles,
                    "MCX Estimated Seller Trap Long",
                    "BUY",
                    entry,
                    stop,
                    entry + 2 * risk,
                    8.8,
                    "Data-sufficient ESTIMATED seller-trap cluster diagnostic confirmed a PAPER-only long setup",
                    context["market_mode"],
                    "cluster_imbalance_trap",
                    float(reference),
                ), diagnostics, reference)
    clusters = context.get("clusters", [])
    last = candles[-1]
    opening = calculate_opening_range(candles)
    stacked_buy = any(r.get("stacked_buy_imbalance") for r in clusters)
    stacked_sell = any(r.get("stacked_sell_imbalance") for r in clusters)
    if stacked_buy and last["high"] > opening["opening_range_high"] and last["close"] < opening["opening_range_high"]:
        entry = last["close"]
        stop = last["high"] + 5
        risk = stop - entry
        return _attach_quality_metadata(
            make_signal(candles, "Cluster Imbalance Trap Short", "SELL", entry, stop, entry - 2 * risk, 8.8, "Stacked buy imbalance failed at resistance, showing buyer absorption", context["market_mode"], "cluster_imbalance_trap", opening["opening_range_high"]),
            diagnostics,
            opening["opening_range_high"],
            fallback_strength=0.75,
        )
    if stacked_sell and last["low"] < opening["opening_range_low"] and last["close"] > opening["opening_range_low"]:
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        return _attach_quality_metadata(
            make_signal(candles, "Cluster Imbalance Trap Long", "BUY", entry, stop, entry + 2 * risk, 8.8, "Stacked sell imbalance failed at support, showing seller absorption", context["market_mode"], "cluster_imbalance_trap", opening["opening_range_low"]),
            diagnostics,
            opening["opening_range_low"],
            fallback_strength=0.75,
        )
    return None


def _attach_quality_metadata(signal, diagnostics: dict, zone: float, fallback_strength: float = 0.0):
    signal.metadata.update({
        "trap_strength": float(diagnostics.get("trap_strength") or fallback_strength),
        "latest_ltq": float(diagnostics.get("latest_ltq") or 0.0),
        "cluster_zone": float(zone),
    })
    return signal
