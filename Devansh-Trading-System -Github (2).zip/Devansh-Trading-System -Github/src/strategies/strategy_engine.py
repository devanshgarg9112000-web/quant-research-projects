from __future__ import annotations

from dataclasses import dataclass

from src.indicators.absorption import detect_absorption
from src.indicators.cluster import build_cluster_table
from src.indicators.cluster_diagnostics import (
    MCX_CLUSTER_SYMBOLS,
    build_mcx_cluster_gate,
    build_symbol_diagnostics,
    evaluate_mcx_cluster_gate_for_side,
)
from src.indicators.key_levels import calculate_key_levels
from src.indicators.opening_range import calculate_opening_range
from src.indicators.order_flow import analyze_order_flow
from src.indicators.support_resistance import find_support_resistance
from src.indicators.volume_profile import calculate_volume_profile
from src.indicators.vwap import calculate_vwap
from src.market_context.regime_router import route_regime
from src.models.signal import Signal
from src.scoring.conflict_resolver import resolve_conflicts

from . import abnormal_flow, breakout_acceptance, breakdown_acceptance, cluster_imbalance_trap, failed_breakdown, failed_breakout, opening_option_mispricing, mcx_metals, poc_magnet, trend_day_vwap_pullback, value_area_rejection, vwap_reclaim, vwap_rejection


STRATEGY_MODULES = {
    "breakout_acceptance": breakout_acceptance,
    "breakdown_acceptance": breakdown_acceptance,
    "failed_breakout": failed_breakout,
    "failed_breakdown": failed_breakdown,
    "vwap_reclaim": vwap_reclaim,
    "vwap_rejection": vwap_rejection,
    "value_area_rejection": value_area_rejection,
    "poc_magnet": poc_magnet,
    "trend_day_vwap_pullback": trend_day_vwap_pullback,
    "cluster_imbalance_trap": cluster_imbalance_trap,
    "abnormal_flow": abnormal_flow,
    "opening_option_mispricing": opening_option_mispricing,
    "mcx_metals": mcx_metals,
}


@dataclass
class StrategyEngineResult:
    best_signal: Signal | None
    candidates: list[Signal]
    rejected_reasons: list[str]
    market_mode: str
    context: dict


class StrategyEngine:
    """Runs enabled strategies after market context is calculated."""

    def __init__(self, settings: dict, strategies: dict):
        self.settings = settings
        self.strategies = strategies

    def build_context(self, candles: list[dict], ticks: list[dict] | None = None) -> dict:
        ticks = ticks or []
        route = route_regime(candles, self.settings)
        vwap_rows = calculate_vwap(candles)
        key_levels = calculate_key_levels(candles)
        clusters = build_cluster_table(ticks) if ticks else []
        order_flow = analyze_order_flow(ticks) if ticks else {"event": "UNCLEAR", "clusters": []}
        context = {
            "market_mode": route["market_mode"],
            "preferred_strategies": route["preferred_strategies"],
            "vwap": vwap_rows,
            "key_levels": key_levels,
            "opening_range": calculate_opening_range(candles),
            "support_resistance": find_support_resistance(candles),
            "volume_profile": calculate_volume_profile(candles),
            "clusters": clusters,
            "order_flow": order_flow,
        }
        symbol = str(candles[-1].get("symbol") or "") if candles else ""
        if symbol in MCX_CLUSTER_SYMBOLS:
            diagnostics = build_symbol_diagnostics(symbol, ticks, bucket_seconds=15)
            context["cluster_diagnostics"] = diagnostics
            context["cluster_gate"] = build_mcx_cluster_gate(diagnostics)
        else:
            context["cluster_diagnostics"] = {}
            context["cluster_gate"] = build_mcx_cluster_gate({"symbol": symbol})
        context["absorption"] = detect_absorption(candles, clusters, key_levels) if clusters else {}
        return context

    def run(self, candles: list[dict], ticks: list[dict] | None = None) -> StrategyEngineResult:
        context = self.build_context(candles, ticks)
        min_score = float(self.settings.get("min_signal_score", 7))
        candidates: list[Signal] = []
        rejected: list[str] = []
        if context["market_mode"] == "HIGH_VOLATILITY_NEWS":
            return StrategyEngineResult(None, [], ["High volatility news mode: no trade."], context["market_mode"], context)
        for name, module in STRATEGY_MODULES.items():
            if not self.strategies.get(name, False):
                rejected.append(f"{name}: disabled in config/strategies.yaml")
                continue
            signal = module.generate_signal(candles, context)
            if signal is None:
                rejected.append(f"{name}: no confirmed setup on latest candle")
                continue
            if signal.score < min_score:
                rejected.append(f"{name}: score {signal.score} below minimum {min_score}")
                continue
            candle_only_without_ticks = bool(self.settings.get("candle_only_backtest")) and not ticks
            if candle_only_without_ticks and name != "cluster_imbalance_trap":
                gate_allowed = True
                gate_reason = "MCX cluster gate not applicable to candle-only historical strategy validation."
                gate_result = "NOT_APPLICABLE_CANDLE_ONLY"
            else:
                gate_allowed, gate_reason, gate_result = evaluate_mcx_cluster_gate_for_side(
                    context["cluster_gate"],
                    signal.side,
                )
            signal.metadata.update({
                "cluster_gate_result": gate_result,
                "cluster_gate_reason": gate_reason,
                "cluster_diagnostic_status": context["cluster_gate"].get("diagnostic_status"),
                "cluster_data_sufficient": context["cluster_gate"].get("data_sufficient"),
                "execution_allowed": False,
            })
            if not gate_allowed:
                rejected.append(f"{name}: {gate_reason}")
                continue
            candidates.append(signal)
        best, resolver_notes = resolve_conflicts(candidates)
        rejected.extend(resolver_notes)
        gate = context["cluster_gate"]
        if gate.get("applicable") and not candidates:
            rejected.append(f"MCX cluster gate {gate['gate_status']}: {gate['reason']}")
        return StrategyEngineResult(best, candidates, rejected, context["market_mode"], context)
