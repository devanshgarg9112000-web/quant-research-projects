from __future__ import annotations

from src.indicators.opening_range import calculate_opening_range
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 5:
        return None
    last = candles[-1]
    prev = candles[-2]
    level = calculate_opening_range(candles)["opening_range_high"]
    if prev["close"] <= level and last["close"] > level and last["close"] > last["open"]:
        entry = last["close"]
        stop = min(last["low"], level - 5)
        risk = entry - stop
        return make_signal(candles, "Breakout Acceptance Long", "BUY", entry, stop, entry + 2 * risk, 7.8, "Price accepted above opening range high with bullish close", context["market_mode"], "breakout_acceptance", level)
    return None
