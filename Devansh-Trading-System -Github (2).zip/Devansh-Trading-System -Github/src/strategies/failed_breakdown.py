from __future__ import annotations

from src.indicators.opening_range import calculate_opening_range
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 4:
        return None
    last = candles[-1]
    opening = calculate_opening_range(candles)
    level = opening["opening_range_low"]
    if last["low"] < level and last["close"] > level and last["close"] > last["open"]:
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        return make_signal(candles, "Failed Breakdown Long", "BUY", entry, stop, entry + 2 * risk, 8.4, "Sell imbalance failed below ORL, price reclaimed the level", context["market_mode"], "failed_breakdown", level)
    return None
