from __future__ import annotations

from src.indicators.volume_profile import calculate_volume_profile
from .base_strategy import make_signal


def generate_signal(candles: list[dict], context: dict):
    if len(candles) < 8:
        return None
    last = candles[-1]
    profile = context.get("volume_profile") or calculate_volume_profile(candles[:-1])
    vah = profile["vah"]
    val = profile["val"]
    if last["high"] > vah and last["close"] < vah:
        entry = last["close"]
        stop = last["high"] + 5
        risk = stop - entry
        target = max(profile["poc"], entry - 2 * risk)
        return make_signal(candles, "Value Area Rejection Short", "SELL", entry, stop, target, 7.6, "Price failed above VAH and returned inside value", context["market_mode"], "value_area_rejection", vah)
    if last["low"] < val and last["close"] > val:
        entry = last["close"]
        stop = last["low"] - 5
        risk = entry - stop
        target = min(profile["poc"], entry + 2 * risk)
        return make_signal(candles, "Value Area Rejection Long", "BUY", entry, stop, target, 7.6, "Price failed below VAL and returned inside value", context["market_mode"], "value_area_rejection", val)
    return None
