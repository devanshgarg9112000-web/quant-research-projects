from pathlib import Path
from kiteconnect import KiteConnect
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / ".env"

def load_env(path):
    data = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            data[k.strip()] = v.strip()
    return data

def upsert_env(path, key, value):
    lines = []
    found = False

    if path.exists():
        lines = path.read_text(encoding="utf-8").splitlines()

    new_lines = []
    for line in lines:
        if line.strip().startswith(key + "="):
            new_lines.append(f"{key}={value}")
            found = True
        else:
            new_lines.append(line)

    if not found:
        new_lines.append(f"{key}={value}")

    path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

env = load_env(ENV_PATH)
api_key = env.get("KITE_API_KEY")
api_secret = env.get("KITE_API_SECRET")

if not api_key or not api_secret:
    raise SystemExit("Missing KITE_API_KEY or KITE_API_SECRET in .env")

print("KITE ACCESS TOKEN GENERATOR")
print("No secrets will be printed.")
print()
print("1) Open this login URL in Chrome:")
print(f"https://kite.trade/connect/login?api_key={api_key}&v=3")
print()
print("2) Login to Zerodha manually.")
print("3) After redirect, copy the full redirected URL OR only request_token.")
print()

raw = input("Paste redirected URL or request_token here: ").strip()

request_token = raw
if "request_token=" in raw:
    query = parse_qs(urlparse(raw).query)
    request_token = query.get("request_token", [""])[0]

if not request_token:
    raise SystemExit("Could not find request_token.")

kite = KiteConnect(api_key=api_key)
session = kite.generate_session(request_token, api_secret=api_secret)
access_token = session["access_token"]

upsert_env(ENV_PATH, "KITE_ACCESS_TOKEN", access_token)

print()
print("SUCCESS: KITE_ACCESS_TOKEN saved to .env")
print("Token value was NOT printed.")
print()
print('Now run:')
print('python -m src.data_collection.kite_readonly_check --symbols "GOLD-I" --dry-run false')


