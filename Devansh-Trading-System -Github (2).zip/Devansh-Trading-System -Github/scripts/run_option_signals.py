from src.option_signals.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
