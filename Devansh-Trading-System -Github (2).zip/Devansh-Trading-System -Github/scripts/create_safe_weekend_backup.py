from __future__ import annotations

import argparse
import csv
import hashlib
import re
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable


BACKUP_DIR = Path("backups")
STAGE_NOTE = "Stage 0 infrastructure/data readiness; not tradeable Launch 1"
REPORT_PATH = Path("reports") / "backups" / "latest_safe_backup_report.txt"
HISTORY_PATH = Path("reports") / "backups" / "safe_backup_history.csv"
MANIFEST_ZIP_PATH = "reports/backups/latest_safe_backup_report.txt"
DEFAULT_INCLUDE_PATHS = [
    Path("src"),
    Path("scripts"),
    Path("tests"),
    Path("docs"),
    Path("config"),
    Path("reports"),
    Path("data") / "kite_recorded",
    Path("data") / "kite_instruments",
    Path("requirements.txt"),
    Path("pyproject.toml"),
    Path("pytest.ini"),
    Path("README.md"),
    Path("NEXT_STEPS.md"),
    Path("run.py"),
]
EXCLUDED_DIR_NAMES = {
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".git",
    ".idea",
    ".vscode",
    "node_modules",
    "backups",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
TEXT_SUFFIXES = {
    ".py",
    ".yaml",
    ".yml",
    ".txt",
    ".md",
    ".csv",
    ".json",
    ".ini",
    ".toml",
    ".ps1",
    ".bat",
    ".example",
}
SECRET_KEYS = [
    "KITE_API_KEY",
    "KITE_API_SECRET",
    "KITE_ACCESS_TOKEN",
    "request_token",
    "access_token",
    "api_secret",
    "api_key",
]
HISTORY_COLUMNS = [
    "timestamp",
    "label",
    "backup_zip_path",
    "sha256",
    "included_file_count",
    "excluded_file_count",
    "excluded_sensitive_file_count",
    "env_excluded",
    "secret_scan_passed",
    "final_safety_verdict",
    "launch1_decision",
    "execution_allowed",
    "production_whatsapp_status",
    "backup_output_directory",
    "stage_note",
]


@dataclass
class Exclusion:
    path: str
    reason: str
    sensitive: bool = False


@dataclass
class SafeBackupResult:
    timestamp: datetime
    label: str
    backup_zip_path: Path
    included_files: list[Path] = field(default_factory=list)
    exclusions: list[Exclusion] = field(default_factory=list)
    sha256: str = ""
    env_excluded: bool = False
    secret_scan_passed: bool = True
    latest_test_status: str = "NOT_CHECKED_BY_BACKUP_SCRIPT"
    final_safety_verdict: str = "NOT_AVAILABLE"
    launch1_decision: str = "NOT_AVAILABLE"
    execution_allowed: str = "false"
    production_whatsapp_status: str = "BLOCKED"
    backup_output_directory: Path | None = None
    stage_note: str = STAGE_NOTE
    report_path: Path | None = None
    history_path: Path | None = None

    @property
    def excluded_sensitive_file_count(self) -> int:
        return sum(1 for item in self.exclusions if item.sensitive)


def create_safe_weekend_backup(
    base_dir: Path | str = ".",
    *,
    label: str,
    output_dir: Path | str | None = None,
    latest_test_status: str | None = None,
    now_fn: Callable[[], datetime] | None = None,
) -> SafeBackupResult:
    """Create a secrets-safe checkpoint ZIP without live service calls."""

    base = Path(base_dir)
    timestamp = (now_fn or (lambda: datetime.now().astimezone()))()
    safe_label = _safe_label(label)
    filename = f"Devansh-Trading-System_{safe_label}_{timestamp.strftime('%Y%m%d_%H%M%S')}.zip"
    backup_output_directory = Path(output_dir) if output_dir is not None else base / BACKUP_DIR
    backup_path = backup_output_directory / filename
    backup_path.parent.mkdir(parents=True, exist_ok=True)

    result = SafeBackupResult(
        timestamp=timestamp,
        label=safe_label,
        backup_zip_path=backup_path,
        backup_output_directory=backup_output_directory,
    )
    if latest_test_status:
        result.latest_test_status = latest_test_status
    candidates = _collect_candidate_files(base)
    included: list[Path] = []
    seen_exclusions: set[tuple[str, str]] = set()
    for path in candidates:
        rel = _rel_path(base, path)
        excluded_reason = _static_exclusion_reason(rel, path)
        if excluded_reason:
            _add_exclusion(result, seen_exclusions, rel, excluded_reason, _is_sensitive_exclusion(rel, excluded_reason))
            continue
        secret_reason = _secret_exclusion_reason(path)
        if secret_reason:
            _add_exclusion(result, seen_exclusions, rel, secret_reason, True)
            continue
        included.append(path)

    result.included_files = sorted(included, key=lambda p: _rel_path(base, p).lower())
    result.env_excluded = any(item.path in {".env"} or item.path.startswith(".env.") for item in result.exclusions)
    result.final_safety_verdict = _extract_value(
        _read_text(base / "reports" / "final_safety" / "latest_final_safety_audit_report.txt"),
        "FINAL VERDICT",
        next_line=True,
    ) or "NOT_AVAILABLE"
    launch1_report = _read_text(base / "reports" / "launch1" / "latest_launch1_readiness_report.txt")
    result.launch1_decision = _extract_value(launch1_report, "decision:") or "NOT_AVAILABLE"
    result.execution_allowed = "false"
    result.production_whatsapp_status = "BLOCKED"

    manifest_text = _format_report(result)
    with zipfile.ZipFile(backup_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in result.included_files:
            zf.write(path, _rel_path(base, path))
        zf.writestr(MANIFEST_ZIP_PATH, manifest_text)

    result.sha256 = _sha256_file(backup_path)
    manifest_text = _format_report(result)
    _write_report(base, result, manifest_text)
    _append_history(base, result)
    _print_summary(result)
    return result


def _collect_candidate_files(base: Path) -> list[Path]:
    files: list[Path] = []
    for relative in DEFAULT_INCLUDE_PATHS:
        path = base / relative
        if not path.exists():
            continue
        if path.is_file():
            files.append(path)
        else:
            files.extend(item for item in path.rglob("*") if item.is_file())
    for env_name in [".env", ".env.local", ".env.production", ".env.dev"]:
        env_path = base / env_name
        if env_path.exists():
            files.append(env_path)
    return sorted(set(files))


def _static_exclusion_reason(rel: str, path: Path) -> str:
    normalized = rel.replace("\\", "/")
    parts = normalized.split("/")
    name = path.name
    lower_name = name.lower()
    if name == ".env" or lower_name.startswith(".env.") or lower_name.endswith(".env"):
        return "excluded environment/secret file"
    if any(part in EXCLUDED_DIR_NAMES for part in parts):
        return "excluded generated/cache/environment directory"
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return "excluded compiled/generated Python file"
    if path.suffix.lower() == ".log":
        return "excluded log file"
    if normalized.startswith("reports/backups/"):
        return "excluded previous backup report/history to avoid stale manifests"
    return ""


def _is_sensitive_exclusion(rel: str, reason: str) -> bool:
    lowered = (rel + " " + reason).lower()
    return ".env" in lowered or "secret" in lowered or "token" in lowered or "credential" in lowered


def _secret_exclusion_reason(path: Path) -> str:
    if not _is_text_candidate(path):
        return ""
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except OSError:
        return ""
    for line in lines:
        for key in SECRET_KEYS:
            value = _extract_secret_value(line, key)
            if value and _looks_like_real_secret(value):
                return f"excluded by secret scan: {key}=****"
    return ""


def _extract_secret_value(line: str, key: str) -> str:
    pattern = re.compile(rf"(?i)\b{re.escape(key)}\b\s*[:=]\s*[\"']?([^\"'\s,#]+)")
    match = pattern.search(line)
    return match.group(1).strip() if match else ""


def _looks_like_real_secret(value: str) -> bool:
    cleaned = value.strip().strip("\"'")
    lowered = cleaned.lower()
    if not cleaned or lowered in {"present", "missing", "not_checked", "none", "null", "false", "true"}:
        return False
    if any(token in lowered for token in ["placeholder", "your_", "xxxx", "example", "masked", "****", "..."]):
        return False
    if len(cleaned) < 12:
        return False
    return bool(re.search(r"[A-Za-z]", cleaned) and re.search(r"\d", cleaned))


def _is_text_candidate(path: Path) -> bool:
    return path.suffix.lower() in TEXT_SUFFIXES or path.name.lower().startswith(".env")


def _format_report(result: SafeBackupResult) -> str:
    lines = [
        "SAFE WEEKEND BACKUP REPORT",
        f"Generated timestamp: {result.timestamp.isoformat()}",
        f"Backup label: {result.label}",
        f"Backup zip path: {result.backup_zip_path}",
        f"Backup output directory: {result.backup_output_directory}",
        f"Stage note: {result.stage_note}",
        f"Included file count: {len(result.included_files)}",
        f"Excluded file count: {len(result.exclusions)}",
        f"Excluded sensitive files: {result.excluded_sensitive_file_count}",
        f".env excluded: {_bool_text(result.env_excluded)}",
        f"Secret scan passed: {_bool_text(result.secret_scan_passed)}",
        f"SHA256: {result.sha256 or 'PENDING_INSIDE_ZIP_MANIFEST'}",
        f"Latest test status: {result.latest_test_status}",
        f"Latest final safety verdict: {result.final_safety_verdict}",
        f"Launch1 decision: {result.launch1_decision}",
        "execution_allowed=false",
        "Production WhatsApp: BLOCKED",
        "Mode: PAPER / RESEARCH / MANUAL ONLY",
        f"Launch/Stage note: {result.stage_note}",
        "",
        "EXCLUDED SENSITIVE FILES",
    ]
    sensitive = [item for item in result.exclusions if item.sensitive]
    lines.extend(
        [f"- {item.path}: {item.reason}" for item in sensitive]
        if sensitive
        else ["NONE"]
    )
    lines.extend(
        [
            "",
            "ALL EXCLUSIONS",
            *([f"- {item.path}: {item.reason}" for item in result.exclusions] if result.exclusions else ["NONE"]),
            "",
            "SAFETY CONFIRMATION",
            ".env and token-like files are excluded.",
            "No raw secret values are printed in this report.",
            "No broker orders were placed.",
            "No live recorder or live TrueData command was run.",
            "Production WhatsApp remains blocked.",
            "Strategy remains RESEARCH_ONLY unless later manually approved.",
        ]
    )
    return "\n".join(lines) + "\n"


def _write_report(base: Path, result: SafeBackupResult, report_text: str) -> None:
    path = base / REPORT_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(report_text, encoding="utf-8")
    result.report_path = path


def _append_history(base: Path, result: SafeBackupResult) -> None:
    path = base / HISTORY_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    row = {
        "timestamp": result.timestamp.isoformat(),
        "label": result.label,
        "backup_zip_path": str(result.backup_zip_path),
        "sha256": result.sha256,
        "included_file_count": len(result.included_files),
        "excluded_file_count": len(result.exclusions),
        "excluded_sensitive_file_count": result.excluded_sensitive_file_count,
        "env_excluded": _bool_text(result.env_excluded),
        "secret_scan_passed": _bool_text(result.secret_scan_passed),
        "final_safety_verdict": result.final_safety_verdict,
        "launch1_decision": result.launch1_decision,
        "execution_allowed": "false",
        "production_whatsapp_status": "BLOCKED",
        "backup_output_directory": str(result.backup_output_directory or result.backup_zip_path.parent),
        "stage_note": result.stage_note,
    }
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=HISTORY_COLUMNS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)
    result.history_path = path


def _print_summary(result: SafeBackupResult) -> None:
    print("SAFE WEEKEND BACKUP")
    print(f"Backup zip path: {result.backup_zip_path}")
    print(f"Backup output directory: {result.backup_output_directory}")
    print(f"Stage note: {result.stage_note}")
    print(f"SHA256: {result.sha256}")
    print(f"Included files: {len(result.included_files)}")
    print(f"Excluded files: {len(result.exclusions)}")
    print(f"Excluded sensitive files: {result.excluded_sensitive_file_count}")
    print(f".env excluded: {_bool_text(result.env_excluded)}")
    print(f"Secret scan passed: {_bool_text(result.secret_scan_passed)}")
    print("execution_allowed=false")
    print("Production WhatsApp: BLOCKED")
    print("PAPER MODE ONLY. No broker orders were placed.")


def _extract_value(text: str, prefix: str, *, next_line: bool = False) -> str:
    lines = text.splitlines()
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith(prefix):
            if next_line:
                return lines[index + 1].strip() if index + 1 < len(lines) else ""
            return stripped.split(prefix, 1)[1].strip()
    return ""


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _add_exclusion(
    result: SafeBackupResult,
    seen: set[tuple[str, str]],
    path: str,
    reason: str,
    sensitive: bool,
) -> None:
    key = (path, reason)
    if key in seen:
        return
    seen.add(key)
    result.exclusions.append(Exclusion(path=path, reason=reason, sensitive=sensitive))


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""


def _rel_path(base: Path, path: Path) -> str:
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


def _safe_label(value: str) -> str:
    label = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())
    return label.strip("._-") or "safe_backup"


def _bool_text(value: bool) -> str:
    return "true" if bool(value) else "false"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create a safe weekend checkpoint ZIP. No live services.")
    parser.add_argument("--label", required=True)
    parser.add_argument("--output-dir", help="Directory where the backup ZIP should be written.")
    parser.add_argument("--latest-test-status", help="Optional latest pytest status to record in the manifest.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    create_safe_weekend_backup(
        label=args.label,
        output_dir=args.output_dir,
        latest_test_status=args.latest_test_status,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
