param(
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
$RootPath = $Root.Path
$Dist = Join-Path $RootPath "dist"

if (-not $OutputPath) {
    $OutputPath = Join-Path $Dist "Devansh-Trading-System-clean.zip"
}

New-Item -ItemType Directory -Force -Path $Dist | Out-Null
if (Test-Path $OutputPath) {
    Remove-Item -LiteralPath $OutputPath -Force
}

$excludedDirs = @(".venv", "__pycache__", ".pytest_cache", "logs", "reports", ".tokens", "dist")
$excludedNames = @(".env")
$excludedExtensions = @(".pyc", ".pyo")

$files = Get-ChildItem -Path $RootPath -Recurse -File | Where-Object {
    $relative = $_.FullName.Substring($RootPath.Length + 1)
    $parts = $relative -split "[\\/]"
    $name = $_.Name.ToLowerInvariant()
    $relativeLower = $relative.ToLowerInvariant()

    -not ($parts | Where-Object { $excludedDirs -contains $_ }) -and
    -not ($excludedNames -contains $_.Name) -and
    -not ($excludedExtensions -contains $_.Extension.ToLowerInvariant()) -and
    -not ($relativeLower -match "access_token|request_token|secret|credential|password")
}

if (-not $files) {
    throw "No files found for clean ZIP."
}

Compress-Archive -LiteralPath $files.FullName -DestinationPath $OutputPath -Force
Write-Output "Clean ZIP created: $OutputPath"
