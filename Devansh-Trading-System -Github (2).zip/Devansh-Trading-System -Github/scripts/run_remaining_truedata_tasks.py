from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORT_ROOT = PROJECT_ROOT / "reports" / "today_truedata_tasks"
TICK_ROOT = PROJECT_ROOT / "data" / "historical" / "truedata" / "ticks"
BAR_ROOT = PROJECT_ROOT / "data" / "historical" / "truedata" / "bars"
SYMBOLS = ("GOLD-I", "SILVER-I")

TICK_DOWNLOAD_COMMAND = [
    sys.executable,
    "-m",
    "src.data_collection.historical_data_downloader",
    "--source",
    "truedata",
    "--data-type",
    "ticks",
    "--symbols",
    "GOLD-I,SILVER-I",
    "--from-date",
    "2026-06-15",
    "--to-date",
    "2026-06-19",
    "--rate-limit-seconds",
    "1",
]
BAR_DOWNLOAD_COMMAND = [
    sys.executable,
    "-m",
    "src.data_collection.historical_data_downloader",
    "--source",
    "truedata",
    "--data-type",
    "bars",
    "--symbols",
    "GOLD-I,SILVER-I",
    "--from-date",
    "2026-06-04",
    "--to-date",
    "2026-06-19",
    "--interval",
    "1minute",
    "--rate-limit-seconds",
    "1",
]
PYTEST_COMMAND = [sys.executable, "-m", "pytest", "-q"]
TICK_BACKTEST_COMMAND = [
    sys.executable,
    "-m",
    "src.backtesting.strategy_backtest_runner",
    "--tick-dir",
    r"data\historical\truedata\ticks",
    "--symbols",
    "GOLD-I,SILVER-I",
    "--strategies",
    "cluster_imbalance_trap",
    "--from-date",
    "2026-06-15",
    "--to-date",
    "2026-06-19",
    "--exit-at-end",
    "true",
    "--one-trade-at-a-time",
    "true",
    "--signal-cooldown-seconds",
    "300",
    "--max-trades-per-day",
    "20",
    "--slippage-points",
    "5",
    "--cost-per-trade",
    "50",
    "--entry-delay-ticks",
    "1",
    "--min-score",
    "8.8",
    "--min-trap-strength",
    "0.7",
    "--same-zone-cooldown-seconds",
    "300",
    "--direction-flip-cooldown-seconds",
    "300",
]
BAR_BACKTEST_COMMAND = [
    sys.executable,
    "-m",
    "src.backtesting.strategy_backtest_runner",
    "--bar-dir",
    r"data\historical\truedata\bars",
    "--symbols",
    "GOLD-I,SILVER-I",
    "--strategies",
    "all",
    "--from-date",
    "2026-06-04",
    "--to-date",
    "2026-06-19",
    "--exit-at-end",
    "true",
    "--one-trade-at-a-time",
    "true",
    "--signal-cooldown-seconds",
    "300",
    "--max-trades-per-day",
    "20",
    "--slippage-points",
    "5",
    "--cost-per-trade",
    "50",
    "--entry-delay-ticks",
    "1",
]


@dataclass
class StepResult:
    name: str
    status: str
    started_at: datetime
    ended_at: datetime
    log_path: Path
    error: str = ""


class TaskStepError(RuntimeError):
    pass


def scan_symbol_files(root: Path, suffix: str) -> dict[str, list[Path]]:
    return {
        symbol: sorted(root.rglob(f"{symbol}_{suffix}.csv")) if root.exists() else []
        for symbol in SYMBOLS
    }


def safe_environment() -> dict[str, str]:
    env = dict(os.environ)
    env["ENABLE_LIVE_TRADING"] = "false"
    env["I_UNDERSTAND_LIVE_TRADING_RISK"] = "false"
    return env


def redact_text(text: str, env: dict[str, str] | None = None) -> str:
    redacted = text
    source = env or os.environ
    sensitive_markers = ("TOKEN", "PASSWORD", "SECRET", "API_KEY")
    for key, value in source.items():
        if any(marker in key.upper() for marker in sensitive_markers) and value and len(value) >= 4:
            redacted = redacted.replace(value, "[REDACTED]")
    return redacted


def run_logged_command(name: str, command: list[str], log_path: Path) -> StepResult:
    started = datetime.now().astimezone()
    print_heading(name)
    print(f"Command: {format_command(command)}")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    env = safe_environment()
    with log_path.open("w", encoding="utf-8") as log:
        log.write(f"Step: {name}\n")
        log.write(f"Started: {started.isoformat()}\n")
        log.write(f"Command: {format_command(command)}\n\n")
        process = subprocess.Popen(
            command,
            cwd=PROJECT_ROOT,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for raw_line in process.stdout:
            line = redact_text(raw_line.rstrip("\n"), env)
            print(line, flush=True)
            log.write(line + "\n")
        return_code = process.wait()
        ended = datetime.now().astimezone()
        log.write(f"\nEnded: {ended.isoformat()}\n")
        log.write(f"Return code: {return_code}\n")
    if return_code != 0:
        raise TaskStepError(f"{name} failed with return code {return_code}. See {log_path}")
    return StepResult(name, "SUCCESS", started, ended, log_path)


def check_ticks(run_dir: Path) -> tuple[StepResult, dict[str, list[Path]]]:
    name = "STEP 1 - CHECK EXISTING TRUEDATA TICK FILES"
    started = datetime.now().astimezone()
    print_heading(name)
    log_path = run_dir / "01_check_tick_files.log"
    files = scan_symbol_files(TICK_ROOT, "ticks")
    missing = [symbol for symbol, paths in files.items() if not paths]
    lines = [f"{symbol}: {len(paths)} tick files" for symbol, paths in files.items()]
    for line in lines:
        print(line)
    if missing:
        print(f"Missing tick files for: {', '.join(missing)}")
        print("Tick download will run only because required files are missing.")
        recovery = run_logged_command(
            "STEP 1A - RECOVER MISSING TRUEDATA TICK FILES",
            TICK_DOWNLOAD_COMMAND,
            run_dir / "01a_missing_tick_download.log",
        )
        files = scan_symbol_files(TICK_ROOT, "ticks")
        still_missing = [symbol for symbol, paths in files.items() if not paths]
        if still_missing:
            raise TaskStepError(f"Tick files are still missing for: {', '.join(still_missing)}")
        lines.append(f"Recovery status: {recovery.status}")
    else:
        lines.append("Tick re-download skipped: existing files found for both symbols.")
    ended = datetime.now().astimezone()
    log_path.write_text(
        "\n".join([
            f"Started: {started.isoformat()}",
            *lines,
            f"Ended: {ended.isoformat()}",
        ])
        + "\n",
        encoding="utf-8",
    )
    return StepResult(name, "SUCCESS", started, ended, log_path), files


def preserve_backtest_reports(run_dir: Path, prefix: str) -> list[Path]:
    source_dir = PROJECT_ROOT / "reports" / "backtests"
    mapping = {
        "latest_strategy_backtest_summary.csv": f"{prefix}_summary.csv",
        "latest_strategy_backtest_trades.csv": f"{prefix}_trades.csv",
        "latest_strategy_backtest_report.txt": f"{prefix}_report.txt",
    }
    copied: list[Path] = []
    for source_name, target_name in mapping.items():
        source = source_dir / source_name
        if not source.exists():
            raise TaskStepError(f"Expected backtest report was not created: {source}")
        target = run_dir / target_name
        shutil.copy2(source, target)
        copied.append(target)
    return copied


def write_summary(
    run_dir: Path,
    overall_start: datetime,
    steps: list[StepResult],
    tick_files: dict[str, list[Path]],
    bar_files: dict[str, list[Path]],
    report_paths: list[Path],
    error: str = "",
) -> Path:
    ended = datetime.now().astimezone()
    lines = [
        "TODAY TRUEDATA REMAINING TASKS SUMMARY",
        "Mode: PAPER",
        "Live Trading: DISABLED",
        "Broker Orders: DISABLED",
        "execution_allowed=false",
        "ENABLE_LIVE_TRADING=false",
        "I_UNDERSTAND_LIVE_TRADING_RISK=false",
        "",
        f"Start Time: {overall_start.isoformat()}",
        f"End Time: {ended.isoformat()}",
        f"Overall Status: {'FAILED' if error else 'SUCCESS'}",
        "",
        "STEP STATUS",
    ]
    for step in steps:
        lines.append(
            f"- {step.name}: {step.status} | {step.started_at.isoformat()} -> "
            f"{step.ended_at.isoformat()} | log={step.log_path}"
        )
    lines.extend(["", "TICK FILES FOUND"])
    for symbol in SYMBOLS:
        lines.append(f"- {symbol}: {len(tick_files.get(symbol, []))}")
    lines.extend(["", "BAR FILES FOUND"])
    for symbol in SYMBOLS:
        lines.append(f"- {symbol}: {len(bar_files.get(symbol, []))}")
    lines.extend(["", "BACKTEST REPORT PATHS"])
    lines.extend(f"- {path}" for path in report_paths)
    lines.extend(["", "ERRORS", f"- {redact_text(error) if error else 'NONE'}"])
    lines.extend([
        "",
        "PAPER/manual-signal system only. No broker orders were placed.",
    ])
    summary_path = run_dir / "final_summary.txt"
    summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(summary_path, REPORT_ROOT / "latest_summary.txt")
    return summary_path


def print_heading(title: str) -> None:
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78, flush=True)


def format_command(command: Iterable[str]) -> str:
    return subprocess.list2cmdline(list(command))


def main() -> int:
    overall_start = datetime.now().astimezone()
    run_id = overall_start.strftime("%Y%m%d_%H%M%S_%f")
    run_dir = REPORT_ROOT / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    steps: list[StepResult] = []
    tick_files: dict[str, list[Path]] = {symbol: [] for symbol in SYMBOLS}
    bar_files: dict[str, list[Path]] = {symbol: [] for symbol in SYMBOLS}
    reports: list[Path] = []
    error = ""

    print("TRUEDATA REMAINING TASKS MASTER RUNNER")
    print(f"Run directory: {run_dir}")
    print("Mode: PAPER")
    print("Live Trading: DISABLED")
    print("Broker Orders: DISABLED")
    print("execution_allowed=false")

    try:
        step, tick_files = check_ticks(run_dir)
        steps.append(step)

        steps.append(run_logged_command(
            "STEP 2 - DOWNLOAD TRUEDATA 1-MINUTE BARS",
            BAR_DOWNLOAD_COMMAND,
            run_dir / "02_download_bars.log",
        ))
        bar_files = scan_symbol_files(BAR_ROOT, "1minute_bars")
        if any(not bar_files[symbol] for symbol in SYMBOLS):
            missing = [symbol for symbol in SYMBOLS if not bar_files[symbol]]
            raise TaskStepError(f"Bar download completed but files are missing for: {', '.join(missing)}")

        steps.append(run_logged_command(
            "STEP 3 - RUN PYTEST",
            PYTEST_COMMAND,
            run_dir / "03_pytest.log",
        ))

        steps.append(run_logged_command(
            "STEP 4 - RUN TICK CLUSTER BACKTEST",
            TICK_BACKTEST_COMMAND,
            run_dir / "04_tick_cluster_backtest.log",
        ))
        reports.extend(preserve_backtest_reports(run_dir, "tick_cluster_backtest"))

        steps.append(run_logged_command(
            "STEP 5 - RUN BAR/CANDLE STRATEGY BACKTEST",
            BAR_BACKTEST_COMMAND,
            run_dir / "05_bar_strategy_backtest.log",
        ))
        reports.extend(preserve_backtest_reports(run_dir, "bar_strategy_backtest"))
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        now = datetime.now().astimezone()
        steps.append(StepResult("FAILED STEP", "FAILED", now, now, run_dir / "failure.log", redact_text(error)))
        (run_dir / "failure.log").write_text(redact_text(error) + "\n", encoding="utf-8")
        print(f"\nMASTER RUNNER STOPPED SAFELY: {redact_text(error)}")
    finally:
        bar_files = scan_symbol_files(BAR_ROOT, "1minute_bars")
        summary_path = write_summary(
            run_dir,
            overall_start,
            steps,
            tick_files,
            bar_files,
            reports,
            error,
        )
        print(f"\nFinal summary: {summary_path}")
        print("PAPER MODE ONLY. No broker orders were placed.")
    return 1 if error else 0


if __name__ == "__main__":
    raise SystemExit(main())
