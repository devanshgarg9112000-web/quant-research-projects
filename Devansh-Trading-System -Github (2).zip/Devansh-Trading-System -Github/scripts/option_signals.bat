@echo off
setlocal
cd /d "%~dp0.."
python -m src.option_signals.cli %*
endlocal
