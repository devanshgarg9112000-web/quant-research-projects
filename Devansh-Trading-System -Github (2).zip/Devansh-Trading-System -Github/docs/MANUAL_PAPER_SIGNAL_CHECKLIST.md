﻿# Manual Paper Signal Checklist

One-line rule: Signal is for research evidence only, not money.

## Before Market

- Confirm strategy status is RESEARCH_ONLY.
- Confirm execution_allowed=false.
- Confirm production WhatsApp alerts are blocked.
- Open chart, VWAP, recent support/resistance, and forward ledger.
- Decide max paper risk on paper only; do not prepare any broker order.

## When Signal Appears

- Record symbol, setup, side, signal_time, entry, stop_loss, target, expected_R, signal_score, market_regime, and lock_version.
- Screenshot the chart immediately.
- Note VWAP context: rejection, reclaim failure, distance, and slope.
- Note support/resistance context near entry, stop, and target.
- Note market condition: trend, trap, chop, news, liquidity, and spread.
- Mark paper entry only after the allowed entry rule is satisfied.
- Write RESEARCH_ONLY and execution_allowed=false beside the paper signal.

## During Trade

- Do not average.
- Do not move stop to make the trade look better.
- Do not increase size.
- Do not convert paper tracking into real money.
- Record whether target, stop, or end-exit happens first.
- Record timestamps and prices from the same evidence source.

## After Outcome

- Mark result as WIN, LOSS, END_EXIT, or still PENDING.
- Record exit_time, exit_price, gross result, net result after costs, R_multiple, MFE, and MAE when available.
- Save chart screenshot and notes.
- Review whether the signal followed the locked rules.
- Do not change parameters because of one trade.

## Daily Review

- Count only completed independent post-lock forward trades.
- Confirm required sample remains 30 trades across required sessions.
- Separate observation notes from strategy tuning notes.
- Check that production alerts stayed blocked.
- Check that no broker order was prepared or sent.
- Update next action: collect more evidence, investigate data quality, or wait for the next valid signal.

## Strict Do Not Do

- Do not use real money.
- Do not use broker orders.
- Do not use auto orders.
- Do not enable production WhatsApp alerts.
- Do not average losers.
- Do not change strategy parameters from one trade.
- Do not treat 1/30 as approval.
- Do not call the strategy approved until the independent forward sample and manual review are complete.
