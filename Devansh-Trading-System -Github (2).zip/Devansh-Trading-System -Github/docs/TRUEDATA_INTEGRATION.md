# TrueData Integration

This implementation is based only on the uploaded `TD_API_Documents.zip`.

## Default Safety

- `enable_true_data: false` remains the default in `config/settings.yaml`.
- `python run.py` continues to use deterministic sample data in PAPER mode.
- Missing TrueData credentials do not crash the system.
- TrueData credentials are read only from `.env` / environment variables.
- Passwords and bearer tokens are never printed.
- Live trading remains disabled by default. TrueData is market data only and does not place trades.

## Environment Variables

```env
TRUEDATA_USERNAME=your_truedata_username_here
TRUEDATA_PASSWORD=your_truedata_password_here
TRUEDATA_APP_KEY=your_truedata_app_key_here
TRUEDATA_REALTIME_PORT=your_truedata_realtime_port_here
```

The uploaded Market Data API v2.6 document specifies the WebSocket URL shape:

```text
wss://push.truedata.in:real_time_port?user=your_user_id&password=your_password
```

The document uses `real_time_port` as a subscription-specific value, so the project requires `TRUEDATA_REALTIME_PORT` instead of guessing a port.

## WebSocket Streaming

Implemented methods:

- `connect()`
- `disconnect()`
- `subscribe(symbols)`
- `unsubscribe(symbols)`
- `on_tick(callback)`

Documented subscription request:

```json
{"method": "addsymbol", "symbols": ["NIFTY BANK", "NIFTY-I"]}
```

Documented unsubscribe request:

```json
{"method": "removesymbol", "symbols": ["NIFTY-I"]}
```

The feed normalizes documented `trade` and `touchline`/`symbollist` payloads into the internal tick format:

```python
{
    "symbol": str,
    "timestamp": datetime,
    "ltp": float,
    "ltq": int | float,
    "volume": int | float,
    "oi": int | float | None,
    "bid": float | None,
    "ask": float | None,
    "bid_qty": int | float | None,
    "ask_qty": int | float | None,
    "raw": original_tick,
}
```

`bidask` and `bidaskL2` messages are cached as market-depth updates. No separate REST market-depth endpoint was found in the uploaded docs.

## REST Historical Data

The uploaded docs and Postman collections specify:

- Auth URL: `https://auth.truedata.in/token`
- Auth method: `POST`
- Auth body format: `x-www-form-urlencoded`
- Auth fields: `username`, `password`, `grant_type=password`
- Historical base URL: `https://history.truedata.in`
- Tick endpoint: `getticks`
- Bar endpoint: `getbars`

Implemented:

- `get_historical(symbol, start, end, interval)`

When `interval` is `tick` or `ticks`, the feed calls `getticks` with `bidask=1` and normalizes the documented CSV columns:

```text
timestamp,ltp,volume,oi,bid,bidqty,ask,askqty
```

For bar intervals such as `1min` or `5min`, the feed calls `getbars` and normalizes:

```text
timestamp,open,high,low,close,volume,oi
```

## Option Chain

The uploaded docs/Postman collections provide option-chain endpoints, but they require an expiry. The project implements:

```python
get_option_chain(symbol, expiry=None)
```

If `expiry` is missing, it safely skips and prints a clear message. With expiry, it uses the documented historical endpoint:

```text
https://history.truedata.in/getSymbolOptionChain?symbol=NIFTY&expiry=230427&response=csv
```

## Safe Test Command

```powershell
python -m src.data_feeds.truedata_feed --test-connection
```

With default config, this prints that TrueData is disabled and exits safely.

## Not Implemented On Purpose

- No guessed endpoints, ports, symbols, or subscription values.
- No hardcoded credentials.
- No automatic live trading.
- No TCP binary parser. The TCP PDF documents binary packet formats, but the Market Data API v2.6 WebSocket contract provides explicit JSON messages, so the project uses the safer WebSocket path.
