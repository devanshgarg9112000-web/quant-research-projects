# Weekly Option Sell Signal System — Forward Validation V1

## Purpose

This subsystem implements the two frozen Aug–Sep 2026 research candidates as a **Kite read-only, signal-only, manual-execution** monitor. It is intentionally isolated from the legacy MCX/research strategy engine and from every broker-order path.

It does **not** call `place_order`, does not enable naked-option execution in the existing global risk configuration, and does not change `KiteBroker.place_order()`.

Runtime flow:

```text
Kite read-only data
        |
        +--> CAS Router -------------------+
        |                                  |
        +--> NIFTY Efficiency Trend -------+--> Signal Manager
                                                |
                                         Portfolio Guard
                                                |
                                  Reference Position Tracker
                                                |
                                CSV Forward Ledger + Telegram
                                                |
                                      MANUAL EXECUTION ONLY
```

## Frozen Strategy A — CAS Router

### NIFTY sleeve

- Eligible days: Monday, Tuesday, Friday.
- Signal window: 09:30 through 14:00 IST.
- Signal input: closed NIFTY 1-minute spot bars only.
- 5-minute spot return threshold: +/- 6 bps.
- Spot up >= 6 bps: SELL ATM PE.
- Spot down <= -6 bps: SELL ATM CE.
- Cooldown: 7 minutes per strategy/underlying.
- ATM CE+PE option-complex filter: compute each current ATM option's 3-minute return and average the two. Reject the CAS signal if the mean premium expansion is greater than 1% or cannot be calculated from closed bars.

### SENSEX sleeve

- Eligible days: Wednesday, Thursday.
- Signal window: 09:16 through 15:13 IST.
- No new signals from 11:00 through 13:30 IST.
- Lookback: previous 25 closed 1-minute SENSEX spot bars.
- Failed upside breakout: current high exceeds prior 25-minute high but current close falls back below that prior high -> SELL ATM CE.
- Failed downside breakout: current low breaks prior 25-minute low but current close recovers above that prior low -> SELL ATM PE.
- Cooldown: 5 minutes.

## Frozen Strategy B — NIFTY Efficiency Trend

- Eligible days: Monday, Tuesday, Friday.
- Signal window: 10:00 through 14:00 IST.
- 15-minute spot return: `Spot_t / Spot_(t-15) - 1`.
- 15-minute Efficiency Ratio: absolute net 15-minute movement divided by sum of absolute 1-minute movements over the same interval.
- Require Efficiency Ratio >= 0.70.
- Require absolute 15-minute return >= 10 bps (0.10%).
- Positive trend -> SELL ATM PE.
- Negative trend -> SELL ATM CE.
- Cooldown: 5 minutes.

## Common Contract and Exit Rules

- Immediate weekly expiry only.
- Contract expiry is resolved from the **actual current Kite instrument master**, never by hard-coded weekday arithmetic. This protects holiday-shifted expiries.
- ATM strike is selected using current spot and an expiry that has both CE and PE at a common strike.
- Position side is SELL-to-open only. The only buy-side action represented by the system is a manual BUY-to-close exit alert.
- Initial forward-validation alert size: 3 lots.
- Maximum open reference positions per underlying: 1.
- Double confirmation does **not** add lots. If CAS and Efficiency independently agree in the same evaluation, one 3-lot signal is emitted with `DOUBLE_CONFIRMATION` classification.
- If the two strategies disagree on CE/PE at the same evaluation, no actionable trade is emitted; a conflict is recorded.
- Stop reference: option premium +50% from reference entry.
- Target reference: option premium -25% from reference entry.
- Maximum reference holding time: 30 minutes.
- Mandatory exit alert at or before 15:15 IST.

## Causal Data Rules

- Strategy indicators use **closed 1-minute bars only**.
- The current still-forming minute is explicitly discarded.
- No future candle is read for signal generation.
- The live alert entry reference uses best visible bid when Kite depth is available; otherwise LTP.
- The reference exit monitor uses best visible ask when depth is available; otherwise LTP.
- These are alert/reference prices, not guaranteed fills.

## Forward-Validation Portfolio Behavior

During initial live validation:

- One open reference position per underlying.
- A second signal while that underlying has an open reference position is logged as `SHADOW` and does not increase lots.
- Strategy intents are always logged separately so CAS-only, Efficiency-only, double-confirmation, conflict, cooldown, and option-filter rejections can be analyzed later.
- No unbacktested daily trade-count cap is applied. The one-position rule and each strategy's frozen signal/cooldown logic remain the controlling constraints.

## Safety Boundaries

The new package is `src/option_signals/`.

It intentionally contains no call to `place_order(`. Automated tests assert that this remains true.

The legacy safeguards remain unchanged:

- global live trading stays disabled;
- existing `allow_naked_options: false` stays unchanged;
- `KiteBroker.place_order()` remains intentionally unimplemented/blocked;
- the option signal subsystem has no broker execution interface.

Do not loosen these safeguards during forward validation.

## Telegram

Telegram uses the official Bot API `sendMessage` endpoint.

Delivery requires all of the following:

1. `alerts.telegram_enabled: true` in `config/option_signals.yaml`;
2. `alerts.telegram_dry_run: false`;
3. environment variable `TELEGRAM_ALERTS_ENABLED=true`;
4. `TELEGRAM_BOT_TOKEN` present;
5. `TELEGRAM_CHAT_ID` present.

Secrets are read from the environment only and are never printed.

A failed Telegram request fails safely: it logs the exception class and does not change strategy logic or place an order.

## Forward Ledger

Generated files:

```text
reports/option_signals/strategy_intents.csv
reports/option_signals/forward_entries.csv
reports/option_signals/forward_exits.csv
```

These are the audit trail for tomorrow's and future forward-validation sessions.

## Commands

Offline deterministic strategy smoke test:

```powershell
python -m src.option_signals.cli self-test
```

Offline readiness check (no market-data request):

```powershell
python -m src.option_signals.cli preflight
```

Read-only live Kite spot/expiry/ATM contract check (network call, still no orders):

```powershell
python -m src.option_signals.cli live-check --underlying NIFTY
python -m src.option_signals.cli live-check --underlying SENSEX
```

Telegram dry-run:

```powershell
python -m src.option_signals.cli telegram-test
```

Telegram network test after explicit opt-in:

```powershell
python -m src.option_signals.cli telegram-test --send
```

Live **read-only** monitor:

```powershell
python -m src.option_signals.cli run --poll-seconds 3
```

Equivalent Windows helper after this patch:

```powershell
scripts\option_signals.bat self-test
scripts\option_signals.bat preflight
scripts\option_signals.bat run --poll-seconds 3
```

## What Is Not Yet Proven Offline

The market is closed, so the following must be verified during a live session before relying on alerts:

- exact Kite index quote payloads for `NSE:NIFTY 50` and `BSE:SENSEX`;
- current NFO/BFO instrument-master naming, lot size, and option-type fields;
- current-minute historical-data timestamp behavior;
- bid/ask depth availability for the selected options;
- Telegram delivery latency;
- live data continuity and API-rate behavior over a full session;
- actual manual fill slippage versus the alert reference.

None of these should be "fixed" by changing strategy parameters. Fix only data/adapter defects unless a new research cycle is explicitly approved.
