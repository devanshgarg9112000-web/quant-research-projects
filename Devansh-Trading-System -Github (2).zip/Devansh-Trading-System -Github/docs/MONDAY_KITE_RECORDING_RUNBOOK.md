# Monday Kite Recording Runbook

This runbook is for Kite read-only market-data collection and research only.

It does not enable live trading, place broker orders, approve a strategy, or permit production WhatsApp alerts.

## Fixed safety state

- Project mode: `PAPER`
- `ENABLE_LIVE_TRADING=false`
- `I_UNDERSTAND_LIVE_TRADING_RISK=false`
- `execution_allowed=false`
- Broker orders: `DISABLED`
- Production WhatsApp alerts: `BLOCKED`
- GOLD-I strategy approval: `RESEARCH_ONLY`

Never paste Kite credentials or tokens into ChatGPT, Codex, screenshots, reports, or source files.

## 1. Before-market checklist

- [ ] Open PowerShell or Terminal.
- [ ] Change to the project folder:

```powershell
cd C:\Users\DELL\Desktop\Devansh-Trading-System
```

- [ ] Confirm the prompt is inside `C:\Users\DELL\Desktop\Devansh-Trading-System`.
- [ ] Run the automated local checklist:

```powershell
python -m src.data_collection.kite_monday_checklist --symbols "GOLD-I"
```

- [ ] Confirm the latest test suite passes:

```powershell
python -m pytest -q
```

- [ ] Confirm Kite credentials show only `PRESENT` or `MISSING`. Never print their values.
- [ ] Confirm the selected real contract is `MCX:GOLD26AUGFUT`.
- [ ] Confirm instrument token is `119445255`.
- [ ] Confirm expiry is `2026-08-05`.
- [ ] Confirm live trading and broker orders remain disabled.
- [ ] Confirm production WhatsApp alerts remain blocked.

## 2. Monday read-only preflight

Run:

```powershell
python -m src.data_collection.kite_monday_preflight --symbols "GOLD-I" --dry-run false
```

Expected result:

- Status: `READY_READ_ONLY` or `READY_WITH_MARKET_NOTE`
- `credential_status: PRESENT`
- Selected contract: `MCX:GOLD26AUGFUT`
- Instrument token: `119445255`
- Expiry: `2026-08-05`
- `safety_flags_ok: true`
- `production_whatsapp_status: BLOCKED`
- `execution_allowed=false`
- `READ ONLY CHECK ONLY. NO ORDERS.`

Do not start the long recording if preflight reports a credential, symbol-resolution, contract, or safety failure.

## 3. Optional short real read-only test

Use this before the full session:

```powershell
python -m src.data_collection.kite_daily_pipeline --symbols "GOLD-I" --duration-seconds 60 --record-depth true --dry-run false
```

Review:

- Recorder tick rows
- Recorder depth rows
- Feature rows generated
- Contract consistency status
- Data Quality Gate status
- Errors and warnings

## 4. Full Monday recording

Seven-hour recording command:

```powershell
python -m src.data_collection.kite_daily_pipeline --symbols "GOLD-I" --duration-seconds 25200 --record-depth true --dry-run false
```

This command is data-only and read-only. It must not place orders.

## 5. During the run

- Keep the laptop powered on and connected to the charger.
- Keep the internet connection stable.
- Do not close the terminal.
- Do not enable trading or broker-order code.
- Do not edit `.env` while recording.
- Do not refresh or replace the Kite token during an active recording.
- Avoid sleep/hibernate until the pipeline exits and writes its final report.
- If the terminal stops unexpectedly, preserve the report and error output before restarting.

## 6. After the run

- [ ] Open the latest pipeline report:

```powershell
Get-Content reports\kite_daily_pipeline\latest_kite_daily_pipeline_report.txt
```

- [ ] Confirm tick rows are greater than zero.
- [ ] Confirm depth rows or a clear quote-only explanation.
- [ ] Confirm feature rows and feature CSV counts match.
- [ ] Confirm contract consistency uses only one real contract.
- [ ] Confirm selected contract is `GOLD26AUGFUT`, token `119445255`, expiry `2026-08-05`.
- [ ] Confirm synthetic/dry-run contracts were ignored.
- [ ] Confirm Data Quality Gate status.
- [ ] Confirm forward validation remains `RESEARCH_ONLY` unless manually reviewed later.
- [ ] Confirm `execution_allowed=false`.
- [ ] Back up the project and recorded data after report review.

Expected reports:

- `reports\kite_daily_pipeline\latest_monday_checklist.txt`
- `reports\kite_daily_pipeline\latest_monday_preflight_report.txt`
- `reports\kite_daily_pipeline\latest_kite_daily_pipeline_report.txt`
- `reports\kite_daily_pipeline\kite_daily_pipeline_runs.csv`
- `reports\forward_validation\latest_forward_validation_summary.txt`

## 7. Failure handling

### Token or credential missing

- Stop before recording.
- Refresh the Kite access token locally.
- Never paste the token into ChatGPT or Codex.
- Run Monday preflight again.

### Symbol-resolution problem

- Do not record under an unresolved or unexpected contract.
- Refresh/check the local MCX instrument cache.
- Confirm the contract, token, and expiry before retrying.

### Quote OK but depth missing

- Data may still be usable as quote-only data.
- Check for `USABLE_QUOTE_ONLY` or `PARTIAL_DATA_KEEP_RECORDING`.
- Continue recording if the market is open and the report has no contract/safety failure.
- Do not invent depth imbalance.

### Zero ticks

- Check whether the market is closed.
- Check internet and token status.
- Check the resolved contract.
- If outside market hours, `MARKET_CLOSED_OR_NO_LIVE_DATA` may be normal.

### Feature rows are zero

- Read the zero-feature reason.
- Run the deterministic feature builder again only after checking input rows.
- Confirm real-only filtering did not leave too few real rows.
- Do not reuse stale feature output.

### Contract mismatch

- Stop research use for that run.
- Confirm `allow-mixed-contracts` remains false.
- Verify the selected real contract and ignored contracts.
- Rebuild features and require one real contract group in the CSV.

### Market closed

- No action may be required.
- Keep the report as evidence of the safe check.
- Retry during market hours.

### Codex/API or execution-credit limit

- This does not mean Kite or the trading project failed.
- Do not bypass the limit or run unreviewed commands.
- Use the commands in this runbook manually from the project folder.
- Preserve reports and resume verification when tooling is available.

## 8. Final safety reminder

- This system is collecting and analyzing data only.
- No real trading is enabled.
- No broker orders are allowed.
- No strategy is approved yet.
- GOLD-I VWAP Rejection Short remains `RESEARCH_ONLY`.
- Manual review is required before any future status change.
