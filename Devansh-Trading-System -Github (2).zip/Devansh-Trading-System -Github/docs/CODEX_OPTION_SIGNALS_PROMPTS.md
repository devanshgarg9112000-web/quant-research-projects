# Codex Prompts — Use Sparingly

The option-signal subsystem has already been implemented offline in this patch. Do not spend Codex quota recreating it. Use Prompt 1 once to review/integrate the patch in the user's local repository. Use Prompt 2 tomorrow only if live Kite behavior exposes a concrete defect.

## Prompt 1 — One-time repository verification

```text
You are working inside my existing Devansh-Trading-System repository. A new isolated `src/option_signals/` subsystem and related config/tests/docs have already been added. Do NOT redesign or rewrite the repository.

Your job is a strict integration/safety review and only necessary fixes.

Read the existing repository architecture and every newly added option-signals file before editing. Preserve all existing working behavior and all existing safety gates.

Non-negotiable safety constraints:
1. This is SIGNAL-ONLY / MANUAL EXECUTION ONLY.
2. Do not implement, call, enable, expose, or route to any broker `place_order` function.
3. Do not modify `KiteBroker.place_order()` to make it executable.
4. Do not enable global live trading.
5. Do not change legacy `allow_naked_options: false` or weaken the existing global risk engine.
6. Do not print/read out secret values from `.env`, `.tokens`, access tokens, API secret, Telegram bot token, or chat ID. You may check only presence/missing state.
7. Do not change frozen strategy parameters to make tests pass.

Frozen Strategy A — CAS Router:
- NIFTY Monday/Tuesday/Friday.
- Signal window 09:30–14:00 IST.
- Closed 1-minute spot bars only.
- 5-minute NIFTY return >= +6 bps => SELL ATM PE.
- 5-minute NIFTY return <= -6 bps => SELL ATM CE.
- 7-minute cooldown.
- Resolve immediate weekly expiry from actual current Kite instrument master; never weekday arithmetic.
- ATM CE+PE current contracts: calculate each option's 3-minute return using closed bars and average them. Reject CAS NIFTY signal if average > 1% or data is missing.
- SENSEX Wednesday/Thursday.
- 09:16–15:13 IST except 11:00–13:30 inclusive.
- 25-minute failed breakout: high breaks prior 25m high then closes back below => SELL ATM CE; low breaks prior 25m low then closes back above => SELL ATM PE.
- SENSEX cooldown 5 minutes.

Frozen Strategy B — NIFTY Efficiency Trend:
- NIFTY Monday/Tuesday/Friday only.
- 10:00–14:00 IST.
- 15-minute return and 15-minute Efficiency Ratio.
- ER >= 0.70 and absolute 15m move >= 10 bps.
- Positive move => SELL ATM PE; negative move => SELL ATM CE.
- Cooldown 5 minutes.

Common forward-validation rules:
- Immediate weekly expiry only; ATM.
- 3 lots per actionable signal.
- Maximum one open reference position per underlying.
- If both strategies independently agree at the same evaluation, emit ONE 3-lot DOUBLE_CONFIRMATION; no extra lots.
- If they conflict, record conflict and send no trade signal.
- If already positioned, later same-underlying signal is SHADOW only.
- Stop reference = +50% option premium.
- Target reference = -25% option premium.
- Max hold 30 minutes.
- Compulsory exit alert by 15:15 IST.
- Use best bid as sell reference and best ask as buy-to-close reference when Kite depth exists; otherwise LTP.
- Strategies must evaluate completed 1-minute candles only; never the current forming minute.
- Telegram is opt-in and tokens remain environment-only.
- CSV forward ledger must preserve individual strategy intents, entries and exits.

Review specifically for: look-ahead, timezone bugs, duplicate-minute evaluation, holiday-shifted expiry handling, NIFTY NFO vs SENSEX BFO mapping, ATM/common CE-PE strike resolution, live lot size, stale quote handling, same-minute duplicate alerts, cooldown behavior, double-confirmation sizing, conflict behavior, graceful network failures, Telegram deduplication, and any accidental broker execution path.

Run:
- `python -m compileall -q src/option_signals`
- `python -m src.option_signals.cli self-test`
- `python -m src.option_signals.cli preflight` (must not make network calls)
- `pytest -q tests/option_signals`
- `pytest -q`

Make only fixes justified by an identified defect. Add/adjust tests for every fix. Do not perform live market/API calls now unless I explicitly ask.

At the end, report concisely:
- files changed,
- defects found/fixed,
- exact test counts/results,
- confirmation that no order path was added/enabled,
- remaining items that can only be verified in live market.
```

## Prompt 2 — Tomorrow's live defect fixer (only if needed)

```text
We are now validating the already-frozen SIGNAL-ONLY option system during live market. Do not redesign strategies or tune any thresholds.

I will paste one concrete live-market discrepancy/error below. First reproduce/trace it using the existing logs/data and relevant code. Identify whether it is DATA, KITE ADAPTER, CONTRACT RESOLUTION, TIMEZONE/CANDLE, TELEGRAM, or RUNTIME logic. Make the smallest safe fix and add a regression test.

Never implement or call broker order placement. Keep execution_allowed=false/manual execution only. Never print secret values.

Frozen strategy parameters must not change. If the issue cannot be fixed without changing a strategy rule, stop and explain why instead of changing it.

After the fix, run the narrow affected tests and then full `pytest -q`. Report the root cause, exact files changed, tests, and whether the monitor is safe to restart.

LIVE DISCREPANCY/ERROR:
<PASTE EXACT ERROR, TIMESTAMP, EXPECTED VS ACTUAL HERE>
```
