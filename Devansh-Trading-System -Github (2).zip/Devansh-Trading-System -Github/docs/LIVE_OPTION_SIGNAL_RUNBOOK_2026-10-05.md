# Live Option Signal Validation Runbook — Monday, 05 October 2026

## Goal

Validate the new option-signal subsystem against live Zerodha/Kite data without placing broker orders. Monday is a NIFTY strategy day; the SENSEX strategy is not expected to generate signals on Monday.

## Before Market

### 1. Security

The repository archive previously shared for review contained local `.env` / token material. Before deployment, rotate any credential that you consider exposed by that archive. Never paste tokens into source code, screenshots, Codex prompts, or chat messages.

### 2. Refresh the daily Kite access token

```powershell
python -m src.brokers.kite_broker --login
```

Complete the official Zerodha login in the browser, then provide the request token/redirect URL only to the local CLI as designed.

### 3. Read-only Kite health checks

```powershell
python -m src.brokers.kite_broker --test-profile
python -m src.brokers.kite_broker --test-quote --symbols "NSE:NIFTY 50"
```

Expected: valid read-only responses and no order placement.

### 4. Read-only NIFTY contract-resolution check

After the Kite read-only quote check succeeds, run:

```powershell
python -m src.option_signals.cli live-check --underlying NIFTY
```

Expected: current NIFTY spot, actual nearest listed weekly expiry, common ATM CE/PE, live lot size, `execution_allowed=false`, `live_check=PASS`. This makes network calls to Kite but has no order path.

### 5. New subsystem offline checks

```powershell
python -m src.option_signals.cli self-test
python -m src.option_signals.cli preflight
pytest -q tests/option_signals
```

Expected:

- self-test PASS;
- `execution_allowed=false`;
- read credentials PRESENT;
- option-signal tests pass.

### 6. Telegram

Create/configure the Telegram bot separately. Keep the bot token in `.env` only.

First run:

```powershell
python -m src.option_signals.cli telegram-test
```

This is local/dry-run only.

Only when ready for a real harmless test message:

```text
TELEGRAM_ALERTS_ENABLED=true
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

and in `config/option_signals.yaml`:

```yaml
alerts:
  telegram_enabled: true
  telegram_dry_run: false
```

Then:

```powershell
python -m src.option_signals.cli telegram-test --send
```

Do not put the token in a command-line argument.

## During Market

### Phase A — Data-only observation

Start with Telegram still in dry-run/console mode if desired:

```powershell
python -m src.option_signals.cli run --poll-seconds 3
```

Verify on the first few data cycles:

- NIFTY spot data timestamps are IST and only completed minutes are evaluated.
- The same closed minute is not evaluated repeatedly.
- instrument master resolves the actual nearest listed NIFTY weekly expiry;
- ATM strike looks correct against live NIFTY spot;
- CE/PE contracts are NFO NIFTY contracts for the resolved expiry;
- current lot size from the instrument master is used for alert quantity;
- no `place_order` or broker-order message appears.

### Phase B — Alert validation

For each alert, independently compare against Zerodha/Kite UI:

- NIFTY spot;
- option symbol/strike/type;
- expiry;
- bid/LTP entry reference;
- lots and exchange quantity;
- stop and target references;
- signal strategy and reason;
- signal timestamp.

Do **not** alter the strategy just because one alert looks bad. If the calculation differs, capture the data and fix the implementation/data adapter only.

### Phase C — Manual forward validation

If the data and Telegram path are correct, use the alerts for the agreed manual forward-validation process.

Initial rules:

- 3 lots maximum live NIFTY exposure at a time;
- double confirmation does not add lots;
- conflict = no trade;
- second same-underlying signal while positioned = shadow only;
- manual BUY-to-close only on exit;
- all positions out by 15:15.

The software itself must remain read-only.

## Monday Expected Strategy Windows

- CAS NIFTY: 09:30–14:00.
- Efficiency Trend: 10:00–14:00.
- No SENSEX strategy on Monday.

A lack of signals is not a failure. The strategy is allowed to do nothing when thresholds are not met.

## End of Day

Stop with Ctrl+C. Then review:

```text
reports/option_signals/strategy_intents.csv
reports/option_signals/forward_entries.csv
reports/option_signals/forward_exits.csv
```

Check:

- duplicate suppression;
- cooldown behavior;
- CAS option-complex rejections;
- Efficiency-only signals;
- double confirmations;
- shadow signals;
- exit-alert timing;
- actual manual fill vs reference bid/ask;
- Telegram latency.

Do not retune thresholds after one day. Log discrepancies and classify them as DATA, IMPLEMENTATION, EXECUTION, or STRATEGY observations.

## Stop Conditions

Stop the monitor and do not rely on alerts if any of these occur:

- contract resolver selects wrong underlying/expiry/strike;
- timestamps are not clearly IST/closed-minute causal;
- instrument-master schema is unexpectedly different;
- repeated API errors/rate-limit errors make data stale;
- signal duplicates are emitted for the same closed bar;
- option reference quotes are obviously stale/zero;
- any broker order attempt is observed;
- configuration fails the frozen-strategy validation.
