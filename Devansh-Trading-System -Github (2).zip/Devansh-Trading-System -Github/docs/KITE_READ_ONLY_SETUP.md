# Kite read-only setup

This project uses Kite only for read-only market data in Launch 1. It must not place broker orders.

## Safety rules

- Keep `ENABLE_LIVE_TRADING=false`.
- Keep `I_UNDERSTAND_LIVE_TRADING_RISK=false`.
- Keep `execution_allowed=false`.
- Do not paste Kite API keys, API secrets, request tokens, or access tokens into ChatGPT/Codex.
- Do not commit `.env`, token files, screenshots, or logs containing secrets.
- Run dry-run checks first.

## Local `.env` placeholders

Create or update `.env` locally in the project root with placeholders replaced on your own machine only:

```text
KITE_API_KEY=replace_with_your_api_key
KITE_API_SECRET=replace_with_your_api_secret
KITE_ACCESS_TOKEN=replace_with_today_access_token

ENABLE_LIVE_TRADING=false
I_UNDERSTAND_LIVE_TRADING_RISK=false
```

The access token is typically a daily/session token. Refresh it locally when Kite requires it.

## Dry-run first

```powershell
python -m src.data_collection.kite_readonly_check --symbols "GOLD-I" --dry-run true
python -m src.data_collection.kite_live_recorder --symbols "GOLD-I" --duration-seconds 5 --record-depth true --dry-run true
```

Dry-run uses synthetic data and does not require credentials.

## Read-only check after `.env` is set

Only after credentials are configured locally:

```powershell
python -m src.data_collection.kite_readonly_check --symbols "GOLD-I" --dry-run false
```

The check reports only whether credentials are `PRESENT` or `MISSING`; it never prints token values.

## Read-only recorder after `.env` is set

Only after the read-only check succeeds:

```powershell
python -m src.data_collection.kite_live_recorder --symbols "GOLD-I" --duration-seconds 60 --record-depth true --dry-run false
```

This remains paper/manual-signal only. Broker orders are disabled.
